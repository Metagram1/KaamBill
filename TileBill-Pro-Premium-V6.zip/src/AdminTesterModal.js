import React,{useState,useEffect} from 'react';
import {View,ScrollView,Pressable,Platform,TextInput,Modal,ActivityIndicator} from 'react-native';
import {T,I,Button,Field,Select,Card,Badge,s,C} from './ui';
import {api} from './api';
import {money} from './domain.cjs';
import {IS_OFFLINE_TEST_MODE} from './config';

export default function AdminTesterModal({visible,onClose,currentUser,onUserUpdated}){
 const [activeTab,setActiveTab]=useState('quick'); // 'quick' | 'accounts' | 'coupons'
 const [data,setData]=useState(null);
 const [loading,setLoading]=useState(false);
 const [errorMsg,setErrorMsg]=useState('');
 const [successMsg,setSuccessMsg]=useState('');
 const [working,setWorking]=useState(false);

 // Quick Grant form state
 const [targetPhone,setTargetPhone]=useState('');
 const [targetName,setTargetName]=useState('');

 // Accounts filter
 const [search,setSearch]=useState('');

 // Coupon form
 const [showCouponForm,setShowCouponForm]=useState(false);
 const [couponForm,setCouponForm]=useState({code:'',price:'500',maxUses:'5',expires:'',email:''});

 const isAdmin=(
  IS_OFFLINE_TEST_MODE||
  currentUser?.isOfflineTester||
  currentUser?.role==='admin'
 );

 const loadOverview=async()=>{
  if(IS_OFFLINE_TEST_MODE){
   setData({
    users: [currentUser || { id: 'local_tester', name: 'Tester', phone: 'Local Device', access: { type: 'test_access' } }],
    coupons: [],
    orders: [],
    rewards: []
   });
   return;
  }
  setLoading(true);
  setErrorMsg('');
  try{
   const res=await api('/admin/overview');
   setData(res);
  }catch(e){
   setErrorMsg(e.message||'Failed to load admin console');
  }finally{
   setLoading(false);
  }
 };

 useEffect(()=>{
  if(visible&&isAdmin){
   loadOverview();
   setSuccessMsg('');
   setErrorMsg('');
  }
 },[visible]);

 if(!visible) return null;

 if(!isAdmin){
  return (
   <View style={{position:Platform.OS==='web'?'fixed':'absolute',top:0,left:0,right:0,bottom:0,zIndex:99999,backgroundColor:'rgba(0,0,0,0.6)',justifyContent:'center',alignItems:'center',padding:20}}>
    <View style={{backgroundColor:'#FFFFFF',borderRadius:16,padding:24,maxWidth:420,width:'100%',alignItems:'center'}}>
     <View style={{width:52,height:52,borderRadius:26,backgroundColor:'#FEE2E2',alignItems:'center',justifyContent:'center',marginBottom:12}}>
      <I name="lock-closed" size={26} color="#DC2626"/>
     </View>
     <T style={{fontSize:18,fontWeight:'800',color:'#111827',marginBottom:8,textAlign:'center'}}>
      Testing Console
     </T>
     <T style={{fontSize:13,color:'#6B7280',textAlign:'center',marginBottom:18,lineHeight:18}}>
      Testing console is only accessible in offline testing mode or with administrator permissions.
     </T>
     <Button onPress={onClose}>Close</Button>
    </View>
   </View>
  );
 }

 const handleGrant=async(type,phoneOverride,userIdOverride)=>{
  const cleanPhone=String(phoneOverride||targetPhone).replace(/\D/g,'').slice(-10);
  if(!userIdOverride&&cleanPhone.length!==10){
   setErrorMsg('దయచేసి సరైన 10 అంకెల మొబైల్ నంబర్ నమోదు చేయండి / Enter a valid 10-digit mobile number');
   return;
  }
  setWorking(true);
  setErrorMsg('');
  setSuccessMsg('');
  try{
   const payload={type};
   if(userIdOverride){
    payload.userId=userIdOverride;
   }else{
    payload.phone=cleanPhone;
    if(targetName.trim()) payload.name=targetName.trim();
   }
   const res=await api('/admin/grant',payload);
   const label=type==='1year'||type==='paid'||type==='test-paid'
    ?'1-Year Premium (₹1000 Plan / 365 Days)'
    :type==='trial'||type==='3day'
    ?'3-Day Free Trial (72 Hours)'
    :type==='free'
    ?'Lifetime Free Access (VIP)'
    :'Access Revoked (Expired)';
   setSuccessMsg(`✅ ${userIdOverride?'Account':'+91 '+cleanPhone} updated: ${label}`);
   if(!userIdOverride){
    setTargetPhone('');
    setTargetName('');
   }
   await loadOverview();
   if(onUserUpdated) onUserUpdated();
  }catch(e){
   setErrorMsg(e.message||'Grant action failed');
  }finally{
   setWorking(false);
  }
 };

 const handleCreateCoupon=async()=>{
  if(!couponForm.code.trim()){
   setErrorMsg('Coupon code is required');
   return;
  }
  setWorking(true);
  setErrorMsg('');
  try{
   await api('/admin/coupon',couponForm);
   setShowCouponForm(false);
   setCouponForm({code:'',price:'500',maxUses:'5',expires:'',email:''});
   setSuccessMsg('✅ Coupon created successfully!');
   await loadOverview();
  }catch(e){
   setErrorMsg(e.message||'Failed to create coupon');
  }finally{
   setWorking(false);
  }
 };

 const handleToggleCoupon=async(id)=>{
  setWorking(true);
  try{
   await api('/admin/coupon-toggle',{id});
   await loadOverview();
  }catch(e){
   setErrorMsg(e.message||'Failed to toggle coupon');
  }finally{
   setWorking(false);
  }
 };

 const filteredUsers=(data?.users||[]).filter(u=>{
  const q=search.toLowerCase().trim();
  if(!q) return true;
  return (
   (u.name||'').toLowerCase().includes(q)||
   (u.phone||'').includes(q)||
   (u.email||'').toLowerCase().includes(q)
  );
 });

 return (
  <View style={{position:Platform.OS==='web'?'fixed':'absolute',top:0,left:0,right:0,bottom:0,zIndex:99999,backgroundColor:'rgba(0,0,0,0.5)',justifyContent:'flex-end'}}>
   <Pressable style={{flex:1}} onPress={onClose}/>
    <View style={{
     backgroundColor:'#FAF9F6',
     borderTopLeftRadius:24,
     borderTopRightRadius:24,
     maxHeight:'92%',
     width:'100%',
     maxWidth:520,
     alignSelf:'center',
     shadowColor:'#000',
     shadowOffset:{width:0,height:-4},
     shadowOpacity:0.15,
     shadowRadius:12,
     elevation:20
    }}>
     {/* Drag Handle */}
     <View style={{alignItems:'center',paddingTop:10,paddingBottom:4}}>
      <View style={{width:40,height:4,borderRadius:2,backgroundColor:'#D1D5DB'}}/>
     </View>

     {/* Modal Header */}
     <View style={{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingHorizontal:18,paddingVertical:12,borderBottomWidth:1,borderColor:'#E5E7EB'}}>
      <View style={{flexDirection:'row',alignItems:'center',gap:10,flex:1}}>
       <View style={{width:36,height:36,borderRadius:10,backgroundColor:'#FEF3C7',alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:'#FDE68A'}}>
        <I name="shield-checkmark" size={20} color="#D97706"/>
       </View>
       <View style={{flex:1}}>
        <T style={{fontSize:16,fontWeight:'800',color:'#111827'}}>
         Owner Admin & Tester Console
        </T>
        <T style={{fontSize:11.5,color:'#6B7280'}}>
         Admin: 9948112633 · Premium Access Control
        </T>
       </View>
      </View>
      <Pressable onPress={onClose} hitSlop={10} style={{padding:6,borderRadius:8,backgroundColor:'#F3F4F6'}}>
       <I name="close" size={20} color="#374151"/>
      </Pressable>
     </View>

     {/* Tabs */}
     <View style={{flexDirection:'row',paddingHorizontal:16,paddingTop:12,gap:8}}>
      <Pressable
       onPress={()=>{setActiveTab('quick');setErrorMsg('');setSuccessMsg('');}}
       style={{
        flex:1,
        paddingVertical:9,
        borderRadius:10,
        backgroundColor:activeTab==='quick'?'#111827':'#E5E7EB',
        alignItems:'center',
        justifyContent:'center'
       }}
      >
       <T style={{fontSize:12.5,fontWeight:'700',color:activeTab==='quick'?'#FFFFFF':'#374151'}}>
        ⚡️ Quick Grant
       </T>
      </Pressable>
      <Pressable
       onPress={()=>{setActiveTab('accounts');setErrorMsg('');setSuccessMsg('');}}
       style={{
        flex:1,
        paddingVertical:9,
        borderRadius:10,
        backgroundColor:activeTab==='accounts'?'#111827':'#E5E7EB',
        alignItems:'center',
        justifyContent:'center'
       }}
      >
       <T style={{fontSize:12.5,fontWeight:'700',color:activeTab==='accounts'?'#FFFFFF':'#374151'}}>
        👥 Accounts ({data?.users?.length||0})
       </T>
      </Pressable>
      <Pressable
       onPress={()=>{setActiveTab('coupons');setErrorMsg('');setSuccessMsg('');}}
       style={{
        flex:1,
        paddingVertical:9,
        borderRadius:10,
        backgroundColor:activeTab==='coupons'?'#111827':'#E5E7EB',
        alignItems:'center',
        justifyContent:'center'
       }}
      >
       <T style={{fontSize:12.5,fontWeight:'700',color:activeTab==='coupons'?'#FFFFFF':'#374151'}}>
        🎟️ Coupons ({data?.coupons?.length||0})
       </T>
      </Pressable>
     </View>

     {/* Messages */}
     {!!errorMsg&&(
      <View style={{marginHorizontal:16,marginTop:10,padding:10,backgroundColor:'#FEE2E2',borderRadius:8,borderWidth:1,borderColor:'#FCA5A5'}}>
       <T style={{fontSize:12,color:'#B91C1C',fontWeight:'600'}}>{errorMsg}</T>
      </View>
     )}
     {!!successMsg&&(
      <View style={{marginHorizontal:16,marginTop:10,padding:10,backgroundColor:'#DEF7EC',borderRadius:8,borderWidth:1,borderColor:'#84E1BC'}}>
       <T style={{fontSize:12,color:'#03543F',fontWeight:'700'}}>{successMsg}</T>
      </View>
     )}

     {/* Tab Body */}
     <ScrollView style={{padding:16}} contentContainerStyle={{paddingBottom:32}} keyboardShouldPersistTaps="handled">
      {loading&&!data?(
       <View style={{paddingVertical:40,alignItems:'center'}}>
        <ActivityIndicator size="large" color="#D97706"/>
        <T style={{marginTop:12,fontSize:13,color:'#6B7280'}}>Loading accounts data…</T>
       </View>
      ):activeTab==='quick'?(
       <View>
        <Card style={{padding:14,marginBottom:14,backgroundColor:'#FFFFFF',borderColor:'#E5E7EB'}}>
         <T style={{fontSize:14,fontWeight:'800',color:'#111827',marginBottom:4}}>
          Grant Testing Access by Phone Number
         </T>
         <T style={{fontSize:12,color:'#6B7280',marginBottom:12}}>
          ఏదైనా కాంట్రాక్టర్ మొబైల్ నంబర్ ఎంటర్ చేసి 1-క్లిక్‌తో ప్రీమియం లేదా ట్రయల్ యాక్సెస్ ఇవ్వండి. వాళ్ళు ఇంకా యాప్‌లో రిజిస్టర్ అవ్వకపోయినా సరే, ఈ నంబర్‌తో లాగిన్ అవ్వగానే వెంటనే ఫుల్ యాక్సెస్ లభిస్తుంది!
         </T>

         <View style={{marginBottom:10}}>
          <T style={{fontSize:12,fontWeight:'700',color:'#374151',marginBottom:4}}>
           Contractor Mobile Number / మొబైల్ నంబర్ *
          </T>
          <View style={{flexDirection:'row',alignItems:'center',backgroundColor:'#F9FAFB',borderWidth:1.2,borderColor:'#D1D5DB',borderRadius:10,paddingHorizontal:12,height:46}}>
           <T style={{fontSize:14,fontWeight:'700',color:'#6B7280',marginRight:6}}>+91</T>
           <TextInput
            placeholder="9876543210"
            placeholderTextColor="#9CA3AF"
            value={targetPhone}
            onChangeText={v=>setTargetPhone(v.replace(/\D/g,'').slice(0,10))}
            keyboardType="number-pad"
            maxLength={10}
            style={{flex:1,fontSize:15,fontWeight:'700',color:'#111827',outlineStyle:'none'}}
           />
           {targetPhone.length===10&&(
            <I name="checkmark-circle" size={18} color="#10B981"/>
           )}
          </View>
         </View>

         <View style={{marginBottom:14}}>
          <T style={{fontSize:12,fontWeight:'600',color:'#6B7280',marginBottom:4}}>
           Contractor Name (Optional / పేరు)
          </T>
          <TextInput
           placeholder="e.g. Suresh Tiles, Raju Builder"
           placeholderTextColor="#9CA3AF"
           value={targetName}
           onChangeText={setTargetName}
           style={{backgroundColor:'#F9FAFB',borderWidth:1.2,borderColor:'#D1D5DB',borderRadius:10,paddingHorizontal:12,height:44,fontSize:13.5,color:'#111827',outlineStyle:'none'}}
          />
         </View>

         <T style={{fontSize:12,fontWeight:'700',color:'#374151',marginBottom:8}}>
          Select Access Level to Grant:
         </T>

         {/* 4 Grant Action Cards */}
         <View style={{gap:8}}>
          {/* 1. 1-Year Premium Access */}
          <Pressable
           disabled={working||targetPhone.length!==10}
           onPress={()=>handleGrant('1year')}
           style={({pressed})=>[{
            backgroundColor:'#FFFBEB',
            borderWidth:1.5,
            borderColor:'#F59E0B',
            borderRadius:12,
            padding:12,
            flexDirection:'row',
            alignItems:'center',
            gap:10,
            opacity:working||targetPhone.length!==10?0.5:pressed?0.85:1
           }]}
          >
           <View style={{width:38,height:38,borderRadius:10,backgroundColor:'#FDE68A',alignItems:'center',justifyContent:'center'}}>
            <I name="diamond" size={20} color="#B45309"/>
           </View>
           <View style={{flex:1}}>
            <T style={{fontSize:13.5,fontWeight:'800',color:'#92400E'}}>
             Grant 1-Year Premium (365 Days)
            </T>
            <T style={{fontSize:11,color:'#B45309'}}>
             ₹1,000 Plan · Full Unlimited Access Across All 12 Trades
            </T>
           </View>
           <I name="arrow-forward-circle" size={22} color="#D97706"/>
          </Pressable>

          {/* 2. 3-Day Free Trial */}
          <Pressable
           disabled={working||targetPhone.length!==10}
           onPress={()=>handleGrant('3day')}
           style={({pressed})=>[{
            backgroundColor:'#EFF6FF',
            borderWidth:1.2,
            borderColor:'#93C5FD',
            borderRadius:12,
            padding:12,
            flexDirection:'row',
            alignItems:'center',
            gap:10,
            opacity:working||targetPhone.length!==10?0.5:pressed?0.85:1
           }]}
          >
           <View style={{width:38,height:38,borderRadius:10,backgroundColor:'#DBEAFE',alignItems:'center',justifyContent:'center'}}>
            <I name="flash" size={20} color="#1D4ED8"/>
           </View>
           <View style={{flex:1}}>
            <T style={{fontSize:13.5,fontWeight:'800',color:'#1E40AF'}}>
             Grant 3-Day Free Trial (72 Hours)
            </T>
            <T style={{fontSize:11,color:'#3B82F6'}}>
             Quick testing trial · 72 hours complete app experience
            </T>
           </View>
           <I name="arrow-forward-circle" size={22} color="#2563EB"/>
          </Pressable>

          {/* 3. Lifetime Free VIP */}
          <Pressable
           disabled={working||targetPhone.length!==10}
           onPress={()=>handleGrant('free')}
           style={({pressed})=>[{
            backgroundColor:'#ECFDF5',
            borderWidth:1.2,
            borderColor:'#6EE7B7',
            borderRadius:12,
            padding:12,
            flexDirection:'row',
            alignItems:'center',
            gap:10,
            opacity:working||targetPhone.length!==10?0.5:pressed?0.85:1
           }]}
          >
           <View style={{width:38,height:38,borderRadius:10,backgroundColor:'#D1FAE5',alignItems:'center',justifyContent:'center'}}>
            <I name="ribbon" size={20} color="#047857"/>
           </View>
           <View style={{flex:1}}>
            <T style={{fontSize:13.5,fontWeight:'800',color:'#065F46'}}>
             Grant Lifetime Free Access (VIP)
            </T>
            <T style={{fontSize:11,color:'#059669'}}>
             Permanent complimentary access granted by owner
            </T>
           </View>
           <I name="arrow-forward-circle" size={22} color="#10B981"/>
          </Pressable>

          {/* 4. Revoke Access */}
          <Pressable
           disabled={working||targetPhone.length!==10}
           onPress={()=>handleGrant('revoke')}
           style={({pressed})=>[{
            backgroundColor:'#FEF2F2',
            borderWidth:1.2,
            borderColor:'#FCA5A5',
            borderRadius:12,
            padding:12,
            flexDirection:'row',
            alignItems:'center',
            gap:10,
            opacity:working||targetPhone.length!==10?0.5:pressed?0.85:1
           }]}
          >
           <View style={{width:38,height:38,borderRadius:10,backgroundColor:'#FEE2E2',alignItems:'center',justifyContent:'center'}}>
            <I name="lock-closed" size={20} color="#B91C1C"/>
           </View>
           <View style={{flex:1}}>
            <T style={{fontSize:13.5,fontWeight:'800',color:'#991B1B'}}>
             Revoke Access / End Trial
            </T>
            <T style={{fontSize:11,color:'#DC2626'}}>
             Deactivate access · Requires subscription to create new bills
            </T>
           </View>
           <I name="close-circle" size={22} color="#EF4444"/>
          </Pressable>
         </View>
        </Card>

        {/* Overview Stats */}
        <View style={{flexDirection:'row',flexWrap:'wrap',gap:8}}>
         {[
          ['Registered Accounts',data?.users?.length||0],
          ['Active Complimentary',data?.users?.filter(x=>x.access?.type==='free').length||0],
          ['Paid / Test Plans',data?.users?.filter(x=>x.access?.type==='test-paid'||x.access?.type==='paid').length||0],
          ['Trial Accounts',data?.users?.filter(x=>x.access?.type==='trial').length||0]
         ].map(([label,val])=><View key={label} style={{flex:1,minWidth:110,backgroundColor:'#FFFFFF',padding:10,borderRadius:10,borderWidth:1,borderColor:'#E5E7EB'}}>
          <T style={{fontSize:11,color:'#6B7280',fontWeight:'600'}}>{label}</T>
          <T style={{fontSize:18,fontWeight:'800',color:'#111827',marginTop:2}}>{val}</T>
         </View>)}
        </View>
       </View>
      ):activeTab==='accounts'?(
       <View>
        {/* Search */}
        <View style={{flexDirection:'row',alignItems:'center',backgroundColor:'#FFFFFF',borderWidth:1.2,borderColor:'#D1D5DB',borderRadius:10,paddingHorizontal:12,height:44,marginBottom:12}}>
         <I name="search" size={17} color="#6B7280" style={{marginRight:8}}/>
         <TextInput
          placeholder="Search phone number or contractor name…"
          placeholderTextColor="#9CA3AF"
          value={search}
          onChangeText={setSearch}
          style={{flex:1,fontSize:13.5,color:'#111827',outlineStyle:'none'}}
         />
         {!!search&&<Pressable onPress={()=>setSearch('')}><I name="close-circle" size={16} color="#9CA3AF"/></Pressable>}
        </View>

        <T style={{fontSize:12,color:'#6B7280',marginBottom:8,fontWeight:'600'}}>
         Showing {filteredUsers.length} of {data?.users?.length||0} accounts
        </T>

        <View style={{gap:10}}>
         {filteredUsers.map(u=>{
          const isUserAdmin=u.role==='admin'||u.phone==='9948112633';
          const accType=u.access?.type||(u.active?'active':u.trialUsed?'trial-used':'expired');
          const isFree=accType==='free';
          const isPaid=accType==='paid'||accType==='test-paid';
          const isTrial=accType==='trial';

          return (
           <Card key={u.id} style={{padding:12,backgroundColor:'#FFFFFF',borderColor:isUserAdmin?'#F59E0B':'#E5E7EB'}}>
            <View style={{flexDirection:'row',alignItems:'flex-start',justifyContent:'space-between',marginBottom:8}}>
             <View style={{flex:1,marginRight:8}}>
              <View style={{flexDirection:'row',alignItems:'center',gap:6}}>
               <T style={{fontSize:14,fontWeight:'800',color:'#111827'}} numberOfLines={1}>
                {u.name||'Contractor'}
               </T>
               {isUserAdmin&&<Badge tone="yellow">👑 Owner</Badge>}
              </View>
              <T style={{fontSize:12.5,fontWeight:'700',color:'#2563EB',marginTop:2}}>
               {u.phone?`+91 ${u.phone}`:u.email}
              </T>
             </View>
             <Badge tone={isUserAdmin?'yellow':isFree?'green':isPaid?'blue':isTrial?'yellow':'gray'}>
              {isUserAdmin?'Owner VIP':isFree?'Lifetime Free':isPaid?'Paid 365d':isTrial?'Trial 3d':'No Access'}
             </Badge>
            </View>

            {u.access?.expiresAt&&(
             <T style={{fontSize:11,color:'#6B7280',marginBottom:8}}>
              Valid until: {u.access.expiresAt.slice(0,10)}
             </T>
            )}

            {!isUserAdmin&&(
             <View style={{flexDirection:'row',gap:6,flexWrap:'wrap',borderTopWidth:1,borderColor:'#F3F4F6',paddingTop:8}}>
              <Button compact secondary disabled={working} style={{flex:1,minWidth:74}} onPress={()=>handleGrant('1year',null,u.id)}>
               +1 Year
              </Button>
              <Button compact secondary disabled={working} style={{flex:1,minWidth:74}} onPress={()=>handleGrant('3day',null,u.id)}>
               3-Days
              </Button>
              <Button compact secondary disabled={working} style={{flex:1,minWidth:74}} onPress={()=>handleGrant('free',null,u.id)}>
               Free VIP
              </Button>
              <Button compact quiet danger disabled={working} style={{minWidth:65}} onPress={()=>handleGrant('revoke',null,u.id)}>
               Revoke
              </Button>
             </View>
            )}
           </Card>
          );
         })}
        </View>
       </View>
      ):activeTab==='coupons'?(
       <View>
        <View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
         <T style={{fontSize:14,fontWeight:'800',color:'#111827'}}>Custom Price Coupons</T>
         <Button compact icon="add" onPress={()=>setShowCouponForm(!showCouponForm)}>
          {showCouponForm?'Cancel':'New Coupon'}
         </Button>
        </View>

        {showCouponForm&&(
         <Card style={{padding:14,backgroundColor:'#FFFFFF',borderColor:'#D1D5DB',marginBottom:14}}>
          <T style={{fontSize:13.5,fontWeight:'700',marginBottom:10}}>Create Discount / Complimentary Coupon</T>
          <Field label="Coupon Code" placeholder="e.g. SPECIAL500, FREEVIP" value={couponForm.code} onChange={v=>setCouponForm({...couponForm,code:v.toUpperCase()})}/>
          <View style={{flexDirection:'row',gap:10}}>
           <View style={{flex:1}}>
            <Field numeric label="Price (₹0 - 1000)" value={couponForm.price} onChange={v=>setCouponForm({...couponForm,price:v})}/>
           </View>
           <View style={{flex:1}}>
            <Field numeric label="Max Uses" value={couponForm.maxUses} onChange={v=>setCouponForm({...couponForm,maxUses:v})}/>
           </View>
          </View>
          <Field label="Expiry (YYYY-MM-DD)" placeholder="2027-12-31" value={couponForm.expires} onChange={v=>setCouponForm({...couponForm,expires:v})}/>
          <Field label="Assigned Email (Optional)" placeholder="contractor@mail.com" value={couponForm.email} onChange={v=>setCouponForm({...couponForm,email:v})}/>
          <Button disabled={working} onPress={handleCreateCoupon}>Save Coupon</Button>
         </Card>
        )}

        <View style={{gap:8}}>
         {(data?.coupons||[]).map(c=>(
          <Card key={c.id} style={{padding:12,backgroundColor:'#FFFFFF',borderColor:'#E5E7EB'}}>
           <View style={{flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}>
            <View style={{flex:1}}>
             <T style={{fontSize:14,fontWeight:'800',color:'#111827'}}>{c.code}</T>
             <T style={{fontSize:12,color:'#6B7280',marginTop:2}}>
              {money(c.price)}/yr · {c.uses}/{c.maxUses} used · Exp: {c.expires?.slice(0,10)}
             </T>
             {!!c.email&&<T style={{fontSize:11,color:'#2563EB',marginTop:2}}>Reserved for: {c.email}</T>}
            </View>
            <Button compact secondary disabled={working} onPress={()=>handleToggleCoupon(c.id)}>
             {c.active?'Disable':'Enable'}
            </Button>
           </View>
          </Card>
         ))}
         {!data?.coupons?.length&&<T style={{color:'#6B7280',textAlign:'center',paddingVertical:20}}>No custom coupons created yet.</T>}
        </View>
       </View>
      ):null}
     </ScrollView>
    </View>
   </View>
  );
 }
