import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  ScrollView,
  Pressable,
  Image,
  Platform,
  Switch,
  Modal,
  StyleSheet
} from 'react-native';
import { I } from './ui';
import { money, defaultTradeMaterials } from './domain.cjs';
import { getStrings } from './i18n';
import ProductImageModal from './ProductImageModal';

export default function ChooseMaterialsPicker({
  service = 'electrical',
  appLang = 'en',
  customer,
  siteLocation = '',
  catalog = [],
  initialSelected = [],
  onBack,
  onReview,
  onSaveToCatalog,
  onSwitchCustomer,
  notify
}) {
  const t = getStrings(appLang);

  // Search & Category Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [showPrices, setShowPrices] = useState(false);

  // Selected items state: map of id -> { ...material, qty, customRate }
  const [selectedItems, setSelectedItems] = useState(() => {
    const map = {};
    if (Array.isArray(initialSelected) && initialSelected.length > 0) {
      initialSelected.forEach(it => {
        map[it.id] = { ...it, qty: Number(it.qty || 1) };
      });
      return map;
    }
    const defaults = (defaultTradeMaterials || []).filter(m => (!m.service || m.service === service) && m.isFavorite);
    defaults.slice(0, 4).forEach((m, idx) => {
      const q = idx === 0 ? 2 : idx === 1 ? 1 : idx === 2 ? 12 : 6;
      map[m.id] = { ...m, qty: q };
    });
    return map;
  });

  // Photo modal state
  const [photoModalVisible, setPhotoModalVisible] = useState(false);
  const [activePhotoMaterialId, setActivePhotoMaterialId] = useState(null);

  // Add custom material modal state
  const [addModalVisible, setAddModalVisible] = useState(false);
  const [customName, setCustomName] = useState('');
  const [customCategory, setCustomCategory] = useState('Other');
  const [customSpecs, setCustomSpecs] = useState('');
  const [customUnit, setCustomUnit] = useState('pcs');
  const [customRate, setCustomRate] = useState('');
  const [customQty, setCustomQty] = useState('1');
  const [saveToCatalogCheck, setSaveToCatalogCheck] = useState(true);

  // Speech Recognition state
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef(null);

  // Extract trade categories
  const categories = useMemo(() => {
    if (service === 'electrical') {
      return ['All', 'Wires', 'Switches', 'Pipes', 'Other'];
    } else if (service === 'tiles') {
      return ['All', 'Tiles', 'Adhesives', 'Grout', 'Spacers', 'Other'];
    } else if (service === 'plumbing') {
      return ['All', 'Pipes', 'Fittings', 'Valves', 'Other'];
    } else if (service === 'painting') {
      return ['All', 'Putty', 'Primer', 'Paint', 'Tools', 'Other'];
    }
    return ['All', 'General', 'Other'];
  }, [service]);

  // Combined materials list: catalog materials + newly added custom items
  const allMaterials = useMemo(() => {
    let list = Array.isArray(catalog) && catalog.length > 0 ? [...catalog] : (defaultTradeMaterials || []).filter(m => !m.service || m.service === service);
    if (list.length === 0) {
      list = (defaultTradeMaterials || []).filter(m => m.service === 'electrical');
    }
    // Include any selected items that might not be in catalog
    Object.values(selectedItems).forEach(sel => {
      if (!list.some(m => m.id === sel.id)) {
        list.push(sel);
      }
    });
    return list;
  }, [catalog, selectedItems, service]);

  // Filtered materials
  const filteredMaterials = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    return allMaterials.filter(m => {
      const matchCat = selectedCategory === 'All' || m.category === selectedCategory;
      if (!matchCat) return false;
      if (!query) return true;
      const name = (m.name || '').toLowerCase();
      const teName = (m.teName || '').toLowerCase();
      const hiName = (m.hiName || '').toLowerCase();
      const specs = (m.specs || '').toLowerCase();
      const brand = (m.brand || '').toLowerCase();
      return (
        name.includes(query) ||
        teName.includes(query) ||
        hiName.includes(query) ||
        specs.includes(query) ||
        brand.includes(query)
      );
    });
  }, [allMaterials, selectedCategory, searchQuery]);

  // Selected count & estimated total
  const selectedList = useMemo(() => {
    return Object.values(selectedItems).filter(it => Number(it.qty || 0) > 0);
  }, [selectedItems]);

  const totalSelectedCount = selectedList.length;

  const estimatedTotalBudget = useMemo(() => {
    return selectedList.reduce((sum, it) => {
      const r = Number(it.customRate ?? it.defaultRate ?? it.rate ?? 0);
      return sum + Number(it.qty || 0) * r;
    }, 0);
  }, [selectedList]);

  // Stepper handlers
  const handleQtyChange = (material, delta) => {
    setSelectedItems(prev => {
      const current = prev[material.id]?.qty || 0;
      const nextQty = Math.max(0, current + delta);
      if (nextQty === 0) {
        const next = { ...prev };
        delete next[material.id];
        return next;
      }
      return {
        ...prev,
        [material.id]: {
          ...material,
          qty: nextQty,
          rate: material.defaultRate || material.rate || 0
        }
      };
    });
  };

  const handleSetExactQty = (material, textVal) => {
    const parsed = parseInt(textVal.replace(/[^0-9]/g, ''), 10) || 0;
    setSelectedItems(prev => {
      if (parsed <= 0) {
        const next = { ...prev };
        delete next[material.id];
        return next;
      }
      return {
        ...prev,
        [material.id]: {
          ...material,
          qty: parsed,
          rate: material.defaultRate || material.rate || 0
        }
      };
    });
  };

  // Photo modal open
  const handleOpenPhotoModal = materialId => {
    setActivePhotoMaterialId(materialId);
    setPhotoModalVisible(true);
  };

  // Photo modal save
  const handleSavePhoto = imageDataUrl => {
    if (!activePhotoMaterialId) return;
    setSelectedItems(prev => {
      if (!prev[activePhotoMaterialId]) return prev;
      return {
        ...prev,
        [activePhotoMaterialId]: {
          ...prev[activePhotoMaterialId],
          imageUri: imageDataUrl
        }
      };
    });
    if (onSaveToCatalog) {
      const itemToUpdate = allMaterials.find(m => m.id === activePhotoMaterialId);
      if (itemToUpdate) {
        onSaveToCatalog({ ...itemToUpdate, imageUri: imageDataUrl }, true);
      }
    }
    if (notify) {
      notify(appLang === 'te' ? 'ఫోటో సేవ్ చేయబడింది' : appLang === 'hi' ? 'फोटो सुरक्षित किया गया' : 'Photo saved');
    }
  };

  // Add custom material handler
  const handleAddCustomMaterial = () => {
    const trimmedName = customName.trim();
    if (!trimmedName) {
      alert(appLang === 'te' ? 'దయచేసి మెటీరియల్ పేరు నమోదు చేయండి' : appLang === 'hi' ? 'कृपया सामग्री का नाम दर्ज करें' : 'Please enter material name');
      return;
    }
    const newId = 'mat-cust-' + Date.now().toString(36);
    const parsedQty = Math.max(1, parseInt(customQty || '1', 10) || 1);
    const parsedRate = Math.max(0, parseFloat(customRate || '0') || 0);

    const newMaterial = {
      id: newId,
      service,
      name: trimmedName,
      category: customCategory,
      specs: customSpecs.trim(),
      unit: customUnit.trim() || 'pcs',
      defaultRate: parsedRate,
      rate: parsedRate,
      qty: parsedQty,
      isCustom: true
    };

    // Add to selected items
    setSelectedItems(prev => ({
      ...prev,
      [newId]: newMaterial
    }));

    // Optionally save to contractor reusable catalog
    if (saveToCatalogCheck && onSaveToCatalog) {
      onSaveToCatalog(newMaterial, false);
    }

    setAddModalVisible(false);
    setCustomName('');
    setCustomSpecs('');
    setCustomRate('');
    setCustomQty('1');

    if (notify) {
      notify(appLang === 'te' ? 'మెటీరియల్ జోడించబడింది' : appLang === 'hi' ? 'सामग्री जोड़ी गई' : 'Material added');
    }
  };

  // Web Speech Recognition
  const handleToggleVoice = () => {
    if (Platform.OS !== 'web' || typeof window === 'undefined') {
      alert('Voice assistance is available in web browser');
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert(appLang === 'te' ? 'మీ బ్రౌజర్ వాయిస్ రికగ్నిషన్‌ను సపోర్ట్ చేయదు' : appLang === 'hi' ? 'आपका ब्राउज़र वॉइस पहचान का समर्थन नहीं करता' : 'Your browser does not support Web Speech Recognition');
      return;
    }

    if (isListening && recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = appLang === 'te' ? 'te-IN' : appLang === 'hi' ? 'hi-IN' : 'en-IN';

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = event => {
        const transcript = event.results?.[0]?.[0]?.transcript || '';
        setIsListening(false);
        if (transcript) {
          setSearchQuery(transcript);
          // Auto match if number found
          const numMatch = transcript.match(/\d+/);
          if (numMatch && notify) {
            notify(`Voice detected: "${transcript}"`);
          }
        }
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch {
      setIsListening(false);
    }
  };

  const activePhotoMaterial = allMaterials.find(m => m.id === activePhotoMaterialId);

  return (
    <View style={styles.container}>
      {/* 1. TOP BAR: Back Arrow • Customer/Site Chip • Trade Badge */}
      <View style={styles.topBar}>
        <Pressable onPress={onBack} style={styles.backButton}>
          <I name="arrow-back" size={20} color="#0F172A" />
        </Pressable>

        <Pressable onPress={onSwitchCustomer} style={styles.customerChip}>
          <Text style={styles.pinIcon}>📍</Text>
          <Text style={styles.customerText} numberOfLines={1}>
            {customer?.name || (siteLocation ? siteLocation : (t.workflowSelectCustomer || 'Select site / customer'))}
          </Text>
          <I name="chevron-down" size={13} color="#475569" />
        </Pressable>

        <View style={styles.tradeBadge}>
          <Text style={styles.tradeText}>
            {service === 'electrical' ? '⚡ ' : service === 'tiles' ? '📐 ' : '🔧 '}
            {service.charAt(0).toUpperCase() + service.slice(1)}
          </Text>
        </View>
      </View>

      <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.scrollContent}>
        {/* 2. HEADER */}
        <View style={styles.headerRow}>
          <Text style={styles.pageTitle}>🛒 {t.workflowChooseMaterialsTitle || 'Choose materials'}</Text>
        </View>

        {/* 3. SEARCH INPUT WITH MICROPHONE */}
        <View style={styles.searchRow}>
          <View style={styles.searchBox}>
            <I name="search" size={17} color="#64748B" />
            <TextInput
              style={styles.searchInput}
              placeholder={t.workflowSearchOrSpeak || 'Search or speak'}
              placeholderTextColor="#94A3B8"
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
            {!!searchQuery && (
              <Pressable onPress={() => setSearchQuery('')} style={{ padding: 4 }}>
                <I name="close-circle" size={16} color="#94A3B8" />
              </Pressable>
            )}
          </View>

          <Pressable
            style={[styles.micButton, isListening && styles.micButtonListening]}
            onPress={handleToggleVoice}
            accessibilityLabel="Voice search"
          >
            <I name={isListening ? 'radio-button-on' : 'mic'} size={19} color="#0F172A" />
          </Pressable>
        </View>

        {/* 4. VOICE ASSISTANT CALLOUT PILL */}
        <Pressable onPress={handleToggleVoice} style={styles.voiceAssistantPill}>
          <Text style={{ fontSize: 13 }}>🎙️</Text>
          <Text style={styles.voiceAssistantText}>
            {isListening
              ? (appLang === 'te' ? 'వినబడుతోంది… మాట్లాడండి' : appLang === 'hi' ? 'सुन रहे हैं… बोलिए' : 'Listening… speak now')
              : (t.workflowSpeakNameQty || 'Speak a name and quantity')}
          </Text>
        </Pressable>

        {/* 5. CATEGORY FILTER PILLS */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoryScroll}
        >
          {categories.map(cat => {
            const isSelected = selectedCategory === cat;
            return (
              <Pressable
                key={cat}
                onPress={() => setSelectedCategory(cat)}
                style={[styles.catPill, isSelected && styles.catPillSelected]}
              >
                <Text style={[styles.catPillText, isSelected && styles.catPillTextSelected]}>
                  {cat === 'All' ? (t.workflowCatAll || 'All') : cat}
                </Text>
              </Pressable>
            );
          })}
        </ScrollView>

        {/* 6. PRICE OPTIONAL TOGGLE */}
        <View style={styles.priceToggleRow}>
          <View style={{ flex: 1 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
              <Text style={styles.priceToggleTitle}>{t.workflowPriceOptional || 'Price optional'}</Text>
              <I name="information-circle-outline" size={14} color="#64748B" />
            </View>
            <Text style={styles.priceToggleDesc}>
              {t.workflowPriceOptionalDesc || 'Show or hide prices on the materials list'}
            </Text>
          </View>
          <Switch
            value={showPrices}
            onValueChange={setShowPrices}
            trackColor={{ false: '#E2E8F0', true: '#FEF08A' }}
            thumbColor={showPrices ? '#CA8A04' : '#FFFFFF'}
          />
        </View>

        {/* 7. MATERIAL ITEMS LIST */}
        <View style={styles.materialsList}>
          {filteredMaterials.map(mat => {
            const currentQty = selectedItems[mat.id]?.qty || 0;
            const isChosen = currentQty > 0;
            const rate = Number(mat.defaultRate || mat.rate || 0);

            return (
              <View
                key={mat.id}
                style={[styles.materialCard, isChosen && styles.materialCardChosen]}
              >
                {/* Thumbnail with Camera Badge */}
                <Pressable
                  onPress={() => handleOpenPhotoModal(mat.id)}
                  style={styles.thumbnailWrapper}
                  accessibilityLabel="Change material photo"
                >
                  {mat.imageUri ? (
                    <Image source={{ uri: mat.imageUri }} style={styles.thumbImage} resizeMode="cover" />
                  ) : (
                    <View style={styles.thumbFallback}>
                      <I
                        name={
                          mat.category === 'Wires'
                            ? 'flash-outline'
                            : mat.category === 'Switches'
                            ? 'toggle-outline'
                            : mat.category === 'Pipes'
                            ? 'git-commit-outline'
                            : 'cube-outline'
                        }
                        size={22}
                        color="#475569"
                      />
                    </View>
                  )}
                  {/* Camera overlay badge */}
                  <View style={styles.cameraBadge}>
                    <I name="camera" size={10} color="#FFFFFF" />
                  </View>
                </Pressable>

                {/* Info */}
                <View style={styles.cardInfo}>
                  <Text style={styles.cardTitle} numberOfLines={1}>
                    {appLang === 'te' && mat.teName ? mat.teName : appLang === 'hi' && mat.hiName ? mat.hiName : mat.name}
                  </Text>
                  {!!mat.specs && (
                    <Text style={styles.cardSpecs} numberOfLines={1}>
                      {mat.specs}
                    </Text>
                  )}
                  {showPrices && rate > 0 && (
                    <Text style={styles.priceTag}>
                      {money(rate)} <Text style={{ fontSize: 10, color: '#64748B' }}>/ {mat.unit || 'pcs'}</Text>
                    </Text>
                  )}
                </View>

                {/* Stepper Control: [ - ] [ qty ] [ + ] unit */}
                <View style={styles.stepperContainer}>
                  <Pressable
                    style={[styles.stepBtn, currentQty === 0 && styles.stepBtnDisabled]}
                    onPress={() => handleQtyChange(mat, -1)}
                    disabled={currentQty === 0}
                  >
                    <I name="remove" size={14} color={currentQty === 0 ? '#94A3B8' : '#0F172A'} />
                  </Pressable>

                  <TextInput
                    style={styles.qtyInput}
                    keyboardType="number-pad"
                    value={String(currentQty)}
                    onChangeText={v => handleSetExactQty(mat, v)}
                  />

                  <Pressable
                    style={styles.stepBtn}
                    onPress={() => handleQtyChange(mat, 1)}
                  >
                    <I name="add" size={14} color="#0F172A" />
                  </Pressable>

                  <Text style={styles.unitText}>{mat.unit || 'pcs'}</Text>
                </View>
              </View>
            );
          })}

          {filteredMaterials.length === 0 && (
            <View style={styles.emptyState}>
              <Text style={{ fontSize: 24, marginBottom: 6 }}>🔍</Text>
              <Text style={styles.emptyStateText}>
                {appLang === 'te' ? 'మెటీరియల్స్ ఏవీ కనుగొనబడలేదు' : appLang === 'hi' ? 'कोई सामग्री नहीं मिली' : 'No materials found matching search'}
              </Text>
            </View>
          )}
        </View>

        {/* 8. + ADD OTHER MATERIAL BUTTON */}
        <Pressable
          style={styles.addOtherBtn}
          onPress={() => setAddModalVisible(true)}
        >
          <I name="add-circle-outline" size={18} color="#0F172A" />
          <Text style={styles.addOtherBtnText}>{t.workflowAddOtherMaterial || '+ Add other material'}</Text>
        </Pressable>

        {/* 9. BOTTOM ACTION BAR (IN-FLOW, MATCHING SCREEN 1 & SPEC) */}
        <View style={styles.actionBar}>
          <View style={styles.footerSummary}>
            <Text style={styles.footerCount}>
              {totalSelectedCount} {appLang === 'te' ? 'రకాలు ఎంపికయ్యాయి' : appLang === 'hi' ? 'सामग्री चुनी गई' : 'materials selected'}
            </Text>
            {showPrices && estimatedTotalBudget > 0 && (
              <Text style={styles.footerBudget}>
                Est. {money(estimatedTotalBudget)}
              </Text>
            )}
          </View>

          <Pressable
            testID="review-materials-btn"
            accessibilityRole="button"
            accessibilityLabel={(t.workflowReviewMaterials || 'Review {count} materials →').replace('{count}', totalSelectedCount)}
            style={[styles.reviewBtn, totalSelectedCount === 0 && styles.reviewBtnDisabled]}
            disabled={totalSelectedCount === 0}
            onPress={() => {
              if (totalSelectedCount === 0) {
                alert(t.workflowNoMaterialsSelected || 'Select at least one material');
                return;
              }
              if (onReview) onReview(selectedList, showPrices);
            }}
          >
            <Text style={styles.reviewBtnText}>
              {(t.workflowReviewMaterials || 'Review {count} materials →').replace('{count}', totalSelectedCount)}
            </Text>
          </Pressable>
        </View>

        <View style={{ height: 30 }} />
      </ScrollView>

      {/* PRODUCT IMAGE MODAL */}
      <ProductImageModal
        visible={photoModalVisible}
        initialImage={activePhotoMaterial?.imageUri || ''}
        title={activePhotoMaterial?.name || ''}
        appLang={appLang}
        onSave={handleSavePhoto}
        onClose={() => setPhotoModalVisible(false)}
      />

      {/* ADD OTHER MATERIAL BOTTOM SHEET MODAL */}
      <Modal
        visible={addModalVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setAddModalVisible(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setAddModalVisible(false)}>
          <Pressable style={styles.addSheetCard} onPress={e => e.stopPropagation()}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{t.workflowAddOtherMaterial || '+ Add other material'}</Text>
              <Pressable onPress={() => setAddModalVisible(false)}>
                <I name="close" size={20} color="#64748B" />
              </Pressable>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              {/* Material Name */}
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>{appLang === 'te' ? 'మెటీరియల్ పేరు' : appLang === 'hi' ? 'सामग्री का नाम' : 'Material Name'} *</Text>
                <TextInput
                  style={styles.textInput}
                  placeholder="e.g. 2-Way Modular Switch"
                  placeholderTextColor="#94A3B8"
                  value={customName}
                  onChangeText={setCustomName}
                />
              </View>

              {/* Category Selector */}
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>{appLang === 'te' ? 'విభాగం' : appLang === 'hi' ? 'श्रेणी' : 'Category'}</Text>
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
                  {categories.filter(c => c !== 'All').map(c => (
                    <Pressable
                      key={c}
                      onPress={() => setCustomCategory(c)}
                      style={[styles.smallChip, customCategory === c && styles.smallChipSelected]}
                    >
                      <Text style={[styles.smallChipText, customCategory === c && styles.smallChipTextSelected]}>
                        {c}
                      </Text>
                    </Pressable>
                  ))}
                </View>
              </View>

              {/* Specifications / Brand */}
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>{appLang === 'te' ? 'స్పెసిఫికేషన్ / బ్రాండ్' : appLang === 'hi' ? 'विनिर्देश / ब्रांड' : 'Specification / Brand'}</Text>
                <TextInput
                  style={styles.textInput}
                  placeholder="e.g. Anchor Roma • White"
                  placeholderTextColor="#94A3B8"
                  value={customSpecs}
                  onChangeText={setCustomSpecs}
                />
              </View>

              {/* Quantity & Unit Row */}
              <View style={{ flexDirection: 'row', gap: 10 }}>
                <View style={[styles.inputGroup, { flex: 1 }]}>
                  <Text style={styles.inputLabel}>{appLang === 'te' ? 'పరిమాణం' : appLang === 'hi' ? 'मात्रा' : 'Quantity'}</Text>
                  <TextInput
                    style={styles.textInput}
                    keyboardType="number-pad"
                    value={customQty}
                    onChangeText={setCustomQty}
                  />
                </View>

                <View style={[styles.inputGroup, { flex: 1 }]}>
                  <Text style={styles.inputLabel}>{appLang === 'te' ? 'యూనిట్' : appLang === 'hi' ? 'इकाई' : 'Unit'}</Text>
                  <TextInput
                    style={styles.textInput}
                    placeholder="pcs / roll / m"
                    placeholderTextColor="#94A3B8"
                    value={customUnit}
                    onChangeText={setCustomUnit}
                  />
                </View>
              </View>

              {/* Optional Rate */}
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>{appLang === 'te' ? 'అంచనా ధర (ఐచ్ఛికం)' : appLang === 'hi' ? 'अनुमानित दर (वैकल्पिक)' : 'Estimated Rate (Optional)'}</Text>
                <TextInput
                  style={styles.textInput}
                  keyboardType="decimal-pad"
                  placeholder="₹ 0"
                  placeholderTextColor="#94A3B8"
                  value={customRate}
                  onChangeText={setCustomRate}
                />
              </View>

              {/* Checkbox: Save to My Materials */}
              <Pressable
                onPress={() => setSaveToCatalogCheck(!saveToCatalogCheck)}
                style={styles.checkboxRow}
              >
                <View style={[styles.checkboxBox, saveToCatalogCheck && styles.checkboxBoxChecked]}>
                  {saveToCatalogCheck && <I name="checkmark" size={13} color="#0F172A" />}
                </View>
                <Text style={styles.checkboxLabel}>
                  {t.workflowSaveToMyMaterials || 'Save to My Materials catalog'}
                </Text>
              </Pressable>

              <View style={{ height: 12 }} />
            </ScrollView>

            <View style={{ flexDirection: 'row', gap: 10, marginTop: 8 }}>
              <Pressable style={styles.cancelBtn} onPress={() => setAddModalVisible(false)}>
                <Text style={styles.cancelBtnText}>{t.workflowCancel || 'Cancel'}</Text>
              </Pressable>

              <Pressable style={styles.submitBtn} onPress={handleAddCustomMaterial}>
                <Text style={styles.submitBtnText}>{appLang === 'te' ? 'జోడించండి' : appLang === 'hi' ? 'जोड़ें' : 'Add Material'}</Text>
              </Pressable>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FCF9F6'
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 14,
    paddingVertical: 10,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9'
  },
  backButton: {
    padding: 6,
    borderRadius: 8
  },
  customerChip: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#F8FAFC',
    borderRadius: 16,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: '#E2E8F0'
  },
  pinIcon: {
    fontSize: 12
  },
  customerText: {
    flex: 1,
    fontSize: 12,
    fontWeight: '700',
    color: '#0F172A'
  },
  tradeBadge: {
    backgroundColor: '#FEF9C3',
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: '#FEF08A'
  },
  tradeText: {
    fontSize: 11,
    fontWeight: '800',
    color: '#854D0E'
  },
  scrollContent: {
    padding: 14
  },
  headerRow: {
    marginBottom: 10
  },
  pageTitle: {
    fontSize: 18,
    fontWeight: '900',
    color: '#0F172A',
    letterSpacing: -0.3
  },
  searchRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 8
  },
  searchBox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: '#E2E8F0'
  },
  searchInput: {
    flex: 1,
    fontSize: 13.5,
    color: '#0F172A',
    fontWeight: '600',
    padding: 0
  },
  micButton: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: '#FFD500',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2
  },
  micButtonListening: {
    backgroundColor: '#EF4444'
  },
  voiceAssistantPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#FEF9E7',
    borderWidth: 1,
    borderColor: '#FEF08A',
    borderRadius: 12,
    paddingVertical: 7,
    paddingHorizontal: 12,
    marginBottom: 12
  },
  voiceAssistantText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#854D0E'
  },
  categoryScroll: {
    gap: 6,
    paddingBottom: 10
  },
  catPill: {
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 18,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E2E8F0'
  },
  catPillSelected: {
    backgroundColor: '#1E293B',
    borderColor: '#1E293B'
  },
  catPillText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#475569'
  },
  catPillTextSelected: {
    color: '#FFD500'
  },
  priceToggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: '#F1F5F9',
    marginBottom: 12
  },
  priceToggleTitle: {
    fontSize: 12.5,
    fontWeight: '700',
    color: '#0F172A'
  },
  priceToggleDesc: {
    fontSize: 10.5,
    color: '#64748B',
    marginTop: 1
  },
  materialsList: {
    gap: 8,
    marginBottom: 14
  },
  materialCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    padding: 10,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.03,
    shadowRadius: 3,
    elevation: 1
  },
  materialCardChosen: {
    borderColor: '#FACC15',
    backgroundColor: '#FFFDF5'
  },
  thumbnailWrapper: {
    position: 'relative',
    width: 44,
    height: 44,
    borderRadius: 10,
    backgroundColor: '#F1F5F9',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden'
  },
  thumbImage: {
    width: '100%',
    height: '100%'
  },
  thumbFallback: {
    alignItems: 'center',
    justifyContent: 'center'
  },
  cameraBadge: {
    position: 'absolute',
    bottom: 2,
    right: 2,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    alignItems: 'center',
    justifyContent: 'center'
  },
  cardInfo: {
    flex: 1,
    paddingHorizontal: 10,
    minWidth: 0
  },
  cardTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: '#0F172A'
  },
  cardSpecs: {
    fontSize: 11,
    color: '#64748B',
    marginTop: 1
  },
  priceTag: {
    fontSize: 11.5,
    fontWeight: '700',
    color: '#0F172A',
    marginTop: 2
  },
  stepperContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4
  },
  stepBtn: {
    width: 28,
    height: 28,
    borderRadius: 8,
    backgroundColor: '#F1F5F9',
    borderWidth: 1,
    borderColor: '#CBD5E1',
    alignItems: 'center',
    justifyContent: 'center'
  },
  stepBtnDisabled: {
    opacity: 0.4
  },
  qtyInput: {
    width: 32,
    textAlign: 'center',
    fontSize: 13.5,
    fontWeight: '800',
    color: '#0F172A',
    padding: 0
  },
  unitText: {
    fontSize: 10.5,
    fontWeight: '600',
    color: '#64748B',
    width: 32
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 28
  },
  emptyStateText: {
    fontSize: 12.5,
    color: '#64748B',
    fontWeight: '600'
  },
  addOtherBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    borderWidth: 1.2,
    borderColor: '#CBD5E1',
    borderStyle: 'dashed',
    paddingVertical: 11
  },
  addOtherBtnText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#0F172A'
  },
  actionBar: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    borderWidth: 1.2,
    borderColor: '#E2E8F0',
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
    marginTop: 14,
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 3
  },
  footerSummary: {
    flex: 1
  },
  footerCount: {
    fontSize: 13,
    fontWeight: '800',
    color: '#0F172A'
  },
  footerBudget: {
    fontSize: 11,
    fontWeight: '700',
    color: '#854D0E',
    marginTop: 1
  },
  reviewBtn: {
    backgroundColor: '#FFD500',
    borderRadius: 12,
    paddingVertical: 11,
    paddingHorizontal: 18,
    alignItems: 'center',
    justifyContent: 'center'
  },
  reviewBtnDisabled: {
    backgroundColor: '#E2E8F0',
    opacity: 0.6
  },
  reviewBtnText: {
    fontSize: 13.5,
    fontWeight: '900',
    color: '#0F172A'
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(15, 23, 42, 0.6)',
    justifyContent: 'flex-end'
  },
  addSheetCard: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 18,
    maxHeight: '85%'
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12
  },
  modalTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: '#0F172A'
  },
  inputGroup: {
    marginBottom: 10
  },
  inputLabel: {
    fontSize: 12,
    fontWeight: '700',
    color: '#334155',
    marginBottom: 4
  },
  textInput: {
    backgroundColor: '#F8FAFC',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    paddingHorizontal: 10,
    paddingVertical: 8,
    fontSize: 13,
    color: '#0F172A'
  },
  smallChip: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
    backgroundColor: '#F1F5F9',
    borderWidth: 1,
    borderColor: '#E2E8F0'
  },
  smallChipSelected: {
    backgroundColor: '#FEF08A',
    borderColor: '#EAB308'
  },
  smallChipText: {
    fontSize: 11.5,
    fontWeight: '600',
    color: '#475569'
  },
  smallChipTextSelected: {
    color: '#854D0E',
    fontWeight: '800'
  },
  checkboxRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 4,
    marginBottom: 8
  },
  checkboxBox: {
    width: 18,
    height: 18,
    borderRadius: 5,
    borderWidth: 1.5,
    borderColor: '#CBD5E1',
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center'
  },
  checkboxBoxChecked: {
    backgroundColor: '#FFD500',
    borderColor: '#EAB308'
  },
  checkboxLabel: {
    fontSize: 12,
    fontWeight: '700',
    color: '#0F172A'
  },
  cancelBtn: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#CBD5E1',
    alignItems: 'center',
    justifyContent: 'center'
  },
  cancelBtnText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#475569'
  },
  submitBtn: {
    flex: 1.5,
    paddingVertical: 10,
    borderRadius: 10,
    backgroundColor: '#FFD500',
    alignItems: 'center',
    justifyContent: 'center'
  },
  submitBtnText: {
    fontSize: 13,
    fontWeight: '900',
    color: '#0F172A'
  }
});
