import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  Animated,
  Modal,
  Platform,
  ScrollView,
  KeyboardAvoidingView,
  useWindowDimensions
} from 'react-native';
import { I, T } from './ui';
import { getStrings } from './i18n';

export default function CustomerModal({
  visible = true,
  initial = {},
  w,
  service,
  onClose,
  onSave,
  busy = false,
  appLang = 'te'
}) {
  const t = getStrings(appLang);
  const { width } = useWindowDimensions();
  const slideAnim = useRef(new Animated.Value(400)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [name, setName] = useState(initial?.name || '');
  const [phone, setPhone] = useState(initial?.phone ? String(initial.phone).replace('+91', '').trim() : '');
  const [address, setAddress] = useState(initial?.address || '');
  const [siteLocation, setSiteLocation] = useState(initial?.siteLocation || '');
  const [notes, setNotes] = useState(initial?.notes || '');
  const [notesOpen, setNotesOpen] = useState(Boolean(initial?.notes));
  const [tried, setTried] = useState(false);

  useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 200,
          useNativeDriver: true
        }),
        Animated.spring(slideAnim, {
          toValue: 0,
          friction: 8,
          tension: 65,
          useNativeDriver: true
        })
      ]).start();
    }
  }, [visible]);

  const handleClose = () => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 0,
        duration: 150,
        useNativeDriver: true
      }),
      Animated.timing(slideAnim, {
        toValue: 400,
        duration: 200,
        useNativeDriver: true
      })
    ]).start(() => {
      onClose?.();
    });
  };

  const handleSave = () => {
    setTried(true);
    const cleanName = name.trim();
    if (!cleanName) {
      return;
    }
    const cleanPhone = phone.trim();
    const payload = {
      id: initial?.id,
      name: cleanName,
      phone: cleanPhone ? (cleanPhone.startsWith('+91') ? cleanPhone : '+91 ' + cleanPhone) : '',
      address: address.trim(),
      siteLocation: siteLocation.trim(),
      notes: notes.trim()
    };
    onSave?.(payload);
  };

  if (!visible) return null;

  return (
    <Modal
      transparent
      visible={visible}
      animationType="none"
      onRequestClose={handleClose}
    >
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={{ flex: 1 }}
      >
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Close customer details"
          onPress={handleClose}
          style={{
            flex: 1,
            backgroundColor: 'rgba(0,0,0,0.5)',
            justifyContent: 'flex-end',
            alignItems: 'center'
          }}
        >
          <Animated.View
            style={{
              opacity: fadeAnim,
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0
            }}
          />

          <Pressable
            onPress={e => e.stopPropagation()}
            style={{
              width: '100%',
              maxWidth: 480,
              backgroundColor: '#FFFFFF',
              borderTopLeftRadius: 28,
              borderTopRightRadius: 28,
              shadowColor: '#000',
              shadowOffset: { width: 0, height: -4 },
              shadowOpacity: 0.15,
              shadowRadius: 12,
              elevation: 20,
              maxHeight: '92%'
            }}
          >
            <Animated.View
              style={{
                transform: [{ translateY: slideAnim }],
                paddingHorizontal: 20,
                paddingTop: 10,
                paddingBottom: Platform.OS === 'ios' ? 28 : 16
              }}
            >
              {/* Drag Handle */}
              <View
                style={{
                  width: 44,
                  height: 4.5,
                  borderRadius: 2.5,
                  backgroundColor: '#9CA3AF',
                  alignSelf: 'center',
                  marginBottom: 14
                }}
              />

              {/* Sheet Header */}
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  marginBottom: 16
                }}
              >
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1, minWidth: 0 }}>
                  <View
                    style={{
                      width: 44,
                      height: 44,
                      borderRadius: 22,
                      backgroundColor: '#FEF08A',
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderWidth: 1,
                      borderColor: '#FDE047'
                    }}
                  >
                    <I name="person-add" size={22} color="#171817" />
                  </View>
                  <View style={{ flex: 1, minWidth: 0 }}>
                    <T numberOfLines={1} style={{ fontSize: 20, fontWeight: '900', color: '#171817' }}>
                      {t.custModalTitle}
                    </T>
                    <T numberOfLines={1} style={{ fontSize: 13, fontWeight: '500', color: '#667085', marginTop: 1 }}>
                      {t.custModalSubtitle}
                    </T>
                  </View>
                </View>

                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel="Close"
                  onPress={handleClose}
                  style={({ pressed }) => [{
                    width: 34,
                    height: 34,
                    borderRadius: 17,
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: pressed ? '#F3F4F6' : 'transparent'
                  }]}
                >
                  <I name="close" size={22} color="#171817" />
                </Pressable>
              </View>

              <ScrollView
                showsVerticalScrollIndicator={false}
                keyboardShouldPersistTaps="handled"
                contentContainerStyle={{ paddingBottom: 12 }}
              >
                {/* 1. Customer Name (Required) */}
                <View style={{ marginBottom: 14 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 }}>
                    <I name="person" size={15} color="#171817" />
                    <T style={{ fontSize: 13.5, fontWeight: '700', color: '#171817' }}>
                      {t.custNameLabel} <T style={{ color: '#DC2626' }}>*</T>
                    </T>
                  </View>
                  <TextInput
                    value={name}
                    onChangeText={setName}
                    placeholder={appLang === 'te' ? 'కస్టమర్ పేరు' : 'Customer name'}
                    placeholderTextColor="#9CA3AF"
                    style={{
                      backgroundColor: '#FFFFFF',
                      borderWidth: 1.2,
                      borderColor: tried && !name.trim() ? '#EF4444' : '#E5E7EB',
                      borderRadius: 12,
                      paddingHorizontal: 14,
                      paddingVertical: 11,
                      fontSize: 15,
                      fontWeight: '600',
                      color: '#171817'
                    }}
                  />
                  {tried && !name.trim() && (
                    <T style={{ fontSize: 12, color: '#DC2626', marginTop: 4, fontWeight: '500' }}>
                      {t.custNameRequired}
                    </T>
                  )}
                </View>

                {/* 2. Mobile Number */}
                <View style={{ marginBottom: 14 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 }}>
                    <I name="call" size={15} color="#171817" />
                    <T style={{ fontSize: 13.5, fontWeight: '700', color: '#171817' }}>
                      {t.custPhoneLabel}
                    </T>
                  </View>
                  <View
                    style={{
                      flexDirection: 'row',
                      borderWidth: 1.2,
                      borderColor: '#E5E7EB',
                      borderRadius: 12,
                      overflow: 'hidden',
                      backgroundColor: '#FFFFFF'
                    }}
                  >
                    <View
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        gap: 4,
                        paddingHorizontal: 12,
                        backgroundColor: '#F9FAFB',
                        borderRightWidth: 1,
                        borderRightColor: '#E5E7EB'
                      }}
                    >
                      <T style={{ fontSize: 15, fontWeight: '800', color: '#171817' }}>+91</T>
                      <I name="chevron-down" size={13} color="#667085" />
                    </View>
                    <TextInput
                      value={phone}
                      onChangeText={setPhone}
                      keyboardType="phone-pad"
                      placeholder={t.custPhonePlaceholder}
                      placeholderTextColor="#9CA3AF"
                      style={{
                        flex: 1,
                        paddingHorizontal: 14,
                        paddingVertical: 11,
                        fontSize: 15,
                        fontWeight: '600',
                        color: '#171817'
                      }}
                    />
                  </View>
                </View>

                {/* 3. Address */}
                <View style={{ marginBottom: 14 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 }}>
                    <I name="home" size={15} color="#171817" />
                    <T style={{ fontSize: 13.5, fontWeight: '700', color: '#171817' }}>
                      {t.custAddressLabel}
                    </T>
                  </View>
                  <TextInput
                    value={address}
                    onChangeText={setAddress}
                    multiline
                    numberOfLines={3}
                    placeholder={t.custAddressPlaceholder}
                    placeholderTextColor="#9CA3AF"
                    style={{
                      backgroundColor: '#FFFFFF',
                      borderWidth: 1.2,
                      borderColor: '#E5E7EB',
                      borderRadius: 12,
                      paddingHorizontal: 14,
                      paddingVertical: 10,
                      minHeight: 74,
                      textAlignVertical: 'top',
                      fontSize: 14.5,
                      color: '#171817'
                    }}
                  />
                </View>

                {/* 4. Site Location (Optional) */}
                <View style={{ marginBottom: 14 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 }}>
                    <I name="location" size={15} color="#171817" />
                    <T style={{ fontSize: 13.5, fontWeight: '700', color: '#171817' }}>
                      {t.custSiteLocationLabel}
                    </T>
                  </View>
                  <TextInput
                    value={siteLocation}
                    onChangeText={setSiteLocation}
                    placeholder={appLang === 'te' ? 'కైలాసపురం' : 'e.g. Kailasapuram'}
                    placeholderTextColor="#9CA3AF"
                    style={{
                      backgroundColor: '#FFFFFF',
                      borderWidth: 1.2,
                      borderColor: '#E5E7EB',
                      borderRadius: 12,
                      paddingHorizontal: 14,
                      paddingVertical: 11,
                      fontSize: 15,
                      fontWeight: '600',
                      color: '#171817'
                    }}
                  />
                  <T style={{ fontSize: 12, color: '#667085', marginTop: 4, fontWeight: '500' }}>
                    {t.custSiteLocationHint}
                  </T>
                </View>

                {/* 5. Notes (Optional) Collapsible */}
                <View style={{ marginBottom: 18 }}>
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel={t.custNotesLabel}
                    onPress={() => setNotesOpen(!notesOpen)}
                    style={({ pressed }) => [{
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      borderWidth: 1.2,
                      borderColor: '#E5E7EB',
                      borderRadius: 12,
                      paddingHorizontal: 14,
                      paddingVertical: 12,
                      backgroundColor: pressed ? '#F9FAFB' : '#FFFFFF'
                    }]}
                  >
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                      <I name="document-text-outline" size={18} color="#171817" />
                      <T style={{ fontSize: 14, fontWeight: '700', color: '#171817' }}>
                        {t.custNotesLabel}
                      </T>
                    </View>
                    <I name={notesOpen ? 'chevron-up' : 'chevron-down'} size={18} color="#171817" />
                  </Pressable>

                  {notesOpen && (
                    <TextInput
                      value={notes}
                      onChangeText={setNotes}
                      multiline
                      numberOfLines={3}
                      placeholder={appLang === 'te' ? 'కస్టమర్ గురించి ముఖ్యమైన వివరాలు…' : 'Important notes about the customer…'}
                      placeholderTextColor="#9CA3AF"
                      style={{
                        backgroundColor: '#FFFFFF',
                        borderWidth: 1.2,
                        borderColor: '#E5E7EB',
                        borderRadius: 12,
                        paddingHorizontal: 14,
                        paddingVertical: 10,
                        marginTop: 8,
                        minHeight: 70,
                        textAlignVertical: 'top',
                        fontSize: 14,
                        color: '#171817'
                      }}
                    />
                  )}
                </View>

                {/* 6. Save Customer Button */}
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel={t.custSaveBtn}
                  disabled={busy}
                  onPress={handleSave}
                  style={({ pressed }) => [{
                    backgroundColor: '#FFD500',
                    height: 52,
                    borderRadius: 14,
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: 8,
                    shadowColor: '#000',
                    shadowOffset: { width: 0, height: 2 },
                    shadowOpacity: 0.1,
                    shadowRadius: 4,
                    elevation: 2,
                    opacity: busy ? 0.6 : pressed ? 0.9 : 1
                  }]}
                >
                  <I name="checkmark" size={20} color="#171817" />
                  <T style={{ fontSize: 16.5, fontWeight: '900', color: '#171817' }}>
                    {busy ? (appLang === 'te' ? 'సేవ్ అవుతోంది…' : 'Saving…') : t.custSaveBtn}
                  </T>
                </Pressable>
              </ScrollView>
            </Animated.View>
          </Pressable>
        </Pressable>
      </KeyboardAvoidingView>
    </Modal>
  );
}
