import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  Platform,
  useWindowDimensions
} from 'react-native';
import { I, T, Empty } from './ui';
import { money } from './domain.cjs';
import { getStrings } from './i18n';
import CustomerModal from './CustomerModal';

export function formatTeluguDate(dateStr, lang = 'te') {
  if (!dateStr) return '—';
  try {
    const d = new Date(dateStr);
    if (Number.isNaN(d.getTime())) return dateStr;
    const day = d.getDate();
    const year = d.getFullYear();
    const monthsTe = ['జన', 'ఫిబ్ర', 'మార్చి', 'ఏప్రి', 'మే', 'జూన్', 'జూలై', 'ఆగ', 'సెప్టెం', 'అక్టో', 'నవం', 'డిసెం'];
    const monthsHi = ['जन', 'फ़र', 'मार्च', 'अप्रै', 'मई', 'जून', 'जुला', 'अग', 'सितं', 'अक्टू', 'नव', 'दिसं'];
    const monthsEn = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const mList = lang === 'te' ? monthsTe : lang === 'hi' ? monthsHi : monthsEn;
    return `${day} ${mList[d.getMonth()]} ${year}`;
  } catch {
    return dateStr;
  }
}

export function getCustomerBillMetrics(customer, allDocs = []) {
  const custDocs = allDocs.filter(d => (d.customerId === customer.id || d.customer?.id === customer.id));
  const invoices = custDocs.filter(d => d.kind === 'invoice');
  const quotes = custDocs.filter(d => d.kind === 'quotation');
  const totalBilled = invoices.reduce((s, d) => s + (d.total || 0), 0);
  const totalPaid = invoices.reduce((s, d) => s + (d.paid || 0), 0);
  const due = Math.max(0, invoices.reduce((s, d) => s + Math.max(0, (d.total || 0) - (d.paid || 0)), 0));

  const sortedDocs = [...custDocs].sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  const latestDoc = sortedDocs[0] || null;

  let statusKey = 'none';
  let statusText = 'బిల్లు లేదు';
  let statusTone = 'gray';

  const today = new Date().toISOString().slice(0, 10);
  if (custDocs.length > 0) {
    const hasHold = invoices.some(d => d.status === 'hold' || (d.dueDate && d.dueDate < today && (d.total - (d.paid || 0)) > 0.01));
    if (hasHold) {
      statusKey = 'hold';
      statusText = 'Bill Hold · హోల్డ్ లో ఉంది';
      statusTone = 'red';
    } else if (invoices.length > 0 && due <= 0.01) {
      statusKey = 'passed';
      statusText = 'Bill Passed · క్లియర్ అయింది';
      statusTone = 'green';
    } else {
      statusKey = 'valid';
      statusText = 'Bill Valid · యాక్టివ్ బిల్లు';
      statusTone = 'blue';
    }
  }

  return { custDocs, latestDoc, invoices, quotes, totalBilled, totalPaid, due, statusKey, statusText, statusTone };
}

export default function CustomersPage({
  w,
  service,
  appLang = 'te',
  open,
  setModal,
  save,
  busy,
  onOpenDashboard
}) {
  const t = getStrings(appLang);
  const { width } = useWindowDimensions();

  const [q, setQ] = useState('');
  const [filter, setFilter] = useState('all'); // 'all' | 'due' | 'valid' | 'hold' | 'passed'
  const [statusMenuOpen, setStatusMenuOpen] = useState(false);
  const [modalCustomer, setModalCustomer] = useState(null); // null, 'new', or customer object
  const [activeSiteFilter, setActiveSiteFilter] = useState('');

  const serviceCustomers = w.customers.filter(c => c.service === service || !c.service);

  // Financial aggregates
  const totalDueAll = serviceCustomers.reduce((acc, c) => {
    const m = getCustomerBillMetrics(c, w.documents);
    return acc + m.due;
  }, 0);

  const filtered = serviceCustomers.filter(c => {
    const searchTarget = (
      c.name + ' ' +
      (c.phone || '') + ' ' +
      (c.address || '') + ' ' +
      (c.siteLocation || '') + ' ' +
      (c.notes || '')
    ).toLowerCase();

    const queryTerm = q.trim().toLowerCase();
    if (queryTerm && !searchTarget.includes(queryTerm)) {
      return false;
    }

    if (activeSiteFilter && !(c.siteLocation || '').toLowerCase().includes(activeSiteFilter.toLowerCase())) {
      return false;
    }

    const metrics = getCustomerBillMetrics(c, w.documents);
    if (filter === 'due') {
      return metrics.due > 0.01;
    }
    if (filter === 'valid') {
      return metrics.statusKey === 'valid';
    }
    if (filter === 'hold') {
      return metrics.statusKey === 'hold';
    }
    if (filter === 'passed') {
      return metrics.statusKey === 'passed';
    }
    return true;
  });

  // Check if search query matches any siteLocation
  const matchedSite = activeSiteFilter || (
    q.trim() && serviceCustomers.find(c => (c.siteLocation || '').toLowerCase().includes(q.trim().toLowerCase()))?.siteLocation
  );

  const handleSaveCustomer = async (custData) => {
    const success = await save('customer', custData);
    if (success) {
      setModalCustomer(null);
    }
  };

  return (
    <View style={{ width: '100%' }}>
      {/* 1. Page Title & + Customer Action Button */}
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: 14,
          paddingHorizontal: 2
        }}
      >
        <T style={{ fontSize: 24, fontWeight: '900', color: '#171817' }}>
          {t.custPageTitle}
        </T>

        <Pressable
          accessibilityRole="button"
          accessibilityLabel={t.custAddBtn}
          onPress={() => setModalCustomer('new')}
          style={({ pressed }) => [{
            backgroundColor: '#FFD500',
            borderRadius: 14,
            paddingHorizontal: 16,
            paddingVertical: 10,
            flexDirection: 'row',
            alignItems: 'center',
            gap: 6,
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.1,
            shadowRadius: 4,
            elevation: 2,
            opacity: pressed ? 0.85 : 1
          }]}
        >
          <I name="person-add" size={17} color="#171817" />
          <T style={{ fontSize: 14.5, fontWeight: '900', color: '#171817' }}>
            {t.custAddBtn}
          </T>
        </Pressable>
      </View>

      {/* 2. Top Summary KPI Card (Split 50/50 with Count & Outstanding Balance) */}
      <View
        style={{
          backgroundColor: '#FFFFFF',
          borderRadius: 18,
          borderWidth: 1.2,
          borderColor: '#F1F5F9',
          paddingVertical: 14,
          paddingHorizontal: 16,
          flexDirection: 'row',
          alignItems: 'center',
          marginBottom: 14,
          shadowColor: '#0F172A',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.04,
          shadowRadius: 6,
          elevation: 2
        }}
      >
        {/* Left half: Customers Count */}
        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <View
            style={{
              width: 44,
              height: 44,
              borderRadius: 12,
              backgroundColor: '#FEF3C7',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            <I name="people" size={22} color="#B45309" />
          </View>
          <View>
            <T style={{ fontSize: 12.5, fontWeight: '600', color: '#667085' }}>
              {t.custSummaryCount}
            </T>
            <T style={{ fontSize: 22, fontWeight: '900', color: '#171817', marginTop: 1 }}>
              {serviceCustomers.length}
            </T>
          </View>
        </View>

        {/* Vertical divider */}
        <View style={{ width: 1, height: 38, backgroundColor: '#E2E8F0', marginHorizontal: 12 }} />

        {/* Right half: Outstanding Balance */}
        <View style={{ flex: 1.1, flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <View
            style={{
              width: 44,
              height: 44,
              borderRadius: 12,
              backgroundColor: '#FFEDD5',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            <I name="time" size={22} color="#C2410C" />
          </View>
          <View style={{ flex: 1, minWidth: 0 }}>
            <T numberOfLines={1} style={{ fontSize: 12.5, fontWeight: '600', color: '#C2410C' }}>
              {t.custSummaryDue}
            </T>
            <T numberOfLines={1} style={{ fontSize: 22, fontWeight: '900', color: '#171817', marginTop: 1 }}>
              ₹{totalDueAll.toLocaleString('en-IN')}
            </T>
          </View>
        </View>
      </View>

      {/* 3. Full-width Search Input */}
      <View
        style={{
          backgroundColor: '#FFFFFF',
          borderRadius: 14,
          borderWidth: 1.2,
          borderColor: '#E5E7EB',
          height: 48,
          paddingHorizontal: 14,
          flexDirection: 'row',
          alignItems: 'center',
          gap: 10,
          marginBottom: 10,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 1 },
          shadowOpacity: 0.03,
          shadowRadius: 3,
          elevation: 1
        }}
      >
        <I name="search" size={19} color="#667085" />
        <TextInput
          value={q}
          onChangeText={setQ}
          placeholder={t.custSearchPlaceholder}
          placeholderTextColor="#9CA3AF"
          style={{
            flex: 1,
            fontSize: 14.5,
            color: '#171817',
            fontWeight: '500'
          }}
        />
        {!!q && (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Clear search"
            onPress={() => { setQ(''); setActiveSiteFilter(''); }}
            style={{ padding: 4 }}
          >
            <I name="close-circle" size={18} color="#9CA3AF" />
          </Pressable>
        )}
      </View>

      {/* 4. Active Site Chip & Result Count (Matching Mockup exactly e.g. 📍 కైలాసపురం ✕   1 కస్టమర్) */}
      {(matchedSite || q.trim() || activeSiteFilter) && (
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: 12,
            paddingHorizontal: 2
          }}
        >
          {matchedSite ? (
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={`Clear filter ${matchedSite}`}
              onPress={() => { setActiveSiteFilter(''); setQ(''); }}
              style={({ pressed }) => [{
                flexDirection: 'row',
                alignItems: 'center',
                gap: 6,
                backgroundColor: '#FEF9C3',
                borderWidth: 1,
                borderColor: '#FDE047',
                borderRadius: 20,
                paddingHorizontal: 12,
                paddingVertical: 5,
                opacity: pressed ? 0.8 : 1
              }]}
            >
              <I name="location" size={14} color="#854D0E" />
              <T style={{ fontSize: 13, fontWeight: '800', color: '#854D0E' }}>
                {matchedSite}
              </T>
              <I name="close" size={14} color="#854D0E" />
            </Pressable>
          ) : (
            <View />
          )}

          <T style={{ fontSize: 13, fontWeight: '700', color: '#667085' }}>
            {filtered.length} {filtered.length === 1 ? t.custCountSingle : t.custCountPlural}
          </T>
        </View>
      )}

      {/* 5. Filter Pills: అందరూ | బాకీ ఉన్నవారు | బిల్ స్థితి ⌵ */}
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 14 }}>
        {/* All Filter */}
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={t.custFilterAll}
          onPress={() => setFilter('all')}
          style={({ pressed }) => [{
            paddingHorizontal: 16,
            paddingVertical: 8,
            borderRadius: 20,
            backgroundColor: filter === 'all' ? '#171817' : '#FFFFFF',
            borderWidth: 1,
            borderColor: filter === 'all' ? '#171817' : '#E5E7EB',
            opacity: pressed ? 0.85 : 1
          }]}
        >
          <T style={{ fontSize: 13.5, fontWeight: '700', color: filter === 'all' ? '#FFFFFF' : '#171817' }}>
            {t.custFilterAll}
          </T>
        </Pressable>

        {/* Due Filter */}
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={t.custFilterDue}
          onPress={() => setFilter('due')}
          style={({ pressed }) => [{
            paddingHorizontal: 16,
            paddingVertical: 8,
            borderRadius: 20,
            backgroundColor: filter === 'due' ? '#171817' : '#FFFFFF',
            borderWidth: 1,
            borderColor: filter === 'due' ? '#171817' : '#E5E7EB',
            opacity: pressed ? 0.85 : 1
          }]}
        >
          <T style={{ fontSize: 13.5, fontWeight: '700', color: filter === 'due' ? '#FFFFFF' : '#171817' }}>
            {t.custFilterDue}
          </T>
        </Pressable>

        {/* Status Dropdown */}
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={t.custFilterBillStatus}
          onPress={() => setStatusMenuOpen(!statusMenuOpen)}
          style={({ pressed }) => [{
            flexDirection: 'row',
            alignItems: 'center',
            gap: 5,
            paddingHorizontal: 14,
            paddingVertical: 8,
            borderRadius: 20,
            backgroundColor: ['valid', 'hold', 'passed'].includes(filter) ? '#171817' : '#FFFFFF',
            borderWidth: 1,
            borderColor: ['valid', 'hold', 'passed'].includes(filter) ? '#171817' : '#E5E7EB',
            opacity: pressed ? 0.85 : 1
          }]}
        >
          <T style={{ fontSize: 13.5, fontWeight: '700', color: ['valid', 'hold', 'passed'].includes(filter) ? '#FFFFFF' : '#171817' }}>
            {filter === 'valid' ? (appLang === 'te' ? 'యాక్టివ్ బిల్లు' : 'Valid') : filter === 'hold' ? (appLang === 'te' ? 'హోల్డ్' : 'Hold') : filter === 'passed' ? (appLang === 'te' ? 'క్లియర్' : 'Cleared') : t.custFilterBillStatus}
          </T>
          <I name="chevron-down" size={13} color={['valid', 'hold', 'passed'].includes(filter) ? '#FFFFFF' : '#171817'} />
        </Pressable>
      </View>

      {/* Bill Status Dropdown Menu Overlay */}
      {statusMenuOpen && (
        <View
          style={{
            backgroundColor: '#FFFFFF',
            borderRadius: 14,
            borderWidth: 1,
            borderColor: '#E5E7EB',
            padding: 8,
            marginBottom: 12,
            shadowColor: '#000',
            shadowOpacity: 0.1,
            shadowRadius: 8,
            elevation: 4
          }}
        >
          {[
            { id: 'all', label: appLang === 'te' ? 'అందరూ (All)' : 'All' },
            { id: 'valid', label: appLang === 'te' ? 'యాక్టివ్ బిల్లు (Bill Valid)' : 'Bill Valid' },
            { id: 'hold', label: appLang === 'te' ? 'హోల్డ్ లో ఉంది (Bill Hold)' : 'Bill Hold' },
            { id: 'passed', label: appLang === 'te' ? 'క్లియర్ అయింది (Bill Passed)' : 'Bill Passed' }
          ].map(opt => (
            <Pressable
              key={opt.id}
              onPress={() => { setFilter(opt.id); setStatusMenuOpen(false); }}
              style={{
                paddingVertical: 9,
                paddingHorizontal: 12,
                borderRadius: 8,
                backgroundColor: filter === opt.id ? '#F3F4F6' : 'transparent',
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}
            >
              <T style={{ fontSize: 13.5, fontWeight: filter === opt.id ? '700' : '500', color: '#171817' }}>
                {opt.label}
              </T>
              {filter === opt.id && <I name="checkmark" size={16} color="#171817" />}
            </Pressable>
          ))}
        </View>
      )}

      {/* 6. Customer Cards List */}
      {filtered.map(c => {
        const { latestDoc, totalBilled, due } = getCustomerBillMetrics(c, w.documents);
        const initialLetter = (c.name || 'C').trim()[0]?.toUpperCase();

        return (
          <View
            key={c.id}
            style={{
              backgroundColor: '#FFFFFF',
              borderRadius: 18,
              borderWidth: 1.2,
              borderColor: '#F1F5F9',
              padding: 16,
              marginBottom: 12,
              shadowColor: '#0F172A',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.04,
              shadowRadius: 6,
              elevation: 2
            }}
          >
            {/* Top Row: Avatar + Name + Status Pill + Amount + Due Pill */}
            <View style={{ flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 10 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1, minWidth: 0, paddingRight: 8 }}>
                {/* Initial Avatar */}
                <View
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: 22,
                    backgroundColor: '#DBEAFE',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  <T style={{ fontSize: 18, fontWeight: '800', color: '#0284C7' }}>
                    {initialLetter}
                  </T>
                </View>

                {/* Name & Payment Status Badge */}
                <View style={{ flex: 1, minWidth: 0 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                    <T numberOfLines={1} style={{ fontSize: 17, fontWeight: '900', color: '#171817' }}>
                      {c.name}
                    </T>
                    {due > 0 ? (
                      <View style={{ backgroundColor: '#FEF3C7', paddingHorizontal: 7, paddingVertical: 2.5, borderRadius: 6 }}>
                        <T style={{ fontSize: 11, fontWeight: '700', color: '#D97706' }}>
                          {t.custStatusPending}
                        </T>
                      </View>
                    ) : totalBilled > 0 ? (
                      <View style={{ backgroundColor: '#DCFCE7', paddingHorizontal: 7, paddingVertical: 2.5, borderRadius: 6 }}>
                        <T style={{ fontSize: 11, fontWeight: '700', color: '#16A34A' }}>
                          {t.custStatusCleared}
                        </T>
                      </View>
                    ) : null}
                  </View>
                </View>
              </View>

              {/* Amount & Due pill */}
              <View style={{ alignItems: 'flex-end' }}>
                <T style={{ fontSize: 18, fontWeight: '900', color: due > 0 ? '#C2410C' : '#171817' }}>
                  ₹{(due > 0 ? due : totalBilled).toLocaleString('en-IN')}
                </T>
                {due > 0 ? (
                  <View style={{ backgroundColor: '#FFEDD5', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4, marginTop: 2 }}>
                    <T style={{ fontSize: 10.5, fontWeight: '700', color: '#C2410C' }}>
                      {t.custBadgeDue}
                    </T>
                  </View>
                ) : (
                  <T style={{ fontSize: 11, color: '#667085', marginTop: 2 }}>
                    {totalBilled > 0 ? t.custStatusCleared : '—'}
                  </T>
                )}
              </View>
            </View>

            {/* Row 2: Site location chip + chevron */}
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
              {c.siteLocation ? (
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel={`Filter by site ${c.siteLocation}`}
                  onPress={() => { setActiveSiteFilter(c.siteLocation); setQ(c.siteLocation); }}
                  style={({ pressed }) => [{
                    flexDirection: 'row',
                    alignItems: 'center',
                    gap: 5,
                    backgroundColor: '#FEF9C3',
                    borderWidth: 1,
                    borderColor: '#FEF08A',
                    borderRadius: 8,
                    paddingHorizontal: 9,
                    paddingVertical: 3.5,
                    opacity: pressed ? 0.75 : 1
                  }]}
                >
                  <I name="location" size={13} color="#854D0E" />
                  <T style={{ fontSize: 12.5, fontWeight: '700', color: '#854D0E' }}>
                    {t.custSiteLabel}: {c.siteLocation}
                  </T>
                </Pressable>
              ) : (
                <View />
              )}

              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Open customer details"
                onPress={() => onOpenDashboard(c)}
                style={{ padding: 4 }}
              >
                <I name="chevron-forward" size={18} color="#9CA3AF" />
              </Pressable>
            </View>

            {/* Row 3: Calendar latest bill line */}
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 12 }}>
              <I name="calendar-outline" size={14} color="#667085" />
              <T numberOfLines={1} style={{ fontSize: 12.5, color: '#667085', fontWeight: '500' }}>
                {latestDoc ? `${latestDoc.number} • ${formatTeluguDate(latestDoc.date, appLang)}` : t.custNoBillYet}
              </T>
            </View>

            {/* Card Divider */}
            <View style={{ height: 1, backgroundColor: '#F1F5F9', marginBottom: 10 }} />

            {/* Bottom Actions: Details | + New Bill */}
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={t.custBtnDetails}
                onPress={() => onOpenDashboard(c)}
                style={({ pressed }) => [{
                  flex: 1,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 6,
                  paddingVertical: 8,
                  opacity: pressed ? 0.75 : 1
                }]}
              >
                <I name="document-text-outline" size={16} color="#171817" />
                <T style={{ fontSize: 13.5, fontWeight: '700', color: '#171817' }}>
                  {t.custBtnDetails}
                </T>
              </Pressable>

              <View style={{ width: 1, height: 22, backgroundColor: '#E2E8F0' }} />

              <Pressable
                accessibilityRole="button"
                accessibilityLabel={t.custBtnNewBill}
                onPress={() => open('document', { customerId: c.id })}
                style={({ pressed }) => [{
                  flex: 1,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 6,
                  paddingVertical: 8,
                  opacity: pressed ? 0.75 : 1
                }]}
              >
                <I name="receipt-outline" size={16} color="#171817" />
                <T style={{ fontSize: 13.5, fontWeight: '700', color: '#171817' }}>
                  {t.custBtnNewBill}
                </T>
              </Pressable>
            </View>
          </View>
        );
      })}

      {/* Empty State */}
      {filtered.length === 0 && (
        <View
          style={{
            backgroundColor: '#FFFFFF',
            borderRadius: 18,
            borderWidth: 1.2,
            borderColor: '#F1F5F9',
            paddingVertical: 36,
            paddingHorizontal: 20,
            alignItems: 'center',
            justifyContent: 'center',
            marginBottom: 16
          }}
        >
          <I name="people-outline" size={40} color="#9CA3AF" />
          <T style={{ fontSize: 16, fontWeight: '800', color: '#171817', marginTop: 10 }}>
            {q || filter !== 'all' ? (appLang === 'te' ? 'కస్టమర్లు కనపడలేదు' : 'No matching customers found') : (appLang === 'te' ? 'ఇంకా కస్టమర్లు లేరు' : 'No customers yet')}
          </T>
          <T style={{ fontSize: 13, color: '#667085', marginTop: 4, textAlign: 'center', lineHeight: 18 }}>
            {q || filter !== 'all' ? (appLang === 'te' ? 'వెతుకులాట లేదా ఫిల్టర్ క్లియర్ చేసి చూడండి.' : 'Try clearing your search query or status filter.') : (appLang === 'te' ? 'కొత్త కస్టమర్‌ను జోడించి వెంటనే బిల్లులు సృష్టించండి.' : 'Add your first customer to start billing.')}
          </T>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={t.custAddBtn}
            onPress={() => setModalCustomer('new')}
            style={({ pressed }) => [{
              marginTop: 16,
              backgroundColor: '#FFD500',
              borderRadius: 12,
              paddingHorizontal: 18,
              paddingVertical: 10,
              flexDirection: 'row',
              alignItems: 'center',
              gap: 6,
              opacity: pressed ? 0.85 : 1
            }]}
          >
            <I name="person-add" size={17} color="#171817" />
            <T style={{ fontSize: 14, fontWeight: '800', color: '#171817' }}>
              {t.custAddBtn}
            </T>
          </Pressable>
        </View>
      )}

      {/* 7. Bottom Search Helper Note */}
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 6,
          marginTop: 8,
          marginBottom: 16
        }}
      >
        <I name="search" size={16} color="#667085" />
        <T style={{ fontSize: 13, color: '#667085', fontWeight: '500' }}>
          {t.custSearchHelper}
        </T>
      </View>

      {/* Customer Modal (Add / Edit) */}
      {modalCustomer && (
        <CustomerModal
          visible={Boolean(modalCustomer)}
          initial={typeof modalCustomer === 'object' ? modalCustomer : {}}
          w={w}
          service={service}
          busy={busy}
          appLang={appLang}
          onClose={() => setModalCustomer(null)}
          onSave={handleSaveCustomer}
        />
      )}
    </View>
  );
}
