import React, { useState, useEffect } from 'react';
import {
  View,
  Text as T,
  Pressable,
  TextInput,
  ScrollView,
  Modal,
  Platform,
  Alert
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons as I } from '@expo/vector-icons';
import { services, units, calcLine, totals, money, resolveTemplate, documentTemplates, numberToIndianWords } from './domain.cjs';
import { getStrings } from './i18n';
import CustomerModal from './CustomerModal';
import TemplatePickerModal from './TemplatePickerModal';
import TemplatePreviewModal from './TemplatePreviewModal';
import MaterialsAgreementEditor from './MaterialsAgreementEditor';
import MaterialsAgreementPreviewModal from './MaterialsAgreementPreviewModal';
import { formatMeasurementBillLines } from './measurementEngine';

const localDate = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

const addDaysDate = (days = 7) => {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2);

export default function DocumentSetupModal({
  visible = true,
  initial = {},
  w = { customers: [], projects: [], rates: [], business: {} },
  service = 'tiles',
  busy = false,
  appLang = 'te',
  onClose,
  onSave,
  onSaveCustomer,
  printDoc,
  shareDoc,
  onOpenAgreement
}) {
  const t = getStrings(appLang);
  const svcObj = services.find(s => s.id === service) || services[0];
  const defaultWorkTitle = (k) => {
    if (appLang === 'te') return `${svcObj.name} పని అంచనా`;
    if (appLang === 'hi') return `${svcObj.name} कार्य अनुमान`;
    return `${svcObj.name} Work Estimate`;
  };

  // Step state: 0 = Customer & Document Setup, 1 = Items & Measurements, 2 = Review & Template Selection
  const [step, setStep] = useState(initial.initialStep !== undefined ? initial.initialStep : 0);

  useEffect(() => {
    if (initial.initialStep !== undefined) {
      setStep(initial.initialStep);
    }
  }, [initial.initialStep]);

  // Form State
  const [docKind, setDocKind] = useState(initial.kind || 'quotation'); // 'quotation' | 'invoice' | 'agreement'
  const [customerId, setCustomerId] = useState(initial.customerId || w.customers[0]?.id || '');
  const [siteLocation, setSiteLocation] = useState(initial.siteLocation || w.customers.find(c => c.id === (initial.customerId || w.customers[0]?.id))?.siteLocation || '');
  const [title, setTitle] = useState(initial.title || defaultWorkTitle(initial.kind || 'quotation'));
  const [startDate, setStartDate] = useState(initial.date || localDate());
  const [endDate, setEndDate] = useState(initial.dueDate || addDaysDate(7));
  const [docLanguage, setDocLanguage] = useState(initial.language || appLang || 'en');
  const [template, setTemplate] = useState(initial.template || w.business?.template || 'classic_ledger');
  const [pageSize, setPageSize] = useState(initial.pageSize || w.business?.pageSize || 'a4');
  const [discount, setDiscount] = useState(String(initial.discount || '0'));
  const [taxPercent, setTaxPercent] = useState(String(initial.taxPercent || '0'));
  const [retentionPercent, setRetentionPercent] = useState(String(initial.retentionPercent || '0'));
  const [terms, setTerms] = useState(initial.terms || '');
  const [items, setItems] = useState(Array.isArray(initial.items) ? initial.items : []);

  // Business & GST Details
  const [contractorGstin, setContractorGstin] = useState(w.business?.gstin || '');
  const [contractorState, setContractorState] = useState(w.business?.state || 'Andhra Pradesh');
  const [gstTab, setGstTab] = useState('my'); // 'my' | 'cust'
  const [gstAccordionOpen, setGstAccordionOpen] = useState(false);
  const [custBusinessName, setCustBusinessName] = useState(initial.custBusinessName || '');
  const [custGstin, setCustGstin] = useState(initial.custGstin || '');

  // Sub-modals
  const [templatePickerOpen, setTemplatePickerOpen] = useState(false);
  const [previewModalOpen, setPreviewModalOpen] = useState(false);
  const [previewTemplateTarget, setPreviewTemplateTarget] = useState('classic_ledger');
  const [agreementPreviewOpen, setAgreementPreviewOpen] = useState(false);
  const [agreementPreviewData, setAgreementPreviewData] = useState(null);
  const [customerModalOpen, setCustomerModalOpen] = useState(false);
  const [customerToEdit, setCustomerToEdit] = useState(null);
  const [customerDropdownOpen, setCustomerDropdownOpen] = useState(false);
  const [customerSearch, setCustomerSearch] = useState('');

  // Units supported (12 units)
  const ALL_UNITS = ['pcs', 'm', 'ft', 'sq.ft', 'sq.m', 'box', 'bag', 'coil', 'set', 'point', 'hr', 'ls'];
  const UNIT_METADATA = [
    { code: 'sq.ft', name: 'Square Feet (sq.ft)' },
    { code: 'sq.m', name: 'Square Meters (sq.m)' },
    { code: 'pcs', name: 'Pieces (pcs)' },
    { code: 'box', name: 'Boxes (box)' },
    { code: 'bag', name: 'Bags (bag)' },
    { code: 'ft', name: 'Feet / Running Feet (ft)' },
    { code: 'm', name: 'Meters (m)' },
    { code: 'coil', name: 'Coils (coil)' },
    { code: 'set', name: 'Sets (set)' },
    { code: 'point', name: 'Points (point)' },
    { code: 'hr', name: 'Hours (hr)' },
    { code: 'ls', name: 'Lump Sum (ls)' },
  ];

  // Optional item field definitions
  const OPTIONAL_ITEM_FIELDS = [
    { key: 'size', label: t.fieldOptSize || 'Size / Dimensions', placeholder: 'e.g. 600 × 600 mm' },
    { key: 'brand', label: t.fieldOptBrand || 'Brand / Manufacturer', placeholder: 'e.g. Kajaria' },
    { key: 'hsn', label: t.fieldOptHsn || 'HSN / SAC', placeholder: 'e.g. 6907' },
    { key: 'model', label: t.fieldOptModel || 'Model / Grade', placeholder: 'e.g. Double Charge' },
    { key: 'notes', label: t.fieldOptNotes || 'Notes', placeholder: 'e.g. First grade vitrified' },
    { key: 'custom', label: t.fieldOptCustom || 'Other custom field', placeholder: '' },
  ];

  // Document field definitions
  const DOC_FIELD_OPTIONS = [
    { key: 'destination', label: t.fieldDocDestination || 'Destination' },
    { key: 'orderNumber', label: t.fieldDocOrderNumber || 'Order Number' },
    { key: 'modeOfPayment', label: t.fieldDocModeOfPayment || 'Mode of Payment' },
    { key: 'terms', label: t.fieldDocTerms || 'Terms and Conditions' },
    { key: 'vehicleNo', label: t.fieldDocVehicleNo || 'Vehicle Number' },
    { key: 'ewayBillNo', label: t.fieldDocEwayBill || 'E-way Bill Number' },
    { key: 'driverPhone', label: t.fieldDocDriverPhone || 'Driver Phone' },
    { key: 'transporterName', label: t.fieldDocTransporter || 'Transporter Name' },
    { key: 'dueDate', label: t.fieldDocDueDate || 'Due Date / Valid Till' },
  ];

  const PAYMENT_METHODS = ['UPI', 'Cash', 'Bank Transfer', 'Cheque'];

  // Item entry in Step 1
  const [addingItem, setAddingItem] = useState(false);
  const [editingItemId, setEditingItemId] = useState(null);
  const [draftName, setDraftName] = useState('');
  const [draftQty, setDraftQty] = useState('1');
  const [draftRate, setDraftRate] = useState('');
  const [draftUnit, setDraftUnit] = useState('sq.ft');
  const [draftBasis, setDraftBasis] = useState('Labour only');
  const [draftSize, setDraftSize] = useState('');
  const [draftBrand, setDraftBrand] = useState('');
  const [draftHsn, setDraftHsn] = useState('');
  const [draftModel, setDraftModel] = useState('');
  const [draftNotes, setDraftNotes] = useState('');
  const [draftCustomFields, setDraftCustomFields] = useState([]);
  const [activeOptionalFields, setActiveOptionalFields] = useState([]);
  const [selectedOptFieldToAdd, setSelectedOptFieldToAdd] = useState('');
  const [unitPickerOpen, setUnitPickerOpen] = useState(false);
  const [unitSearchText, setUnitSearchText] = useState('');
  const [optFieldPickerOpen, setOptFieldPickerOpen] = useState(false);
  const [measureImportStatus, setMeasureImportStatus] = useState('');

  // Unsaved item draft protection
  const [unsavedModalOpen, setUnsavedModalOpen] = useState(false);
  const [pendingNavTarget, setPendingNavTarget] = useState(null);

  // Buyer & Document Details (Screen 3)
  const [buyerDocOpen, setBuyerDocOpen] = useState(false);
  const [destination, setDestination] = useState(initial.destination || siteLocation || '');
  const [orderNumber, setOrderNumber] = useState(initial.orderNumber || initial.orderNo || '');
  const [modeOfPayment, setModeOfPayment] = useState(initial.modeOfPayment || initial.paymentMode || 'UPI');
  const [vehicleNo, setVehicleNo] = useState(initial.vehicleNo || '');
  const [ewayBillNo, setEwayBillNo] = useState(initial.ewayBillNo || initial.ewayBill || '');
  const [driverPhone, setDriverPhone] = useState(initial.driverPhone || '');
  const [transporterName, setTransporterName] = useState(initial.transporterName || initial.transporter || '');
  const [buyerAddress, setBuyerAddress] = useState(initial.buyerAddress || '');
  const [buyerCity, setBuyerCity] = useState(initial.buyerCity || '');
  const [buyerState, setBuyerState] = useState(initial.buyerState || 'Andhra Pradesh');
  const [buyerPincode, setBuyerPincode] = useState(initial.buyerPincode || '');
  const [buyerEmail, setBuyerEmail] = useState(initial.buyerEmail || '');
  const [buyerPhone, setBuyerPhone] = useState(initial.buyerPhone || '');
  const [businessName, setBusinessName] = useState(initial.businessName || w.business?.name || '');
  const [businessAddress, setBusinessAddress] = useState(initial.businessAddress || w.business?.address || '');
  const [businessCity, setBusinessCity] = useState(initial.businessCity || w.business?.city || '');
  const [businessStatePin, setBusinessStatePin] = useState(initial.businessStatePin || `${w.business?.state || ''} ${w.business?.pincode || ''}`.trim());
  const [businessEmail, setBusinessEmail] = useState(initial.businessEmail || w.business?.email || '');
  const [businessPhone, setBusinessPhone] = useState(initial.businessPhone || w.business?.phone || '');
  const [activeDocFields, setActiveDocFields] = useState(['destination', 'orderNumber', 'modeOfPayment', 'terms']);
  const [selectedDocFieldToAdd, setSelectedDocFieldToAdd] = useState('');
  const [docFieldPickerOpen, setDocFieldPickerOpen] = useState(false);
  const [buyerDetailsAccordionOpen, setBuyerDetailsAccordionOpen] = useState(false);
  const [businessDetailsAccordionOpen, setBusinessDetailsAccordionOpen] = useState(false);
  const [docDetailsSavedMsg, setDocDetailsSavedMsg] = useState('');
  const [payMethodPickerOpen, setPayMethodPickerOpen] = useState(false);

  // When customer changes, automatically update site location if available
  const handleSelectCustomer = (c) => {
    setCustomerId(c.id);
    if (c.siteLocation && !siteLocation) {
      setSiteLocation(c.siteLocation);
    }
    if (c.siteLocation && !destination) {
      setDestination(c.siteLocation);
    }
    if (c.address && !buyerAddress) setBuyerAddress(c.address);
    if (c.city && !buyerCity) setBuyerCity(c.city);
    if (c.state && !buyerState) setBuyerState(c.state);
    if (c.pincode && !buyerPincode) setBuyerPincode(c.pincode);
    if (c.phone && !buyerPhone) setBuyerPhone(c.phone);
    if (c.email && !buyerEmail) setBuyerEmail(c.email);
    setCustomerDropdownOpen(false);
    setCustomerSearch('');
  };

  const selectedCustomer = w.customers.find(c => c.id === customerId) || w.customers[0];

  // Recalculate totals
  let totalData;
  try {
    totalData = totals(items, discount, taxPercent, retentionPercent);
  } catch (e) {
    totalData = {
      subtotal: items.reduce((s, it) => s + (Number(it.amount) || 0), 0),
      total: items.reduce((s, it) => s + (Number(it.amount) || 0), 0),
      error: e.message
    };
  }

  // Handle customer modal save
  const handleCustomerSaved = async (custData) => {
    if (onSaveCustomer) {
      try {
        const created = await onSaveCustomer(custData);
        if (created) {
          setCustomerId(created.id);
          if (created.siteLocation) {
            setSiteLocation(created.siteLocation);
            setDestination(created.siteLocation);
          }
          if (created.address) setBuyerAddress(created.address);
          if (created.city) setBuyerCity(created.city);
        }
      } catch (e) {
        Alert.alert('Error', e.message);
      }
    }
    setCustomerModalOpen(false);
    setCustomerToEdit(null);
  };

  // Import saved measurements from AsyncStorage
  const handleImportSavedMeasurements = async () => {
    try {
      const storageKey = `tilebill_measure_v6_guest_${service}`;
      const saved = await AsyncStorage.getItem(storageKey);
      if (!saved) {
        setMeasureImportStatus(t.measureNoSaved || 'ఈ ట్రేడ్ కోసం సేవ్ చేసిన కొలతలు లేవు');
        setTimeout(() => setMeasureImportStatus(''), 4000);
        return;
      }
      const parsedRooms = JSON.parse(saved);
      if (Array.isArray(parsedRooms) && parsedRooms.length > 0) {
        const lines = formatMeasurementBillLines(parsedRooms, service);
        if (lines.length > 0) {
          setItems([...items, ...lines]);
          setAddingItem(false);
          setMeasureImportStatus((t.measureImportSuccess || '{count} కొలత ఐటెమ్‌లు జోడించబడ్డాయి').replace('{count}', lines.length));
          setTimeout(() => setMeasureImportStatus(''), 4000);
        } else {
          setMeasureImportStatus(t.measureNoSaved || 'ఈ ట్రేడ్ కోసం సేవ్ చేసిన కొలతలు లేవు');
          setTimeout(() => setMeasureImportStatus(''), 4000);
        }
      }
    } catch (e) {
      setMeasureImportStatus('Error importing measurements');
      setTimeout(() => setMeasureImportStatus(''), 4000);
    }
  };

  // Draft Item management
  const hasUnsavedItemDraft = () => {
    if (!addingItem && editingItemId === null) return false;
    return draftName.trim().length > 0 || (draftRate && Number(draftRate) > 0);
  };

  const resetDraftState = () => {
    setDraftName('');
    setDraftQty('1');
    setDraftRate('');
    setDraftUnit('sq.ft');
    setDraftBasis('Labour only');
    setDraftSize('');
    setDraftBrand('');
    setDraftHsn('');
    setDraftModel('');
    setDraftNotes('');
    setDraftCustomFields([]);
    setActiveOptionalFields([]);
    setSelectedOptFieldToAdd('');
    setOptFieldPickerOpen(false);
  };

  const handleSaveDraftItem = () => {
    if (!draftName.trim() || Number(draftRate) <= 0) {
      Alert.alert('Required', t.validationItemRequired || 'Please enter an item description and a valid rate.');
      return false;
    }
    const q = Math.max(1, Number(draftQty) || 1);
    const r = Math.max(0, Number(draftRate) || 0);
    const itemObj = {
      id: editingItemId || uid(),
      name: draftName.trim(),
      qty: String(q),
      measuredQty: q,
      unit: draftUnit || 'sq.ft',
      rate: r,
      amount: q * r,
      basis: draftBasis || 'Labour only',
      size: activeOptionalFields.includes('size') ? draftSize.trim() : '',
      brand: activeOptionalFields.includes('brand') ? draftBrand.trim() : '',
      hsn: activeOptionalFields.includes('hsn') ? draftHsn.trim() : '',
      model: activeOptionalFields.includes('model') ? draftModel.trim() : '',
      notes: activeOptionalFields.includes('notes') ? draftNotes.trim() : '',
      customFields: draftCustomFields.filter(c => c.label.trim() && c.value.trim())
    };

    if (editingItemId) {
      setItems(items.map(it => it.id === editingItemId ? itemObj : it));
    } else {
      setItems([...items, itemObj]);
    }
    resetDraftState();
    setAddingItem(false);
    setEditingItemId(null);
    return true;
  };

  const handleEditItem = (it) => {
    setEditingItemId(it.id);
    setDraftName(it.name || '');
    setDraftQty(String(it.measuredQty || it.qty || 1));
    setDraftUnit(it.unit || 'sq.ft');
    setDraftRate(String(it.rate || 0));
    setDraftBasis(it.basis || 'Labour only');
    setDraftSize(it.size || '');
    setDraftBrand(it.brand || '');
    setDraftHsn(it.hsn || '');
    setDraftModel(it.model || '');
    setDraftNotes(it.notes || '');
    setDraftCustomFields(Array.isArray(it.customFields) ? [...it.customFields] : []);
    const activeOpts = [];
    if (it.size) activeOpts.push('size');
    if (it.brand) activeOpts.push('brand');
    if (it.hsn) activeOpts.push('hsn');
    if (it.model) activeOpts.push('model');
    if (it.notes) activeOpts.push('notes');
    setActiveOptionalFields(activeOpts);
    setAddingItem(true);
  };

  const handleDeleteSavedItem = (idx) => {
    const target = items[idx];
    if (target && editingItemId === target.id) {
      resetDraftState();
      setAddingItem(false);
      setEditingItemId(null);
    }
    setItems(items.filter((_, i) => i !== idx));
  };

  const handleGoToStep = (targetStep) => {
    if (step === 1 && targetStep !== 1) {
      if (hasUnsavedItemDraft()) {
        setPendingNavTarget(targetStep);
        setUnsavedModalOpen(true);
        return;
      }
      if (targetStep === 2 && (!items || items.length === 0)) {
        Alert.alert(t.alertUnsavedItemTitle || 'Missing Items', t.emptyItemsNotice || 'Add at least 1 item or import measurements first');
        return;
      }
    }
    if (targetStep === -1) {
      onClose();
      return;
    }
    setStep(targetStep);
  };

  const handleAddOptionalField = (key) => {
    const k = key || selectedOptFieldToAdd;
    if (!k) return;
    if (k === 'custom') {
      setDraftCustomFields([...draftCustomFields, { id: uid(), label: '', value: '' }]);
    } else if (!activeOptionalFields.includes(k)) {
      setActiveOptionalFields([...activeOptionalFields, k]);
    }
    setSelectedOptFieldToAdd('');
    setOptFieldPickerOpen(false);
  };

  const handleRemoveOptionalField = (key) => {
    setActiveOptionalFields(activeOptionalFields.filter(k => k !== key));
    if (key === 'size') setDraftSize('');
    if (key === 'brand') setDraftBrand('');
    if (key === 'hsn') setDraftHsn('');
    if (key === 'model') setDraftModel('');
    if (key === 'notes') setDraftNotes('');
  };

  const handleRemoveCustomField = (id) => {
    setDraftCustomFields(draftCustomFields.filter(c => c.id !== id));
  };

  const handleUpdateCustomField = (id, prop, val) => {
    setDraftCustomFields(draftCustomFields.map(c => c.id === id ? { ...c, [prop]: val } : c));
  };

  const handleAddDocField = (key) => {
    const k = key || selectedDocFieldToAdd;
    if (!k) return;
    if (!activeDocFields.includes(k)) {
      setActiveDocFields([...activeDocFields, k]);
    }
    setSelectedDocFieldToAdd('');
    setDocFieldPickerOpen(false);
  };

  const handleRemoveDocField = (key) => {
    setActiveDocFields(activeDocFields.filter(k => k !== key));
  };

  const handleSaveDocDetails = () => {
    setDocDetailsSavedMsg(t.noticeSavedDetailsAppear || 'Saved details appear in your document.');
    setTimeout(() => setDocDetailsSavedMsg(''), 3500);
  };

  // Build document payload
  const currentDocPayload = {
    ...initial,
    kind: docKind,
    service,
    customerId,
    customer: {
      ...selectedCustomer,
      siteLocation: destination || siteLocation || selectedCustomer?.siteLocation,
      address: buyerAddress || selectedCustomer?.address,
      city: buyerCity || selectedCustomer?.city,
      state: buyerState || selectedCustomer?.state,
      pincode: buyerPincode || selectedCustomer?.pincode,
      email: buyerEmail || selectedCustomer?.email,
      phone: buyerPhone || selectedCustomer?.phone,
      gstin: custGstin || selectedCustomer?.gstin
    },
    siteLocation: destination || siteLocation,
    title,
    date: startDate,
    dueDate: endDate,
    language: docLanguage,
    template,
    pageSize,
    discount,
    taxPercent,
    retentionPercent,
    terms,
    items,
    subtotal: totalData.subtotal,
    total: totalData.total,
    custBusinessName,
    custGstin,
    contractorGstin,
    contractorState,
    destination,
    orderNumber,
    orderNo: orderNumber,
    vehicleNo,
    ewayBillNo,
    ewayBill: ewayBillNo,
    driverPhone,
    transporterName,
    transporter: transporterName,
    modeOfPayment,
    paymentMode: modeOfPayment,
    paymentTerms: terms,
    buyerAddress,
    buyerCity,
    buyerState,
    buyerPincode,
    buyerEmail,
    buyerPhone,
    businessName,
    businessAddress,
    businessCity,
    businessStatePin,
    businessEmail,
    businessPhone
  };

  // Save Document
  const handleFinalSave = async () => {
    if (!customerId) {
      Alert.alert('Missing Customer', 'Select a customer first');
      setStep(0);
      return;
    }
    if (!items || items.length === 0) {
      Alert.alert('Missing Items', 'Add at least 1 line item or import measurements first');
      setStep(1);
      return;
    }
    if (onSave) {
      await onSave('document', currentDocPayload);
    }
  };

  const selectedTemplateObj = resolveTemplate(template);
  const tmplKey = selectedTemplateObj.id === 'classic_ledger' ? '01' : selectedTemplateObj.id === 'amber_grid' ? '02' : selectedTemplateObj.id === 'olive_grid' ? '03' : selectedTemplateObj.id === 'compact_trade' ? '04' : selectedTemplateObj.id === 'blue_timesheet' ? '05' : selectedTemplateObj.id === 'sales_detail' ? '06' : selectedTemplateObj.id === 'corporate_sales' ? '07' : selectedTemplateObj.id === 'contractor_detail' ? '08' : selectedTemplateObj.id === 'project_summary' ? '09' : '10';
  const selectedTemplateName = t[`tmpl${tmplKey}Name`] || selectedTemplateObj.name;
  const selectedTemplateDesc = t[`tmpl${tmplKey}Desc`] || selectedTemplateObj.desc;

  if (!visible) return null;

  if (docKind === 'agreement') {
    return (
      <>
        <MaterialsAgreementEditor
          visible={visible}
          initial={{
            ...initial,
            customerId,
            siteLocation,
            title,
            language: docLanguage,
            materials: initial.materials || initial.items
          }}
          w={w}
          service={service}
          appLang={appLang}
          onClose={onClose}
          onOpenQuotation={() => setDocKind('quotation')}
          onOpenInvoice={() => setDocKind('invoice')}
          onPreview={(agreeData) => {
            setAgreementPreviewData(agreeData);
            setAgreementPreviewOpen(true);
          }}
          onSave={async (agreeData) => {
            if (onSave) await onSave('agreement', agreeData);
          }}
          onSaveCustomer={handleCustomerSaved}
        />
        {agreementPreviewOpen && (
          <MaterialsAgreementPreviewModal
            visible={agreementPreviewOpen}
            agreement={agreementPreviewData}
            business={w.business}
            appLang={appLang}
            onClose={() => setAgreementPreviewOpen(false)}
            onEdit={() => setAgreementPreviewOpen(false)}
            onGeneratePdf={(agreeData) => {
              if (printDoc) printDoc({ ...agreeData, isAgreement: true });
            }}
            onDownload={(agreeData) => {
              if (printDoc) printDoc({ ...agreeData, isAgreement: true });
            }}
            onShare={(agreeData) => {
              if (shareDoc) shareDoc(agreeData);
            }}
          />
        )}
      </>
    );
  }

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end', alignItems: 'center' }}>
        <View
          style={{
            backgroundColor: '#FAF9F6',
            width: '100%',
            maxWidth: 480,
            height: '95%',
            borderTopLeftRadius: 28,
            borderTopRightRadius: 28,
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column'
          }}
        >
          {/* 1. Header with Back, Brand Logo, and Close */}
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 10, borderBottomWidth: 1, borderColor: '#F1F5F9' }}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Back"
              onPress={() => {
                if (step > 0) handleGoToStep(step - 1);
                else onClose();
              }}
              style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 20 }}
            >
              <I name="chevron-back" size={24} color="#171817" />
            </Pressable>

            {/* TileBill PRO Brand Logo */}
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
              <T style={{ fontSize: 18, fontWeight: '900', color: '#171817', letterSpacing: -0.3 }}>TileBill</T>
              <View style={{ backgroundColor: '#FFD500', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 }}>
                <T style={{ fontSize: 11, fontWeight: '900', color: '#171817' }}>PRO</T>
              </View>
            </View>

            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Close"
              onPress={() => {
                if (step === 1 && hasUnsavedItemDraft()) {
                  setPendingNavTarget(-1);
                  setUnsavedModalOpen(true);
                } else {
                  onClose();
                }
              }}
              style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 20 }}
            >
              <I name="close" size={22} color="#171817" />
            </Pressable>
          </View>

          {/* 2. Screen Title & Subtitle */}
          <View style={{ alignItems: 'center', paddingVertical: 6 }}>
            <T style={{ fontSize: 20, fontWeight: '800', color: '#171817' }}>
              {t.docSetupTitle || 'డాక్యుమెంట్ తయారీ'}
            </T>
            <T style={{ fontSize: 12.5, color: '#667085', marginTop: 1 }}>
              {t.docSetupSub || 'కొటేషన్, ఇన్వాయిస్ లేదా అగ్రిమెంట్ రూపొందించండి'}
            </T>
          </View>

          {/* 3. Document Type Tabs: Quotation / Invoice / Agreement */}
          <View style={{ paddingHorizontal: 16, marginBottom: 10 }}>
            <View style={{ flexDirection: 'row', backgroundColor: '#FFFFFF', borderRadius: 14, padding: 4, borderWidth: 1, borderColor: '#E2E8F0' }}>
              {[
                { id: 'quotation', label: t.docTypeQuotation || 'కొటేషన్', icon: 'document-text-outline' },
                { id: 'invoice', label: t.docTypeInvoice || 'ఇన్వాయిస్', icon: 'receipt-outline' },
                { id: 'agreement', label: t.docTypeAgreement || 'అగ్రిమెంట్', icon: 'newspaper-outline' }
              ].map((dt) => {
                const isActive = docKind === dt.id;
                return (
                  <Pressable
                    key={dt.id}
                    accessibilityRole="button"
                    accessibilityLabel={dt.label}
                    onPress={() => {
                      if (dt.id === 'agreement') {
                        if (onOpenAgreement) {
                          onOpenAgreement({
                            customerId,
                            siteLocation,
                            title,
                            service,
                            language: docLanguage
                          });
                        } else {
                          setDocKind('agreement');
                        }
                      } else {
                        setDocKind(dt.id);
                      }
                    }}
                    style={{
                      flex: 1,
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: 5,
                      paddingVertical: 10,
                      borderRadius: 10,
                      backgroundColor: isActive ? '#FFD500' : 'transparent',
                      shadowColor: '#000',
                      shadowOpacity: isActive ? 0.08 : 0,
                      shadowRadius: 2,
                      elevation: isActive ? 1 : 0
                    }}
                  >
                    <I name={dt.icon} size={16} color="#171817" />
                    <T numberOfLines={1} style={{ fontSize: 13, fontWeight: '800', color: '#171817' }}>
                      {dt.label}
                    </T>
                  </Pressable>
                );
              })}
            </View>
          </View>

          {/* 4. Wizard Stepper Indicator */}
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingHorizontal: 16, marginBottom: 12 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
              <View style={{ width: 22, height: 22, borderRadius: 11, backgroundColor: step === 0 ? '#FFD500' : '#E2E8F0', alignItems: 'center', justifyContent: 'center' }}>
                <T style={{ fontSize: 11, fontWeight: '800', color: '#171817' }}>1</T>
              </View>
              <T style={{ fontSize: 12, fontWeight: step === 0 ? '800' : '500', color: step === 0 ? '#171817' : '#667085' }}>
                {t.stepCustSelect || 'కస్టమర్ ఎంపిక'}
              </T>
            </View>

            <View style={{ width: 24, height: 1.5, backgroundColor: '#CBD5E1' }} />

            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
              <View style={{ width: 22, height: 22, borderRadius: 11, backgroundColor: step === 1 ? '#FFD500' : '#E2E8F0', alignItems: 'center', justifyContent: 'center' }}>
                <T style={{ fontSize: 11, fontWeight: '800', color: '#171817' }}>2</T>
              </View>
              <T style={{ fontSize: 12, fontWeight: step === 1 ? '800' : '500', color: step === 1 ? '#171817' : '#667085' }}>
                {t.stepEnterDetails || 'వివరాలు నమోదు'}
              </T>
            </View>

            <View style={{ width: 24, height: 1.5, backgroundColor: '#CBD5E1' }} />

            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
              <View style={{ width: 22, height: 22, borderRadius: 11, backgroundColor: step === 2 ? '#FFD500' : '#E2E8F0', alignItems: 'center', justifyContent: 'center' }}>
                <T style={{ fontSize: 11, fontWeight: '800', color: '#171817' }}>3</T>
              </View>
              <T style={{ fontSize: 12, fontWeight: step === 2 ? '800' : '500', color: step === 2 ? '#171817' : '#667085' }}>
                {t.stepSendSave || 'పంపండి / సేవ్'}
              </T>
            </View>
          </View>

          {/* 5. Main Step Content Area */}
          <ScrollView
            style={{ flex: 1, paddingHorizontal: 16 }}
            contentContainerStyle={{ paddingBottom: 24 }}
            showsVerticalScrollIndicator={false}
          >
            {step === 0 && (
              /* ============================================================== */
              /* STEP 0: CUSTOMER & DOCUMENT SETUP (Image 01)                   */
              /* ============================================================== */
              <View style={{ gap: 12 }}>
                {/* CARD 1: CUSTOMER DETAILS */}
                <View style={{ backgroundColor: '#FFFFFF', borderRadius: 16, padding: 14, borderWidth: 1, borderColor: '#E2E8F0' }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                      <I name="person" size={18} color="#171817" />
                      <T style={{ fontSize: 15, fontWeight: '800', color: '#171817' }}>
                        {t.custCardTitle || 'కస్టమర్ వివరాలు'}
                      </T>
                    </View>

                    <View style={{ flexDirection: 'row', gap: 6 }}>
                      <Pressable
                        accessibilityRole="button"
                        onPress={() => {
                          setCustomerToEdit(null);
                          setCustomerModalOpen(true);
                        }}
                        style={{ flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#EFF6FF', borderWidth: 1, borderColor: '#BFDBFE', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 }}
                      >
                        <T style={{ fontSize: 11.5, fontWeight: '700', color: '#1D4ED8' }}>
                          {t.btnNewCustomer || '+ కొత్త కస్టమర్'}
                        </T>
                      </Pressable>

                      {selectedCustomer && (
                        <Pressable
                          accessibilityRole="button"
                          onPress={() => {
                            setCustomerToEdit(selectedCustomer);
                            setCustomerModalOpen(true);
                          }}
                          style={{ flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#E2E8F0', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 }}
                        >
                          <I name="create-outline" size={13} color="#475569" />
                          <T style={{ fontSize: 11.5, fontWeight: '700', color: '#475569' }}>
                            {t.btnEditCustomer || 'సవరించు'}
                          </T>
                        </Pressable>
                      )}
                    </View>
                  </View>

                  {/* Customer Select Dropdown */}
                  <View style={{ flexDirection: 'row', gap: 10 }}>
                    <View style={{ flex: 1 }}>
                      <T style={{ fontSize: 11.5, color: '#667085', marginBottom: 4 }}>
                        {t.labelCustomerName || 'కస్టమర్ పేరు'}
                      </T>
                      <Pressable
                        accessibilityRole="button"
                        onPress={() => setCustomerDropdownOpen(!customerDropdownOpen)}
                        style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 10, paddingHorizontal: 10, paddingVertical: 10, backgroundColor: '#FFFFFF' }}
                      >
                        <T numberOfLines={1} style={{ fontSize: 13.5, fontWeight: '700', color: '#171817' }}>
                          {selectedCustomer?.name || 'కస్టమర్‌ని ఎంచుకోండి'}
                        </T>
                        <I name="chevron-down" size={16} color="#667085" />
                      </Pressable>
                    </View>

                    {/* Site / Location Field */}
                    <View style={{ flex: 1 }}>
                      <T style={{ fontSize: 11.5, color: '#667085', marginBottom: 4 }}>
                        {t.labelSiteLocation || 'సైట్ / ప్రదేశం'}
                      </T>
                      <TextInput
                        value={siteLocation}
                        onChangeText={setSiteLocation}
                        placeholder={t.selectSitePlaceholder || 'ప్రదేశం / సైట్'}
                        placeholderTextColor="#94A3B8"
                        style={{ borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 10, paddingHorizontal: 10, paddingVertical: 9, fontSize: 13.5, fontWeight: '600', color: '#171817', backgroundColor: '#FFFFFF' }}
                      />
                    </View>
                  </View>

                  {/* Dropdown List with Search */}
                  {customerDropdownOpen && (
                    <View style={{ marginTop: 10, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 10, backgroundColor: '#FFFFFF', padding: 8, maxHeight: 180 }}>
                      <TextInput
                        value={customerSearch}
                        onChangeText={setCustomerSearch}
                        placeholder={t.selectCustomerPlaceholder || 'కస్టమర్‌ను శోధించండి…'}
                        placeholderTextColor="#94A3B8"
                        style={{ borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 8, paddingHorizontal: 8, paddingVertical: 6, fontSize: 12, marginBottom: 6 }}
                      />
                      <ScrollView style={{ maxHeight: 120 }}>
                        {w.customers
                          .filter(c => (c.name + ' ' + (c.phone || '') + ' ' + (c.siteLocation || '')).toLowerCase().includes(customerSearch.toLowerCase()))
                          .map(c => (
                            <Pressable
                              key={c.id}
                              onPress={() => handleSelectCustomer(c)}
                              style={{ paddingVertical: 8, paddingHorizontal: 6, borderBottomWidth: 1, borderColor: '#F1F5F9' }}
                            >
                              <T style={{ fontSize: 13, fontWeight: '700', color: '#171817' }}>{c.name}</T>
                              <T style={{ fontSize: 11, color: '#667085' }}>{[c.phone, c.siteLocation].filter(Boolean).join(' • ')}</T>
                            </Pressable>
                          ))}
                      </ScrollView>
                    </View>
                  )}
                </View>

                {/* CARD 2: WORK DETAILS */}
                <View style={{ backgroundColor: '#FFFFFF', borderRadius: 16, padding: 14, borderWidth: 1, borderColor: '#E2E8F0' }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                    <I name="document-text-outline" size={18} color="#171817" />
                    <T style={{ fontSize: 15, fontWeight: '800', color: '#171817' }}>
                      {t.workCardTitle || 'పని వివరాలు'}
                    </T>
                  </View>

                  {/* Work Name / Title */}
                  <View style={{ marginBottom: 10 }}>
                    <T style={{ fontSize: 11.5, color: '#667085', marginBottom: 4 }}>
                      {t.labelWorkTitle || 'పని పేరు / శీర్షిక'}
                    </T>
                    <TextInput
                      value={title}
                      onChangeText={setTitle}
                      placeholder={t.workTitlePlaceholder || 'టైల్స్ పని అంచనా'}
                      placeholderTextColor="#94A3B8"
                      style={{ borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 10, paddingHorizontal: 10, paddingVertical: 9, fontSize: 14, fontWeight: '600', color: '#171817', backgroundColor: '#FFFFFF' }}
                    />
                  </View>

                  {/* Start Date & End Date */}
                  <View style={{ flexDirection: 'row', gap: 10 }}>
                    <View style={{ flex: 1 }}>
                      <T style={{ fontSize: 11.5, color: '#667085', marginBottom: 4 }}>
                        {t.labelStartDate || 'ప్రారంభ తేదీ'}
                      </T>
                      <View style={{ flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 10, paddingHorizontal: 8, backgroundColor: '#FFFFFF' }}>
                        <I name="calendar-outline" size={16} color="#667085" />
                        <TextInput
                          value={startDate}
                          onChangeText={setStartDate}
                          placeholder="YYYY-MM-DD"
                          placeholderTextColor="#94A3B8"
                          style={{ flex: 1, paddingVertical: 9, paddingHorizontal: 6, fontSize: 13, fontWeight: '600', color: '#171817' }}
                        />
                      </View>
                    </View>

                    <View style={{ flex: 1 }}>
                      <T style={{ fontSize: 11.5, color: '#667085', marginBottom: 4 }}>
                        {t.labelEndDate || 'పూర్తి చేసే తేదీ'}
                      </T>
                      <View style={{ flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 10, paddingHorizontal: 8, backgroundColor: '#FFFFFF' }}>
                        <I name="calendar-outline" size={16} color="#667085" />
                        <TextInput
                          value={endDate}
                          onChangeText={setEndDate}
                          placeholder="YYYY-MM-DD"
                          placeholderTextColor="#94A3B8"
                          style={{ flex: 1, paddingVertical: 9, paddingHorizontal: 6, fontSize: 13, fontWeight: '600', color: '#171817' }}
                        />
                      </View>
                    </View>
                  </View>
                </View>

                {/* CARD 3: BUSINESS & GST DETAILS ACCORDION */}
                <View style={{ backgroundColor: '#FFFFFF', borderRadius: 16, borderWidth: 1, borderColor: '#E2E8F0', overflow: 'hidden' }}>
                  <Pressable
                    accessibilityRole="button"
                    onPress={() => setGstAccordionOpen(!gstAccordionOpen)}
                    style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 14, paddingVertical: 12 }}
                  >
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                      <I name="business-outline" size={18} color="#171817" />
                      <T style={{ fontSize: 15, fontWeight: '800', color: '#171817' }}>
                        {t.bizGstCardTitle || 'వ్యాపారం & GST వివరాలు'}
                      </T>
                    </View>
                    <I name={gstAccordionOpen ? 'chevron-up' : 'chevron-down'} size={18} color="#667085" />
                  </Pressable>

                  {gstAccordionOpen && (
                    <View style={{ padding: 14, borderTopWidth: 1, borderColor: '#F1F5F9' }}>
                      {/* Sub-tabs: మీ వివరాలు | కస్టమర్ వివరాలు */}
                      <View style={{ flexDirection: 'row', backgroundColor: '#F1F5F9', borderRadius: 10, padding: 3, marginBottom: 12 }}>
                        <Pressable
                          accessibilityRole="button"
                          onPress={() => setGstTab('my')}
                          style={{ flex: 1, paddingVertical: 6, alignItems: 'center', borderRadius: 8, backgroundColor: gstTab === 'my' ? '#FEF08A' : 'transparent' }}
                        >
                          <T style={{ fontSize: 12, fontWeight: '800', color: '#171817' }}>
                            {t.tabMyDetails || 'మీ వివరాలు'}
                          </T>
                        </Pressable>

                        <Pressable
                          accessibilityRole="button"
                          onPress={() => setGstTab('cust')}
                          style={{ flex: 1, paddingVertical: 6, alignItems: 'center', borderRadius: 8, backgroundColor: gstTab === 'cust' ? '#FEF08A' : 'transparent' }}
                        >
                          <T style={{ fontSize: 12, fontWeight: '800', color: '#171817' }}>
                            {t.tabCustDetails || 'కస్టమర్ వివరాలు'}
                          </T>
                        </Pressable>
                      </View>

                      {gstTab === 'my' ? (
                        <View>
                          <View style={{ flexDirection: 'row', gap: 10, marginBottom: 10 }}>
                            <View style={{ flex: 1 }}>
                              <T style={{ fontSize: 11.5, color: '#667085', marginBottom: 4 }}>{t.labelGstinOptional || 'GSTIN (ఉంటే)'}</T>
                              <TextInput
                                value={contractorGstin}
                                onChangeText={setContractorGstin}
                                placeholder={t.placeholderGstin || 'GSTIN నమోదు చేయండి'}
                                placeholderTextColor="#94A3B8"
                                style={{ borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8, fontSize: 12.5 }}
                              />
                            </View>
                            <View style={{ flex: 1 }}>
                              <T style={{ fontSize: 11.5, color: '#667085', marginBottom: 4 }}>{t.labelState || 'రాష్ట్రం'}</T>
                              <TextInput
                                value={contractorState}
                                onChangeText={setContractorState}
                                style={{ borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8, fontSize: 12.5, fontWeight: '600' }}
                              />
                            </View>
                          </View>

                          {/* Quick Actions row */}
                          <View style={{ flexDirection: 'row', gap: 6, marginTop: 4 }}>
                            <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#E2E8F0', paddingVertical: 7, paddingHorizontal: 8, borderRadius: 8, justifyContent: 'center' }}>
                              <I name="home-outline" size={13} color="#475569" />
                              <T numberOfLines={1} style={{ fontSize: 11, fontWeight: '700', color: '#475569' }}>{t.btnEditAddress || 'చిరునామా'}</T>
                            </View>
                            <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#E2E8F0', paddingVertical: 7, paddingHorizontal: 8, borderRadius: 8, justifyContent: 'center' }}>
                              <I name="call-outline" size={13} color="#475569" />
                              <T numberOfLines={1} style={{ fontSize: 11, fontWeight: '700', color: '#475569' }}>{t.btnEditPhone || 'ఫోన్'}</T>
                            </View>
                            <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#E2E8F0', paddingVertical: 7, paddingHorizontal: 8, borderRadius: 8, justifyContent: 'center' }}>
                              <I name="image-outline" size={13} color="#475569" />
                              <T numberOfLines={1} style={{ fontSize: 11, fontWeight: '700', color: '#475569' }}>{t.btnChangeLogo || 'లోగో'}</T>
                            </View>
                          </View>
                        </View>
                      ) : (
                        <View>
                          <T style={{ fontSize: 11.5, color: '#667085', marginBottom: 4 }}>Customer Business Name</T>
                          <TextInput
                            value={custBusinessName}
                            onChangeText={setCustBusinessName}
                            placeholder="Optional Business Name"
                            style={{ borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8, fontSize: 12.5, marginBottom: 8 }}
                          />
                          <T style={{ fontSize: 11.5, color: '#667085', marginBottom: 4 }}>Customer GSTIN</T>
                          <TextInput
                            value={custGstin}
                            onChangeText={setCustGstin}
                            placeholder="Optional Customer GSTIN"
                            style={{ borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8, fontSize: 12.5 }}
                          />
                        </View>
                      )}
                    </View>
                  )}
                </View>

                {/* CARD 4: DOCUMENT LANGUAGE */}
                <View style={{ backgroundColor: '#FFFFFF', borderRadius: 16, padding: 14, borderWidth: 1, borderColor: '#E2E8F0' }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                    <I name="globe-outline" size={18} color="#171817" />
                    <T style={{ fontSize: 15, fontWeight: '800', color: '#171817' }}>
                      {t.docLangCardTitle || 'డాక్యుమెంట్ భాష'}
                    </T>
                  </View>

                  <View style={{ flexDirection: 'row', gap: 10 }}>
                    {[
                      { id: 'te', label: 'తెలుగు' },
                      { id: 'en', label: 'English' },
                      { id: 'hi', label: 'हिन्दी' }
                    ].map(lg => {
                      const isActive = docLanguage === lg.id;
                      return (
                        <Pressable
                          key={lg.id}
                          accessibilityRole="button"
                          onPress={() => setDocLanguage(lg.id)}
                          style={{
                            flex: 1,
                            paddingVertical: 10,
                            borderRadius: 12,
                            backgroundColor: isActive ? '#FEF08A' : '#F8FAFC',
                            borderWidth: isActive ? 1.5 : 1,
                            borderColor: isActive ? '#FACC15' : '#E2E8F0',
                            alignItems: 'center',
                            justifyContent: 'center'
                          }}
                        >
                          <T style={{ fontSize: 13.5, fontWeight: isActive ? '900' : '600', color: '#171817' }}>
                            {lg.label}
                          </T>
                        </Pressable>
                      );
                    })}
                  </View>
                </View>

                {/* CARD 5: DESIGN & PAPER SIZE */}
                <View style={{ backgroundColor: '#FFFFFF', borderRadius: 16, padding: 14, borderWidth: 1, borderColor: '#E2E8F0' }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                    <I name="color-palette-outline" size={18} color="#171817" />
                    <T style={{ fontSize: 15, fontWeight: '800', color: '#171817' }}>
                      {t.designPaperCardTitle || 'డిజైన్ & పేపర్ సైజు'}
                    </T>
                  </View>

                  <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
                    <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                      <View style={{ width: 44, height: 50, borderWidth: 1, borderColor: '#171817', padding: 3, backgroundColor: '#FFFFFF', borderRadius: 4, justifyContent: 'center' }}>
                        <View style={{ height: 4, backgroundColor: '#171817', marginBottom: 2 }} />
                        <View style={{ height: 2, backgroundColor: '#94A3B8', marginBottom: 2 }} />
                        <View style={{ height: 16, borderWidth: 0.5, borderColor: '#CBD5E1' }} />
                      </View>
                      <View style={{ flex: 1 }}>
                        <T numberOfLines={1} style={{ fontSize: 14, fontWeight: '800', color: '#171817' }}>
                          {selectedTemplateName} • {pageSize.toUpperCase()}
                        </T>
                        <T numberOfLines={2} style={{ fontSize: 11, color: '#667085', marginTop: 2 }}>
                          {selectedTemplateDesc}
                        </T>
                      </View>
                    </View>

                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel="Choose Template"
                      onPress={() => setTemplatePickerOpen(true)}
                      style={({ pressed }) => [{
                        backgroundColor: '#FEF08A',
                        borderWidth: 1,
                        borderColor: '#FACC15',
                        borderRadius: 12,
                        paddingVertical: 9,
                        paddingHorizontal: 12,
                        alignItems: 'center',
                        opacity: pressed ? 0.85 : 1
                      }]}
                    >
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                        <I name="grid-outline" size={15} color="#171817" />
                        <T style={{ fontSize: 12.5, fontWeight: '800', color: '#171817' }}>Choose Template</T>
                        <I name="chevron-forward" size={14} color="#171817" />
                      </View>
                      <T style={{ fontSize: 10, color: '#854D0E', marginTop: 1 }}>10 డిజైన్లు</T>
                    </Pressable>
                  </View>
                </View>
              </View>
            )}

            {step === 1 && (
              /* ============================================================== */
              /* STEP 1: ADD ITEMS & MEASUREMENTS (Mockup Screens 1, 2, 3)       */
              /* ============================================================== */
              <View style={{ gap: 14 }}>
                {/* Screen Heading */}
                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 2 }}>
                  <T style={{ fontSize: 20, fontWeight: '900', color: '#171817' }}>
                    {addingItem ? (t.titleAddYourItems || 'Add your items') : (t.titleYourItemList || 'Your item list')}
                  </T>
                </View>

                {/* Pale-yellow Instruction Strip */}
                <View style={{ backgroundColor: '#FEF9C3', borderRadius: 12, padding: 12, borderWidth: 1, borderColor: '#FDE047', flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                  <View style={{ width: 34, height: 34, borderRadius: 8, backgroundColor: '#FACC15', alignItems: 'center', justifyContent: 'center' }}>
                    <I name="list" size={18} color="#854D0E" />
                  </View>
                  <T style={{ fontSize: 13, fontWeight: '700', color: '#713F12', flex: 1 }}>
                    {t.instructionAddItems || 'Add your items here.'}
                  </T>
                </View>

                {/* OPAQUE WHITE CARD: YOUR ITEMS */}
                <View style={{ backgroundColor: '#FFFFFF', borderRadius: 16, padding: 14, borderWidth: 1, borderColor: '#E2E8F0' }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
                    <T style={{ fontSize: 15, fontWeight: '900', color: '#171817' }}>
                      {items.length > 0
                        ? (t.headingYourItemsWithCount ? t.headingYourItemsWithCount.replace('{count}', items.length) : `${t.headingYourItems || 'Your Items'} (${items.length})`)
                        : (t.headingYourItems || 'Your Items (0)')}
                    </T>
                    {!addingItem && items.length > 0 && (
                      <Pressable
                        accessibilityRole="button"
                        accessibilityLabel="Add custom item"
                        onPress={() => {
                          resetDraftState();
                          setAddingItem(true);
                        }}
                        style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: '#FEF08A', borderWidth: 1, borderColor: '#FACC15', paddingHorizontal: 9, paddingVertical: 5, borderRadius: 8 }}
                      >
                        <T style={{ fontSize: 11.5, fontWeight: '800', color: '#854D0E' }}>{t.btnAddItem || '+ Add Item'}</T>
                      </Pressable>
                    )}
                  </View>

                  {/* SAVED ITEMS LIST (When not in inline editor) */}
                  {!addingItem && items.length > 0 && (
                    <View style={{ gap: 10 }}>
                      {items.map((it, idx) => {
                        const specSummary = [
                          it.size ? `Size: ${it.size}` : '',
                          it.brand ? `Brand: ${it.brand}` : '',
                          it.model ? `Model: ${it.model}` : '',
                          it.hsn ? `HSN: ${it.hsn}` : '',
                          it.notes,
                          ...(it.customFields || []).map(c => `${c.label}: ${c.value}`)
                        ].filter(Boolean).join(' · ');

                        return (
                          <View
                            key={it.id || idx}
                            style={{
                              backgroundColor: '#FFFFFF',
                              borderWidth: 1,
                              borderColor: '#E2E8F0',
                              borderRadius: 12,
                              padding: 12,
                              gap: 8
                            }}
                          >
                            <View style={{ flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' }}>
                              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 }}>
                                <View style={{ width: 44, height: 44, borderRadius: 8, backgroundColor: '#F1F5F9', borderWidth: 1, borderColor: '#E2E8F0', alignItems: 'center', justifyContent: 'center' }}>
                                  <I name="cube-outline" size={22} color="#64748B" />
                                </View>
                                <View style={{ flex: 1, paddingRight: 6 }}>
                                  <T numberOfLines={1} style={{ fontSize: 14.5, fontWeight: '800', color: '#171817' }}>
                                    {idx + 1}. {it.name}
                                  </T>
                                  {!!specSummary && (
                                    <T numberOfLines={2} style={{ fontSize: 11.5, color: '#64748B', marginTop: 2 }}>
                                      {specSummary}
                                    </T>
                                  )}
                                </View>
                              </View>
                              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                                <Pressable
                                  accessibilityRole="button"
                                  accessibilityLabel="Edit item"
                                  onPress={() => handleEditItem(it)}
                                  style={{ padding: 6, borderRadius: 6, backgroundColor: '#F8FAFC' }}
                                >
                                  <I name="create-outline" size={16} color="#334155" />
                                </Pressable>
                                <Pressable
                                  accessibilityRole="button"
                                  accessibilityLabel="Delete item"
                                  onPress={() => handleDeleteSavedItem(idx)}
                                  style={{ padding: 6, borderRadius: 6, backgroundColor: '#FEF2F2' }}
                                >
                                  <I name="trash-outline" size={16} color="#EF4444" />
                                </Pressable>
                              </View>
                            </View>

                            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: 6, borderTopWidth: 1, borderColor: '#F8FAFC' }}>
                              <T style={{ fontSize: 12.5, color: '#475569', fontWeight: '600' }}>
                                {it.measuredQty || it.qty} {it.unit} × ₹{Number(it.rate || 0).toLocaleString('en-IN')} {it.basis ? `• ${it.basis}` : ''}
                              </T>
                              <T style={{ fontSize: 15, fontWeight: '900', color: '#171817' }}>
                                ₹{Number(it.amount || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                              </T>
                            </View>
                          </View>
                        );
                      })}

                      {/* + Add Another Item Button */}
                      <Pressable
                        accessibilityRole="button"
                        accessibilityLabel="Add another item"
                        onPress={() => {
                          resetDraftState();
                          setAddingItem(true);
                        }}
                        style={({ pressed }) => [{
                          backgroundColor: pressed ? '#FEF9C3' : '#FFFFFF',
                          borderWidth: 1.5,
                          borderColor: '#FACC15',
                          borderRadius: 12,
                          paddingVertical: 12,
                          alignItems: 'center',
                          justifyContent: 'center',
                          flexDirection: 'row',
                          marginTop: 4
                        }]}
                      >
                        <T style={{ fontSize: 14, fontWeight: '800', color: '#B45309' }}>
                          {t.btnAddAnotherItem || '+ Add Another Item'}
                        </T>
                      </Pressable>
                    </View>
                  )}

                  {/* EMPTY STATE (When not editing and items is empty) */}
                  {!addingItem && items.length === 0 && (
                    <View style={{ alignItems: 'center', paddingVertical: 20, gap: 12 }}>
                      <View style={{ width: 48, height: 48, borderRadius: 24, backgroundColor: '#F1F5F9', alignItems: 'center', justifyContent: 'center' }}>
                        <I name="cube-outline" size={24} color="#94A3B8" />
                      </View>
                      <T style={{ fontSize: 13, color: '#64748B', textAlign: 'center', paddingHorizontal: 16 }}>
                        {t.emptyItemsNotice || 'No items added yet. Tap "+ Add Item" above to add your first item, or import saved measurements.'}
                      </T>
                      <Pressable
                        accessibilityRole="button"
                        accessibilityLabel="Add item"
                        onPress={() => {
                          resetDraftState();
                          setAddingItem(true);
                        }}
                        style={{ backgroundColor: '#FFD500', borderRadius: 10, paddingVertical: 10, paddingHorizontal: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }}
                      >
                        <T style={{ fontSize: 13.5, fontWeight: '800', color: '#171817' }}>
                          {t.btnAddItem || '+ Add Item'}
                        </T>
                      </Pressable>
                    </View>
                  )}

                  {/* INLINE ITEM EDITOR */}
                  {addingItem && (
                    <View style={{ backgroundColor: '#FFFFFF', borderRadius: 14, gap: 12 }}>
                      {/* Field 1: Item / Work Description */}
                      <View>
                        <T style={{ fontSize: 12.5, fontWeight: '700', color: '#334155', marginBottom: 5 }}>
                          {t.labelItemDescription || 'Item / Work Description'}
                        </T>
                        <TextInput
                          accessibilityLabel="Item description input"
                          value={draftName}
                          onChangeText={setDraftName}
                          placeholder={t.placeholderItemDescription || 'e.g. 600x600 Double Charge Vitrified Tiles'}
                          style={{
                            height: 44,
                            borderWidth: 1.5,
                            borderColor: '#CBD5E1',
                            borderRadius: 10,
                            paddingHorizontal: 12,
                            fontSize: 13.5,
                            backgroundColor: '#FFFFFF',
                            color: '#171817'
                          }}
                        />
                      </View>

                      {/* Row 2: Quantity & Unit */}
                      <View style={{ flexDirection: 'row', gap: 12 }}>
                        <View style={{ flex: 1 }}>
                          <T style={{ fontSize: 12.5, fontWeight: '700', color: '#334155', marginBottom: 5 }}>
                            {t.labelQuantity || 'Quantity'}
                          </T>
                          <TextInput
                            accessibilityLabel="Item quantity input"
                            value={draftQty}
                            onChangeText={setDraftQty}
                            placeholder="1"
                            keyboardType="numeric"
                            style={{
                              height: 44,
                              borderWidth: 1.5,
                              borderColor: '#CBD5E1',
                              borderRadius: 10,
                              paddingHorizontal: 12,
                              fontSize: 13.5,
                              backgroundColor: '#FFFFFF',
                              color: '#171817'
                            }}
                          />
                        </View>

                        <View style={{ flex: 1 }}>
                          <T style={{ fontSize: 12.5, fontWeight: '700', color: '#334155', marginBottom: 5 }}>
                            {t.labelUnit || 'Unit'}
                          </T>
                          <Pressable
                            accessibilityRole="button"
                            accessibilityLabel="Choose item unit"
                            onPress={() => setUnitPickerOpen(true)}
                            style={{
                              height: 44,
                              borderWidth: 1.5,
                              borderColor: '#CBD5E1',
                              borderRadius: 10,
                              paddingHorizontal: 12,
                              backgroundColor: '#FFFFFF',
                              flexDirection: 'row',
                              alignItems: 'center',
                              justifyContent: 'space-between'
                            }}
                          >
                            <T style={{ fontSize: 13.5, fontWeight: '700', color: '#171817' }}>
                              {draftUnit}
                            </T>
                            <I name="chevron-down" size={16} color="#64748B" />
                          </Pressable>
                        </View>
                      </View>

                      {/* Row 3: Rate & Amount */}
                      <View style={{ flexDirection: 'row', gap: 12 }}>
                        <View style={{ flex: 1 }}>
                          <T style={{ fontSize: 12.5, fontWeight: '700', color: '#334155', marginBottom: 5 }}>
                            {t.labelRate || 'Rate (₹)'}
                          </T>
                          <TextInput
                            accessibilityLabel="Item rate input"
                            value={draftRate}
                            onChangeText={setDraftRate}
                            placeholder="0"
                            keyboardType="numeric"
                            style={{
                              height: 44,
                              borderWidth: 1.5,
                              borderColor: '#CBD5E1',
                              borderRadius: 10,
                              paddingHorizontal: 12,
                              fontSize: 13.5,
                              backgroundColor: '#FFFFFF',
                              color: '#171817'
                            }}
                          />
                        </View>

                        <View style={{ flex: 1 }}>
                          <T style={{ fontSize: 12.5, fontWeight: '700', color: '#334155', marginBottom: 5 }}>
                            {t.labelAmount || 'Amount (₹)'}
                          </T>
                          <View
                            style={{
                              height: 44,
                              borderWidth: 1.5,
                              borderColor: '#E2E8F0',
                              borderRadius: 10,
                              paddingHorizontal: 12,
                              backgroundColor: '#F1F5F9',
                              justifyContent: 'center'
                            }}
                          >
                            <T style={{ fontSize: 14, fontWeight: '800', color: '#171817' }}>
                              ₹{((Number(draftQty) || 0) * (Number(draftRate) || 0)).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                            </T>
                          </View>
                        </View>
                      </View>

                      {/* Optional Item Details Section */}
                      <View style={{ marginTop: 4, paddingTop: 10, borderTopWidth: 1, borderColor: '#F1F5F9' }}>
                        <T style={{ fontSize: 12, fontWeight: '700', color: '#475569', marginBottom: 8 }}>
                          {t.headingAdditionalItemDetails || 'Additional item details · Optional'}
                        </T>

                        {/* Dropdown + Add Row */}
                        <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center', marginBottom: 4 }}>
                          <Pressable
                            accessibilityRole="button"
                            accessibilityLabel="Choose optional field"
                            onPress={() => setOptFieldPickerOpen(true)}
                            style={{
                              flex: 1,
                              height: 40,
                              borderWidth: 1.5,
                              borderColor: '#CBD5E1',
                              borderRadius: 8,
                              paddingHorizontal: 10,
                              backgroundColor: '#FFFFFF',
                              flexDirection: 'row',
                              alignItems: 'center',
                              justifyContent: 'space-between'
                            }}
                          >
                            <T numberOfLines={1} style={{ fontSize: 12.5, color: selectedOptFieldToAdd ? '#171817' : '#94A3B8', fontWeight: selectedOptFieldToAdd ? '700' : '500' }}>
                              {selectedOptFieldToAdd ? (OPTIONAL_ITEM_FIELDS.find(f => f.key === selectedOptFieldToAdd)?.label) : (t.chooseFieldPlaceholder || 'Choose a field')}
                            </T>
                            <I name="chevron-down" size={14} color="#64748B" />
                          </Pressable>

                          <Pressable
                            accessibilityRole="button"
                            accessibilityLabel="Add chosen field"
                            onPress={() => handleAddOptionalField()}
                            style={({ pressed }) => [{
                              backgroundColor: '#FFD500',
                              borderRadius: 8,
                              paddingHorizontal: 14,
                              height: 40,
                              alignItems: 'center',
                              justifyContent: 'center',
                              opacity: pressed ? 0.85 : 1
                            }]}
                          >
                            <T style={{ fontSize: 12.5, fontWeight: '800', color: '#171817' }}>
                              {t.btnAddField || '+ Add'}
                            </T>
                          </Pressable>
                        </View>
                        <T style={{ fontSize: 11, color: '#94A3B8', marginBottom: 10 }}>
                          {t.hintChooseField || 'Choose a field, then tap Add.'}
                        </T>

                        {/* Active Added Optional Fields Inputs */}
                        <View style={{ gap: 8 }}>
                          {activeOptionalFields.includes('size') && (
                            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                              <TextInput
                                accessibilityLabel="Item size input"
                                value={draftSize}
                                onChangeText={setDraftSize}
                                placeholder={`${t.fieldOptSize || 'Size / Dimensions'} (e.g. 600 × 600 mm)`}
                                style={{ flex: 1, height: 40, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12.5, backgroundColor: '#FFFFFF' }}
                              />
                              <Pressable onPress={() => handleRemoveOptionalField('size')} style={{ padding: 6 }}>
                                <I name="close-circle" size={18} color="#94A3B8" />
                              </Pressable>
                            </View>
                          )}

                          {activeOptionalFields.includes('brand') && (
                            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                              <TextInput
                                accessibilityLabel="Item brand input"
                                value={draftBrand}
                                onChangeText={setDraftBrand}
                                placeholder={`${t.fieldOptBrand || 'Brand / Manufacturer'} (e.g. Kajaria)`}
                                style={{ flex: 1, height: 40, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12.5, backgroundColor: '#FFFFFF' }}
                              />
                              <Pressable onPress={() => handleRemoveOptionalField('brand')} style={{ padding: 6 }}>
                                <I name="close-circle" size={18} color="#94A3B8" />
                              </Pressable>
                            </View>
                          )}

                          {activeOptionalFields.includes('hsn') && (
                            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                              <TextInput
                                accessibilityLabel="Item hsn input"
                                value={draftHsn}
                                onChangeText={setDraftHsn}
                                placeholder={`${t.fieldOptHsn || 'HSN / SAC'} (e.g. 6907)`}
                                style={{ flex: 1, height: 40, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12.5, backgroundColor: '#FFFFFF' }}
                              />
                              <Pressable onPress={() => handleRemoveOptionalField('hsn')} style={{ padding: 6 }}>
                                <I name="close-circle" size={18} color="#94A3B8" />
                              </Pressable>
                            </View>
                          )}

                          {activeOptionalFields.includes('model') && (
                            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                              <TextInput
                                accessibilityLabel="Item model input"
                                value={draftModel}
                                onChangeText={setDraftModel}
                                placeholder={`${t.fieldOptModel || 'Model / Grade'} (e.g. Double Charge)`}
                                style={{ flex: 1, height: 40, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12.5, backgroundColor: '#FFFFFF' }}
                              />
                              <Pressable onPress={() => handleRemoveOptionalField('model')} style={{ padding: 6 }}>
                                <I name="close-circle" size={18} color="#94A3B8" />
                              </Pressable>
                            </View>
                          )}

                          {activeOptionalFields.includes('notes') && (
                            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                              <TextInput
                                accessibilityLabel="Item notes input"
                                value={draftNotes}
                                onChangeText={setDraftNotes}
                                placeholder={`${t.fieldOptNotes || 'Notes'} (e.g. First grade vitrified)`}
                                style={{ flex: 1, height: 40, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12.5, backgroundColor: '#FFFFFF' }}
                              />
                              <Pressable onPress={() => handleRemoveOptionalField('notes')} style={{ padding: 6 }}>
                                <I name="close-circle" size={18} color="#94A3B8" />
                              </Pressable>
                            </View>
                          )}

                          {draftCustomFields.map((cf) => (
                            <View key={cf.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                              <TextInput
                                value={cf.label}
                                onChangeText={(val) => handleUpdateCustomField(cf.id, 'label', val)}
                                placeholder={t.placeholderCustomLabel || 'Field Name'}
                                style={{ flex: 1, height: 40, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 8, fontSize: 12, backgroundColor: '#FFFFFF' }}
                              />
                              <TextInput
                                value={cf.value}
                                onChangeText={(val) => handleUpdateCustomField(cf.id, 'value', val)}
                                placeholder={t.placeholderCustomValue || 'Field Value'}
                                style={{ flex: 1.5, height: 40, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 8, fontSize: 12, backgroundColor: '#FFFFFF' }}
                              />
                              <Pressable onPress={() => handleRemoveCustomField(cf.id)} style={{ padding: 6 }}>
                                <I name="close-circle" size={18} color="#94A3B8" />
                              </Pressable>
                            </View>
                          ))}
                        </View>
                      </View>

                      {/* Action Buttons inside Card */}
                      <View style={{ gap: 8, marginTop: 8 }}>
                        <Pressable
                          accessibilityRole="button"
                          accessibilityLabel="Save Item"
                          onPress={handleSaveDraftItem}
                          style={({ pressed }) => [{
                            backgroundColor: '#FFD500',
                            borderRadius: 12,
                            paddingVertical: 12,
                            alignItems: 'center',
                            opacity: pressed ? 0.88 : 1
                          }]}
                        >
                          <T style={{ fontSize: 14, fontWeight: '800', color: '#171817' }}>
                            {editingItemId ? (t.btnSaveChanges || 'Save Changes') : (t.btnSaveItem || 'Save Item')}
                          </T>
                        </Pressable>

                        <Pressable
                          accessibilityRole="button"
                          accessibilityLabel="Cancel item editing"
                          onPress={() => {
                            resetDraftState();
                            setAddingItem(false);
                            setEditingItemId(null);
                          }}
                          style={{
                            backgroundColor: '#FFFFFF',
                            borderWidth: 1.5,
                            borderColor: '#CBD5E1',
                            borderRadius: 12,
                            paddingVertical: 11,
                            alignItems: 'center'
                          }}
                        >
                          <T style={{ fontSize: 13.5, fontWeight: '700', color: '#475569' }}>
                            {t.btnCancelItem || 'Cancel'}
                          </T>
                        </Pressable>
                      </View>
                    </View>
                  )}
                </View>

                {/* MEASUREMENTS QUICK IMPORT CARD */}
                <View style={{ backgroundColor: '#FEF9C3', borderRadius: 16, padding: 14, borderWidth: 1, borderColor: '#FDE047' }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                    <I name="calculator-outline" size={18} color="#854D0E" />
                    <T style={{ fontSize: 14, fontWeight: '800', color: '#854D0E' }}>
                      {t.measureImportTitle || 'కొలతలు ఇంపోర్ట్ చేయండి'}
                    </T>
                  </View>
                  <T style={{ fontSize: 12, color: '#713F12', marginBottom: 10 }}>
                    {t.measureImportSub || 'ఈ డాక్యుమెంట్ కోసం సేవ్ చేసిన గది కొలతలను వాడండి'}
                  </T>
                  <Pressable
                    accessibilityRole="button"
                    onPress={handleImportSavedMeasurements}
                    style={{ backgroundColor: '#FFD500', borderRadius: 10, paddingVertical: 9, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 }}
                  >
                    <I name="download-outline" size={16} color="#171817" />
                    <T style={{ fontSize: 13, fontWeight: '800', color: '#171817' }}>
                      {t.btnUseSavedMeasurements || 'సేవ్ చేసిన కొలతలు వాడండి'}
                    </T>
                  </Pressable>
                  {!!measureImportStatus && (
                    <T style={{ fontSize: 11.5, fontWeight: '700', color: '#854D0E', marginTop: 6, textAlign: 'center' }}>
                      {measureImportStatus}
                    </T>
                  )}
                </View>

                {/* BUYER & DOCUMENT DETAILS · OPTIONAL (Screen 3) */}
                <View style={{ backgroundColor: '#FFFFFF', borderRadius: 16, borderWidth: 1, borderColor: '#E2E8F0', overflow: 'hidden' }}>
                  <Pressable
                    accessibilityRole="button"
                    onPress={() => setBuyerDocOpen(!buyerDocOpen)}
                    style={{ padding: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#FFFFFF' }}
                  >
                    <T style={{ fontSize: 14.5, fontWeight: '800', color: '#171817' }}>
                      {t.headingBuyerDocDetails || 'Buyer & Document Details · Optional'}
                    </T>
                    <I name={buyerDocOpen ? 'chevron-up' : 'chevron-down'} size={18} color="#64748B" />
                  </Pressable>

                  {buyerDocOpen && (
                    <View style={{ padding: 14, paddingTop: 0, gap: 12 }}>
                      {/* Customer Summary Bar */}
                      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#F8FAFC', borderRadius: 10, padding: 10, borderWidth: 1, borderColor: '#E2E8F0' }}>
                        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flex: 1 }}>
                          <I name="person-circle-outline" size={22} color="#475569" />
                          <T numberOfLines={1} style={{ fontSize: 13, fontWeight: '700', color: '#171817', flex: 1 }}>
                            {selectedCustomer?.name || 'Customer'} {selectedCustomer?.siteLocation ? `· ${selectedCustomer.siteLocation}` : ''}
                          </T>
                        </View>
                        <Pressable
                          accessibilityRole="button"
                          onPress={() => {
                            setCustomerToEdit(selectedCustomer);
                            setCustomerModalOpen(true);
                          }}
                          style={{ paddingHorizontal: 10, paddingVertical: 4, borderRadius: 6, backgroundColor: '#EFF6FF', borderWidth: 1, borderColor: '#BFDBFE' }}
                        >
                          <T style={{ fontSize: 11.5, fontWeight: '700', color: '#1D4ED8' }}>Edit</T>
                        </Pressable>
                      </View>

                      {/* Additional details · Optional */}
                      <View style={{ backgroundColor: '#FFFFFF', borderRadius: 12, padding: 12, borderWidth: 1, borderColor: '#E2E8F0', gap: 10 }}>
                        <T style={{ fontSize: 12.5, fontWeight: '800', color: '#171817' }}>
                          {t.headingAdditionalDocDetails || 'Additional details · Optional'}
                        </T>

                        {/* Dropdown + Add button */}
                        <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
                          <Pressable
                            accessibilityRole="button"
                            onPress={() => setDocFieldPickerOpen(true)}
                            style={{
                              flex: 1,
                              height: 40,
                              borderWidth: 1.5,
                              borderColor: '#CBD5E1',
                              borderRadius: 8,
                              paddingHorizontal: 10,
                              backgroundColor: '#FFFFFF',
                              flexDirection: 'row',
                              alignItems: 'center',
                              justifyContent: 'space-between'
                            }}
                          >
                            <T numberOfLines={1} style={{ fontSize: 12.5, color: selectedDocFieldToAdd ? '#171817' : '#94A3B8', fontWeight: selectedDocFieldToAdd ? '700' : '500' }}>
                              {selectedDocFieldToAdd ? (DOC_FIELD_OPTIONS.find(f => f.key === selectedDocFieldToAdd)?.label) : (t.chooseDocFieldPlaceholder || 'Choose a document field')}
                            </T>
                            <I name="chevron-down" size={14} color="#64748B" />
                          </Pressable>

                          <Pressable
                            accessibilityRole="button"
                            onPress={() => handleAddDocField()}
                            style={({ pressed }) => [{
                              backgroundColor: '#FFD500',
                              borderRadius: 8,
                              paddingHorizontal: 14,
                              height: 40,
                              alignItems: 'center',
                              justifyContent: 'center',
                              opacity: pressed ? 0.85 : 1
                            }]}
                          >
                            <T style={{ fontSize: 12.5, fontWeight: '800', color: '#171817' }}>
                              {t.btnAddField || '+ Add'}
                            </T>
                          </Pressable>
                        </View>

                        {/* Added Document Fields */}
                        <View style={{ gap: 10, marginTop: 4 }}>
                          {activeDocFields.includes('destination') && (
                            <View>
                              <T style={{ fontSize: 11.5, fontWeight: '700', color: '#334155', marginBottom: 4 }}>
                                {t.fieldDocDestination || 'Destination'}
                              </T>
                              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                                <TextInput
                                  value={destination}
                                  onChangeText={setDestination}
                                  placeholder="e.g. Kakinada site"
                                  style={{ flex: 1, height: 40, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12.5, backgroundColor: '#FFFFFF' }}
                                />
                                <Pressable onPress={() => handleRemoveDocField('destination')} style={{ padding: 4 }}>
                                  <I name="close-circle" size={18} color="#94A3B8" />
                                </Pressable>
                              </View>
                            </View>
                          )}

                          {activeDocFields.includes('orderNumber') && (
                            <View>
                              <T style={{ fontSize: 11.5, fontWeight: '700', color: '#334155', marginBottom: 4 }}>
                                {t.fieldDocOrderNumber || 'Order Number'}
                              </T>
                              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                                <TextInput
                                  value={orderNumber}
                                  onChangeText={setOrderNumber}
                                  placeholder="e.g. PO-024"
                                  style={{ flex: 1, height: 40, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12.5, backgroundColor: '#FFFFFF' }}
                                />
                                <Pressable onPress={() => handleRemoveDocField('orderNumber')} style={{ padding: 4 }}>
                                  <I name="close-circle" size={18} color="#94A3B8" />
                                </Pressable>
                              </View>
                            </View>
                          )}

                          {activeDocFields.includes('modeOfPayment') && (
                            <View>
                              <T style={{ fontSize: 11.5, fontWeight: '700', color: '#334155', marginBottom: 4 }}>
                                {t.fieldDocModeOfPayment || 'Mode of Payment'}
                              </T>
                              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                                <Pressable
                                  accessibilityRole="button"
                                  onPress={() => setPayMethodPickerOpen(true)}
                                  style={{
                                    flex: 1,
                                    height: 40,
                                    borderWidth: 1,
                                    borderColor: '#CBD5E1',
                                    borderRadius: 8,
                                    paddingHorizontal: 10,
                                    backgroundColor: '#FFFFFF',
                                    flexDirection: 'row',
                                    alignItems: 'center',
                                    justifyContent: 'space-between'
                                  }}
                                >
                                  <T style={{ fontSize: 12.5, fontWeight: '700', color: '#171817' }}>
                                    {modeOfPayment}
                                  </T>
                                  <I name="chevron-down" size={14} color="#64748B" />
                                </Pressable>
                                <Pressable onPress={() => handleRemoveDocField('modeOfPayment')} style={{ padding: 4 }}>
                                  <I name="close-circle" size={18} color="#94A3B8" />
                                </Pressable>
                              </View>
                            </View>
                          )}

                          {activeDocFields.includes('terms') && (
                            <View>
                              <T style={{ fontSize: 11.5, fontWeight: '700', color: '#334155', marginBottom: 4 }}>
                                {t.fieldDocTerms || 'Terms and Conditions'}
                              </T>
                              <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: 8 }}>
                                <TextInput
                                  value={terms}
                                  onChangeText={setTerms}
                                  multiline
                                  numberOfLines={3}
                                  placeholder="e.g. Materials as agreed with the customer."
                                  style={{ flex: 1, minHeight: 64, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, padding: 8, fontSize: 12, backgroundColor: '#FFFFFF', textAlignVertical: 'top' }}
                                />
                                <Pressable onPress={() => handleRemoveDocField('terms')} style={{ padding: 4 }}>
                                  <I name="close-circle" size={18} color="#94A3B8" />
                                </Pressable>
                              </View>
                            </View>
                          )}

                          {activeDocFields.includes('vehicleNo') && (
                            <View>
                              <T style={{ fontSize: 11.5, fontWeight: '700', color: '#334155', marginBottom: 4 }}>
                                {t.fieldDocVehicleNo || 'Vehicle Number'}
                              </T>
                              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                                <TextInput
                                  value={vehicleNo}
                                  onChangeText={setVehicleNo}
                                  placeholder="e.g. AP 05 TE 1234"
                                  style={{ flex: 1, height: 40, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12.5, backgroundColor: '#FFFFFF' }}
                                />
                                <Pressable onPress={() => handleRemoveDocField('vehicleNo')} style={{ padding: 4 }}>
                                  <I name="close-circle" size={18} color="#94A3B8" />
                                </Pressable>
                              </View>
                            </View>
                          )}

                          {activeDocFields.includes('ewayBillNo') && (
                            <View>
                              <T style={{ fontSize: 11.5, fontWeight: '700', color: '#334155', marginBottom: 4 }}>
                                {t.fieldDocEwayBill || 'E-way Bill Number'}
                              </T>
                              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                                <TextInput
                                  value={ewayBillNo}
                                  onChangeText={setEwayBillNo}
                                  placeholder="e.g. 101234567890"
                                  style={{ flex: 1, height: 40, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12.5, backgroundColor: '#FFFFFF' }}
                                />
                                <Pressable onPress={() => handleRemoveDocField('ewayBillNo')} style={{ padding: 4 }}>
                                  <I name="close-circle" size={18} color="#94A3B8" />
                                </Pressable>
                              </View>
                            </View>
                          )}

                          {activeDocFields.includes('driverPhone') && (
                            <View>
                              <T style={{ fontSize: 11.5, fontWeight: '700', color: '#334155', marginBottom: 4 }}>
                                {t.fieldDocDriverPhone || 'Driver Phone'}
                              </T>
                              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                                <TextInput
                                  value={driverPhone}
                                  onChangeText={setDriverPhone}
                                  placeholder="10-digit mobile"
                                  keyboardType="phone-pad"
                                  style={{ flex: 1, height: 40, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12.5, backgroundColor: '#FFFFFF' }}
                                />
                                <Pressable onPress={() => handleRemoveDocField('driverPhone')} style={{ padding: 4 }}>
                                  <I name="close-circle" size={18} color="#94A3B8" />
                                </Pressable>
                              </View>
                            </View>
                          )}

                          {activeDocFields.includes('transporterName') && (
                            <View>
                              <T style={{ fontSize: 11.5, fontWeight: '700', color: '#334155', marginBottom: 4 }}>
                                {t.fieldDocTransporter || 'Transporter Name'}
                              </T>
                              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                                <TextInput
                                  value={transporterName}
                                  onChangeText={setTransporterName}
                                  placeholder="e.g. VRL Logistics"
                                  style={{ flex: 1, height: 40, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12.5, backgroundColor: '#FFFFFF' }}
                                />
                                <Pressable onPress={() => handleRemoveDocField('transporterName')} style={{ padding: 4 }}>
                                  <I name="close-circle" size={18} color="#94A3B8" />
                                </Pressable>
                              </View>
                            </View>
                          )}
                        </View>

                        {/* Disclaimer */}
                        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 }}>
                          <I name="information-circle-outline" size={15} color="#64748B" />
                          <T style={{ fontSize: 11, color: '#64748B', flex: 1 }}>
                            {t.disclaimerModeOfPayment || 'Payment method does not record a payment.'}
                          </T>
                        </View>

                        {/* Save Details Button */}
                        <Pressable
                          accessibilityRole="button"
                          onPress={handleSaveDocDetails}
                          style={{ backgroundColor: '#FFD500', borderRadius: 10, paddingVertical: 11, alignItems: 'center', marginTop: 6 }}
                        >
                          <T style={{ fontSize: 13.5, fontWeight: '800', color: '#171817' }}>
                            {t.btnSaveDetails || 'Save Details'}
                          </T>
                        </Pressable>
                        {!!docDetailsSavedMsg && (
                          <T style={{ fontSize: 11, color: '#16A34A', fontWeight: '700', textAlign: 'center' }}>
                            {docDetailsSavedMsg}
                          </T>
                        )}
                      </View>

                      {/* Sub-accordions: Buyer details & Business details */}
                      <View style={{ backgroundColor: '#FFFFFF', borderRadius: 12, borderWidth: 1, borderColor: '#E2E8F0', overflow: 'hidden' }}>
                        <Pressable
                          onPress={() => setBuyerDetailsAccordionOpen(!buyerDetailsAccordionOpen)}
                          style={{ padding: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#F8FAFC' }}
                        >
                          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                            <I name="person-outline" size={16} color="#475569" />
                            <T style={{ fontSize: 13, fontWeight: '700', color: '#171817' }}>
                              {t.accordionBuyerDetails || 'Buyer details'}
                            </T>
                          </View>
                          <I name={buyerDetailsAccordionOpen ? 'chevron-up' : 'chevron-down'} size={16} color="#64748B" />
                        </Pressable>
                        {buyerDetailsAccordionOpen && (
                          <View style={{ padding: 12, gap: 8 }}>
                            <TextInput
                              value={custBusinessName}
                              onChangeText={setCustBusinessName}
                              placeholder="Buyer Company Name"
                              style={{ height: 38, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12, backgroundColor: '#FFFFFF' }}
                            />
                            <TextInput
                              value={buyerAddress}
                              onChangeText={setBuyerAddress}
                              placeholder="Buyer Street Address"
                              style={{ height: 38, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12, backgroundColor: '#FFFFFF' }}
                            />
                            <View style={{ flexDirection: 'row', gap: 8 }}>
                              <TextInput
                                value={buyerCity}
                                onChangeText={setBuyerCity}
                                placeholder="City"
                                style={{ flex: 1, height: 38, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12, backgroundColor: '#FFFFFF' }}
                              />
                              <TextInput
                                value={buyerPincode}
                                onChangeText={setBuyerPincode}
                                placeholder="PIN Code"
                                keyboardType="numeric"
                                style={{ flex: 1, height: 38, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12, backgroundColor: '#FFFFFF' }}
                              />
                            </View>
                            <TextInput
                              value={custGstin}
                              onChangeText={setCustGstin}
                              placeholder="Buyer GSTIN"
                              style={{ height: 38, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12, backgroundColor: '#FFFFFF' }}
                            />
                          </View>
                        )}
                      </View>

                      <View style={{ backgroundColor: '#FFFFFF', borderRadius: 12, borderWidth: 1, borderColor: '#E2E8F0', overflow: 'hidden' }}>
                        <Pressable
                          onPress={() => setBusinessDetailsAccordionOpen(!businessDetailsAccordionOpen)}
                          style={{ padding: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#F8FAFC' }}
                        >
                          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                            <I name="business-outline" size={16} color="#475569" />
                            <T style={{ fontSize: 13, fontWeight: '700', color: '#171817' }}>
                              {t.accordionBusinessDetails || 'Business details'}
                            </T>
                          </View>
                          <I name={businessDetailsAccordionOpen ? 'chevron-up' : 'chevron-down'} size={16} color="#64748B" />
                        </Pressable>
                        {businessDetailsAccordionOpen && (
                          <View style={{ padding: 12, gap: 8 }}>
                            <TextInput
                              value={businessName}
                              onChangeText={setBusinessName}
                              placeholder="Business Name"
                              style={{ height: 38, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12, backgroundColor: '#FFFFFF' }}
                            />
                            <TextInput
                              value={businessAddress}
                              onChangeText={setBusinessAddress}
                              placeholder="Business Address"
                              style={{ height: 38, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12, backgroundColor: '#FFFFFF' }}
                            />
                            <View style={{ flexDirection: 'row', gap: 8 }}>
                              <TextInput
                                value={businessCity}
                                onChangeText={setBusinessCity}
                                placeholder="City"
                                style={{ flex: 1, height: 38, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12, backgroundColor: '#FFFFFF' }}
                              />
                              <TextInput
                                value={businessStatePin}
                                onChangeText={setBusinessStatePin}
                                placeholder="State & PIN"
                                style={{ flex: 1, height: 38, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12, backgroundColor: '#FFFFFF' }}
                              />
                            </View>
                            <TextInput
                              value={contractorGstin}
                              onChangeText={setContractorGstin}
                              placeholder="Business GSTIN"
                              style={{ height: 38, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, fontSize: 12, backgroundColor: '#FFFFFF' }}
                            />
                          </View>
                        )}
                      </View>

                      <T style={{ fontSize: 11, color: '#64748B', textAlign: 'center' }}>
                        {t.noticeSavedDetailsAppear || 'Saved details appear in your document.'}
                      </T>
                    </View>
                  )}
                </View>

                {/* SUBTOTAL, DISCOUNT, TAX & GRAND TOTAL CARD */}
                <View style={{ backgroundColor: '#FFFFFF', borderRadius: 16, padding: 16, borderWidth: 1, borderColor: '#E2E8F0' }}>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }}>
                    <T style={{ fontSize: 13.5, color: '#667085', fontWeight: '600' }}>Subtotal</T>
                    <T style={{ fontSize: 14.5, fontWeight: '800', color: '#171817' }}>
                      ₹{totalData.subtotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </T>
                  </View>
                  <View style={{ flexDirection: 'row', gap: 10, marginVertical: 6 }}>
                    <View style={{ flex: 1 }}>
                      <T style={{ fontSize: 11, color: '#667085', marginBottom: 4 }}>Discount (₹)</T>
                      <TextInput
                        value={discount}
                        onChangeText={setDiscount}
                        keyboardType="numeric"
                        style={{ borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, padding: 6, fontSize: 12, backgroundColor: '#FFFFFF' }}
                      />
                    </View>
                    <View style={{ flex: 1 }}>
                      <T style={{ fontSize: 11, color: '#667085', marginBottom: 4 }}>Tax (%)</T>
                      <TextInput
                        value={taxPercent}
                        onChangeText={setTaxPercent}
                        keyboardType="numeric"
                        style={{ borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, padding: 6, fontSize: 12, backgroundColor: '#FFFFFF' }}
                      />
                    </View>
                  </View>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 10, paddingTop: 10, borderTopWidth: 1, borderColor: '#F1F5F9' }}>
                    <T style={{ fontSize: 15, fontWeight: '900', color: '#171817' }}>Grand Total</T>
                    <T style={{ fontSize: 18, fontWeight: '900', color: '#171817' }}>
                      ₹{totalData.total.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </T>
                  </View>
                </View>
              </View>
            )}

            {step === 2 && (
              /* ============================================================== */
              /* STEP 2: CHOOSE TEMPLATE & PREVIEW (Before Generation)           */
              /* ============================================================== */
              <View style={{ gap: 12 }}>
                {/* Template Selection Section with Miniatures */}
                <View style={{ backgroundColor: '#FFFFFF', borderRadius: 16, padding: 14, borderWidth: 1, borderColor: '#E2E8F0' }}>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                    <View>
                      <T style={{ fontSize: 15, fontWeight: '800', color: '#171817' }}>
                        {t.chooseTemplateTitle || 'టెంప్లేట్ ఎంచుకోండి'}
                      </T>
                      <T style={{ fontSize: 11, color: '#667085' }}>
                        {docKind === 'quotation' ? 'Quotation Layouts' : 'Invoice Layouts'} • {pageSize.toUpperCase()}
                      </T>
                    </View>
                    <Pressable
                      onPress={() => setTemplatePickerOpen(true)}
                      style={{ paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, backgroundColor: '#FEF08A' }}
                    >
                      <T style={{ fontSize: 11, fontWeight: '800', color: '#854D0E' }}>All Templates</T>
                    </Pressable>
                  </View>

                  <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10, paddingVertical: 4 }}>
                    {documentTemplates.slice(0, 7).map((tmpl) => {
                      const isSelected = tmpl.id === template;
                      const k = tmpl.id === 'classic_ledger' ? '01' : tmpl.id === 'amber_grid' ? '02' : tmpl.id === 'olive_grid' ? '03' : tmpl.id === 'compact_trade' ? '04' : tmpl.id === 'blue_timesheet' ? '05' : tmpl.id === 'corporate_sales' ? '07' : '08';
                      const name = t['tmpl' + k + 'Name'] || tmpl.name;
                      return (
                        <Pressable
                          key={tmpl.id}
                          onPress={() => setTemplate(tmpl.id)}
                          style={{
                            width: 145,
                            padding: 8,
                            borderRadius: 12,
                            borderWidth: isSelected ? 2 : 1,
                            borderColor: isSelected ? '#FFD500' : '#E2E8F0',
                            backgroundColor: isSelected ? '#FFFDF0' : '#F8FAFC'
                          }}
                        >
                          <View style={{ height: 75, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: tmpl.color || '#CBD5E1', borderRadius: 6, padding: 4, marginBottom: 6, justifyContent: 'space-between' }}>
                            <View style={{ height: 11, backgroundColor: tmpl.color || '#171817', borderRadius: 2 }} />
                            <View style={{ gap: 2.5 }}>
                              <View style={{ height: 3.5, backgroundColor: '#CBD5E1', width: '85%' }} />
                              <View style={{ height: 3.5, backgroundColor: '#E2E8F0', width: '65%' }} />
                              <View style={{ height: 3.5, backgroundColor: '#F1F5F9', width: '90%' }} />
                            </View>
                            <View style={{ height: 6, backgroundColor: isSelected ? '#FFD500' : '#E2E8F0', width: '100%', borderRadius: 1 }} />
                          </View>
                          <T style={{ fontSize: 11.5, fontWeight: isSelected ? '800' : '600', color: '#171817' }} numberOfLines={1}>
                            {name}
                          </T>
                          {isSelected ? (
                            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 3, marginTop: 4 }}>
                              <I name="checkmark-circle" size={13} color="#854D0E" />
                              <T style={{ fontSize: 10, fontWeight: '800', color: '#854D0E' }}>Selected</T>
                            </View>
                          ) : (
                            <T style={{ fontSize: 10, color: '#94A3B8', marginTop: 4 }}>Tap to choose</T>
                          )}
                        </Pressable>
                      );
                    })}
                  </ScrollView>

                  <Pressable
                    onPress={() => {
                      setPreviewTemplateTarget(template);
                      setPreviewModalOpen(true);
                    }}
                    style={{ backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 10, padding: 10, alignItems: 'center', flexDirection: 'row', justifyContent: 'center', gap: 6, marginTop: 10 }}
                  >
                    <I name="eye-outline" size={16} color="#171817" />
                    <T style={{ fontSize: 12.5, fontWeight: '800', color: '#171817' }}>Full Page Preview ({selectedTemplateName})</T>
                  </Pressable>
                </View>

                {/* Summary Card */}
                <View style={{ backgroundColor: '#FFFFFF', borderRadius: 16, padding: 14, borderWidth: 1, borderColor: '#E2E8F0' }}>
                  <T style={{ fontSize: 14, fontWeight: '800', color: '#171817', marginBottom: 8 }}>Summary</T>
                  <T style={{ fontSize: 12, color: '#475569' }}>Customer: <T style={{ fontWeight: '700', color: '#171817' }}>{selectedCustomer?.name}</T></T>
                  <T style={{ fontSize: 12, color: '#475569' }}>Site: <T style={{ fontWeight: '700', color: '#171817' }}>{siteLocation || 'None'}</T></T>
                  <T style={{ fontSize: 12, color: '#475569' }}>Date: <T style={{ fontWeight: '700', color: '#171817' }}>{startDate}</T></T>
                  <T style={{ fontSize: 12, color: '#475569' }}>Valid Till: <T style={{ fontWeight: '700', color: '#171817' }}>{endDate}</T></T>
                  <T style={{ fontSize: 12, color: '#475569' }}>Items: <T style={{ fontWeight: '700', color: '#171817' }}>{items.length}</T></T>
                  <T style={{ fontSize: 14, fontWeight: '900', color: '#171817', marginTop: 8 }}>Total: ₹{totalData.total.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</T>
                  <T style={{ fontSize: 11, color: '#667085', marginTop: 2 }}>{numberToIndianWords(totalData.total)}</T>
                </View>
              </View>
            )}
          </ScrollView>

          {/* 6. Fixed / Docked Bottom Action Button */}
          <View
            style={{
              paddingHorizontal: 16,
              paddingVertical: 12,
              backgroundColor: '#FFFFFF',
              borderTopWidth: 1,
              borderColor: '#E2E8F0',
              flexDirection: 'row',
              gap: 10
            }}
          >
            {step === 0 && (
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Add Details"
                onPress={() => setStep(1)}
                style={({ pressed }) => [{
                  flex: 1,
                  backgroundColor: '#FFD500',
                  borderRadius: 14,
                  paddingVertical: 13,
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexDirection: 'row',
                  gap: 8,
                  shadowColor: '#EAB308',
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.25,
                  shadowRadius: 4,
                  elevation: 3,
                  opacity: pressed ? 0.88 : 1
                }]}
              >
                <T style={{ fontSize: 15, fontWeight: '900', color: '#171817' }}>
                  {t.btnContinueAddDetails || 'వివరాలు జోడించండి'}
                </T>
                <I name="arrow-forward" size={18} color="#171817" />
              </Pressable>
            )}

            {step === 1 && (
              <>
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel="Back"
                  onPress={() => handleGoToStep(0)}
                  style={{ flex: 1, borderWidth: 1.5, borderColor: '#CBD5E1', borderRadius: 14, paddingVertical: 12, alignItems: 'center', justifyContent: 'center' }}
                >
                  <T style={{ fontSize: 14, fontWeight: '800', color: '#171817' }}>
                    {t.btnBack || 'Back'}
                  </T>
                </Pressable>
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel="Continue to Template Selection"
                  onPress={() => handleGoToStep(2)}
                  style={({ pressed }) => [{
                    flex: 2,
                    backgroundColor: '#FFD500',
                    borderRadius: 14,
                    paddingVertical: 12,
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexDirection: 'row',
                    gap: 6,
                    opacity: pressed ? 0.88 : 1
                  }]}
                >
                  <T style={{ fontSize: 14.5, fontWeight: '900', color: '#171817' }}>
                    {t.btnContinueChooseTemplate || 'Choose Template ➔'}
                  </T>
                </Pressable>
              </>
            )}

            {step === 2 && (
              <>
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel="Back"
                  onPress={() => setStep(1)}
                  style={{ flex: 1, borderWidth: 1.5, borderColor: '#CBD5E1', borderRadius: 14, paddingVertical: 12, alignItems: 'center', justifyContent: 'center' }}
                >
                  <T style={{ fontSize: 14, fontWeight: '800', color: '#171817' }}>Back</T>
                </Pressable>

                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel="Preview"
                  onPress={() => {
                    setPreviewTemplateTarget(template);
                    setPreviewModalOpen(true);
                  }}
                  style={{ flex: 1, borderWidth: 1.5, borderColor: '#CBD5E1', borderRadius: 14, paddingVertical: 12, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 4 }}
                >
                  <I name="eye-outline" size={16} color="#171817" />
                  <T style={{ fontSize: 13, fontWeight: '800', color: '#171817' }}>Preview</T>
                </Pressable>

                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel="Generate Document"
                  disabled={busy}
                  onPress={handleFinalSave}
                  style={({ pressed }) => [{
                    flex: 2.2,
                    backgroundColor: '#FFD500',
                    borderRadius: 14,
                    paddingVertical: 12,
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexDirection: 'row',
                    gap: 6,
                    shadowColor: '#EAB308',
                    shadowOffset: { width: 0, height: 2 },
                    shadowOpacity: 0.25,
                    shadowRadius: 4,
                    elevation: 3,
                    opacity: pressed || busy ? 0.88 : 1
                  }]}
                >
                  <I name="flash" size={17} color="#171817" />
                  <T style={{ fontSize: 14.5, fontWeight: '900', color: '#171817' }}>
                    {busy ? 'Generating…' : (docKind === 'quotation' ? (t.btnGenerateQuotation || 'Generate Quotation') : (t.btnGenerateInvoice || 'Generate Invoice'))}
                  </T>
                </Pressable>
              </>
            )}
          </View>
        </View>
      </View>

      {/* Sub-Modal 1: Template Picker Modal (Images 02 & 03) */}
      <TemplatePickerModal
        visible={templatePickerOpen}
        onClose={() => setTemplatePickerOpen(false)}
        appliedTemplate={template}
        onApply={(newTmpl) => setTemplate(newTmpl)}
        onOpenPreview={(targetTmpl) => {
          setPreviewTemplateTarget(targetTmpl);
          setPreviewModalOpen(true);
        }}
        kind={docKind}
        onKindChange={(k) => setDocKind(k)}
        appLang={appLang}
        pageSize={pageSize}
      />

      {/* Sub-Modal 2: Template Preview Modal (Images 04 & 05) */}
      <TemplatePreviewModal
        visible={previewModalOpen}
        onClose={() => setPreviewModalOpen(false)}
        doc={currentDocPayload}
        business={w.business}
        templateId={previewTemplateTarget}
        onTemplateChange={(newTmpl) => setTemplate(newTmpl)}
        onEdit={() => {
          setPreviewModalOpen(false);
          setStep(1);
        }}
        onUseTemplate={(confirmedTmpl) => {
          setTemplate(confirmedTmpl);
          setPreviewModalOpen(false);
        }}
        printDoc={printDoc}
        appLang={appLang}
      />

      {/* Sub-Modal 3: Customer Modal (Add or Edit Customer) */}
      <CustomerModal
        visible={customerModalOpen}
        initial={customerToEdit || {}}
        w={w}
        service={service}
        appLang={appLang}
        busy={busy}
        onClose={() => {
          setCustomerModalOpen(false);
          setCustomerToEdit(null);
        }}
        onSave={handleCustomerSaved}
      />

      {/* Sub-Modal: Unsaved Item Confirmation */}
      <Modal visible={unsavedModalOpen} transparent animationType="fade" onRequestClose={() => setUnsavedModalOpen(false)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 20 }}>
          <View style={{ backgroundColor: '#FFFFFF', borderRadius: 16, padding: 20, width: '100%', maxWidth: 380, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.15, shadowRadius: 10, elevation: 6 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 12 }}>
              <View style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: '#FEF3C7', alignItems: 'center', justifyContent: 'center' }}>
                <I name="alert-circle" size={22} color="#D97706" />
              </View>
              <T style={{ fontSize: 16, fontWeight: '800', color: '#171817', flex: 1 }}>
                {t.alertUnsavedItemTitle || 'Unsaved Item'}
              </T>
            </View>
            <T style={{ fontSize: 13, color: '#475569', lineHeight: 18, marginBottom: 18 }}>
              {t.alertUnsavedItemMsg || 'You have entered item details that have not been saved yet. Do you want to save this item or discard your changes?'}
            </T>
            <View style={{ gap: 8 }}>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Save Item"
                onPress={() => {
                  const saved = handleSaveDraftItem();
                  if (saved !== false) {
                    setUnsavedModalOpen(false);
                    if (pendingNavTarget === -1) {
                      onClose();
                    } else if (pendingNavTarget !== null) {
                      setStep(pendingNavTarget);
                    }
                    setPendingNavTarget(null);
                  }
                }}
                style={{ backgroundColor: '#FFD500', borderRadius: 10, paddingVertical: 12, alignItems: 'center' }}
              >
                <T style={{ fontSize: 14, fontWeight: '800', color: '#171817' }}>
                  {t.btnSaveItem || 'Save Item'}
                </T>
              </Pressable>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Discard"
                onPress={() => {
                  resetDraftState();
                  setAddingItem(false);
                  setEditingItemId(null);
                  setUnsavedModalOpen(false);
                  if (pendingNavTarget === -1) {
                    onClose();
                  } else if (pendingNavTarget !== null) {
                    setStep(pendingNavTarget);
                  }
                  setPendingNavTarget(null);
                }}
                style={{ backgroundColor: '#FEE2E2', borderRadius: 10, paddingVertical: 12, alignItems: 'center' }}
              >
                <T style={{ fontSize: 13.5, fontWeight: '800', color: '#DC2626' }}>
                  {t.btnDiscardItem || 'Discard'}
                </T>
              </Pressable>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Cancel"
                onPress={() => {
                  setUnsavedModalOpen(false);
                  setPendingNavTarget(null);
                }}
                style={{ paddingVertical: 10, alignItems: 'center' }}
              >
                <T style={{ fontSize: 13, fontWeight: '700', color: '#64748B' }}>
                  {t.btnCancelPrompt || t.btnCancelItem || 'Cancel'}
                </T>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      {/* Sub-Modal: Unit Selector */}
      <Modal visible={unitPickerOpen} transparent animationType="fade" onRequestClose={() => setUnitPickerOpen(false)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 20 }}>
          <View style={{ backgroundColor: '#FFFFFF', borderRadius: 16, padding: 18, width: '100%', maxWidth: 380, maxHeight: '80%', shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.15, shadowRadius: 10, elevation: 6 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <T style={{ fontSize: 16, fontWeight: '800', color: '#171817' }}>
                {t.chooseUnitTitle || 'Choose Unit'}
              </T>
              <Pressable accessibilityRole="button" accessibilityLabel="Close unit picker" onPress={() => setUnitPickerOpen(false)} style={{ padding: 4 }}>
                <I name="close" size={20} color="#64748B" />
              </Pressable>
            </View>
            <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, height: 38, marginBottom: 12 }}>
              <I name="search" size={16} color="#94A3B8" style={{ marginRight: 6 }} />
              <TextInput
                value={unitSearchText}
                onChangeText={setUnitSearchText}
                placeholder={t.searchUnitPlaceholder || 'Search unit…'}
                style={{ flex: 1, fontSize: 13, color: '#171817' }}
              />
              {unitSearchText.length > 0 && (
                <Pressable accessibilityRole="button" accessibilityLabel="Clear search" onPress={() => setUnitSearchText('')}>
                  <I name="close-circle" size={16} color="#94A3B8" />
                </Pressable>
              )}
            </View>
            <ScrollView style={{ maxHeight: 260 }} showsVerticalScrollIndicator={false}>
              {UNIT_METADATA.filter(u =>
                !unitSearchText.trim() ||
                u.code.toLowerCase().includes(unitSearchText.toLowerCase()) ||
                u.name.toLowerCase().includes(unitSearchText.toLowerCase())
              ).map((u) => {
                const isSelected = draftUnit === u.code;
                return (
                  <Pressable
                    key={u.code}
                    accessibilityRole="button"
                    accessibilityLabel={u.name}
                    onPress={() => {
                      setDraftUnit(u.code);
                      setUnitSearchText('');
                      setUnitPickerOpen(false);
                    }}
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      paddingVertical: 10,
                      paddingHorizontal: 12,
                      borderRadius: 8,
                      backgroundColor: isSelected ? '#FEF08A' : 'transparent',
                      marginBottom: 2
                    }}
                  >
                    <T style={{ fontSize: 13.5, fontWeight: isSelected ? '800' : '600', color: '#171817' }}>
                      {u.name}
                    </T>
                    {isSelected && <I name="checkmark" size={16} color="#854D0E" />}
                  </Pressable>
                );
              })}
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Sub-Modal: Optional Field Selector */}
      <Modal visible={optFieldPickerOpen} transparent animationType="fade" onRequestClose={() => setOptFieldPickerOpen(false)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 20 }}>
          <View style={{ backgroundColor: '#FFFFFF', borderRadius: 16, padding: 18, width: '100%', maxWidth: 380, maxHeight: '80%', shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.15, shadowRadius: 10, elevation: 6 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <T style={{ fontSize: 16, fontWeight: '800', color: '#171817' }}>
                {t.chooseFieldPlaceholder || 'Choose a field'}
              </T>
              <Pressable accessibilityRole="button" accessibilityLabel="Close field picker" onPress={() => setOptFieldPickerOpen(false)} style={{ padding: 4 }}>
                <I name="close" size={20} color="#64748B" />
              </Pressable>
            </View>
            <ScrollView style={{ maxHeight: 280 }} showsVerticalScrollIndicator={false}>
              {OPTIONAL_ITEM_FIELDS.map((opt) => {
                const isAdded = activeOptionalFields.includes(opt.key) && opt.key !== 'custom';
                return (
                  <Pressable
                    key={opt.key}
                    accessibilityRole="button"
                    accessibilityLabel={opt.label}
                    disabled={isAdded}
                    onPress={() => handleAddOptionalField(opt.key)}
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      paddingVertical: 11,
                      paddingHorizontal: 12,
                      borderRadius: 8,
                      backgroundColor: isAdded ? '#F1F5F9' : 'transparent',
                      opacity: isAdded ? 0.5 : 1,
                      marginBottom: 2
                    }}
                  >
                    <T style={{ fontSize: 13.5, fontWeight: '700', color: isAdded ? '#94A3B8' : '#171817' }}>
                      {opt.label}
                    </T>
                    {isAdded ? (
                      <T style={{ fontSize: 11, color: '#94A3B8' }}>Added</T>
                    ) : (
                      <I name="add-circle-outline" size={18} color="#FFD500" />
                    )}
                  </Pressable>
                );
              })}
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Sub-Modal: Document Field Selector */}
      <Modal visible={docFieldPickerOpen} transparent animationType="fade" onRequestClose={() => setDocFieldPickerOpen(false)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 20 }}>
          <View style={{ backgroundColor: '#FFFFFF', borderRadius: 16, padding: 18, width: '100%', maxWidth: 380, maxHeight: '80%', shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.15, shadowRadius: 10, elevation: 6 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <T style={{ fontSize: 16, fontWeight: '800', color: '#171817' }}>
                {t.chooseDocFieldPlaceholder || 'Choose a document field'}
              </T>
              <Pressable accessibilityRole="button" accessibilityLabel="Close document field picker" onPress={() => setDocFieldPickerOpen(false)} style={{ padding: 4 }}>
                <I name="close" size={20} color="#64748B" />
              </Pressable>
            </View>
            <ScrollView style={{ maxHeight: 280 }} showsVerticalScrollIndicator={false}>
              {DOC_FIELD_OPTIONS.map((field) => {
                const isAdded = activeDocFields.includes(field.key);
                return (
                  <Pressable
                    key={field.key}
                    accessibilityRole="button"
                    accessibilityLabel={field.label}
                    disabled={isAdded}
                    onPress={() => handleAddDocField(field.key)}
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      paddingVertical: 11,
                      paddingHorizontal: 12,
                      borderRadius: 8,
                      backgroundColor: isAdded ? '#F1F5F9' : 'transparent',
                      opacity: isAdded ? 0.5 : 1,
                      marginBottom: 2
                    }}
                  >
                    <T style={{ fontSize: 13.5, fontWeight: '700', color: isAdded ? '#94A3B8' : '#171817' }}>
                      {field.label}
                    </T>
                    {isAdded ? (
                      <T style={{ fontSize: 11, color: '#94A3B8' }}>Added</T>
                    ) : (
                      <I name="add-circle-outline" size={18} color="#FFD500" />
                    )}
                  </Pressable>
                );
              })}
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Sub-Modal: Payment Method Selector */}
      <Modal visible={payMethodPickerOpen} transparent animationType="fade" onRequestClose={() => setPayMethodPickerOpen(false)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 20 }}>
          <View style={{ backgroundColor: '#FFFFFF', borderRadius: 16, padding: 18, width: '100%', maxWidth: 360, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.15, shadowRadius: 10, elevation: 6 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <T style={{ fontSize: 16, fontWeight: '800', color: '#171817' }}>
                {t.fieldDocModeOfPayment || 'Mode of Payment'}
              </T>
              <Pressable accessibilityRole="button" accessibilityLabel="Close payment method picker" onPress={() => setPayMethodPickerOpen(false)} style={{ padding: 4 }}>
                <I name="close" size={20} color="#64748B" />
              </Pressable>
            </View>
            <View style={{ gap: 4 }}>
              {PAYMENT_METHODS.map((method) => {
                const isSelected = modeOfPayment === method;
                return (
                  <Pressable
                    key={method}
                    accessibilityRole="button"
                    accessibilityLabel={method}
                    onPress={() => {
                      setModeOfPayment(method);
                      setPayMethodPickerOpen(false);
                    }}
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      paddingVertical: 12,
                      paddingHorizontal: 14,
                      borderRadius: 8,
                      backgroundColor: isSelected ? '#FEF08A' : '#F8FAFC',
                      borderWidth: 1,
                      borderColor: isSelected ? '#FACC15' : '#E2E8F0'
                    }}
                  >
                    <T style={{ fontSize: 14, fontWeight: isSelected ? '800' : '600', color: '#171817' }}>
                      {method}
                    </T>
                    {isSelected && <I name="checkmark" size={18} color="#854D0E" />}
                  </Pressable>
                );
              })}
            </View>
          </View>
        </View>
      </Modal>
    </Modal>
  );
}
