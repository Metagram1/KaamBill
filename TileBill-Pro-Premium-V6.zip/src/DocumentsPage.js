import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  Platform,
  useWindowDimensions
} from 'react-native';
import { I, T, Empty } from './ui';
import { money } from './domain.cjs';
import { getStrings } from './i18n';
import { formatTeluguDate } from './CustomersPage';

export default function DocumentsPage({
  w,
  service,
  appLang = 'te',
  open,
  setModal,
  printDoc,
  shareDoc
}) {
  const t = getStrings(appLang);
  const { width } = useWindowDimensions();

  const [q, setQ] = useState('');
  const [kindTab, setKindTab] = useState('all'); // 'all' | 'invoice' | 'quotation'
  const [payFilter, setPayFilter] = useState('all'); // 'all' | 'unpaid' | 'paid'
  const [dateFilter, setDateFilter] = useState('all'); // 'all' | 'this_month' | 'last_month'
  const [payMenuOpen, setPayMenuOpen] = useState(false);
  const [dateMenuOpen, setDateMenuOpen] = useState(false);

  // Scope to current service
  const serviceDocs = w.documents.filter(d => d.service === service || !d.service);
  const invoices = serviceDocs.filter(d => d.kind === 'invoice');

  // KPI calculations: Quotations NEVER inflate total billed or pending balances!
  const totalBilled = invoices.reduce((s, d) => s + (d.total || 0), 0);
  const totalPaid = invoices.reduce((s, d) => s + (d.paid || 0), 0);
  const totalPending = Math.max(0, invoices.reduce((s, d) => s + Math.max(0, (d.total || 0) - (d.paid || 0)), 0));

  // Date boundaries for date filters
  const now = new Date();
  const thisMonthPrefix = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  const lastMonthDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const lastMonthPrefix = `${lastMonthDate.getFullYear()}-${String(lastMonthDate.getMonth() + 1).padStart(2, '0')}`;

  const filtered = serviceDocs.filter(d => {
    // 1. Kind Tab filter
    if (kindTab !== 'all' && d.kind !== kindTab) {
      return false;
    }

    // 2. Payment status filter
    if (payFilter === 'unpaid') {
      if (d.kind === 'invoice' && (d.paid || 0) >= (d.total || 0)) return false;
    } else if (payFilter === 'paid') {
      if (d.kind !== 'invoice' || (d.paid || 0) < (d.total || 0)) return false;
    }

    // 3. Date filter
    if (dateFilter === 'this_month') {
      if (!d.date || !d.date.startsWith(thisMonthPrefix)) return false;
    } else if (dateFilter === 'last_month') {
      if (!d.date || !d.date.startsWith(lastMonthPrefix)) return false;
    }

    // 4. Search text (name, bill number, site location, title)
    const query = q.trim().toLowerCase();
    if (query) {
      const searchTarget = (
        (d.number || '') + ' ' +
        (d.title || '') + ' ' +
        (d.customer?.name || '') + ' ' +
        (d.customer?.phone || '') + ' ' +
        (d.customer?.siteLocation || '') + ' ' +
        (d.siteLocation || '') + ' ' +
        (d.project?.name || '')
      ).toLowerCase();
      if (!searchTarget.includes(query)) return false;
    }

    return true;
  });

  return (
    <View style={{ width: '100%' }}>
      {/* 1. Header: Title, Subtitle and + New Bill Button */}
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'flex-start',
          justifyContent: 'space-between',
          marginBottom: 14,
          paddingHorizontal: 2
        }}
      >
        <View style={{ flex: 1, paddingRight: 10 }}>
          <T style={{ fontSize: 24, fontWeight: '900', color: '#171817' }}>
            {t.docsPageTitle}
          </T>
          <T style={{ fontSize: 13, fontWeight: '500', color: '#667085', marginTop: 3 }}>
            {t.docsPageSub}
          </T>
        </View>

        <Pressable
          accessibilityRole="button"
          accessibilityLabel={t.docsBtnNew}
          onPress={() => open('document', { kind: 'invoice' })}
          style={({ pressed }) => [{
            backgroundColor: '#FFD500',
            borderRadius: 14,
            paddingHorizontal: 16,
            paddingVertical: 10,
            flexDirection: 'row',
            alignItems: 'center',
            gap: 6,
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.1,
            shadowRadius: 4,
            elevation: 2,
            opacity: pressed ? 0.85 : 1
          }]}
        >
          <I name="add" size={19} color="#171817" />
          <T style={{ fontSize: 14.5, fontWeight: '900', color: '#171817' }}>
            {t.docsBtnNew}
          </T>
        </Pressable>
      </View>

      {/* 2. Three Financial KPI Cards in one row */}
      <View
        style={{
          backgroundColor: '#FFFFFF',
          borderRadius: 18,
          borderWidth: 1.2,
          borderColor: '#F1F5F9',
          paddingVertical: 14,
          paddingHorizontal: 12,
          flexDirection: 'row',
          alignItems: 'center',
          marginBottom: 14,
          shadowColor: '#0F172A',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.04,
          shadowRadius: 6,
          elevation: 2
        }}
      >
        {/* KPI 1: Total Billed */}
        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <View
            style={{
              width: 38,
              height: 38,
              borderRadius: 10,
              backgroundColor: '#F1F5F9',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            <I name="receipt-outline" size={19} color="#475569" />
          </View>
          <View style={{ flex: 1, minWidth: 0 }}>
            <T numberOfLines={1} style={{ fontSize: 11.5, fontWeight: '600', color: '#667085' }}>
              {t.docsKpiTotal}
            </T>
            <T numberOfLines={1} style={{ fontSize: 18, fontWeight: '900', color: '#171817', marginTop: 1 }}>
              ₹{totalBilled.toLocaleString('en-IN')}
            </T>
          </View>
        </View>

        {/* Divider 1 */}
        <View style={{ width: 1, height: 32, backgroundColor: '#E2E8F0', marginHorizontal: 6 }} />

        {/* KPI 2: Received */}
        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <View
            style={{
              width: 38,
              height: 38,
              borderRadius: 10,
              backgroundColor: '#DCFCE7',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            <I name="checkmark" size={19} color="#16A34A" />
          </View>
          <View style={{ flex: 1, minWidth: 0 }}>
            <T numberOfLines={1} style={{ fontSize: 11.5, fontWeight: '600', color: '#667085' }}>
              {t.docsKpiReceived}
            </T>
            <T numberOfLines={1} style={{ fontSize: 18, fontWeight: '900', color: '#171817', marginTop: 1 }}>
              ₹{totalPaid.toLocaleString('en-IN')}
            </T>
          </View>
        </View>

        {/* Divider 2 */}
        <View style={{ width: 1, height: 32, backgroundColor: '#E2E8F0', marginHorizontal: 6 }} />

        {/* KPI 3: Pending */}
        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <View
            style={{
              width: 38,
              height: 38,
              borderRadius: 10,
              backgroundColor: '#FFEDD5',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            <I name="time" size={19} color="#C2410C" />
          </View>
          <View style={{ flex: 1, minWidth: 0 }}>
            <T numberOfLines={1} style={{ fontSize: 11.5, fontWeight: '600', color: '#C2410C' }}>
              {t.docsKpiPending}
            </T>
            <T numberOfLines={1} style={{ fontSize: 18, fontWeight: '900', color: '#171817', marginTop: 1 }}>
              ₹{totalPending.toLocaleString('en-IN')}
            </T>
          </View>
        </View>
      </View>

      {/* 3. Segmented Tab Bar (📑 అన్నీ | 📄 బిల్లులు | 📝 కొటేషన్లు) */}
      <View
        style={{
          backgroundColor: '#FFFFFF',
          borderRadius: 14,
          borderWidth: 1.2,
          borderColor: '#E5E7EB',
          padding: 4,
          flexDirection: 'row',
          marginBottom: 12
        }}
      >
        {[
          { key: 'all', label: t.docsTabAll, icon: 'documents-outline' },
          { key: 'invoice', label: t.docsTabBills, icon: 'receipt-outline' },
          { key: 'quotation', label: t.docsTabQuotes, icon: 'create-outline' }
        ].map(tb => {
          const active = kindTab === tb.key;
          return (
            <Pressable
              key={tb.key}
              accessibilityRole="button"
              accessibilityLabel={tb.label}
              onPress={() => setKindTab(tb.key)}
              style={({ pressed }) => [{
                flex: 1,
                paddingVertical: 9,
                borderRadius: 10,
                backgroundColor: active ? '#171817' : 'transparent',
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 6,
                opacity: pressed ? 0.85 : 1
              }]}
            >
              <I name={tb.icon} size={16} color={active ? '#FFFFFF' : '#667085'} />
              <T style={{ fontSize: 13.5, fontWeight: active ? '800' : '600', color: active ? '#FFFFFF' : '#667085' }}>
                {tb.label}
              </T>
            </Pressable>
          );
        })}
      </View>

      {/* 4. Full-width Search Input */}
      <View
        style={{
          backgroundColor: '#FFFFFF',
          borderRadius: 14,
          borderWidth: 1.2,
          borderColor: '#E5E7EB',
          height: 48,
          paddingHorizontal: 14,
          flexDirection: 'row',
          alignItems: 'center',
          gap: 10,
          marginBottom: 10,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 1 },
          shadowOpacity: 0.03,
          shadowRadius: 3,
          elevation: 1
        }}
      >
        <I name="search" size={19} color="#667085" />
        <TextInput
          value={q}
          onChangeText={setQ}
          placeholder={t.docsSearchPlaceholder}
          placeholderTextColor="#9CA3AF"
          style={{
            flex: 1,
            fontSize: 14.5,
            color: '#171817',
            fontWeight: '500'
          }}
        />
        {!!q && (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Clear search"
            onPress={() => setQ('')}
            style={{ padding: 4 }}
          >
            <I name="close-circle" size={18} color="#9CA3AF" />
          </Pressable>
        )}
      </View>

      {/* 5. Dropdown Filters Row: Payment Status & Date */}
      <View style={{ flexDirection: 'row', gap: 10, marginBottom: 14 }}>
        {/* Payment filter dropdown button */}
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={t.docsFilterPayment}
          onPress={() => { setPayMenuOpen(!payMenuOpen); setDateMenuOpen(false); }}
          style={({ pressed }) => [{
            flex: 1,
            backgroundColor: '#FFFFFF',
            borderWidth: 1.2,
            borderColor: payFilter !== 'all' ? '#171817' : '#E5E7EB',
            borderRadius: 12,
            paddingVertical: 9,
            paddingHorizontal: 12,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            opacity: pressed ? 0.85 : 1
          }]}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, flex: 1, minWidth: 0 }}>
            <I name="filter" size={15} color="#171817" />
            <T numberOfLines={1} style={{ fontSize: 13, fontWeight: '700', color: '#171817' }}>
              {payFilter === 'unpaid' ? t.docsStatusUnpaid : payFilter === 'paid' ? t.docsStatusPaid : t.docsFilterPayment}
            </T>
          </View>
          <I name="chevron-down" size={13} color="#667085" />
        </Pressable>

        {/* Date filter dropdown button */}
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={t.docsFilterDate}
          onPress={() => { setDateMenuOpen(!dateMenuOpen); setPayMenuOpen(false); }}
          style={({ pressed }) => [{
            flex: 1,
            backgroundColor: '#FFFFFF',
            borderWidth: 1.2,
            borderColor: dateFilter !== 'all' ? '#171817' : '#E5E7EB',
            borderRadius: 12,
            paddingVertical: 9,
            paddingHorizontal: 12,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            opacity: pressed ? 0.85 : 1
          }]}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, flex: 1, minWidth: 0 }}>
            <I name="calendar-outline" size={15} color="#171817" />
            <T numberOfLines={1} style={{ fontSize: 13, fontWeight: '700', color: '#171817' }}>
              {dateFilter === 'this_month' ? t.docsFilterDateThisMonth : dateFilter === 'last_month' ? t.docsFilterDateLastMonth : t.docsFilterDate}
            </T>
          </View>
          <I name="chevron-down" size={13} color="#667085" />
        </Pressable>
      </View>

      {/* Payment Filter Popover */}
      {payMenuOpen && (
        <View
          style={{
            backgroundColor: '#FFFFFF',
            borderRadius: 14,
            borderWidth: 1,
            borderColor: '#E5E7EB',
            padding: 8,
            marginBottom: 12,
            shadowColor: '#000',
            shadowOpacity: 0.1,
            shadowRadius: 8,
            elevation: 4
          }}
        >
          {[
            { id: 'all', label: t.docsFilterPayAll },
            { id: 'unpaid', label: t.docsFilterPayUnpaid },
            { id: 'paid', label: t.docsFilterPayPaid }
          ].map(opt => (
            <Pressable
              key={opt.id}
              onPress={() => { setPayFilter(opt.id); setPayMenuOpen(false); }}
              style={{
                paddingVertical: 9,
                paddingHorizontal: 12,
                borderRadius: 8,
                backgroundColor: payFilter === opt.id ? '#F3F4F6' : 'transparent',
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}
            >
              <T style={{ fontSize: 13.5, fontWeight: payFilter === opt.id ? '700' : '500', color: '#171817' }}>
                {opt.label}
              </T>
              {payFilter === opt.id && <I name="checkmark" size={16} color="#171817" />}
            </Pressable>
          ))}
        </View>
      )}

      {/* Date Filter Popover */}
      {dateMenuOpen && (
        <View
          style={{
            backgroundColor: '#FFFFFF',
            borderRadius: 14,
            borderWidth: 1,
            borderColor: '#E5E7EB',
            padding: 8,
            marginBottom: 12,
            shadowColor: '#000',
            shadowOpacity: 0.1,
            shadowRadius: 8,
            elevation: 4
          }}
        >
          {[
            { id: 'all', label: t.docsFilterDateAll },
            { id: 'this_month', label: t.docsFilterDateThisMonth },
            { id: 'last_month', label: t.docsFilterDateLastMonth }
          ].map(opt => (
            <Pressable
              key={opt.id}
              onPress={() => { setDateFilter(opt.id); setDateMenuOpen(false); }}
              style={{
                paddingVertical: 9,
                paddingHorizontal: 12,
                borderRadius: 8,
                backgroundColor: dateFilter === opt.id ? '#F3F4F6' : 'transparent',
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}
            >
              <T style={{ fontSize: 13.5, fontWeight: dateFilter === opt.id ? '700' : '500', color: '#171817' }}>
                {opt.label}
              </T>
              {dateFilter === opt.id && <I name="checkmark" size={16} color="#171817" />}
            </Pressable>
          ))}
        </View>
      )}

      {/* 6. Document Cards List */}
      {filtered.map(d => {
        const isInvoice = d.kind === 'invoice';
        const isPaid = isInvoice && (d.paid || 0) >= (d.total || 0);
        const isPartial = isInvoice && !isPaid && (d.paid || 0) > 0;
        const siteLocation = d.siteLocation || d.customer?.siteLocation || d.project?.name;

        return (
          <View
            key={d.id}
            style={{
              backgroundColor: '#FFFFFF',
              borderRadius: 18,
              borderWidth: 1.2,
              borderColor: '#F1F5F9',
              padding: 16,
              marginBottom: 12,
              shadowColor: '#0F172A',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.04,
              shadowRadius: 6,
              elevation: 2
            }}
          >
            {/* Top row: Yellow icon badge + Customer Name + Amount + Status Badge */}
            <View style={{ flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 10 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1, minWidth: 0, paddingRight: 8 }}>
                {/* Yellow document icon badge */}
                <View
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: 12,
                    backgroundColor: '#FEF9C3',
                    borderWidth: 1,
                    borderColor: '#FEF08A',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  <I name="receipt-outline" size={22} color="#854D0E" />
                </View>

                {/* Customer Name */}
                <View style={{ flex: 1, minWidth: 0 }}>
                  <T numberOfLines={1} style={{ fontSize: 17, fontWeight: '900', color: '#171817' }}>
                    {d.customer?.name || 'Customer'}
                  </T>
                </View>
              </View>

              {/* Amount & Status Badge */}
              <View style={{ alignItems: 'flex-end' }}>
                <T style={{ fontSize: 19, fontWeight: '900', color: '#171817' }}>
                  ₹{(d.total || 0).toLocaleString('en-IN')}
                </T>
                <View
                  style={{
                    marginTop: 3,
                    paddingHorizontal: 7,
                    paddingVertical: 2.5,
                    borderRadius: 5,
                    backgroundColor: isInvoice
                      ? isPaid ? '#DCFCE7' : isPartial ? '#FEF3C7' : '#FFEDD5'
                      : '#EFF6FF'
                  }}
                >
                  <T
                    style={{
                      fontSize: 11,
                      fontWeight: '700',
                      color: isInvoice
                        ? isPaid ? '#15803D' : isPartial ? '#D97706' : '#C2410C'
                        : '#2563EB'
                    }}
                  >
                    {isInvoice
                      ? isPaid ? t.docsStatusPaid : isPartial ? t.docsStatusPartial : t.docsStatusUnpaid
                      : (appLang === 'te' ? 'కొటేషన్' : 'Quotation')}
                  </T>
                </View>
              </View>
            </View>

            {/* Document Details: Number & Date */}
            <View style={{ marginBottom: 4 }}>
              <T numberOfLines={1} style={{ fontSize: 13, fontWeight: '600', color: '#667085' }}>
                {d.number} • {formatTeluguDate(d.date, appLang)}
              </T>
            </View>

            {/* Site location row */}
            {siteLocation ? (
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5, marginBottom: 4 }}>
                <I name="location" size={13} color="#4B5563" />
                <T numberOfLines={1} style={{ fontSize: 13, fontWeight: '600', color: '#4B5563' }}>
                  {siteLocation}
                </T>
              </View>
            ) : null}

            {/* Work title / description */}
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5, marginBottom: 12 }}>
              <I name="business-outline" size={13} color="#4B5563" />
              <T numberOfLines={1} style={{ fontSize: 13, fontWeight: '600', color: '#4B5563' }}>
                {d.title}
              </T>
            </View>

            {/* Divider Line */}
            <View style={{ height: 1, backgroundColor: '#F1F5F9', marginBottom: 10 }} />

            {/* Bottom 3 Action Buttons: View | PDF | Share */}
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              {/* 1. View button */}
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={t.docsBtnView}
                onPress={() => setModal({ type: 'detail', data: d })}
                style={({ pressed }) => [{
                  flex: 1,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 5,
                  paddingVertical: 8,
                  opacity: pressed ? 0.75 : 1
                }]}
              >
                <I name="eye-outline" size={17} color="#171817" />
                <T style={{ fontSize: 13.5, fontWeight: '700', color: '#171817' }}>
                  {t.docsBtnView}
                </T>
              </Pressable>

              <View style={{ width: 1, height: 20, backgroundColor: '#E2E8F0' }} />

              {/* 2. PDF Download / Print button */}
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={t.docsBtnPdf}
                onPress={() => printDoc(d)}
                style={({ pressed }) => [{
                  flex: 1,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 5,
                  paddingVertical: 8,
                  opacity: pressed ? 0.75 : 1
                }]}
              >
                <I name="download-outline" size={17} color="#171817" />
                <T style={{ fontSize: 13.5, fontWeight: '700', color: '#171817' }}>
                  {t.docsBtnPdf}
                </T>
              </Pressable>

              <View style={{ width: 1, height: 20, backgroundColor: '#E2E8F0' }} />

              {/* 3. Share button */}
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={t.docsBtnShare}
                onPress={() => shareDoc(d)}
                style={({ pressed }) => [{
                  flex: 1,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 5,
                  paddingVertical: 8,
                  opacity: pressed ? 0.75 : 1
                }]}
              >
                <I name="share-social-outline" size={17} color="#171817" />
                <T style={{ fontSize: 13.5, fontWeight: '700', color: '#171817' }}>
                  {t.docsBtnShare}
                </T>
              </Pressable>
            </View>
          </View>
        );
      })}

      {/* Empty State */}
      {filtered.length === 0 && (
        <View
          style={{
            backgroundColor: '#FFFFFF',
            borderRadius: 18,
            borderWidth: 1.2,
            borderColor: '#F1F5F9',
            paddingVertical: 36,
            paddingHorizontal: 20,
            alignItems: 'center',
            justifyContent: 'center',
            marginBottom: 16
          }}
        >
          <I name="receipt-outline" size={40} color="#9CA3AF" />
          <T style={{ fontSize: 16, fontWeight: '800', color: '#171817', marginTop: 10 }}>
            {t.docsEmptyTitle}
          </T>
          <T style={{ fontSize: 13, color: '#667085', marginTop: 4, textAlign: 'center', lineHeight: 18 }}>
            {t.docsEmptySub}
          </T>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={t.docsBtnNew}
            onPress={() => open('document', { kind: 'invoice' })}
            style={({ pressed }) => [{
              marginTop: 16,
              backgroundColor: '#FFD500',
              borderRadius: 12,
              paddingHorizontal: 18,
              paddingVertical: 10,
              flexDirection: 'row',
              alignItems: 'center',
              gap: 6,
              opacity: pressed ? 0.85 : 1
            }]}
          >
            <I name="add" size={17} color="#171817" />
            <T style={{ fontSize: 14, fontWeight: '800', color: '#171817' }}>
              {t.docsBtnNew}
            </T>
          </Pressable>
        </View>
      )}

      {/* 7. Bottom helper note */}
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 6,
          marginTop: 8,
          marginBottom: 16
        }}
      >
        <I name="information-circle-outline" size={16} color="#667085" />
        <T style={{ fontSize: 13, color: '#667085', fontWeight: '500' }}>
          {t.docsBottomHelper}
        </T>
      </View>
    </View>
  );
}
