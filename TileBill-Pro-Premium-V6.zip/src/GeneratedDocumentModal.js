import React, { useState, useEffect } from 'react';
import {
  View,
  Text as T,
  Pressable,
  ScrollView,
  Modal,
  Platform,
  Linking,
  ActivityIndicator,
  BackHandler,
  useWindowDimensions
} from 'react-native';
import { Ionicons as I } from '@expo/vector-icons';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import * as FileSystem from 'expo-file-system/legacy';
import { documentHtml, agreementHtml, resolveTemplate, documentTemplates } from './domain.cjs';
import { getStrings } from './i18n';
import { API, loadToken, api, arrayBufferToBase64 } from './api';
import TemplatePickerModal from './TemplatePickerModal';

export default function GeneratedDocumentModal({
  visible = true,
  doc = {},
  business = {},
  appLang = 'te',
  onClose,
  onEdit,
  onBack,
  onTemplateChange,
  printDoc,
  shareDoc,
  notify
}) {
  const t = getStrings(appLang);
  const { width: windowWidth, height: windowHeight } = useWindowDimensions();
  const isDesktop = windowWidth >= 768;

  const [activeTemplate, setActiveTemplate] = useState(doc.template || business.template || 'classic_ledger');
  const [templatePickerOpen, setTemplatePickerOpen] = useState(false);
  const [exportingPdf, setExportingPdf] = useState(false);
  const [exportingWord, setExportingWord] = useState(false);
  const [sharingWa, setSharingWa] = useState(false);
  const [sendingMail, setSendingMail] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(1); // 1 = 100%, 0.85, 1.15
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    if (doc.template) {
      setActiveTemplate(doc.template);
    }
  }, [doc.template]);

  // Handle hardware back on Android and Escape on Web
  useEffect(() => {
    if (Platform.OS === 'web' && typeof window !== 'undefined') {
      const handleKeyDown = (e) => {
        if (e.key === 'Escape') {
          e.preventDefault();
          if (templatePickerOpen) setTemplatePickerOpen(false);
          else if (onBack) onBack(fullDoc);
          else if (onClose) onClose();
        }
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
    } else {
      const backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
        if (templatePickerOpen) {
          setTemplatePickerOpen(false);
          return true;
        }
        if (onBack) {
          onBack(fullDoc);
          return true;
        }
        if (onClose) {
          onClose();
          return true;
        }
        return false;
      });
      return () => backHandler.remove();
    }
  }, [templatePickerOpen, onBack, onClose, activeTemplate]);

  if (!visible || !doc) return null;

  const isAgreement = Boolean(doc.isAgreement || doc.kind === 'agreement');
  const isQuotation = doc.kind === 'quotation';
  const docTypeLabel = isAgreement
    ? (t.docKindAgreement || 'మెటీరియల్ అగ్రిమెంట్')
    : isQuotation
      ? (t.quotationTitle || 'కొటేషన్ (Quotation)')
      : (t.invoiceTitle || 'పన్ను బిల్లు (Tax Invoice)');

  const docNumber = doc.number || (isAgreement ? 'AG-0001' : isQuotation ? 'QT-0001' : 'INV-0001');
  const custName = doc.customer?.name || (isAgreement ? doc.customerName : 'Customer') || 'Customer';
  const cleanCustName = custName.replace(/[^a-zA-Z0-9_\u0C00-\u0C7F\u0900-\u097F\s-]/g, '').trim().replace(/\s+/g, '_') || 'Customer';
  const docTypePrefix = isAgreement ? 'Agreement' : (isQuotation ? 'Quotation' : 'Invoice');
  const baseFilename = `${docTypePrefix}_${docNumber}_${cleanCustName}`;

  // Current template metadata
  const tmplObj = resolveTemplate(activeTemplate);
  const tmplKey = tmplObj.id === 'classic_ledger' ? '01' : tmplObj.id === 'amber_grid' ? '02' : tmplObj.id === 'olive_grid' ? '03' : tmplObj.id === 'compact_trade' ? '04' : tmplObj.id === 'blue_timesheet' ? '05' : tmplObj.id === 'sales_detail' ? '06' : tmplObj.id === 'corporate_sales' ? '07' : tmplObj.id === 'contractor_detail' ? '08' : tmplObj.id === 'project_summary' ? '09' : '10';
  const tmplDisplayName = t[`tmpl${tmplKey}Name`] || tmplObj.name;

  // Build full document payload for rendering
  const fullDoc = {
    ...doc,
    template: activeTemplate,
    customer: doc.customer || { name: custName, siteLocation: doc.siteLocation || doc.projectSite || '' }
  };

  // Render authentic HTML representation
  const renderedHtml = isAgreement
    ? agreementHtml(fullDoc, business)
    : documentHtml(fullDoc, business);

  // ---------------------------------------------------------------------------
  // ACTION 1: Download PDF (Real A4 PDF file via /export/pdf)
  // ---------------------------------------------------------------------------
  const handleDownloadPdf = async () => {
    if (exportingPdf) return;
    try {
      setExportingPdf(true);
      const pdfFilename = `${baseFilename}.pdf`;

      let generatedSuccessfully = false;
      try {
        const token = await loadToken();
        const res = await fetch(API + '/export/pdf', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(token ? { Authorization: 'Bearer ' + token } : {})
          },
          body: JSON.stringify({ doc: fullDoc, business, html: renderedHtml })
        });

        if (res.ok) {
          if (Platform.OS === 'web' && typeof window !== 'undefined') {
            const blob = await res.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = pdfFilename;
            document.body.appendChild(a);
            a.click();
            a.remove();

            // Also open in browser PDF viewer
            try {
              window.open(url, '_blank');
            } catch {}

            if (notify) {
              notify(appLang === 'te' ? 'PDF డౌన్‌లోడ్ అయ్యింది!' : appLang === 'hi' ? 'PDF डाउनलोड हो गया!' : 'PDF downloaded successfully!');
            }
            generatedSuccessfully = true;
          } else {
            const arrayBuf = await res.arrayBuffer();
            const base64 = arrayBufferToBase64(arrayBuf);
            const uri = FileSystem.documentDirectory + pdfFilename;
            await FileSystem.writeAsStringAsync(uri, base64, { encoding: FileSystem.EncodingType.Base64 });
            if (await Sharing.isAvailableAsync()) {
              await Sharing.shareAsync(uri, { mimeType: 'application/pdf', dialogTitle: pdfFilename });
            } else if (notify) {
              notify(`PDF created: ${uri}`);
            }
            generatedSuccessfully = true;
          }
        }
      } catch (fetchErr) {
        // Backend offline or unreachable — seamlessly proceed to native fallback
      }

      if (!generatedSuccessfully) {
        // Offline native PDF generation
        if (Platform.OS !== 'web') {
          const f = await Print.printToFileAsync({ html: renderedHtml });
          if (await Sharing.isAvailableAsync()) {
            await Sharing.shareAsync(f.uri, { mimeType: 'application/pdf', dialogTitle: pdfFilename });
          } else if (notify) {
            notify(`PDF created: ${f.uri}`);
          }
        } else {
          throw new Error('Server connection required for web PDF download');
        }
      }
    } catch (err) {
      if (notify) notify('PDF Error: ' + err.message, true);
    } finally {
      setExportingPdf(false);
    }
  };

  // ---------------------------------------------------------------------------
  // ACTION 2: Download Word (.docx with genuine OOXML styling)
  // ---------------------------------------------------------------------------
  const handleDownloadWord = async () => {
    try {
      setExportingWord(true);
      const docxFilename = `${baseFilename}.docx`;
      const token = await loadToken();

      const res = await fetch(API + '/export/docx', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: 'Bearer ' + token } : {})
        },
        body: JSON.stringify({ doc: fullDoc, business })
      });

      if (!res.ok) {
        const errText = await res.text();
        throw new Error(errText || 'Server failed to generate Word document');
      }

      if (Platform.OS === 'web' && typeof window !== 'undefined') {
        const blob = await res.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = docxFilename;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        if (notify) {
          notify(appLang === 'te' ? 'Word (.docx) డాక్యుమెంట్ డౌన్‌లోడ్ అయ్యింది!' : appLang === 'hi' ? 'Word (.docx) दस्तावेज़ डाउनलोड हो गया!' : 'Word (.docx) document downloaded!');
        }
      } else {
        const arrayBuf = await res.arrayBuffer();
        const base64 = arrayBufferToBase64(arrayBuf);
        const uri = FileSystem.documentDirectory + docxFilename;
        await FileSystem.writeAsStringAsync(uri, base64, { encoding: FileSystem.EncodingType.Base64 });
        if (await Sharing.isAvailableAsync()) {
          await Sharing.shareAsync(uri, {
            mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            dialogTitle: docxFilename
          });
        }
      }
    } catch (err) {
      if (notify) notify('Word Error: ' + err.message, true);
    } finally {
      setExportingWord(false);
    }
  };

  // ---------------------------------------------------------------------------
  // Helper: Retrieve or Create Public Share Link
  // ---------------------------------------------------------------------------
  const getShareLink = async () => {
    if (!doc.id) return '';
    try {
      const x = await api('/share', { docId: doc.id });
      if (x && x.path) return API + x.path;
    } catch (e) {
      console.warn('Share link generation error:', e.message);
    }
    return '';
  };

  // ---------------------------------------------------------------------------
  // ACTION 3: Share through WhatsApp
  // ---------------------------------------------------------------------------
  const handleShareWhatsApp = async () => {
    try {
      setSharingWa(true);
      const shareLink = await getShareLink();
      const site = doc.siteLocation || doc.projectSite || doc.customer?.siteLocation || 'Site';
      const bizName = business.name || 'TileBill Pro';

      let msg = '';
      if (isAgreement) {
        msg = `*📋 ${bizName.toUpperCase()} - MATERIAL SPECIFICATION AGREEMENT*\n\n` +
          `*Agreement No:* ${docNumber}\n` +
          `*Customer:* ${custName}\n` +
          `*Site:* ${site}\n` +
          `*Date:* ${doc.date || 'Today'}\n` +
          `*Materials Count:* ${(doc.materials || []).length} items\n\n` +
          `Material specifications and supply responsibilities confirmed.\n`;
      } else {
        msg = `*📋 ${bizName.toUpperCase()} - ${isQuotation ? 'QUOTATION' : 'TAX INVOICE'}*\n\n` +
          `*Document No:* ${docNumber}\n` +
          `*Customer:* ${custName}\n` +
          `*Site:* ${site}\n` +
          `*Date:* ${doc.date || 'Today'}\n` +
          `*Total Amount:* ₹${Number(doc.total || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}\n\n`;
      }

      if (shareLink) {
        msg += `*🔗 View / Download Document:*\n${shareLink}\n\n`;
      }
      msg += `_Generated with TileBill PRO_`;

      const cleanPhone = (doc.customer?.phone || '').replace(/\D/g, '').slice(-10);
      const waUrl = cleanPhone.length === 10
        ? `https://wa.me/91${cleanPhone}?text=${encodeURIComponent(msg)}`
        : `https://wa.me/?text=${encodeURIComponent(msg)}`;

      if (Platform.OS === 'web' && typeof window !== 'undefined') {
        window.open(waUrl, '_blank');
      } else {
        await Linking.openURL(waUrl);
      }
      if (notify) {
        notify(appLang === 'te' ? 'WhatsApp తెరవబడింది' : appLang === 'hi' ? 'WhatsApp खोला गया' : 'WhatsApp opened');
      }
    } catch (err) {
      if (notify) notify('WhatsApp Error: ' + err.message, true);
    } finally {
      setSharingWa(false);
    }
  };

  // ---------------------------------------------------------------------------
  // ACTION 4: Send through Email
  // ---------------------------------------------------------------------------
  const handleSendEmail = async () => {
    try {
      setSendingMail(true);
      const shareLink = await getShareLink();
      const bizName = business.name || 'TileBill Pro';
      const custEmail = doc.customer?.email || '';

      const subject = `${bizName}: ${docTypeLabel} (${docNumber}) - ${custName}`;
      let body = `Dear ${custName},\n\nPlease find attached the ${docTypeLabel} (${docNumber}) for your project site.\n\n`;
      if (!isAgreement) {
        body += `Total Amount: ₹${Number(doc.total || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}\n\n`;
      }
      if (shareLink) {
        body += `You can view, verify or print the document directly using this link:\n${shareLink}\n\n`;
      }
      body += `Thank you for choosing ${bizName}.\n\nWarm regards,\n${bizName}\nPhone: ${business.phone || ''}`;

      const mailUrl = `mailto:${custEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

      if (Platform.OS === 'web' && typeof window !== 'undefined') {
        window.location.href = mailUrl;
      } else {
        await Linking.openURL(mailUrl);
      }
      if (notify) {
        notify(appLang === 'te' ? 'ఈమెయిల్ యాప్ తెరవబడింది' : appLang === 'hi' ? 'ईमेल ऐप खोला गया' : 'Email client opened');
      }
    } catch (err) {
      if (notify) notify('Email Error: ' + err.message, true);
    } finally {
      setSendingMail(false);
    }
  };

  // Handle template selection
  const handleSelectTemplate = (newTmplId) => {
    setActiveTemplate(newTmplId);
    setTemplatePickerOpen(false);
    if (onTemplateChange) {
      onTemplateChange(newTmplId);
    }
    if (notify) {
      notify(appLang === 'te' ? 'టెంప్లేట్ మార్చబడింది' : appLang === 'hi' ? 'टेम्पलेट बदल दिया गया' : 'Template updated');
    }
  };

  return (
    <Modal visible={visible} transparent={false} animationType="fade" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: '#0F172A', flexDirection: 'column' }}>

        {/* ----------------------------------------------------------------- */}
        {/* TOP STATUS & CONTROLS TOOLBAR                                     */}
        {/* ----------------------------------------------------------------- */}
        <View
          style={{
            backgroundColor: '#1E293B',
            borderBottomWidth: 1,
            borderColor: '#334155',
            paddingHorizontal: 16,
            paddingVertical: 10,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: 10,
            zIndex: 10
          }}
        >
          {/* Left: Back & Document Title */}
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Back"
              onPress={() => {
                if (onBack) onBack(fullDoc);
                else onClose();
              }}
              style={({ pressed }) => [{
                width: 38,
                height: 38,
                borderRadius: 10,
                backgroundColor: '#334155',
                alignItems: 'center',
                justifyContent: 'center',
                opacity: pressed ? 0.8 : 1
              }]}
            >
              <I name="arrow-back" size={20} color="#FFFFFF" />
            </Pressable>

            <View>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <T style={{ fontSize: 16, fontWeight: '900', color: '#FFFFFF', letterSpacing: -0.2 }}>
                  {docTypeLabel}
                </T>
                <View style={{ backgroundColor: '#FFD500', paddingHorizontal: 6, paddingVertical: 1.5, borderRadius: 5 }}>
                  <T style={{ fontSize: 11, fontWeight: '900', color: '#171817' }}>{docNumber}</T>
                </View>
              </View>
              <T style={{ fontSize: 11.5, color: '#94A3B8' }} numberOfLines={1}>
                {custName} • {doc.date || 'Today'}
              </T>
            </View>
          </View>

          {/* Center / Right: Template & Quick Actions */}
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
            {/* Active Template Switcher */}
            {!isAgreement && (
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Change Template"
                onPress={() => setTemplatePickerOpen(true)}
                style={({ pressed }) => [{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: 6,
                  backgroundColor: '#0F172A',
                  borderWidth: 1,
                  borderColor: '#475569',
                  paddingHorizontal: 10,
                  paddingVertical: 7,
                  borderRadius: 8,
                  opacity: pressed ? 0.8 : 1
                }]}
              >
                <I name="color-palette-outline" size={15} color="#FFD500" />
                <T style={{ fontSize: 12, fontWeight: '800', color: '#F1F5F9' }}>
                  {tmplDisplayName}
                </T>
                <I name="chevron-down" size={13} color="#94A3B8" />
              </Pressable>
            )}

            {/* Edit Button */}
            {onEdit && (
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Edit Details"
                onPress={() => {
                  onClose();
                  onEdit(fullDoc);
                }}
                style={({ pressed }) => [{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: 5,
                  backgroundColor: '#334155',
                  paddingHorizontal: 10,
                  paddingVertical: 7,
                  borderRadius: 8,
                  opacity: pressed ? 0.8 : 1
                }]}
              >
                <I name="create-outline" size={15} color="#E2E8F0" />
                <T style={{ fontSize: 12, fontWeight: '700', color: '#FFFFFF' }}>
                  {t.btnEditDetails || 'Edit'}
                </T>
              </Pressable>
            )}

            {/* Done / Close Button */}
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Done"
              onPress={onClose}
              style={({ pressed }) => [{
                paddingHorizontal: 12,
                paddingVertical: 7,
                backgroundColor: '#0284C7',
                borderRadius: 8,
                opacity: pressed ? 0.8 : 1
              }]}
            >
              <T style={{ fontSize: 12, fontWeight: '800', color: '#FFFFFF' }}>
                {t.btnDone || 'Done'}
              </T>
            </Pressable>
          </View>
        </View>

        {/* ----------------------------------------------------------------- */}
        {/* SECONDARY TOOLBAR: FOUR PRIMARY EXPORT & SHARING BUTTONS          */}
        {/* ----------------------------------------------------------------- */}
        <View
          style={{
            backgroundColor: '#0F172A',
            borderBottomWidth: 1,
            borderColor: '#1E293B',
            paddingHorizontal: 14,
            paddingVertical: 8,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 10,
            flexWrap: 'wrap'
          }}
        >
          {/* 1. Download PDF */}
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Download PDF"
            disabled={exportingPdf}
            onPress={handleDownloadPdf}
            style={({ pressed }) => [{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 6,
              backgroundColor: '#FFD500',
              paddingHorizontal: 14,
              paddingVertical: 8,
              borderRadius: 8,
              shadowColor: '#EAB308',
              shadowOffset: { width: 0, height: 1 },
              shadowOpacity: 0.2,
              shadowRadius: 3,
              elevation: 2,
              opacity: (pressed || exportingPdf) ? 0.8 : 1
            }]}
          >
            {exportingPdf ? (
              <ActivityIndicator size="small" color="#171817" />
            ) : (
              <I name="document-text" size={16} color="#171817" />
            )}
            <T style={{ fontSize: 12.5, fontWeight: '900', color: '#171817' }}>
              {exportingPdf ? (appLang === 'te' ? 'PDF తయారవుతోంది…' : appLang === 'hi' ? 'PDF बन रहा है…' : 'Generating PDF…') : (t.downloadPdf || 'Download PDF')}
            </T>
          </Pressable>

          {/* 2. Download Word (.docx) */}
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Download Word"
            disabled={exportingWord}
            onPress={handleDownloadWord}
            style={({ pressed }) => [{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 6,
              backgroundColor: '#1E3A8A',
              borderWidth: 1,
              borderColor: '#3B82F6',
              paddingHorizontal: 14,
              paddingVertical: 8,
              borderRadius: 8,
              opacity: exportingWord ? 0.6 : pressed ? 0.85 : 1
            }]}
          >
            {exportingWord ? (
              <ActivityIndicator size="small" color="#93C5FD" />
            ) : (
              <I name="document-attach" size={16} color="#93C5FD" />
            )}
            <T style={{ fontSize: 12.5, fontWeight: '800', color: '#EFF6FF' }}>
              {t.downloadWord || 'Download Word'}
            </T>
          </Pressable>

          {/* 3. Share through WhatsApp */}
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Share through WhatsApp"
            disabled={sharingWa}
            onPress={handleShareWhatsApp}
            style={({ pressed }) => [{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 6,
              backgroundColor: '#15803D',
              borderWidth: 1,
              borderColor: '#22C55E',
              paddingHorizontal: 14,
              paddingVertical: 8,
              borderRadius: 8,
              opacity: sharingWa ? 0.6 : pressed ? 0.85 : 1
            }]}
          >
            {sharingWa ? (
              <ActivityIndicator size="small" color="#86EFAC" />
            ) : (
              <I name="logo-whatsapp" size={16} color="#86EFAC" />
            )}
            <T style={{ fontSize: 12.5, fontWeight: '800', color: '#F0FDF4' }}>
              {t.shareWhatsApp || 'WhatsApp'}
            </T>
          </Pressable>

          {/* 4. Send through Email */}
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Send through Email"
            disabled={sendingMail}
            onPress={handleSendEmail}
            style={({ pressed }) => [{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 6,
              backgroundColor: '#334155',
              borderWidth: 1,
              borderColor: '#64748B',
              paddingHorizontal: 14,
              paddingVertical: 8,
              borderRadius: 8,
              opacity: sendingMail ? 0.6 : pressed ? 0.85 : 1
            }]}
          >
            {sendingMail ? (
              <ActivityIndicator size="small" color="#CBD5E1" />
            ) : (
              <I name="mail" size={15} color="#CBD5E1" />
            )}
            <T style={{ fontSize: 12.5, fontWeight: '800', color: '#F8FAFC' }}>
              {t.sendEmail || 'Email'}
            </T>
          </Pressable>

          {/* Zoom In / Out for Preview Inspection */}
          <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: '#1E293B', borderRadius: 8, borderWidth: 1, borderColor: '#334155' }}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Zoom Out"
              onPress={() => setZoomLevel(z => Math.max(0.75, z - 0.1))}
              style={{ paddingHorizontal: 8, paddingVertical: 6 }}
            >
              <I name="remove" size={14} color="#94A3B8" />
            </Pressable>
            <T style={{ fontSize: 11, fontWeight: '700', color: '#CBD5E1', paddingHorizontal: 4 }}>
              {Math.round(zoomLevel * 100)}%
            </T>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Zoom In"
              onPress={() => setZoomLevel(z => Math.min(1.4, z + 0.1))}
              style={{ paddingHorizontal: 8, paddingVertical: 6 }}
            >
              <I name="add" size={14} color="#94A3B8" />
            </Pressable>
          </View>
        </View>

        {/* ----------------------------------------------------------------- */}
        {/* A4 PAPER VIEWPORT WITH REAL POPULATED DOCUMENT HTML                */}
        {/* ----------------------------------------------------------------- */}
        <View style={{ flex: 1, backgroundColor: '#334155', padding: isDesktop ? 16 : 8, alignItems: 'center', justifyContent: 'center' }}>
          {Platform.OS === 'web' ? (
            <View
              style={{
                width: '100%',
                maxWidth: 860,
                height: '100%',
                backgroundColor: '#FFFFFF',
                borderRadius: 8,
                shadowColor: '#000000',
                shadowOffset: { width: 0, height: 8 },
                shadowOpacity: 0.35,
                shadowRadius: 18,
                elevation: 8,
                overflow: 'hidden',
                transform: [{ scale: zoomLevel }]
              }}
            >
              <iframe
                title="Generated Document A4 Viewport"
                srcDoc={renderedHtml}
                style={{
                  width: '100%',
                  height: '100%',
                  border: 'none',
                  backgroundColor: '#FFFFFF'
                }}
              />
            </View>
          ) : (
            <ScrollView
              contentContainerStyle={{ alignItems: 'center', paddingVertical: 12 }}
              style={{ width: '100%' }}
            >
              <View
                style={{
                  width: '100%',
                  maxWidth: 600,
                  backgroundColor: '#FFFFFF',
                  borderRadius: 12,
                  padding: 16,
                  shadowColor: '#000000',
                  shadowOffset: { width: 0, height: 4 },
                  shadowOpacity: 0.2,
                  shadowRadius: 10,
                  elevation: 5
                }}
              >
                {/* Fallback structured preview for native without iframe */}
                <View style={{ alignItems: 'center', borderBottomWidth: 1.5, borderColor: '#0F172A', paddingBottom: 10, marginBottom: 12 }}>
                  <T style={{ fontSize: 18, fontWeight: '900', color: '#0F172A' }}>{docTypeLabel}</T>
                  <T style={{ fontSize: 12, fontWeight: '700', color: '#64748B', marginTop: 2 }}>{docNumber} • {doc.date}</T>
                </View>

                <View style={{ marginBottom: 14 }}>
                  <T style={{ fontSize: 12, fontWeight: '800', color: '#475569' }}>Customer:</T>
                  <T style={{ fontSize: 14, fontWeight: '800', color: '#0F172A' }}>{custName}</T>
                  <T style={{ fontSize: 12, color: '#64748B' }}>{doc.siteLocation || doc.projectSite || 'Site'}</T>
                </View>

                {!isAgreement ? (
                  <>
                    <View style={{ borderTopWidth: 1, borderColor: '#E2E8F0', paddingTop: 8, marginBottom: 8 }}>
                      {(doc.items || []).map((it, idx) => (
                        <View key={idx} style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 4 }}>
                          <T style={{ fontSize: 12, color: '#1E293B', flex: 2 }}>{it.name}</T>
                          <T style={{ fontSize: 12, color: '#64748B', flex: 1, textAlign: 'center' }}>{it.qty} {it.unit}</T>
                          <T style={{ fontSize: 12, fontWeight: '700', color: '#0F172A', flex: 1, textAlign: 'right' }}>₹{Number(it.amount || 0).toLocaleString('en-IN')}</T>
                        </View>
                      ))}
                    </View>
                    <View style={{ borderTopWidth: 1.5, borderColor: '#0F172A', paddingTop: 8, flexDirection: 'row', justifyContent: 'space-between' }}>
                      <T style={{ fontSize: 14, fontWeight: '900', color: '#0F172A' }}>Total Amount:</T>
                      <T style={{ fontSize: 15, fontWeight: '900', color: '#0F172A' }}>₹{Number(doc.total || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}</T>
                    </View>
                  </>
                ) : (
                  <View style={{ borderTopWidth: 1, borderColor: '#E2E8F0', paddingTop: 8 }}>
                    <T style={{ fontSize: 13, fontWeight: '800', color: '#0F172A', marginBottom: 6 }}>Material Specifications (Zero Pricing):</T>
                    {(doc.materials || []).map((m, idx) => (
                      <View key={idx} style={{ paddingVertical: 4, borderBottomWidth: 0.5, borderColor: '#E2E8F0' }}>
                        <T style={{ fontSize: 12, fontWeight: '700', color: '#0F172A' }}>{m.name}</T>
                        <T style={{ fontSize: 11, color: '#64748B' }}>Brand: {m.brand || 'As agreed'} • Supplied by: {m.suppliedBy}</T>
                      </View>
                    ))}
                  </View>
                )}
              </View>
            </ScrollView>
          )}
        </View>

        {/* ----------------------------------------------------------------- */}
        {/* TEMPLATE PICKER MODAL                                             */}
        {/* ----------------------------------------------------------------- */}
        {templatePickerOpen && (
          <TemplatePickerModal
            visible={templatePickerOpen}
            selectedTemplateId={activeTemplate}
            docKind={doc.kind}
            onSelectTemplate={handleSelectTemplate}
            onClose={() => setTemplatePickerOpen(false)}
            appLang={appLang}
          />
        )}
      </View>
    </Modal>
  );
}
