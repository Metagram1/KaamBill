import React, { useState } from 'react';
import { View, Image, ScrollView, Pressable, Platform } from 'react-native';
import { T, I, Button, Field, Card, Badge, s, C } from './ui';
import { services } from './domain.cjs';
import { languages } from './i18n';
import { pickImageFile } from '../App';

const logoImg = require('../assets/logo.png');

export default function LocalTestSetup({ appLang = 'te', onSetAppLang, onComplete, initialLocation = 'మురళీనగర్, విశాఖపట్నం' }) {
  const [step, setStep] = useState(1); // 1: Language & Welcome, 2: Business Profile
  const [selectedLang, setSelectedLang] = useState(appLang);
  const [businessName, setBusinessName] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [phone, setPhone] = useState('');
  const [selectedService, setSelectedService] = useState('tiles');
  const [city, setCity] = useState(initialLocation);
  const [address, setAddress] = useState('');
  const [prefix, setPrefix] = useState('TB');
  const [logoUri, setLogoUri] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const t = {
    en: {
      badge: 'OFFLINE TESTING EDITION',
      welcomeTitle: 'TileBill PRO',
      welcomeSub: 'Test all core features directly on your device without any server, computer, or backend connection.',
      chooseLang: '1. Choose App Language',
      startTestingBtn: 'Start Testing →',
      setupTitle: '2. Setup Business Profile',
      setupSub: 'These business details will appear on your generated invoices, quotations, and agreements.',
      bizNameLabel: 'Business / Contractor Name *',
      bizNamePlace: 'e.g. Sri Venkateswara Tiles & Works',
      ownerLabel: 'Contractor / Owner Name',
      ownerPlace: 'e.g. Ramesh Kumar',
      serviceLabel: 'Primary Trade / Service',
      phoneLabel: 'Contact Phone (Printed on bills — not verified)',
      phonePlace: 'e.g. 9876543210',
      cityLabel: 'City / Mandal',
      addressLabel: 'Business Address (Optional)',
      prefixLabel: 'Bill Prefix (e.g. TB, SVT)',
      logoLabel: 'Business Logo (Optional)',
      uploadLogo: 'Pick Logo Image',
      changeLogo: 'Change Logo',
      removeLogo: 'Remove',
      backBtn: '← Back',
      launchBtn: 'Launch Dashboard →',
      reqError: 'Please enter your business or contractor name to continue.'
    },
    te: {
      badge: 'ఆఫ్‌లైన్ టెస్టింగ్ ఎడిషన్',
      welcomeTitle: 'టైల్‌బిల్ ప్రో',
      welcomeSub: 'సర్వర్ లేదా కంప్యూటర్ అవసరం లేకుండా అన్ని ప్రధాన ఫీచర్లను మీ ఫోన్‌లోనే నేరుగా టెస్ట్ చేయండి.',
      chooseLang: '1. యాప్ భాషను ఎంచుకోండి',
      startTestingBtn: 'టెస్టింగ్ ప్రారంభించండి →',
      setupTitle: '2. వ్యాపార వివరాలను నమోదు చేయండి',
      setupSub: 'ఈ వివరాలు మీరు తయారుచేసే బిల్లులు, కొటేషన్లు మరియు మెటీరియల్ ఒప్పందాలపై ముద్రించబడతాయి.',
      bizNameLabel: 'షాప్ / వ్యాపారం / కాంట్రాక్టర్ పేరు *',
      bizNamePlace: 'ఉదా: శ్రీ వేంకటేశ్వర టైల్స్ & వర్క్స్',
      ownerLabel: 'యజమాని / కాంట్రాక్టర్ పేరు',
      ownerPlace: 'ఉదా: రమేష్ బాబు',
      serviceLabel: 'ప్రధాన విభాగం (Trade)',
      phoneLabel: 'మొబైల్ నంబర్ (బిల్లులపై ముద్రించడానికి — OTP అవసరం లేదు)',
      phonePlace: 'ఉదా: 9876543210',
      cityLabel: 'నగరం / మండలం',
      addressLabel: 'షాప్ / సైట్ చిరునామా (ఐచ్ఛికం)',
      prefixLabel: 'బిల్ నంబర్ ప్రిఫిక్స్ (ఉదా: TB, SVT)',
      logoLabel: 'బిజినెస్ లోగో (ఐచ్ఛికం)',
      uploadLogo: 'లోగో ఫోటో ఎంచుకోండి',
      changeLogo: 'లోగో మార్చండి',
      removeLogo: 'తొలగించు',
      backBtn: '← వెనుకకు',
      launchBtn: 'డ్యాష్‌బోర్డ్ తెరవండి →',
      reqError: 'కొనసాగడానికి దయచేసి వ్యాపారం లేదా కాంట్రాక్టర్ పేరు నమోదు చేయండి.'
    },
    hi: {
      badge: 'ऑफ़लाइन टेस्टिंग संस्करण',
      welcomeTitle: 'टाइल-बिल प्रो',
      welcomeSub: 'किसी सर्वर या कंप्यूटर के बिना सभी मुख्य सुविधाओं का सीधे अपने डिवाइस पर परीक्षण करें।',
      chooseLang: '1. ऐप की भाषा चुनें',
      startTestingBtn: 'परीक्षण शुरू करें →',
      setupTitle: '2. व्यावसायिक प्रोफ़ाइल दर्ज करें',
      setupSub: 'यह विवरण आपके द्वारा बनाए गए चालान, कोटेशन और समझौतों पर दिखाई देगा।',
      bizNameLabel: 'दुकान / व्यवसाय / ठेकेदार का नाम *',
      bizNamePlace: 'जैसे श्री वेंकटेश्वर टाइल्स',
      ownerLabel: 'मालिक / ठेकेदार का नाम',
      ownerPlace: 'जैसे रमेश कुमार',
      serviceLabel: 'मुख्य सेवा (Trade)',
      phoneLabel: 'संपर्क मोबाइल नंबर (बिलों पर छपने के लिए — OTP आवश्यक नहीं)',
      phonePlace: 'जैसे 9876543210',
      cityLabel: 'शहर / कस्बा',
      addressLabel: 'दुकान का पता (वैकल्पिक)',
      prefixLabel: 'बिल उपसर्ग (जैसे TB, SVT)',
      logoLabel: 'व्यवसाय का लोगो (वैकल्पिक)',
      uploadLogo: 'लोगो फोटो चुनें',
      changeLogo: 'लोगो बदलें',
      removeLogo: 'हटाएं',
      backBtn: '← पीछे',
      launchBtn: 'डैशबोर्ड खोलें →',
      reqError: 'कृपया आगे बढ़ने के लिए व्यवसाय या ठेकेदार का नाम दर्ज करें।'
    }
  }[selectedLang] || t.te;

  const handleLangChange = (l) => {
    setSelectedLang(l);
    if (typeof onSetAppLang === 'function') onSetAppLang(l);
  };

  const handleLaunch = () => {
    if (!businessName.trim()) {
      setErrorMsg(t.reqError);
      return;
    }
    setErrorMsg('');
    onComplete({
      businessName: businessName.trim(),
      ownerName: ownerName.trim(),
      phone: phone.trim(),
      service: selectedService || 'tiles',
      city: city.trim() || 'విశాఖపట్నం',
      address: address.trim(),
      prefix: (prefix.trim() || 'TB').toUpperCase().slice(0, 8),
      logoUri,
      language: selectedLang
    });
  };

  return (
    <ScrollView contentContainerStyle={{ padding: 18, maxWidth: 580, alignSelf: 'center', width: '100%' }}>
      {/* App Branding */}
      <View style={{ alignItems: 'center', marginTop: 12, marginBottom: 16 }}>
        <Image source={logoImg} style={{ width: 220, height: 75 }} resizeMode="contain" />
        <View style={{ marginTop: 8 }}>
          <Badge tone="yellow">{t.badge}</Badge>
        </View>
        <T style={{ fontSize: 13, color: C.muted, textAlign: 'center', marginTop: 8, lineHeight: 18, maxWidth: 420 }}>
          {t.welcomeSub}
        </T>
      </View>

      {step === 1 ? (
        /* STEP 1: CHOOSE LANGUAGE & START TESTING */
        <Card style={{ padding: 18, backgroundColor: '#FFFFFF', borderRadius: 14, borderWidth: 1, borderColor: '#E2E8F0' }}>
          <T style={[s.h3, { marginBottom: 4, color: C.ink }]}>{t.chooseLang}</T>
          <T style={{ fontSize: 12.5, color: C.muted, marginBottom: 14 }}>
            Select your preferred display and document language:
          </T>

          <View style={{ gap: 10, marginBottom: 20 }}>
            {languages.map((l) => {
              const active = selectedLang === l.id;
              return (
                <Pressable
                  key={l.id}
                  onPress={() => handleLangChange(l.id)}
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: 14,
                    borderRadius: 10,
                    borderWidth: 2,
                    borderColor: active ? '#1A56DB' : '#E2E8F0',
                    backgroundColor: active ? '#EFF6FF' : '#F8FAFC'
                  }}
                >
                  <View>
                    <T style={{ fontSize: 15, fontWeight: active ? '700' : '600', color: active ? '#1A56DB' : C.ink }}>
                      {l.label}
                    </T>
                    <T style={{ fontSize: 11.5, color: C.muted, marginTop: 2 }}>{l.native}</T>
                  </View>
                  <View
                    style={{
                      width: 22,
                      height: 22,
                      borderRadius: 11,
                      borderWidth: 2,
                      borderColor: active ? '#1A56DB' : '#CBD5E1',
                      alignItems: 'center',
                      justifyContent: 'center',
                      backgroundColor: active ? '#1A56DB' : '#FFFFFF'
                    }}
                  >
                    {active && <I name="checkmark" size={14} color="#FFFFFF" />}
                  </View>
                </Pressable>
              );
            })}
          </View>

          <Button
            primary
            icon="arrow-forward"
            onPress={() => setStep(2)}
            style={{ paddingVertical: 14 }}
          >
            {t.startTestingBtn}
          </Button>
        </Card>
      ) : (
        /* STEP 2: BUSINESS PROFILE ENTRY */
        <Card style={{ padding: 18, backgroundColor: '#FFFFFF', borderRadius: 14, borderWidth: 1, borderColor: '#E2E8F0' }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
            <T style={[s.h3, { color: C.ink }]}>{t.setupTitle}</T>
            <Pressable onPress={() => setStep(1)} style={{ padding: 4 }}>
              <T style={{ fontSize: 12.5, color: '#1A56DB', fontWeight: '600' }}>{t.backBtn}</T>
            </Pressable>
          </View>
          <T style={{ fontSize: 12, color: C.muted, marginBottom: 14, lineHeight: 16 }}>
            {t.setupSub}
          </T>

          {errorMsg ? (
            <View style={{ backgroundColor: '#FEE2E2', padding: 10, borderRadius: 8, marginBottom: 12 }}>
              <T style={{ fontSize: 12.5, color: '#DC2626', fontWeight: '600' }}>{errorMsg}</T>
            </View>
          ) : null}

          {/* Business Name */}
          <Field
            label={t.bizNameLabel}
            placeholder={t.bizNamePlace}
            value={businessName}
            onChange={(v) => {
              setBusinessName(v);
              if (errorMsg) setErrorMsg('');
            }}
          />

          {/* Owner Name */}
          <Field
            label={t.ownerLabel}
            placeholder={t.ownerPlace}
            value={ownerName}
            onChange={setOwnerName}
          />

          {/* Primary Trade / Service */}
          <T style={{ fontSize: 12, fontWeight: '700', color: C.ink, marginBottom: 6, marginTop: 4 }}>
            {t.serviceLabel}
          </T>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 14 }}>
            <View style={{ flexDirection: 'row', gap: 8 }}>
              {services.map((svc) => {
                const active = selectedService === svc.id;
                return (
                  <Pressable
                    key={svc.id}
                    onPress={() => setSelectedService(svc.id)}
                    style={{
                      paddingHorizontal: 12,
                      paddingVertical: 8,
                      borderRadius: 8,
                      borderWidth: 1.5,
                      borderColor: active ? '#1A56DB' : '#E2E8F0',
                      backgroundColor: active ? '#EFF6FF' : '#F8FAFC'
                    }}
                  >
                    <T style={{ fontSize: 12.5, fontWeight: active ? '700' : '500', color: active ? '#1A56DB' : C.ink }}>
                      {svc.name}
                    </T>
                  </Pressable>
                );
              })}
            </View>
          </ScrollView>

          {/* Contact Phone */}
          <Field
            label={t.phoneLabel}
            placeholder={t.phonePlace}
            numeric
            value={phone}
            onChange={setPhone}
          />

          {/* City / Mandal */}
          <Field
            label={t.cityLabel}
            value={city}
            onChange={setCity}
          />

          {/* Business Address */}
          <Field
            multiline
            label={t.addressLabel}
            placeholder="e.g. Near Main Road, Visakhapatnam"
            value={address}
            onChange={setAddress}
          />

          {/* Bill Prefix */}
          <Field
            label={t.prefixLabel}
            value={prefix}
            onChange={(v) => setPrefix(v.toUpperCase().slice(0, 8))}
          />

          {/* Logo Picker */}
          <View style={{ marginTop: 6, marginBottom: 18 }}>
            <T style={{ fontSize: 12, fontWeight: '700', color: C.ink, marginBottom: 6 }}>
              {t.logoLabel}
            </T>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              {logoUri ? (
                <Image source={{ uri: logoUri }} style={{ width: 50, height: 50, borderRadius: 8, borderWidth: 1, borderColor: '#CBD5E1' }} resizeMode="contain" />
              ) : (
                <View style={{ width: 50, height: 50, borderRadius: 8, backgroundColor: '#F1F5F9', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: '#E2E8F0' }}>
                  <I name="image-outline" size={24} color="#94A3B8" />
                </View>
              )}
              <View style={{ flexDirection: 'row', gap: 8, flex: 1 }}>
                <Button
                  secondary
                  compact
                  icon="cloud-upload-outline"
                  onPress={() => pickImageFile((uri) => setLogoUri(uri))}
                  style={{ flex: 1 }}
                >
                  {logoUri ? t.changeLogo : t.uploadLogo}
                </Button>
                {logoUri ? (
                  <Button
                    danger
                    compact
                    icon="trash-outline"
                    onPress={() => setLogoUri('')}
                  >
                    {t.removeLogo}
                  </Button>
                ) : null}
              </View>
            </View>
          </View>

          {/* Launch Dashboard */}
          <Button
            primary
            icon="checkmark-circle"
            onPress={handleLaunch}
            style={{ paddingVertical: 14 }}
          >
            {t.launchBtn}
          </Button>
        </Card>
      )}

      {/* Footer notice */}
      <View style={{ alignItems: 'center', marginTop: 16 }}>
        <T style={{ fontSize: 11, color: '#94A3B8', textAlign: 'center' }}>
          TileBill PRO v6.0.4 · Standalone Local Testing Edition
        </T>
      </View>
    </ScrollView>
  );
}
