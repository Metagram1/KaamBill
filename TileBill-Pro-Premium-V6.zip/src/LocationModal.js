/**
 * TileBill PRO - Location Modal (src/LocationModal.js)
 * Implements strict Google Places search, Place Details resolution,
 * Confirmation Summary, Stale-result prevention, and GPS verification.
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text as T,
  Pressable,
  TextInput,
  ScrollView,
  Modal,
  Platform,
  ActivityIndicator,
  BackHandler,
  useWindowDimensions
} from 'react-native';
import { Ionicons as I } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getStrings } from './i18n';
import { API } from './api';

export default function LocationModal({
  visible = false,
  onClose,
  onSelectLocation,
  currentLocation = '',
  appLang = 'te'
}) {
  const t = getStrings(appLang);
  const { width } = useWindowDimensions();
  const isDesktop = width >= 768;

  // Tabs: 'search' | 'gps' | 'quick'
  const [activeTab, setActiveTab] = useState('search');

  // Search state
  const [query, setQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const [pendingSelection, setPendingSelection] = useState(null);
  const [placesConfig, setPlacesConfig] = useState({ configured: false, provider: 'regional_database' });

  // GPS state
  const [gpsLoading, setGpsLoading] = useState(false);
  const [gpsError, setGpsError] = useState('');
  const [gpsResult, setGpsResult] = useState(null);

  // Request counter to cancel stale search responses
  const searchReqIdRef = useRef(0);

  // Check Places status on mount
  useEffect(() => {
    fetch(`${API}/api/places/status`)
      .then(res => res.json())
      .then(data => {
        if (data && data.provider) {
          setPlacesConfig(data);
        }
      })
      .catch(() => {});
  }, []);

  // Android hardware back & Web Escape handling
  useEffect(() => {
    if (!visible) return;
    if (Platform.OS === 'web' && typeof window !== 'undefined') {
      const handleKeyDown = (e) => {
        if (e.key === 'Escape') {
          e.preventDefault();
          onClose();
        }
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
    } else {
      const sub = BackHandler.addEventListener('hardwareBackPress', () => {
        onClose();
        return true;
      });
      return () => sub.remove();
    }
  }, [visible, onClose]);

  // Debounced search for place suggestions
  useEffect(() => {
    const cleanQ = query.trim();
    if (cleanQ.length === 0) {
      setSuggestions([]);
      setSearching(false);
      return;
    }

    const currentReqId = ++searchReqIdRef.current;
    setSearching(true);

    const timer = setTimeout(() => {
      fetch(`${API}/api/places/search?q=${encodeURIComponent(cleanQ)}`)
        .then(res => res.json())
        .then(data => {
          // Prevent stale search results from overwriting newer query!
          if (currentReqId === searchReqIdRef.current) {
            setSuggestions(Array.isArray(data.predictions) ? data.predictions : []);
            setSearching(false);
          }
        })
        .catch(() => {
          if (currentReqId === searchReqIdRef.current) {
            setSearching(false);
          }
        });
    }, 280);

    return () => clearTimeout(timer);
  }, [query]);

  // Handle typing after selecting a place -> Clear confirmed selection until re-picked!
  const handleQueryChange = (text) => {
    setQuery(text);
    if (pendingSelection) {
      setPendingSelection(null);
    }
  };

  // Select a suggestion -> Resolve Place Details & Show Confirmation Summary
  const handleSelectSuggestion = async (item) => {
    try {
      setSearching(true);
      const res = await fetch(`${API}/api/places/details?placeId=${encodeURIComponent(item.placeId)}`);
      const details = await res.json();
      setSearching(false);

      if (details && details.ok) {
        setPendingSelection({
          placeId: details.placeId || item.placeId,
          displayName: details.displayName || item.displayName,
          formattedAddress: details.formattedAddress || item.formattedAddress,
          locality: details.locality || item.locality || '',
          city: details.city || item.city || '',
          state: details.state || item.state || '',
          pincode: details.pincode || item.pincode || '',
          country: details.country || 'India',
          lat: details.lat || item.lat,
          lng: details.lng || item.lng,
          provider: details.provider || item.provider || 'regional_database'
        });
      } else {
        // Fallback to item data
        setPendingSelection({
          placeId: item.placeId,
          displayName: item.displayName,
          formattedAddress: item.formattedAddress,
          locality: item.locality || '',
          city: item.city || '',
          state: item.state || '',
          pincode: item.pincode || '',
          country: 'India',
          lat: item.lat,
          lng: item.lng,
          provider: 'regional_database'
        });
      }
    } catch {
      setSearching(false);
      setPendingSelection({
        placeId: item.placeId,
        displayName: item.displayName,
        formattedAddress: item.formattedAddress,
        locality: item.locality || '',
        city: item.city || '',
        state: item.state || '',
        pincode: item.pincode || '',
        country: 'India',
        lat: item.lat,
        lng: item.lng,
        provider: 'regional_database'
      });
    }
  };

  // Confirm and save the selected place
  const handleConfirmSave = (selection) => {
    if (!selection) return;
    const finalName = selection.displayName || selection.locality || selection.city || selection.formattedAddress;

    // Persist full structured metadata
    AsyncStorage.setItem('tilebill_saved_location_data', JSON.stringify(selection)).catch(() => {});
    AsyncStorage.setItem('tilebill_saved_location', finalName).catch(() => {});

    // Notify caller
    if (onSelectLocation) {
      onSelectLocation(finalName, selection);
    }
    onClose();
  };

  // Trigger GPS location trace with confirmation
  const handleGpsTrace = () => {
    setGpsLoading(true);
    setGpsError('');
    setGpsResult(null);

    if (typeof navigator !== 'undefined' && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          try {
            const lat = pos.coords.latitude;
            const lng = pos.coords.longitude;

            const res = await fetch(`${API}/api/places/reverse?lat=${lat}&lng=${lng}`);
            const data = await res.json();

            setGpsLoading(false);
            if (data && data.ok) {
              setGpsResult({
                placeId: data.placeId || 'gps_loc',
                displayName: data.displayName,
                formattedAddress: data.formattedAddress,
                locality: data.locality || '',
                city: data.city || '',
                state: data.state || '',
                pincode: data.pincode || '',
                lat,
                lng,
                isApproximate: true,
                provider: data.provider || 'gps'
              });
            } else {
              setGpsResult({
                placeId: 'gps_coords',
                displayName: `GPS: ${lat.toFixed(4)}, ${lng.toFixed(4)}`,
                formattedAddress: `Coordinates: ${lat.toFixed(6)}, ${lng.toFixed(6)}`,
                lat,
                lng,
                isApproximate: true,
                provider: 'gps'
              });
            }
          } catch (err) {
            setGpsLoading(false);
            setGpsError(appLang === 'te' ? 'లొకేషన్ వివరాలు లోడ్ కాలేదు. దయచేసి శోధించండి.' : appLang === 'hi' ? 'स्थान विवरण लोड नहीं हो सका। कृपया खोजें।' : 'Failed to resolve address. Please search manually.');
          }
        },
        (err) => {
          setGpsLoading(false);
          setGpsError(appLang === 'te' ? 'లొకేషన్ అనుమతి నిరాకరించబడింది. దయచేసి శోధించండి.' : appLang === 'hi' ? 'स्थान की अनुमति नहीं मिली। कृपया खोजें।' : 'Location permission was denied. Please search or select below.');
        },
        { timeout: 9000, enableHighAccuracy: true }
      );
    } else {
      setGpsLoading(false);
      setGpsError(appLang === 'te' ? 'మీ పరికరంలో GPS అందుబాటులో లేదు. దయచేసి శోధించండి.' : appLang === 'hi' ? 'GPS उपलब्ध नहीं है। कृपया खोजें।' : 'Geolocation not supported. Please search manually.');
    }
  };

  if (!visible) return null;

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: 'rgba(15,23,42,0.65)', justifyContent: 'flex-end', alignItems: 'center' }}>
        <Pressable style={{ flex: 1, width: '100%' }} onPress={onClose} />

        <View
          style={{
            backgroundColor: '#FFFFFF',
            borderTopLeftRadius: 24,
            borderTopRightRadius: 24,
            width: '100%',
            maxWidth: isDesktop ? 540 : 480,
            maxHeight: '90%',
            paddingTop: 18,
            paddingBottom: Platform.OS === 'ios' ? 36 : 22,
            paddingHorizontal: 20,
            shadowColor: '#000',
            shadowOffset: { width: 0, height: -6 },
            shadowOpacity: 0.15,
            shadowRadius: 14,
            elevation: 25
          }}
        >
          {/* Header */}
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <View style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: '#FEF9C3', alignItems: 'center', justifyContent: 'center' }}>
                <I name="location" size={18} color="#854D0E" />
              </View>
              <View>
                <T style={{ fontSize: 16, fontWeight: '800', color: '#111827' }}>
                  {t.locSelectTitle || 'లొకేషన్ ఎంపిక'}
                </T>
                <T style={{ fontSize: 11.5, color: '#6B7280' }}>
                  {appLang === 'te' ? 'వ్యాపార లేదా సైట్ లొకేషన్‌ను సెట్ చేయండి' : appLang === 'hi' ? 'व्यापार या साइट का स्थान सेट करें' : 'Set business or project site location'}
                </T>
              </View>
            </View>

            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Close"
              onPress={onClose}
              hitSlop={10}
              style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: '#F3F4F6', alignItems: 'center', justifyContent: 'center' }}
            >
              <I name="close" size={18} color="#4B5563" />
            </Pressable>
          </View>

          {/* Mode Tabs: Search vs Current GPS */}
          <View style={{ flexDirection: 'row', backgroundColor: '#F3F4F6', borderRadius: 12, padding: 3, marginBottom: 14 }}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Search Place"
              onPress={() => { setActiveTab('search'); setGpsResult(null); }}
              style={{
                flex: 1,
                paddingVertical: 8,
                borderRadius: 9,
                backgroundColor: activeTab === 'search' ? '#FFFFFF' : 'transparent',
                alignItems: 'center',
                flexDirection: 'row',
                justifyContent: 'center',
                gap: 6,
                elevation: activeTab === 'search' ? 1 : 0
              }}
            >
              <I name="search" size={15} color={activeTab === 'search' ? '#111827' : '#6B7280'} />
              <T style={{ fontSize: 13, fontWeight: activeTab === 'search' ? '800' : '600', color: activeTab === 'search' ? '#111827' : '#6B7280' }}>
                {appLang === 'te' ? 'ప్రదేశం శోధించండి' : appLang === 'hi' ? 'स्थान खोजें' : 'Search Place'}
              </T>
            </Pressable>

            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Current GPS Location"
              onPress={() => { setActiveTab('gps'); setPendingSelection(null); }}
              style={{
                flex: 1,
                paddingVertical: 8,
                borderRadius: 9,
                backgroundColor: activeTab === 'gps' ? '#FFFFFF' : 'transparent',
                alignItems: 'center',
                flexDirection: 'row',
                justifyContent: 'center',
                gap: 6,
                elevation: activeTab === 'gps' ? 1 : 0
              }}
            >
              <I name="navigate" size={15} color={activeTab === 'gps' ? '#111827' : '#6B7280'} />
              <T style={{ fontSize: 13, fontWeight: activeTab === 'gps' ? '800' : '600', color: activeTab === 'gps' ? '#111827' : '#6B7280' }}>
                {appLang === 'te' ? 'ప్రస్తుత GPS' : appLang === 'hi' ? 'वर्तमान GPS' : 'Current GPS'}
              </T>
            </Pressable>
          </View>

          {/* Configuration Notice (Honest declaration of Google API status) */}
          <View style={{ backgroundColor: '#F8FAFC', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 7, marginBottom: 12, flexDirection: 'row', alignItems: 'center', gap: 6, borderWidth: 1, borderColor: '#E2E8F0' }}>
            <I name="information-circle-outline" size={16} color="#64748B" />
            <T style={{ fontSize: 11, color: '#64748B', flex: 1, lineHeight: 15 }}>
              {placesConfig.configured
                ? (appLang === 'te' ? 'Google Places API సక్రియంగా ఉంది.' : appLang === 'hi' ? 'Google Places API सक्रिय है।' : 'Google Places API is active.')
                : (appLang === 'te' ? 'Google Places కీ .env లో లేదు. AP & తెలంగాణ ప్రముఖ కాంట్రాక్టర్ ప్రాంతాల డేటాబేస్ ఉపయోగించబడుతోంది.' : appLang === 'hi' ? 'Google Places कुंजी .env में नहीं है। क्षेत्रीय डेटाबेस सक्रिय है।' : 'GOOGLE_PLACES_API_KEY not set in .env; using verified AP & Telangana contractor localities database.')}
            </T>
          </View>

          {/* TAB 1: SEARCH PLACE FLOW */}
          {activeTab === 'search' && (
            <View>
              {/* Search Input */}
              <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: '#F9FAFB', borderWidth: 1.2, borderColor: '#E5E7EB', borderRadius: 12, paddingHorizontal: 12, height: 44, marginBottom: 10 }}>
                <I name="search-outline" size={18} color="#9CA3AF" />
                <TextInput
                  accessibilityLabel={t.locSearchPlaceholder || 'లొకేషన్ లేదా ఏరియా శోధించండి'}
                  placeholder={t.locSearchPlaceholder || 'లొకేషన్ లేదా ఏరియా శోధించండి (e.g. Muralinagar, Benz Circle)'}
                  placeholderTextColor="#9CA3AF"
                  value={query}
                  onChangeText={handleQueryChange}
                  autoFocus={!pendingSelection}
                  style={{ flex: 1, marginLeft: 8, fontSize: 14, color: '#111827', ...(Platform.OS === 'web' ? { outlineStyle: 'none' } : {}) }}
                />
                {searching && <ActivityIndicator size="small" color="#EAB308" style={{ marginRight: 6 }} />}
                {query.length > 0 && (
                  <Pressable onPress={() => { setQuery(''); setPendingSelection(null); }}>
                    <I name="close-circle" size={18} color="#9CA3AF" />
                  </Pressable>
                )}
              </View>

              {/* CONFIRMATION SUMMARY CARD (Shown when a place is selected) */}
              {pendingSelection ? (
                <View style={{ backgroundColor: '#F0FDF4', borderWidth: 1.5, borderColor: '#86EFAC', borderRadius: 14, padding: 14, marginBottom: 12 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 }}>
                    <I name="checkmark-circle" size={18} color="#16A34A" />
                    <T style={{ fontSize: 13, fontWeight: '800', color: '#166534' }}>
                      {appLang === 'te' ? 'లొకేషన్ ధృవీకరణ' : appLang === 'hi' ? 'स्थान पुष्टि' : 'Location Confirmation'}
                    </T>
                  </View>

                  <T style={{ fontSize: 15, fontWeight: '800', color: '#111827', marginBottom: 2 }}>
                    {pendingSelection.displayName}
                  </T>
                  <T style={{ fontSize: 12.5, color: '#4B5563', marginBottom: 6, lineHeight: 17 }}>
                    {pendingSelection.formattedAddress}
                  </T>

                  {pendingSelection.lat && pendingSelection.lng && (
                    <T style={{ fontSize: 11, color: '#6B7280', marginBottom: 10 }}>
                      Coordinates: {pendingSelection.lat.toFixed(4)}, {pendingSelection.lng.toFixed(4)}
                    </T>
                  )}

                  <View style={{ flexDirection: 'row', gap: 8 }}>
                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel="Confirm & Save"
                      onPress={() => handleConfirmSave(pendingSelection)}
                      style={({ pressed }) => [{
                        flex: 1,
                        backgroundColor: '#16A34A',
                        borderRadius: 10,
                        paddingVertical: 10,
                        alignItems: 'center',
                        justifyContent: 'center',
                        opacity: pressed ? 0.85 : 1
                      }]}
                    >
                      <T style={{ fontSize: 13, fontWeight: '800', color: '#FFFFFF' }}>
                        {appLang === 'te' ? 'ఈ లొకేషన్ సెట్ చేయండి ✓' : appLang === 'hi' ? 'यह स्थान सेट करें ✓' : 'Confirm & Save Location ✓'}
                      </T>
                    </Pressable>

                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel="Cancel"
                      onPress={() => setPendingSelection(null)}
                      style={({ pressed }) => [{
                        paddingHorizontal: 12,
                        paddingVertical: 10,
                        backgroundColor: '#FFFFFF',
                        borderWidth: 1,
                        borderColor: '#CBD5E1',
                        borderRadius: 10,
                        alignItems: 'center',
                        justifyContent: 'center',
                        opacity: pressed ? 0.85 : 1
                      }]}
                    >
                      <T style={{ fontSize: 12.5, fontWeight: '600', color: '#4B5563' }}>
                        {appLang === 'te' ? 'మార్చండి' : appLang === 'hi' ? 'बदलें' : 'Change'}
                      </T>
                    </Pressable>
                  </View>
                </View>
              ) : null}

              {/* Suggestions List */}
              <ScrollView style={{ maxHeight: 260 }} keyboardShouldPersistTaps="handled">
                <View style={{ gap: 6 }}>
                  {suggestions.map((item, idx) => {
                    const isSelected = currentLocation === item.displayName || currentLocation === item.formattedAddress;
                    return (
                      <Pressable
                        key={item.placeId || idx}
                        accessibilityRole="button"
                        accessibilityLabel={item.displayName}
                        onPress={() => handleSelectSuggestion(item)}
                        style={({ pressed }) => [{
                          flexDirection: 'row',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          paddingVertical: 10,
                          paddingHorizontal: 12,
                          borderRadius: 10,
                          backgroundColor: isSelected ? '#FEF9C3' : pressed ? '#F8FAFC' : '#FFFFFF',
                          borderWidth: 1,
                          borderColor: isSelected ? '#FDE047' : '#F1F5F9'
                        }]}
                      >
                        <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: 10, flex: 1, marginRight: 8 }}>
                          <I name="location-outline" size={18} color={isSelected ? '#854D0E' : '#64748B'} style={{ marginTop: 2 }} />
                          <View style={{ flex: 1 }}>
                            <T style={{ fontSize: 13.5, fontWeight: isSelected ? '800' : '600', color: isSelected ? '#854D0E' : '#111827' }}>
                              {item.displayName}
                            </T>
                            <T numberOfLines={1} style={{ fontSize: 11.5, color: '#6B7280', marginTop: 1 }}>
                              {item.secondaryText || item.formattedAddress}
                            </T>
                          </View>
                        </View>
                        <I name="chevron-forward" size={16} color="#94A3B8" />
                      </Pressable>
                    );
                  })}

                  {query.trim().length >= 2 && suggestions.length === 0 && !searching && (
                    <View style={{ padding: 16, alignItems: 'center' }}>
                      <T style={{ fontSize: 13, color: '#64748B', textAlign: 'center', marginBottom: 8 }}>
                        {appLang === 'te' ? `"${query}" పేరుతో ఏరియా దొరకలేదు` : appLang === 'hi' ? `"${query}" नहीं मिला` : `No places found for "${query}"`}
                      </T>
                      <Pressable
                        onPress={() => handleConfirmSave({ placeId: 'custom_' + Date.now(), displayName: query.trim(), formattedAddress: query.trim() })}
                        style={{ backgroundColor: '#EFF6FF', borderWidth: 1, borderColor: '#BFDBFE', borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8 }}
                      >
                        <T style={{ fontSize: 12.5, fontWeight: '700', color: '#2563EB' }}>
                          "{query.trim()}" {t.locCustomSetBtn || 'నేరుగా సెట్ చేయండి'}
                        </T>
                      </Pressable>
                    </View>
                  )}
                </View>
              </ScrollView>
            </View>
          )}

          {/* TAB 2: CURRENT GPS LOCATION FLOW */}
          {activeTab === 'gps' && (
            <View>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Acquire GPS Location"
                onPress={handleGpsTrace}
                disabled={gpsLoading}
                style={({ pressed }) => [{
                  backgroundColor: gpsLoading ? '#F3F4F6' : '#FFD500',
                  borderRadius: 12,
                  paddingVertical: 12,
                  paddingHorizontal: 16,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 8,
                  marginBottom: 12,
                  opacity: (pressed || gpsLoading) ? 0.8 : 1
                }]}
              >
                {gpsLoading ? <ActivityIndicator size="small" color="#111827" /> : <I name="locate" size={18} color="#111827" />}
                <T style={{ fontSize: 14, fontWeight: '800', color: '#111827' }}>
                  {gpsLoading
                    ? (appLang === 'te' ? 'GPS లొకేషన్ శోధిస్తోంది…' : appLang === 'hi' ? 'GPS स्थान खोज रहा है…' : 'Detecting GPS Location…')
                    : (appLang === 'te' ? 'ప్రస్తుత GPS లొకేషన్ పొందండి' : appLang === 'hi' ? 'वर्तमान GPS स्थान प्राप्त करें' : 'Acquire Current GPS Location')}
                </T>
              </Pressable>

              {gpsError ? (
                <View style={{ backgroundColor: '#FEF2F2', borderWidth: 1, borderColor: '#FCA5A5', borderRadius: 10, padding: 10, marginBottom: 12 }}>
                  <T style={{ fontSize: 12, color: '#DC2626', textAlign: 'center', lineHeight: 16 }}>{gpsError}</T>
                </View>
              ) : null}

              {/* GPS Confirmation Summary */}
              {gpsResult && (
                <View style={{ backgroundColor: '#EFF6FF', borderWidth: 1.5, borderColor: '#93C5FD', borderRadius: 14, padding: 14, marginTop: 4 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                    <I name="navigate-circle" size={18} color="#2563EB" />
                    <T style={{ fontSize: 13, fontWeight: '800', color: '#1E40AF' }}>
                      {appLang === 'te' ? 'GPS నుండి కనుగొనబడింది (సుమారు)' : appLang === 'hi' ? 'GPS से प्राप्त स्थान (अनुमानित)' : 'Resolved from GPS (Approximate)'}
                    </T>
                  </View>

                  <T style={{ fontSize: 11, color: '#6B7280', marginBottom: 8 }}>
                    {appLang === 'te' ? 'పరికర స్థానం ఖచ్చితమైన భవనాన్ని చూపకపోవచ్చు. దయచేసి ధృవీకరించండి.' : appLang === 'hi' ? 'डिवाइस स्थान सटीक भवन की पहचान नहीं कर सकता। कृपया पुष्टि करें।' : 'Device location is approximate. Please verify before saving.'}
                  </T>

                  <T style={{ fontSize: 15, fontWeight: '800', color: '#111827', marginBottom: 2 }}>
                    {gpsResult.displayName}
                  </T>
                  <T style={{ fontSize: 12.5, color: '#4B5563', marginBottom: 6, lineHeight: 17 }}>
                    {gpsResult.formattedAddress}
                  </T>
                  <T style={{ fontSize: 11, color: '#6B7280', marginBottom: 12 }}>
                    Coordinates: {gpsResult.lat.toFixed(4)}, {gpsResult.lng.toFixed(4)}
                  </T>

                  <View style={{ flexDirection: 'row', gap: 8 }}>
                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel="Confirm GPS Location"
                      onPress={() => handleConfirmSave(gpsResult)}
                      style={({ pressed }) => [{
                        flex: 1,
                        backgroundColor: '#2563EB',
                        borderRadius: 10,
                        paddingVertical: 10,
                        alignItems: 'center',
                        justifyContent: 'center',
                        opacity: pressed ? 0.85 : 1
                      }]}
                    >
                      <T style={{ fontSize: 13, fontWeight: '800', color: '#FFFFFF' }}>
                        {appLang === 'te' ? 'ఈ లొకేషన్ ధృవీకరించండి ✓' : appLang === 'hi' ? 'यह स्थान सुरक्षित करें ✓' : 'Confirm & Save Location ✓'}
                      </T>
                    </Pressable>

                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel="Search Manually"
                      onPress={() => { setActiveTab('search'); setQuery(gpsResult.locality || gpsResult.city || ''); }}
                      style={({ pressed }) => [{
                        paddingHorizontal: 12,
                        paddingVertical: 10,
                        backgroundColor: '#FFFFFF',
                        borderWidth: 1,
                        borderColor: '#CBD5E1',
                        borderRadius: 10,
                        alignItems: 'center',
                        justifyContent: 'center',
                        opacity: pressed ? 0.85 : 1
                      }]}
                    >
                      <T style={{ fontSize: 12.5, fontWeight: '600', color: '#4B5563' }}>
                        {appLang === 'te' ? 'సవరించండి' : appLang === 'hi' ? 'संशोधन करें' : 'Edit / Search'}
                      </T>
                    </Pressable>
                  </View>
                </View>
              )}
            </View>
          )}

          {/* Current Saved Location Indicator */}
          {currentLocation ? (
            <View style={{ marginTop: 14, paddingTop: 10, borderTopWidth: 1, borderColor: '#F1F5F9', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <T style={{ fontSize: 11.5, color: '#6B7280' }}>
                {appLang === 'te' ? 'ప్రస్తుత సెట్ లొకేషన్:' : appLang === 'hi' ? 'वर्तमान सेट स्थान:' : 'Current set location:'}
              </T>
              <T numberOfLines={1} style={{ fontSize: 12, fontWeight: '700', color: '#111827', maxWidth: 220 }}>
                {currentLocation}
              </T>
            </View>
          ) : null}
        </View>
      </View>
    </Modal>
  );
}
