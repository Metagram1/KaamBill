import React, { useState, useEffect } from 'react';
import {
  View,
  Text as T,
  Pressable,
  TextInput,
  ScrollView,
  Modal,
  Platform,
  Alert
} from 'react-native';
import { Ionicons as I } from '@expo/vector-icons';
import { services } from './domain.cjs';
import { getStrings } from './i18n';
import CustomerModal from './CustomerModal';

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2);

const localDate = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

// Common Trade Presets for Fast Addition
const TRADE_MATERIAL_PRESETS = [
  { id: 'p1', category: 'steel', name: 'స్టీల్ రాడ్లు (Steel Rods)', enName: 'Steel rods', brand: 'Tata Tiscon', grade: 'Fe 550D', sizes: ['8 mm', '10 mm', '12 mm', '16 mm'], whereUsed: 'పునాదులు, కాలములు, బీమ్‌లు, స్లాబ్‌లు', suppliedBy: 'contractor' },
  { id: 'p2', category: 'cement', name: 'సిమెంట్ (Cement)', enName: 'Cement', brand: 'UltraTech', grade: '53 Grade OPC', sizes: ['50 kg bags'], whereUsed: 'కాంక్రీట్, ప్లాస్టరింగ్, బ్రిక్ వర్క్', suppliedBy: 'contractor' },
  { id: 'p3', category: 'sand', name: 'నది ఇసుక (River Sand)', enName: 'River Sand', brand: 'Local River Sand', grade: 'Double Washed', sizes: [], whereUsed: 'ప్లాస్టరింగ్ మరియు కాంక్రీట్', suppliedBy: 'customer' },
  { id: 'p4', category: 'pipes', name: 'పీవీసీ / సీపీవీసీ పైపులు (PVC Pipes)', enName: 'PVC Pipes', brand: 'Ashirvad', grade: 'Schedule 40', sizes: ['1 inch', '1.5 inch', '2 inch'], whereUsed: 'డ్రైనేజీ మరియు వాటర్ సప్లై లైన్స్', suppliedBy: 'contractor' },
  { id: 'p5', category: 'aggregates', name: 'కంకర (Aggregates)', enName: 'Aggregates', brand: 'Blue Metal', grade: '20 mm / 40 mm', sizes: ['20 mm', '40 mm'], whereUsed: 'కాలమ్ మరియు స్లాబ్ కాంక్రీట్', suppliedBy: 'customer' }
];

export default function MaterialsAgreementEditor({
  visible = true,
  onClose,
  w = { customers: [], projects: [], business: {}, agreements: [] },
  service = 'construction',
  appLang = 'te',
  initial = null,
  onSave,
  onOpenQuotation,
  onOpenInvoice,
  onPreview,
  onSaveCustomer
}) {
  const t = getStrings(appLang);
  const svcObj = services.find(s => s.id === service) || services[0];

  // Step state: 0 = Enter Details & Materials, 1 = Choose Template & Review
  const [step, setStep] = useState(initial?.initialStep !== undefined ? initial.initialStep : 0);

  useEffect(() => {
    if (initial?.initialStep !== undefined) {
      setStep(initial.initialStep);
    }
  }, [initial?.initialStep]);

  const [agreeTemplate, setAgreeTemplate] = useState(initial?.template || 'agree_standard');

  // Core metadata
  const [agreementId] = useState(initial?.id || uid());
  const [agreementNo] = useState(initial?.number || ((w.business?.prefix || 'TB') + '-AG-' + String((w.agreements?.length || 0) + 1).padStart(4, '0')));
  const [customerId, setCustomerId] = useState(initial?.customerId || w.customers[0]?.id || '');
  const [siteLocation, setSiteLocation] = useState(initial?.projectSite || initial?.siteLocation || w.customers.find(c => c.id === (initial?.customerId || w.customers[0]?.id))?.siteLocation || 'కైలాసపురం');
  const [workTitle, setWorkTitle] = useState(initial?.title || 'ఇంటి నిర్మాణం');
  const [docLanguage, setDocLanguage] = useState(initial?.language || appLang || 'te');
  const [date] = useState(initial?.date || localDate());

  // Category filter
  const [activeCategory, setActiveCategory] = useState('all');

  // Materials list
  const defaultInitialMaterials = [
    {
      id: uid(),
      category: 'steel',
      name: 'స్టీల్ రాడ్లు',
      brand: '',
      grade: '',
      sizes: ['8 mm', '12 mm'],
      whereUsed: 'పునాదులు, కాలములు, బీమ్‌లు, స్లాబ్‌లు',
      suppliedBy: 'contractor',
      expanded: true
    },
    {
      id: uid(),
      category: 'cement',
      name: 'సిమెంట్',
      brand: '',
      grade: '',
      sizes: [],
      whereUsed: 'ఒప్పుకున్న ప్రకారం',
      suppliedBy: 'contractor',
      expanded: false
    }
  ];

  const [materials, setMaterials] = useState(
    Array.isArray(initial?.materials) && initial.materials.length > 0
      ? initial.materials.map((m, idx) => ({ ...m, expanded: idx === 0 }))
      : defaultInitialMaterials
  );

  // Accordion states
  const [scopeTermsOpen, setScopeTermsOpen] = useState(false);
  const [signaturesOpen, setSignaturesOpen] = useState(false);
  const [terms, setTerms] = useState(initial?.terms || 'మెటీరియల్ మార్పులకు ముందస్తు కస్టమర్ అనుమతి అవసరం.');
  const [notes, setNotes] = useState(initial?.notes || '');

  // Sub-modals
  const [customerModalOpen, setCustomerModalOpen] = useState(false);
  const [customerDropdownOpen, setCustomerDropdownOpen] = useState(false);
  const [customerSearch, setCustomerSearch] = useState('');
  const [sizeInputModal, setSizeInputModal] = useState({ open: false, itemId: null, value: '' });

  if (!visible) return null;

  const selectedCustomer = w.customers.find(c => c.id === customerId) || {
    name: 'Jai Siva',
    siteLocation: 'కైలాసపురం',
    address: 'కైలాసపురం'
  };

  // Filter materials based on category
  const filteredMaterials = activeCategory === 'all'
    ? materials
    : materials.filter(m => m.category === activeCategory);

  // Add a blank material item
  const handleAddMaterial = (preset = null) => {
    const newItem = preset ? {
      id: uid(),
      category: preset.category || 'all',
      name: preset.name,
      brand: preset.brand || '',
      grade: preset.grade || '',
      sizes: [...(preset.sizes || [])],
      whereUsed: preset.whereUsed || '',
      suppliedBy: preset.suppliedBy || 'contractor',
      expanded: true
    } : {
      id: uid(),
      category: activeCategory !== 'all' ? activeCategory : 'all',
      name: 'కొత్త మెటీరియల్',
      brand: '',
      grade: '',
      sizes: [],
      whereUsed: '',
      suppliedBy: 'contractor',
      expanded: true
    };
    setMaterials([...materials, newItem]);
  };

  const handleToggleExpand = (id) => {
    setMaterials(materials.map(m => m.id === id ? { ...m, expanded: !m.expanded } : m));
  };

  const handleDeleteItem = (id) => {
    if (materials.length <= 1) {
      Alert.alert('Notice', 'At least one material specification is required.');
      return;
    }
    setMaterials(materials.filter(m => m.id !== id));
  };

  const handleUpdateItem = (id, field, value) => {
    setMaterials(materials.map(m => m.id === id ? { ...m, [field]: value } : m));
  };

  const handleRemoveSizeChip = (itemId, sizeIndex) => {
    setMaterials(materials.map(m => {
      if (m.id !== itemId) return m;
      const updatedSizes = [...m.sizes];
      updatedSizes.splice(sizeIndex, 1);
      return { ...m, sizes: updatedSizes };
    }));
  };

  const handleAddSizeChip = (itemId, sizeStr) => {
    const trimmed = String(sizeStr || '').trim();
    if (!trimmed) return;
    setMaterials(materials.map(m => {
      if (m.id !== itemId) return m;
      return { ...m, sizes: [...(m.sizes || []), trimmed] };
    }));
    setSizeInputModal({ open: false, itemId: null, value: '' });
  };

  // Compile full agreement payload
  const buildAgreementPayload = () => ({
    id: agreementId,
    number: agreementNo,
    customerId: selectedCustomer.id,
    customer: selectedCustomer,
    projectSite: siteLocation,
    title: workTitle,
    service,
    language: docLanguage,
    date,
    template: agreeTemplate,
    materials: materials.map(m => ({
      id: m.id,
      category: m.category,
      name: m.name,
      brand: m.brand,
      grade: m.grade,
      sizes: m.sizes,
      whereUsed: m.whereUsed,
      suppliedBy: m.suppliedBy
    })),
    terms,
    notes,
    status: 'draft'
  });

  const handlePreview = () => {
    const payload = buildAgreementPayload();
    if (onPreview) {
      onPreview(payload);
    }
  };

  const handleGenerateAgreement = async () => {
    if (!selectedCustomer?.id) {
      Alert.alert('Missing Customer', 'Select a customer first');
      setStep(0);
      return;
    }
    if (!materials || materials.length === 0) {
      Alert.alert('Missing Materials', 'Add at least 1 material specification');
      setStep(0);
      return;
    }
    const payload = buildAgreementPayload();
    if (onSave) {
      await onSave(payload);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end', alignItems: 'center' }}>
        <View
          style={{
            backgroundColor: '#FAF9F6',
            width: '100%',
            maxWidth: 480,
            height: '95%',
            borderTopLeftRadius: 28,
            borderTopRightRadius: 28,
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column'
          }}
        >
          {/* 1. Header with Back Chevron, TileBill PRO Logo, and Close */}
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 10, borderBottomWidth: 1, borderColor: '#F1F5F9' }}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Back"
              onPress={onClose}
              style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 20 }}
            >
              <I name="chevron-back" size={24} color="#171817" />
            </Pressable>

            {/* TileBill PRO Brand Logo */}
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
              <T style={{ fontSize: 18, fontWeight: '900', color: '#171817', letterSpacing: -0.3 }}>TileBill</T>
              <View style={{ backgroundColor: '#FFD500', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 }}>
                <T style={{ fontSize: 11, fontWeight: '900', color: '#171817' }}>PRO</T>
              </View>
            </View>

            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Close"
              onPress={onClose}
              style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 20 }}
            >
              <I name="close" size={22} color="#171817" />
            </Pressable>
          </View>

          {/* 2. Screen Title & Subtitle */}
          <View style={{ paddingHorizontal: 16, paddingVertical: 6, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E2E8F0', alignItems: 'center', justifyContent: 'center' }}>
              <I name="document-text-outline" size={20} color="#171817" />
            </View>
            <View>
              <T style={{ fontSize: 20, fontWeight: '800', color: '#171817' }}>
                {t.agreeEditorTitle || 'మెటీరియల్ అగ్రిమెంట్'}
              </T>
              <T style={{ fontSize: 12, color: '#667085', marginTop: 1 }}>
                {t.agreeEditorSub || 'ప్రాజెక్ట్ కోసం అవసరమైన మెటీరియల్ వివరాలు జోడించండి'}
              </T>
            </View>
          </View>

          {/* 3. Document Kind Tabs: Quotation / Invoice / Agreement */}
          <View style={{ paddingHorizontal: 16, marginVertical: 8 }}>
            <View style={{ flexDirection: 'row', backgroundColor: '#FFFFFF', borderRadius: 14, padding: 4, borderWidth: 1, borderColor: '#E2E8F0' }}>
              <Pressable
                accessibilityRole="tab"
                accessibilityLabel="Quotation"
                onPress={() => {
                  if (onOpenQuotation) onOpenQuotation();
                }}
                style={{ flex: 1, paddingVertical: 9, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 6, borderRadius: 10 }}
              >
                <I name="chatbox-ellipses-outline" size={15} color="#475569" />
                <T style={{ fontSize: 13, fontWeight: '600', color: '#475569' }}>
                  {t.docTypeQuotation || 'కొటేషన్'}
                </T>
              </Pressable>

              <Pressable
                accessibilityRole="tab"
                accessibilityLabel="Invoice"
                onPress={() => {
                  if (onOpenInvoice) onOpenInvoice();
                }}
                style={{ flex: 1, paddingVertical: 9, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 6, borderRadius: 10 }}
              >
                <I name="receipt-outline" size={15} color="#475569" />
                <T style={{ fontSize: 13, fontWeight: '600', color: '#475569' }}>
                  {t.docTypeInvoice || 'ఇన్‌వాయిస్'}
                </T>
              </Pressable>

              <Pressable
                accessibilityRole="tab"
                accessibilityLabel="Agreement"
                accessibilityState={{ selected: true }}
                style={{ flex: 1.2, paddingVertical: 9, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 6, borderRadius: 10, backgroundColor: '#FFD500' }}
              >
                <I name="create-outline" size={15} color="#171817" />
                <T style={{ fontSize: 13, fontWeight: '900', color: '#171817' }}>
                  {t.docTypeAgreement || 'అగ్రిమెంట్'}
                </T>
              </Pressable>
            </View>
          </View>

          {/* Scrollable Form Body */}
          <ScrollView
            style={{ flex: 1, paddingHorizontal: 16 }}
            contentContainerStyle={{ paddingBottom: 24 }}
            showsVerticalScrollIndicator={false}
          >
            {/* 4. 2x2 Metadata Cards (Reference 07) */}
            <View style={{ gap: 8, marginBottom: 10 }}>
              {/* Row 1: Customer & Service Type */}
              <View style={{ flexDirection: 'row', gap: 8 }}>
                {/* Customer Selector Card */}
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel="Select Customer"
                  onPress={() => setCustomerDropdownOpen(!customerDropdownOpen)}
                  style={{ flex: 1, backgroundColor: '#FFFFFF', borderRadius: 14, borderWidth: 1, borderColor: '#E2E8F0', padding: 10, justifyContent: 'center' }}
                >
                  <T style={{ fontSize: 11, color: '#64748B', fontWeight: '600' }}>కస్టమర్</T>
                  <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 3 }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, flex: 1, paddingRight: 4 }}>
                      <I name="person-outline" size={15} color="#171817" />
                      <T numberOfLines={1} style={{ fontSize: 12.5, fontWeight: '800', color: '#171817' }}>
                        {selectedCustomer.name} • {selectedCustomer.siteLocation || selectedCustomer.address || 'కైలాసపురం'}
                      </T>
                    </View>
                    <I name="chevron-forward" size={14} color="#667085" />
                  </View>
                </Pressable>

                {/* Service Type Card */}
                <View style={{ flex: 1, backgroundColor: '#FFFFFF', borderRadius: 14, borderWidth: 1, borderColor: '#E2E8F0', padding: 10, justifyContent: 'center' }}>
                  <T style={{ fontSize: 11, color: '#64748B', fontWeight: '600' }}>సేవా రకం</T>
                  <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 3 }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, flex: 1, paddingRight: 4 }}>
                      <I name="home-outline" size={15} color="#171817" />
                      <T numberOfLines={1} style={{ fontSize: 12.5, fontWeight: '800', color: '#171817' }}>
                        {svcObj.name} ({svcObj.id === 'construction' ? 'Construction' : svcObj.id})
                      </T>
                    </View>
                    <I name="chevron-forward" size={14} color="#667085" />
                  </View>
                </View>
              </View>

              {/* Row 2: Work Title & Language */}
              <View style={{ flexDirection: 'row', gap: 8 }}>
                {/* Work Title Card */}
                <View style={{ flex: 1.5, backgroundColor: '#FFFFFF', borderRadius: 14, borderWidth: 1, borderColor: '#E2E8F0', padding: 10, justifyContent: 'center' }}>
                  <T style={{ fontSize: 11, color: '#64748B', fontWeight: '600' }}>పని పేరు</T>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 3 }}>
                    <I name="document-outline" size={15} color="#171817" />
                    <TextInput
                      value={workTitle}
                      onChangeText={setWorkTitle}
                      placeholder="పని పేరు (Work title)"
                      placeholderTextColor="#94A3B8"
                      style={{ flex: 1, fontSize: 13, fontWeight: '800', color: '#171817', padding: 0 }}
                    />
                  </View>
                </View>

                {/* Language Card */}
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel="Select Document Language"
                  onPress={() => {
                    const next = docLanguage === 'te' ? 'en' : docLanguage === 'en' ? 'hi' : 'te';
                    setDocLanguage(next);
                  }}
                  style={{ flex: 1, backgroundColor: '#FFFFFF', borderRadius: 14, borderWidth: 1, borderColor: '#E2E8F0', padding: 10, justifyContent: 'center' }}
                >
                  <T style={{ fontSize: 11, color: '#64748B', fontWeight: '600' }}>భాష</T>
                  <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 3 }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                      <View style={{ width: 18, height: 18, borderRadius: 4, backgroundColor: '#171817', alignItems: 'center', justifyContent: 'center' }}>
                        <T style={{ fontSize: 10, fontWeight: '900', color: '#FFFFFF' }}>A</T>
                      </View>
                      <T style={{ fontSize: 12.5, fontWeight: '800', color: '#171817' }}>
                        {docLanguage === 'te' ? 'తెలుగు' : docLanguage === 'en' ? 'English' : 'हिंदी'}
                      </T>
                    </View>
                    <I name="chevron-down" size={14} color="#667085" />
                  </View>
                </Pressable>
              </View>
            </View>

            {/* Customer Dropdown (if open) */}
            {customerDropdownOpen && (
              <View style={{ backgroundColor: '#FFFFFF', borderRadius: 14, borderWidth: 1, borderColor: '#E2E8F0', padding: 12, marginBottom: 12, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 4, elevation: 3 }}>
                <TextInput
                  value={customerSearch}
                  onChangeText={setCustomerSearch}
                  placeholder="కస్టమర్ పేరు లేదా ఫోన్ వెతకండి…"
                  placeholderTextColor="#94A3B8"
                  style={{ backgroundColor: '#F8FAFC', borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8, fontSize: 13, borderWidth: 1, borderColor: '#E2E8F0', marginBottom: 8 }}
                />
                {(w.customers || [])
                  .filter(c => !customerSearch || c.name.toLowerCase().includes(customerSearch.toLowerCase()) || c.phone?.includes(customerSearch))
                  .slice(0, 5)
                  .map(c => (
                    <Pressable
                      key={c.id}
                      onPress={() => {
                        setCustomerId(c.id);
                        if (c.siteLocation) setSiteLocation(c.siteLocation);
                        setCustomerDropdownOpen(false);
                      }}
                      style={{ paddingVertical: 8, borderBottomWidth: 1, borderColor: '#F1F5F9', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}
                    >
                      <View>
                        <T style={{ fontSize: 13, fontWeight: '700', color: '#171817' }}>{c.name}</T>
                        <T style={{ fontSize: 11, color: '#64748B' }}>{c.siteLocation || c.address || 'కైలాసపురం'}</T>
                      </View>
                      {customerId === c.id && <I name="checkmark-circle" size={18} color="#FFD500" />}
                    </Pressable>
                  ))}
                <Pressable
                  onPress={() => {
                    setCustomerDropdownOpen(false);
                    setCustomerModalOpen(true);
                  }}
                  style={{ marginTop: 8, paddingVertical: 8, alignItems: 'center', backgroundColor: '#FEF9C3', borderRadius: 8 }}
                >
                  <T style={{ fontSize: 12, fontWeight: '800', color: '#854D0E' }}>+ కొత్త కస్టమర్‌ని జోడించండి</T>
                </Pressable>
              </View>
            )}

            {/* 5. Warning Notice: Material Specifications Only · NO PRICES (Reference 07) */}
            <View style={{ backgroundColor: '#FEF9C3', borderRadius: 12, paddingVertical: 10, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 14, borderWidth: 1, borderColor: '#FEF08A' }}>
              <I name="information-circle" size={18} color="#854D0E" />
              <T style={{ fontSize: 12.5, fontWeight: '700', color: '#713F12', flex: 1 }}>
                {t.agreeInfoNotice || 'మెటీరియల్ వివరాలు మాత్రమే · ధరలు ఉండవు'}
              </T>
            </View>

            {/* 6. Section Header & Category Filters */}
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
              <T style={{ fontSize: 15, fontWeight: '800', color: '#171817' }}>
                {t.agreeSectionMaterials || 'మెటీరియల్ జాబితా'}
              </T>

              {/* Category Pills */}
              <View style={{ flexDirection: 'row', gap: 6 }}>
                {[
                  { id: 'all', label: t.agreeCatAll || 'అన్నీ' },
                  { id: 'steel', label: t.agreeCatSteel || 'స్టీల్' },
                  { id: 'cement', label: t.agreeCatCement || 'సిమెంట్' }
                ].map(cat => {
                  const isActive = activeCategory === cat.id;
                  return (
                    <Pressable
                      key={cat.id}
                      accessibilityRole="button"
                      accessibilityLabel={cat.label}
                      onPress={() => setActiveCategory(cat.id)}
                      style={{
                        paddingHorizontal: 12,
                        paddingVertical: 5,
                        borderRadius: 16,
                        backgroundColor: isActive ? '#FFD500' : '#F1F5F9',
                        borderWidth: isActive ? 0 : 1,
                        borderColor: '#E2E8F0'
                      }}
                    >
                      <T style={{ fontSize: 12, fontWeight: isActive ? '800' : '600', color: '#171817' }}>
                        {cat.label}
                      </T>
                    </Pressable>
                  );
                })}
              </View>
            </View>

            {/* 7. Material Cards List */}
            <View style={{ gap: 10 }}>
              {filteredMaterials.map((m, idx) => {
                const itemIndexStr = String(idx + 1).padStart(2, '0');
                const isExpanded = m.expanded;
                const isContractorSupply = m.suppliedBy === 'contractor';

                return (
                  <View
                    key={m.id}
                    style={{
                      backgroundColor: '#FFFFFF',
                      borderRadius: 16,
                      borderWidth: 1,
                      borderColor: '#E2E8F0',
                      padding: 14,
                      shadowColor: '#000',
                      shadowOffset: { width: 0, height: 1 },
                      shadowOpacity: 0.04,
                      shadowRadius: 3,
                      elevation: 1
                    }}
                  >
                    {/* Item Top Bar */}
                    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1, paddingRight: 6 }}>
                        {/* Number Badge */}
                        <View style={{ width: 28, height: 28, borderRadius: 14, backgroundColor: '#FEF08A', alignItems: 'center', justifyContent: 'center' }}>
                          <T style={{ fontSize: 12, fontWeight: '800', color: '#713F12' }}>{itemIndexStr}</T>
                        </View>

                        {/* Trade Icon */}
                        <View style={{ width: 34, height: 34, borderRadius: 8, backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#E2E8F0', alignItems: 'center', justifyContent: 'center' }}>
                          <I
                            name={m.category === 'steel' ? 'construct-outline' : m.category === 'cement' ? 'cube-outline' : 'layers-outline'}
                            size={18}
                            color="#334155"
                          />
                        </View>

                        {/* Title & summary if collapsed */}
                        <View style={{ flex: 1 }}>
                          <TextInput
                            value={m.name}
                            onChangeText={(val) => handleUpdateItem(m.id, 'name', val)}
                            placeholder="మెటీరియల్ పేరు"
                            placeholderTextColor="#94A3B8"
                            style={{ fontSize: 15, fontWeight: '800', color: '#171817', padding: 0 }}
                          />
                          {!isExpanded && (
                            <T style={{ fontSize: 11, color: '#64748B', marginTop: 2 }}>
                              బ్రాండ్: {m.brand || '—'}  |  గ్రేడ్: {m.grade || '—'}
                            </T>
                          )}
                        </View>
                      </View>

                      {/* Right Action Buttons */}
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                        {/* Edit Button */}
                        <Pressable
                          accessibilityRole="button"
                          accessibilityLabel="Edit item"
                          onPress={() => handleToggleExpand(m.id)}
                          style={{ width: 32, height: 32, borderRadius: 8, backgroundColor: '#F1F5F9', alignItems: 'center', justifyContent: 'center' }}
                        >
                          <I name="pencil" size={14} color="#334155" />
                        </Pressable>

                        {/* Delete Button */}
                        <Pressable
                          accessibilityRole="button"
                          accessibilityLabel="Delete item"
                          onPress={() => handleDeleteItem(m.id)}
                          style={{ width: 32, height: 32, borderRadius: 8, backgroundColor: '#FEE2E2', alignItems: 'center', justifyContent: 'center' }}
                        >
                          <I name="trash-outline" size={15} color="#EF4444" />
                        </Pressable>

                        {/* Collapse/Expand Chevron */}
                        <Pressable
                          accessibilityRole="button"
                          accessibilityLabel="Expand or collapse item"
                          onPress={() => handleToggleExpand(m.id)}
                          style={{ width: 28, height: 28, alignItems: 'center', justifyContent: 'center' }}
                        >
                          <I name={isExpanded ? 'chevron-up' : 'chevron-down'} size={17} color="#64748B" />
                        </Pressable>
                      </View>
                    </View>

                    {/* Expanded Fields */}
                    {isExpanded && (
                      <View style={{ marginTop: 14, paddingTop: 12, borderTopWidth: 1, borderColor: '#F1F5F9', gap: 12 }}>
                        {/* Row: Brand & Grade */}
                        <View style={{ flexDirection: 'row', gap: 10 }}>
                          {/* Brand */}
                          <View style={{ flex: 1 }}>
                            <T style={{ fontSize: 11.5, fontWeight: '700', color: '#171817', marginBottom: 4 }}>
                              {t.agreeBrandLabel || 'బ్రాండ్'}
                            </T>
                            <TextInput
                              value={m.brand}
                              onChangeText={(val) => handleUpdateItem(m.id, 'brand', val)}
                              placeholder={t.agreeBrandPlaceholder || 'బ్రాండ్ నమోదు చేయండి'}
                              placeholderTextColor="#94A3B8"
                              style={{ backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8, fontSize: 13, color: '#171817' }}
                            />
                          </View>

                          {/* Grade */}
                          <View style={{ flex: 1 }}>
                            <T style={{ fontSize: 11.5, fontWeight: '700', color: '#171817', marginBottom: 4 }}>
                              {t.agreeGradeLabel || 'గ్రేడ్'}
                            </T>
                            <TextInput
                              value={m.grade}
                              onChangeText={(val) => handleUpdateItem(m.id, 'grade', val)}
                              placeholder={t.agreeGradePlaceholder || 'గ్రేడ్ నమోదు చేయండి'}
                              placeholderTextColor="#94A3B8"
                              style={{ backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8, fontSize: 13, color: '#171817' }}
                            />
                          </View>
                        </View>

                        {/* Sizes Chips Row */}
                        <View>
                          <T style={{ fontSize: 11.5, fontWeight: '700', color: '#171817', marginBottom: 6 }}>
                            {t.agreeSizesLabel || 'సైజులు'}
                          </T>
                          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, alignItems: 'center' }}>
                            {(m.sizes || []).map((sz, szIdx) => (
                              <View
                                key={szIdx}
                                style={{ backgroundColor: '#F1F5F9', borderRadius: 14, paddingHorizontal: 10, paddingVertical: 6, flexDirection: 'row', alignItems: 'center', gap: 6, borderWidth: 1, borderColor: '#E2E8F0' }}
                              >
                                <T style={{ fontSize: 12, fontWeight: '700', color: '#171817' }}>{sz}</T>
                                <Pressable
                                  accessibilityRole="button"
                                  accessibilityLabel={`Remove size ${sz}`}
                                  onPress={() => handleRemoveSizeChip(m.id, szIdx)}
                                >
                                  <I name="close-circle" size={14} color="#94A3B8" />
                                </Pressable>
                              </View>
                            ))}

                            {/* + Size Chip Button */}
                            <Pressable
                              accessibilityRole="button"
                              accessibilityLabel="Add size"
                              onPress={() => setSizeInputModal({ open: true, itemId: m.id, value: '' })}
                              style={{ borderStyle: 'dashed', borderWidth: 1, borderColor: '#94A3B8', borderRadius: 14, paddingHorizontal: 12, paddingVertical: 6, backgroundColor: '#FFFFFF' }}
                            >
                              <T style={{ fontSize: 12, fontWeight: '700', color: '#475569' }}>
                                {t.agreeAddSizeChip || '+ సైజు'}
                              </T>
                            </Pressable>
                          </View>
                          <T style={{ fontSize: 10.5, color: '#94A3B8', marginTop: 4 }}>
                            {t.agreeSizesHint || 'నమూనా • ప్రాజెక్ట్ ప్రకారం మార్చండి'}
                          </T>
                        </View>

                        {/* Where Used Input */}
                        <View>
                          <T style={{ fontSize: 11.5, fontWeight: '700', color: '#171817', marginBottom: 4 }}>
                            {t.agreeWhereUsedLabel || 'వాడే ప్రదేశం'}
                          </T>
                          <TextInput
                            value={m.whereUsed}
                            onChangeText={(val) => handleUpdateItem(m.id, 'whereUsed', val)}
                            placeholder={t.agreeWhereUsedPlaceholder || 'ఉదా: పునాదులు, కాలములు, బీమ్‌లు, స్లాబ్‌లు'}
                            placeholderTextColor="#94A3B8"
                            multiline
                            style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8, fontSize: 12.5, color: '#171817', minHeight: 48 }}
                          />
                        </View>

                        {/* Supplied By Toggle */}
                        <View>
                          <T style={{ fontSize: 11.5, fontWeight: '700', color: '#171817', marginBottom: 6 }}>
                            {t.agreeSuppliedByLabel || 'సరఫరా'}
                          </T>
                          <View style={{ flexDirection: 'row', gap: 10 }}>
                            {/* Contractor Option */}
                            <Pressable
                              accessibilityRole="button"
                              accessibilityLabel="Supplied by contractor"
                              onPress={() => handleUpdateItem(m.id, 'suppliedBy', 'contractor')}
                              style={{
                                flex: 1,
                                paddingVertical: 10,
                                borderRadius: 12,
                                backgroundColor: isContractorSupply ? '#FFD500' : '#F1F5F9',
                                flexDirection: 'row',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: 6,
                                borderWidth: isContractorSupply ? 0 : 1,
                                borderColor: '#E2E8F0'
                              }}
                            >
                              <I name="car-outline" size={16} color={isContractorSupply ? '#171817' : '#475569'} />
                              <T style={{ fontSize: 12.5, fontWeight: isContractorSupply ? '800' : '600', color: isContractorSupply ? '#171817' : '#475569' }}>
                                {t.agreeByContractor || 'కాంట్రాక్టర్ ద్వారా'}
                              </T>
                            </Pressable>

                            {/* Customer Option */}
                            <Pressable
                              accessibilityRole="button"
                              accessibilityLabel="Supplied by customer"
                              onPress={() => handleUpdateItem(m.id, 'suppliedBy', 'customer')}
                              style={{
                                flex: 1,
                                paddingVertical: 10,
                                borderRadius: 12,
                                backgroundColor: !isContractorSupply ? '#FFD500' : '#F1F5F9',
                                flexDirection: 'row',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: 6,
                                borderWidth: !isContractorSupply ? 0 : 1,
                                borderColor: '#E2E8F0'
                              }}
                            >
                              <I name="person-outline" size={16} color={!isContractorSupply ? '#171817' : '#475569'} />
                              <T style={{ fontSize: 12.5, fontWeight: !isContractorSupply ? '800' : '600', color: !isContractorSupply ? '#171817' : '#475569' }}>
                                {t.agreeByCustomer || 'కస్టమర్ ద్వారా'}
                              </T>
                            </Pressable>
                          </View>
                        </View>
                      </View>
                    )}
                  </View>
                );
              })}
            </View>

            {/* 8. Add Material Button (Dashed Yellow Border) */}
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Add material"
              onPress={() => handleAddMaterial()}
              style={{
                borderWidth: 1.5,
                borderStyle: 'dashed',
                borderColor: '#F59E0B',
                borderRadius: 14,
                paddingVertical: 14,
                alignItems: 'center',
                justifyContent: 'center',
                flexDirection: 'row',
                gap: 8,
                backgroundColor: '#FFFDF5',
                marginTop: 12
              }}
            >
              <I name="add" size={18} color="#D97706" />
              <T style={{ fontSize: 14, fontWeight: '800', color: '#B45309' }}>
                {t.agreeAddMaterialBtn || '+ మెటీరియల్ జోడించండి'}
              </T>
            </Pressable>

            {/* 9. Import From Presets Shortcut */}
            <View style={{ marginTop: 12, backgroundColor: '#FFFFFF', borderRadius: 14, borderWidth: 1, borderColor: '#E2E8F0', overflow: 'hidden' }}>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Import from presets"
                onPress={() => {
                  TRADE_MATERIAL_PRESETS.forEach(p => {
                    if (!materials.some(m => m.name.includes(p.enName))) {
                      handleAddMaterial(p);
                    }
                  });
                  Alert.alert('Presets Imported', 'Common building materials specifications added.');
                }}
                style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 14 }}
              >
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                  <I name="list-outline" size={18} color="#171817" />
                  <T style={{ fontSize: 13.5, fontWeight: '700', color: '#171817' }}>
                    {t.agreeImportPresetsBtn || 'సేవ్ చేసిన జాబితా నుండి తీసుకోండి'}
                  </T>
                </View>
                <I name="chevron-forward" size={16} color="#667085" />
              </Pressable>
            </View>

            {/* 10. Scope & Terms Accordion */}
            <View style={{ marginTop: 10, backgroundColor: '#FFFFFF', borderRadius: 14, borderWidth: 1, borderColor: '#E2E8F0', overflow: 'hidden' }}>
              <Pressable
                accessibilityRole="button"
                onPress={() => setScopeTermsOpen(!scopeTermsOpen)}
                style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 14 }}
              >
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                  <I name="clipboard-outline" size={18} color="#171817" />
                  <T style={{ fontSize: 13.5, fontWeight: '700', color: '#171817' }}>
                    {t.agreeScopeTerms || 'పని పరిధి & నిబంధనలు'}
                  </T>
                </View>
                <I name={scopeTermsOpen ? 'chevron-up' : 'chevron-down'} size={16} color="#667085" />
              </Pressable>

              {scopeTermsOpen && (
                <View style={{ padding: 14, borderTopWidth: 1, borderColor: '#F1F5F9', backgroundColor: '#FAFAFA' }}>
                  <TextInput
                    value={terms}
                    onChangeText={setTerms}
                    placeholder="నిబంధనలు నమోదు చేయండి…"
                    placeholderTextColor="#94A3B8"
                    multiline
                    style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 10, padding: 10, fontSize: 12.5, color: '#171817', minHeight: 60 }}
                  />
                </View>
              )}
            </View>

            {/* 11. Signatures Accordion */}
            <View style={{ marginTop: 10, backgroundColor: '#FFFFFF', borderRadius: 14, borderWidth: 1, borderColor: '#E2E8F0', overflow: 'hidden' }}>
              <Pressable
                accessibilityRole="button"
                onPress={() => setSignaturesOpen(!signaturesOpen)}
                style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 14 }}
              >
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                  <I name="pencil-outline" size={18} color="#171817" />
                  <T style={{ fontSize: 13.5, fontWeight: '700', color: '#171817' }}>
                    {t.agreeSignatures || 'సంతకాలు'}
                  </T>
                </View>
                <I name={signaturesOpen ? 'chevron-up' : 'chevron-down'} size={16} color="#667085" />
              </Pressable>

              {signaturesOpen && (
                <View style={{ padding: 14, borderTopWidth: 1, borderColor: '#F1F5F9', backgroundColor: '#FAFAFA', gap: 8 }}>
                  <T style={{ fontSize: 12, color: '#475569' }}>
                    Contractor Signatory: {w.business?.name || 'Mahesh Constructions'}
                  </T>
                  <T style={{ fontSize: 12, color: '#475569' }}>
                    Customer Signatory: {selectedCustomer.name}
                  </T>
                  <T style={{ fontSize: 11, color: '#64748B' }}>
                    Printed agreement will include verified signature boxes with dates.
                  </T>
                </View>
              )}
            </View>
          </ScrollView>

          {/* 12. Sticky Bottom Bar (Reference 07) */}
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              paddingHorizontal: 16,
              paddingVertical: 12,
              backgroundColor: '#FFFFFF',
              borderTopWidth: 1,
              borderColor: '#E2E8F0'
            }}
          >
            {/* Left Counter */}
            <View>
              <T style={{ fontSize: 14, fontWeight: '900', color: '#171817' }}>
                {t.agreeCountLabel ? t.agreeCountLabel.replace('{count}', materials.length) : `${materials.length} మెటీరియల్స్`}
              </T>
              <T style={{ fontSize: 11, color: '#64748B', marginTop: 1 }}>
                {t.agreeSpecsOnly || 'మెటీరియల్ వివరాలు మాత్రమే'}
              </T>
            </View>

            {/* Right Preview Action Button */}
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Agreement Preview"
              onPress={handlePreview}
              style={({ pressed }) => [{
                backgroundColor: '#FFD500',
                borderRadius: 14,
                paddingVertical: 12,
                paddingHorizontal: 20,
                flexDirection: 'row',
                alignItems: 'center',
                gap: 6,
                shadowColor: '#EAB308',
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.25,
                shadowRadius: 4,
                elevation: 3,
                opacity: pressed ? 0.88 : 1
              }]}
            >
              <I name="eye" size={17} color="#171817" />
              <T style={{ fontSize: 14, fontWeight: '900', color: '#171817' }}>
                {t.agreePreviewBtn || 'అగ్రిమెంట్ ప్రివ్యూ'}
              </T>
              <I name="chevron-forward" size={15} color="#171817" />
            </Pressable>
          </View>
        </View>
      </View>

      {/* Customer Modal if adding new customer */}
      {customerModalOpen && (
        <CustomerModal
          visible={customerModalOpen}
          service={service}
          appLang={appLang}
          onClose={() => setCustomerModalOpen(false)}
          onSave={(cust) => {
            if (onSaveCustomer) onSaveCustomer(cust);
            setCustomerId(cust.id);
            if (cust.siteLocation) setSiteLocation(cust.siteLocation);
            setCustomerModalOpen(false);
          }}
        />
      )}

      {/* Mini Modal for Custom Size Input */}
      {sizeInputModal.open && (
        <Modal transparent animationType="fade" visible={sizeInputModal.open} onRequestClose={() => setSizeInputModal({ open: false, itemId: null, value: '' })}>
          <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center', padding: 24 }}>
            <View style={{ width: '100%', maxWidth: 360, backgroundColor: '#FFFFFF', borderRadius: 16, padding: 20, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.15, shadowRadius: 8, elevation: 5 }}>
              <T style={{ fontSize: 16, fontWeight: '800', color: '#171817', marginBottom: 10 }}>
                {t.agreeAddSizeChip || '+ సైజు నమోదు చేయండి'}
              </T>
              <TextInput
                autoFocus
                value={sizeInputModal.value}
                onChangeText={(val) => setSizeInputModal({ ...sizeInputModal, value: val })}
                placeholder="ఉదా: 8 mm, 12 mm, 2 inch"
                placeholderTextColor="#94A3B8"
                style={{ borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10, fontSize: 14, color: '#171817', marginBottom: 14 }}
              />
              <View style={{ flexDirection: 'row', gap: 10 }}>
                <Pressable
                  onPress={() => setSizeInputModal({ open: false, itemId: null, value: '' })}
                  style={{ flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 10, borderWidth: 1, borderColor: '#CBD5E1' }}
                >
                  <T style={{ fontSize: 13, fontWeight: '700', color: '#475569' }}>Cancel</T>
                </Pressable>
                <Pressable
                  onPress={() => handleAddSizeChip(sizeInputModal.itemId, sizeInputModal.value)}
                  style={{ flex: 1.5, paddingVertical: 10, alignItems: 'center', borderRadius: 10, backgroundColor: '#FFD500' }}
                >
                  <T style={{ fontSize: 13, fontWeight: '900', color: '#171817' }}>Add Size</T>
                </Pressable>
              </View>
            </View>
          </View>
        </Modal>
      )}
    </Modal>
  );
}
