import React, { useState } from 'react';
import {
  View,
  Text as T,
  Pressable,
  ScrollView,
  Modal,
  Platform,
  Alert
} from 'react-native';
import { Ionicons as I } from '@expo/vector-icons';
import { getStrings } from './i18n';
import { agreementHtml } from './domain.cjs';

export default function MaterialsAgreementPreviewModal({
  visible = true,
  onClose,
  agreement = {},
  business = {},
  linkedQuotation = null,
  appLang = 'te',
  onEdit,
  onGeneratePdf,
  onDownload,
  onShare
}) {
  const t = getStrings(appLang);

  const [docLanguage, setDocLanguage] = useState(agreement.language || 'en');
  const [pageSize, setPageSize] = useState(agreement.pageSize || 'a4');
  const [pdfMode, setPdfMode] = useState('standalone'); // 'standalone' | 'annexure'

  if (!visible) return null;

  const bizName = business.name || 'Mahesh Constructions';
  const bizAddress = business.address || 'Kailasapuram, Hyderabad - 500072';
  const bizPhone = business.phone || '97000 12345';
  const bizEmail = business.email || 'mahesh@construction.in';
  const custName = agreement.customer?.name || linkedQuotation?.customer?.name || 'Jai Siva';
  const siteLocation = agreement.projectSite || agreement.siteLocation || linkedQuotation?.siteLocation || 'Kailasapuram';
  const agreeNumber = agreement.number || 'AG-0001';
  const agreeDate = agreement.date || '18 Oct 2026';

  const defaultMaterials = [
    { name: 'Steel rods', brand: '', grade: '', sizes: ['8 mm', '12 mm*'], whereUsed: '', suppliedBy: 'contractor' },
    { name: 'Cement', brand: '', grade: '', sizes: [], whereUsed: 'As agreed', suppliedBy: 'contractor' },
    { name: 'Pipes', brand: '', grade: '', sizes: [], whereUsed: 'To be specified', suppliedBy: 'customer' }
  ];

  const materials = (agreement.materials && agreement.materials.length > 0)
    ? agreement.materials
    : defaultMaterials;

  const scopeNotes = agreement.terms || agreement.notes || 'Material substitutions require prior customer approval.';

  const handleGeneratePdf = () => {
    if (onGeneratePdf) {
      onGeneratePdf({ ...agreement, language: docLanguage, pageSize, pdfMode });
    } else {
      Alert.alert('PDF Ready', `Generated ${pdfMode === 'standalone' ? 'Standalone Agreement PDF' : 'Quotation Annexure PDF'}`);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end', alignItems: 'center' }}>
        <View
          style={{
            backgroundColor: '#FAF9F6',
            width: '100%',
            maxWidth: 480,
            height: '95%',
            borderTopLeftRadius: 28,
            borderTopRightRadius: 28,
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column'
          }}
        >
          {/* 1. Top Header Bar: Back, Title, 3-dots Menu (Reference 08) */}
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 10, borderBottomWidth: 1, borderColor: '#F1F5F9' }}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Back"
              onPress={onClose}
              style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 20 }}
            >
              <I name="arrow-back" size={24} color="#171817" />
            </Pressable>

            <T style={{ fontSize: 18, fontWeight: '800', color: '#171817' }}>
              {t.agreePreviewTitle || 'అగ్రిమెంట్ ప్రివ్యూ'}
            </T>

            <Pressable
              accessibilityRole="button"
              accessibilityLabel="More options"
              onPress={() => {
                Alert.alert('Agreement Options', `Agreement ${agreeNumber}\nCustomer: ${custName}\nSite: ${siteLocation}`);
              }}
              style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 20 }}
            >
              <I name="ellipsis-vertical" size={20} color="#171817" />
            </Pressable>
          </View>

          {/* 2. Top 3 Selectors Pill Row: Draft | Language | Page Size */}
          <View style={{ flexDirection: 'row', gap: 8, paddingHorizontal: 16, marginVertical: 8 }}>
            {/* Status Pill */}
            <View
              style={{
                backgroundColor: '#FEF08A',
                borderRadius: 12,
                paddingHorizontal: 12,
                paddingVertical: 7,
                flexDirection: 'row',
                alignItems: 'center',
                gap: 5
              }}
            >
              <I name="document-text-outline" size={15} color="#713F12" />
              <T style={{ fontSize: 12, fontWeight: '800', color: '#713F12' }}>Draft</T>
            </View>

            {/* Language Selector Pill */}
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Select document language"
              onPress={() => {
                const next = docLanguage === 'en' ? 'te' : docLanguage === 'te' ? 'hi' : 'en';
                setDocLanguage(next);
              }}
              style={{
                backgroundColor: '#FFFFFF',
                borderRadius: 12,
                borderWidth: 1,
                borderColor: '#E2E8F0',
                paddingHorizontal: 12,
                paddingVertical: 7,
                flexDirection: 'row',
                alignItems: 'center',
                gap: 6
              }}
            >
              <I name="globe-outline" size={15} color="#171817" />
              <T style={{ fontSize: 12, fontWeight: '700', color: '#171817' }}>
                {docLanguage === 'en' ? 'English' : docLanguage === 'te' ? 'తెలుగు' : 'हिंदी'}
              </T>
              <I name="chevron-down" size={13} color="#64748B" />
            </Pressable>

            {/* Page Size Pill */}
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Select paper size"
              onPress={() => {
                const next = pageSize === 'a4' ? 'letter' : pageSize === 'letter' ? 'a5' : 'a4';
                setPageSize(next);
              }}
              style={{
                backgroundColor: '#FFFFFF',
                borderRadius: 12,
                borderWidth: 1,
                borderColor: '#E2E8F0',
                paddingHorizontal: 12,
                paddingVertical: 7,
                flexDirection: 'row',
                alignItems: 'center',
                gap: 6
              }}
            >
              <I name="document-outline" size={15} color="#171817" />
              <T style={{ fontSize: 12, fontWeight: '700', color: '#171817' }}>
                {pageSize.toUpperCase()}
              </T>
              <I name="chevron-down" size={13} color="#64748B" />
            </Pressable>
          </View>

          {/* 3. Scrollable Document Card Area */}
          <ScrollView
            style={{ flex: 1, paddingHorizontal: 16 }}
            contentContainerStyle={{ paddingBottom: 24 }}
            showsVerticalScrollIndicator={false}
          >
            {/* Document Render Container */}
            <View
              style={{
                backgroundColor: '#FFFFFF',
                borderRadius: 14,
                borderWidth: 1,
                borderColor: '#E2E8F0',
                padding: 16,
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.06,
                shadowRadius: 6,
                elevation: 2
              }}
            >
              {/* Header: Brand + Metadata */}
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', paddingBottom: 10 }}>
                {/* Brand Info */}
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1, paddingRight: 8 }}>
                  <View style={{ width: 42, height: 42, borderRadius: 10, backgroundColor: '#FEF08A', alignItems: 'center', justifyContent: 'center' }}>
                    <I name="home" size={24} color="#854D0E" />
                  </View>
                  <View style={{ flex: 1 }}>
                    <T style={{ fontSize: 16, fontWeight: '900', color: '#0F172A' }}>
                      {bizName}
                    </T>
                    <T style={{ fontSize: 10.5, color: '#475569', marginTop: 1 }}>{bizAddress}</T>
                    <T style={{ fontSize: 10, color: '#64748B', marginTop: 1 }}>Ph: {bizPhone} | {bizEmail}</T>
                  </View>
                </View>

                {/* Right Meta Column */}
                <View style={{ alignItems: 'flex-end', minWidth: 120 }}>
                  <T style={{ fontSize: 10.5, color: '#334155' }}>
                    Agreement No: <T style={{ fontWeight: '800', color: '#0F172A' }}>{agreeNumber}</T>
                  </T>
                  <T style={{ fontSize: 10.5, color: '#334155', marginTop: 2 }}>
                    Date: <T style={{ fontWeight: '600', color: '#0F172A' }}>{agreeDate}</T>
                  </T>
                  <T style={{ fontSize: 10.5, color: '#334155', marginTop: 2 }}>
                    Customer: <T style={{ fontWeight: '700', color: '#0F172A' }}>{custName}</T>
                  </T>
                  <T style={{ fontSize: 10.5, color: '#334155', marginTop: 2 }}>
                    Site: <T style={{ fontWeight: '600', color: '#0F172A' }}>{siteLocation}</T>
                  </T>
                </View>
              </View>

              {/* Yellow Horizontal Accent Line */}
              <View style={{ height: 2, backgroundColor: '#FFD500', marginVertical: 8 }} />

              {/* Document Title */}
              <View style={{ alignItems: 'center', marginVertical: 8 }}>
                <T style={{ fontSize: 14, fontWeight: '900', color: '#0F172A', letterSpacing: 0.5, textTransform: 'uppercase' }}>
                  MATERIAL SPECIFICATION AGREEMENT
                </T>
              </View>

              {/* 1. Project Details Box */}
              <View style={{ marginBottom: 12 }}>
                <T style={{ fontSize: 11.5, fontWeight: '800', color: '#0F172A', marginBottom: 4 }}>
                  1. Project Details
                </T>
                <View style={{ backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 6, padding: 8, gap: 3 }}>
                  <View style={{ flexDirection: 'row' }}>
                    <T style={{ fontSize: 11, color: '#64748B', width: 110 }}>Customer Name</T>
                    <T style={{ fontSize: 11, color: '#0F172A', fontWeight: '700' }}>: {custName}</T>
                  </View>
                  <View style={{ flexDirection: 'row' }}>
                    <T style={{ fontSize: 11, color: '#64748B', width: 110 }}>Project Site</T>
                    <T style={{ fontSize: 11, color: '#0F172A', fontWeight: '700' }}>: {siteLocation}</T>
                  </View>
                  <View style={{ flexDirection: 'row' }}>
                    <T style={{ fontSize: 11, color: '#64748B', width: 110 }}>Agreement No.</T>
                    <T style={{ fontSize: 11, color: '#0F172A', fontWeight: '700' }}>: {agreeNumber}</T>
                  </View>
                  <View style={{ flexDirection: 'row' }}>
                    <T style={{ fontSize: 11, color: '#64748B', width: 110 }}>Date</T>
                    <T style={{ fontSize: 11, color: '#0F172A', fontWeight: '700' }}>: {agreeDate}</T>
                  </View>
                </View>
              </View>

              {/* 2. Material Specifications Table */}
              <View style={{ marginBottom: 12 }}>
                <T style={{ fontSize: 11.5, fontWeight: '800', color: '#0F172A', marginBottom: 4 }}>
                  2. Material Specifications
                </T>
                <View style={{ borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 4, overflow: 'hidden' }}>
                  {/* Table Header: Yellow-Tinted Background */}
                  <View style={{ flexDirection: 'row', backgroundColor: '#FEF08A', borderBottomWidth: 1, borderColor: '#CBD5E1' }}>
                    <View style={{ flex: 1.2, padding: 6, borderRightWidth: 1, borderColor: '#CBD5E1' }}>
                      <T style={{ fontSize: 10.5, fontWeight: '800', color: '#171817' }}>Material</T>
                    </View>
                    <View style={{ flex: 1.2, padding: 6, borderRightWidth: 1, borderColor: '#CBD5E1', alignItems: 'center' }}>
                      <T style={{ fontSize: 10.5, fontWeight: '800', color: '#171817' }}>Brand-Grade</T>
                    </View>
                    <View style={{ flex: 1.2, padding: 6, borderRightWidth: 1, borderColor: '#CBD5E1', alignItems: 'center' }}>
                      <T style={{ fontSize: 10.5, fontWeight: '800', color: '#171817' }}>Specification</T>
                    </View>
                    <View style={{ flex: 1.1, padding: 6, alignItems: 'center' }}>
                      <T style={{ fontSize: 10.5, fontWeight: '800', color: '#171817' }}>Supplied by</T>
                    </View>
                  </View>

                  {/* Table Rows */}
                  {materials.map((m, idx) => {
                    const brandGrade = [m.brand, m.grade].filter(Boolean).join(' - ') || 'To be confirmed';
                    let spec = '';
                    if (m.sizes && m.sizes.length > 0) {
                      spec = m.sizes.join(', ') + (m.whereUsed ? ` (${m.whereUsed})` : '');
                    } else if (m.whereUsed) {
                      spec = m.whereUsed;
                    } else {
                      spec = 'As agreed';
                    }
                    const supplied = m.suppliedBy === 'customer' ? 'Customer' : 'Contractor';

                    return (
                      <View key={idx} style={{ flexDirection: 'row', borderBottomWidth: idx === materials.length - 1 ? 0 : 1, borderColor: '#CBD5E1' }}>
                        <View style={{ flex: 1.2, padding: 6, borderRightWidth: 1, borderColor: '#CBD5E1', justifyContent: 'center' }}>
                          <T style={{ fontSize: 11, fontWeight: '700', color: '#0F172A' }}>{m.name}</T>
                        </View>
                        <View style={{ flex: 1.2, padding: 6, borderRightWidth: 1, borderColor: '#CBD5E1', alignItems: 'center', justifyContent: 'center' }}>
                          <T style={{ fontSize: 10.5, color: '#334155', textAlign: 'center' }}>{brandGrade}</T>
                        </View>
                        <View style={{ flex: 1.2, padding: 6, borderRightWidth: 1, borderColor: '#CBD5E1', alignItems: 'center', justifyContent: 'center' }}>
                          <T style={{ fontSize: 10.5, color: '#334155', textAlign: 'center' }}>{spec}</T>
                        </View>
                        <View style={{ flex: 1.1, padding: 6, alignItems: 'center', justifyContent: 'center' }}>
                          <T style={{ fontSize: 10.5, color: '#334155' }}>{supplied}</T>
                        </View>
                      </View>
                    );
                  })}
                </View>
                <T style={{ fontSize: 9.5, color: '#64748B', fontStyle: 'italic', marginTop: 4 }}>
                  *Illustrative entries; confirm project specifications.
                </T>
              </View>

              {/* 3. Scope & Notes */}
              <View style={{ marginBottom: 12 }}>
                <T style={{ fontSize: 11.5, fontWeight: '800', color: '#0F172A', marginBottom: 4 }}>
                  3. Scope & Notes
                </T>
                <View style={{ backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 6, padding: 8 }}>
                  <T style={{ fontSize: 11, color: '#334155', lineHeight: 15 }}>
                    • {scopeNotes}
                  </T>
                </View>
              </View>

              {/* 4. Signatures (Two Bordered Boxes) */}
              <View>
                <T style={{ fontSize: 11.5, fontWeight: '800', color: '#0F172A', marginBottom: 4 }}>
                  4. Signatures
                </T>
                <View style={{ flexDirection: 'row', gap: 10 }}>
                  {/* Contractor Box */}
                  <View style={{ flex: 1, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 6, padding: 8, backgroundColor: '#FFFFFF' }}>
                    <T style={{ fontSize: 11, fontWeight: '800', color: '#0F172A' }}>For {bizName}</T>
                    <T style={{ fontSize: 9.5, color: '#64748B', marginBottom: 18 }}>(Contractor)</T>
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', borderTopWidth: 1, borderColor: '#CBD5E1', paddingTop: 3 }}>
                      <T style={{ fontSize: 9.5, color: '#64748B' }}>Signature</T>
                      <T style={{ fontSize: 9.5, color: '#64748B' }}>Date</T>
                    </View>
                  </View>

                  {/* Customer Box */}
                  <View style={{ flex: 1, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 6, padding: 8, backgroundColor: '#FFFFFF' }}>
                    <T style={{ fontSize: 11, fontWeight: '800', color: '#0F172A' }}>For {custName}</T>
                    <T style={{ fontSize: 9.5, color: '#64748B', marginBottom: 18 }}>(Customer)</T>
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', borderTopWidth: 1, borderColor: '#CBD5E1', paddingTop: 3 }}>
                      <T style={{ fontSize: 9.5, color: '#64748B' }}>Signature</T>
                      <T style={{ fontSize: 9.5, color: '#64748B' }}>Date</T>
                    </View>
                  </View>
                </View>
              </View>
            </View>

            {/* 4. Two Action Pills: Edit | Full View (Reference 08) */}
            <View style={{ flexDirection: 'row', gap: 10, marginTop: 12 }}>
              {/* Edit Pill */}
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Edit Agreement"
                onPress={() => {
                  if (onEdit) onEdit();
                  else onClose();
                }}
                style={{
                  flex: 1,
                  backgroundColor: '#FEF9C3',
                  borderRadius: 14,
                  paddingVertical: 10,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 6
                }}
              >
                <I name="eye-outline" size={16} color="#854D0E" />
                <T style={{ fontSize: 13, fontWeight: '800', color: '#713F12' }}>
                  {t.btnEditDetails || 'ఎడిట్ చేయండి'}
                </T>
              </Pressable>

              {/* Full View Pill */}
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Full View"
                onPress={() => {
                  Alert.alert('Full View', 'Displaying full A4 document view.');
                }}
                style={{
                  flex: 1,
                  backgroundColor: '#F1F5F9',
                  borderRadius: 14,
                  paddingVertical: 10,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 6
                }}
              >
                <I name="document-text-outline" size={16} color="#334155" />
                <T style={{ fontSize: 13, fontWeight: '800', color: '#334155' }}>
                  {t.agreeFullViewBtn || 'పూర్తి వీక్షణ'}
                </T>
              </Pressable>
            </View>

            {/* 5. PDF Output Mode Radio Card (Reference 08) */}
            <View style={{ marginTop: 12, backgroundColor: '#FFFFFF', borderRadius: 16, borderWidth: 1, borderColor: '#E2E8F0', padding: 14, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.04, shadowRadius: 3, elevation: 1 }}>
              <T style={{ fontSize: 14, fontWeight: '800', color: '#171817', marginBottom: 10 }}>
                {t.agreePdfOutputTitle || 'PDF అవుట్‌పుట్'}
              </T>

              {/* Radio 1: Standalone PDF */}
              <Pressable
                accessibilityRole="radio"
                accessibilityLabel="Send as standalone PDF"
                accessibilityState={{ checked: pdfMode === 'standalone' }}
                onPress={() => setPdfMode('standalone')}
                style={{ flexDirection: 'row', alignItems: 'flex-start', gap: 10, paddingVertical: 8, borderBottomWidth: 1, borderColor: '#F1F5F9' }}
              >
                <View style={{ width: 20, height: 20, borderRadius: 10, borderWidth: 2, borderColor: pdfMode === 'standalone' ? '#FFD500' : '#94A3B8', alignItems: 'center', justifyContent: 'center', marginTop: 2 }}>
                  {pdfMode === 'standalone' && <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: '#FFD500' }} />}
                </View>
                <View style={{ flex: 1 }}>
                  <T style={{ fontSize: 13.5, fontWeight: '800', color: '#171817' }}>
                    {t.agreePdfStandalone || 'ప్రత్యేక PDFగా పంపండి'}
                  </T>
                  <T style={{ fontSize: 11.5, color: '#64748B', marginTop: 1 }}>
                    {t.agreePdfStandaloneSub || 'ఈ అగ్రిమెంట్‌ను ప్రత్యేక PDF ఫైల్‌గా పంపండి.'}
                  </T>
                </View>
              </Pressable>

              {/* Radio 2: Quotation Annexure */}
              <Pressable
                accessibilityRole="radio"
                accessibilityLabel="Attach as quotation annexure"
                accessibilityState={{ checked: pdfMode === 'annexure' }}
                onPress={() => setPdfMode('annexure')}
                style={{ flexDirection: 'row', alignItems: 'flex-start', gap: 10, paddingVertical: 8 }}
              >
                <View style={{ width: 20, height: 20, borderRadius: 10, borderWidth: 2, borderColor: pdfMode === 'annexure' ? '#FFD500' : '#94A3B8', alignItems: 'center', justifyContent: 'center', marginTop: 2 }}>
                  {pdfMode === 'annexure' && <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: '#FFD500' }} />}
                </View>
                <View style={{ flex: 1 }}>
                  <T style={{ fontSize: 13.5, fontWeight: '800', color: '#171817' }}>
                    {t.agreePdfAnnexure || 'కొటేషన్‌కు అనుబంధంగా జోడించండి'}
                  </T>
                  <T style={{ fontSize: 11.5, color: '#64748B', marginTop: 1 }}>
                    {t.agreePdfAnnexureSub || 'ఈ అగ్రిమెంట్‌ను కొటేషన్ PDFతో కలిపి జోడించండి.'}
                  </T>
                </View>
              </Pressable>
            </View>
          </ScrollView>

          {/* 6. Bottom Sticky Buttons: Generate PDF + Download & Share */}
          <View
            style={{
              paddingHorizontal: 16,
              paddingVertical: 12,
              backgroundColor: '#FFFFFF',
              borderTopWidth: 1,
              borderColor: '#E2E8F0',
              gap: 8
            }}
          >
            {/* Big Yellow Generate PDF Button */}
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Generate PDF"
              onPress={handleGeneratePdf}
              style={({ pressed }) => [{
                backgroundColor: '#FFD500',
                borderRadius: 14,
                paddingVertical: 13,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 8,
                shadowColor: '#EAB308',
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.25,
                shadowRadius: 4,
                elevation: 3,
                opacity: pressed ? 0.88 : 1
              }]}
            >
              <I name="document-text" size={18} color="#171817" />
              <T style={{ fontSize: 14.5, fontWeight: '900', color: '#171817' }}>
                {t.agreeGeneratePdfBtn || 'PDF తయారు చేయండి'}
              </T>
            </Pressable>

            {/* Row of Download and Share Buttons */}
            <View style={{ flexDirection: 'row', gap: 10 }}>
              {/* Download */}
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Download PDF"
                onPress={() => {
                  if (onDownload) {
                    onDownload({ ...agreement, language: docLanguage, pageSize, pdfMode });
                  } else {
                    Alert.alert('Download', 'PDF download triggered.');
                  }
                }}
                style={({ pressed }) => [{
                  flex: 1,
                  borderWidth: 1.5,
                  borderColor: '#CBD5E1',
                  borderRadius: 14,
                  paddingVertical: 10,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 6,
                  backgroundColor: pressed ? '#F8FAFC' : '#FFFFFF'
                }]}
              >
                <I name="download-outline" size={17} color="#171817" />
                <T style={{ fontSize: 13.5, fontWeight: '800', color: '#171817' }}>
                  {t.agreeDownloadBtn || 'డౌన్‌లోడ్'}
                </T>
              </Pressable>

              {/* Share */}
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Share PDF"
                onPress={() => {
                  if (onShare) {
                    onShare({ ...agreement, language: docLanguage, pageSize, pdfMode });
                  } else {
                    Alert.alert('Share', 'WhatsApp / Share dialog opened.');
                  }
                }}
                style={({ pressed }) => [{
                  flex: 1,
                  borderWidth: 1.5,
                  borderColor: '#CBD5E1',
                  borderRadius: 14,
                  paddingVertical: 10,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 6,
                  backgroundColor: pressed ? '#F8FAFC' : '#FFFFFF'
                }]}
              >
                <I name="share-social-outline" size={17} color="#171817" />
                <T style={{ fontSize: 13.5, fontWeight: '800', color: '#171817' }}>
                  {t.agreeShareBtn || 'షేర్ చేయండి'}
                </T>
              </Pressable>
            </View>
          </View>
        </View>
      </View>
    </Modal>
  );
}
