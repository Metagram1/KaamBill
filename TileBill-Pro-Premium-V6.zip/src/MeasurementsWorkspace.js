import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  Image,
  ScrollView,
  Pressable,
  Platform,
  TextInput,
  Modal,
  StyleSheet,
  Alert
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { T, I, Button, s, C } from './ui';
import { money, defaultTradeMaterials } from './domain.cjs';
import { getStrings } from './i18n';
import {
  MEASURE_SERVICES,
  calculateMeasurementItem,
  getDefaultRoomsForService,
  formatMeasurementBillLines,
  round2
} from './measurementEngine';
import ChooseMaterialsPicker from './ChooseMaterialsPicker';
import ReadyToShareMaterialsModal from './ReadyToShareMaterialsModal';

const measureTileFloor = require('../assets/measure-tile-floor.png');
const measureTileWall = require('../assets/measure-tile-wall.png');
const measureTileSkirting = require('../assets/measure-tile-skirting.png');
const measureRoomGuide = require('../assets/measure-room-guide.png');

export function MeasurementsWorkspace({
  service = 'electrical',
  appLang = 'en',
  user,
  business,
  customer,
  customers = [],
  catalog = [],
  initialScreen = 'rooms_work', // 'rooms_work' | 'choose_materials'
  onSaveToCatalog,
  onSaveMaterialList,
  onSwitchCustomer,
  openDocument,
  notify,
  onBack
}) {
  const t = getStrings(appLang);
  const svcConfig = MEASURE_SERVICES[service] || MEASURE_SERVICES.electrical;
  const workTypes = svcConfig.workTypes;
  const storageKey = `tilebill_measure_v6_${user?.id || 'guest'}_${service}`;

  // Screen state: 'rooms_work' | 'choose_materials'
  const [currentScreen, setCurrentScreen] = useState(initialScreen || 'rooms_work');

  // Customer state
  const [activeCust, setActiveCust] = useState(customer || customers[0] || null);
  const [customerModalOpen, setCustomerModalOpen] = useState(false);
  const [customSiteInput, setCustomSiteInput] = useState('');

  // Selected materials for project (Screen 2 & 3)
  const [selectedMaterials, setSelectedMaterials] = useState([]);
  const [showPricesInShare, setShowPricesInShare] = useState(false);
  const [readyShareModalVisible, setReadyShareModalVisible] = useState(false);

  // Rooms and items state
  const [rooms, setRooms] = useState(() => getDefaultRoomsForService(service, appLang));
  const [activeRoomId, setActiveRoomId] = useState(() => rooms[0]?.id || 'room-bed');
  const [activeWorkTypeId, setActiveWorkTypeId] = useState(() => rooms[0]?.workType || workTypes[0]?.id || 'wiring');
  const [saveStatus, setSaveStatus] = useState('saved');

  // Modals state
  const [addRoomModalVisible, setAddRoomModalVisible] = useState(false);
  const [renameModalVisible, setRenameModalVisible] = useState(false);
  const [newRoomName, setNewRoomName] = useState('');
  const [editRoomName, setEditRoomName] = useState('');

  // Cable route edit modal
  const [cableModalVisible, setCableModalVisible] = useState(false);
  const [cableLengthInput, setCableLengthInput] = useState('24');
  const [cableRouteInput, setCableRouteInput] = useState('DB to Bedroom switchboard');
  const [cableNotesInput, setCableNotesInput] = useState('');

  // Custom work item modal
  const [customWorkModalVisible, setCustomWorkModalVisible] = useState(false);
  const [customWorkName, setCustomWorkName] = useState('');
  const [customWorkQty, setCustomWorkQty] = useState('1');
  const [customWorkRate, setCustomWorkRate] = useState('650');
  const [customWorkUnit, setCustomWorkUnit] = useState('point');

  // Unit selector dropdown
  const [unitMenuOpen, setUnitMenuOpen] = useState(false);

  // Sync customer prop when parent changes
  useEffect(() => {
    if (customer) setActiveCust(customer);
  }, [customer]);

  // Sync initialScreen prop when parent changes (e.g. shortcut entry)
  useEffect(() => {
    if (initialScreen) {
      setCurrentScreen(initialScreen);
    }
  }, [initialScreen]);

  // Load saved measurements from AsyncStorage
  useEffect(() => {
    let isMounted = true;
    AsyncStorage.getItem(storageKey)
      .then(saved => {
        if (!isMounted) return;
        if (saved) {
          try {
            const parsed = JSON.parse(saved);
            if (Array.isArray(parsed) && parsed.length > 0) {
              setRooms(parsed);
              setActiveRoomId(parsed[0].id);
              setActiveWorkTypeId(parsed[0].workType || workTypes[0]?.id || 'wiring');
            }
          } catch {}
        } else {
          const defRooms = getDefaultRoomsForService(service, appLang);
          setRooms(defRooms);
          setActiveRoomId(defRooms[0]?.id || 'room-bed');
          setActiveWorkTypeId(defRooms[0]?.workType || workTypes[0]?.id || 'wiring');
        }
      })
      .catch(() => {});
    return () => {
      isMounted = false;
    };
  }, [service, user?.id]);

  // Auto-save to AsyncStorage
  const saveTimeoutRef = useRef(null);
  const persistRooms = updatedRooms => {
    setSaveStatus('saving');
    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    saveTimeoutRef.current = setTimeout(() => {
      AsyncStorage.setItem(storageKey, JSON.stringify(updatedRooms))
        .then(() => setSaveStatus('saved'))
        .catch(() => setSaveStatus('saved'));
    }, 400);
  };

  // Find active room
  const activeRoom = useMemo(() => {
    return rooms.find(r => r.id === activeRoomId) || rooms[0] || null;
  }, [rooms, activeRoomId]);

  const activeWorkType = useMemo(() => {
    return workTypes.find(w => w.id === activeWorkTypeId) || workTypes[0];
  }, [workTypes, activeWorkTypeId]);

  const activeItem = useMemo(() => {
    if (!activeRoom) return null;
    const found = (activeRoom.items || []).find(it => it.workTypeId === activeWorkTypeId);
    if (found) return found;

    return calculateMeasurementItem({
      id: 'it-' + Date.now().toString(36),
      workTypeId: activeWorkType.id,
      workTypeName: activeWorkType.name[appLang] || activeWorkType.name.en,
      mode: activeWorkType.mode,
      length: activeWorkType.mode === 'volume' ? 5 : activeWorkType.mode === 'qty' ? 0 : 10,
      width: activeWorkType.mode === 'volume' ? 2 : activeWorkType.mode === 'qty' ? 0 : 10,
      height: 0,
      depth: 0,
      count: 1,
      qty: activeWorkType.mode === 'qty' ? 5 : 1,
      deduction: 0,
      rate: activeWorkType.defaultRate,
      unit: activeWorkType.defaultUnit,
      dimensionUnit: activeWorkType.dimensionUnit || 'ft',
      customFields: [],
      saved: true
    });
  }, [activeRoom, activeWorkTypeId, activeWorkType, appLang]);

  // Update field in active item
  const updateActiveItem = updates => {
    if (!activeRoom || !activeItem) return;
    const currentItem = activeItem;
    const merged = { ...currentItem, ...updates };
    const calculated = calculateMeasurementItem(merged);

    const updatedRooms = rooms.map(r => {
      if (r.id !== activeRoom.id) return r;
      const items = r.items || [];
      const itemExists = items.some(it => it.workTypeId === activeWorkTypeId);
      const nextItems = itemExists
        ? items.map(it => (it.workTypeId === activeWorkTypeId ? calculated : it))
        : [...items, calculated];
      return {
        ...r,
        workType: activeWorkTypeId,
        items: nextItems
      };
    });

    setRooms(updatedRooms);
    persistRooms(updatedRooms);
  };

  // Stepper handler for Electrical points (light, fan, socket)
  const handleUpdateElectricalPoint = (pointType, delta) => {
    if (!activeRoom) return;
    const currentPoints = activeRoom.points || { light: 4, fan: 1, socket: 3 };
    const curVal = Number(currentPoints[pointType] || 0);
    const nextVal = Math.max(0, curVal + delta);
    const updatedPoints = { ...currentPoints, [pointType]: nextVal };

    const totalPts = (Number(updatedPoints.light || 0) + Number(updatedPoints.fan || 0) + Number(updatedPoints.socket || 0));

    // Update or add the wiring points measurement item
    const items = activeRoom.items || [];
    const wiringIdx = items.findIndex(it => it.workTypeId === 'wiring');
    let nextItems = [...items];

    const wiringItem = calculateMeasurementItem({
      id: wiringIdx >= 0 ? items[wiringIdx].id : ('it-el-pts-' + Date.now().toString(36)),
      workTypeId: 'wiring',
      workTypeName: `${activeRoom.name} — ${t.workflowLightPowerPoints || 'Light & power points'}`,
      mode: 'qty',
      qty: totalPts,
      count: totalPts,
      rate: wiringIdx >= 0 ? items[wiringIdx].rate : 650,
      unit: 'point',
      saved: true
    });

    if (wiringIdx >= 0) {
      nextItems[wiringIdx] = wiringItem;
    } else {
      nextItems.unshift(wiringItem);
    }

    const updatedRooms = rooms.map(r => {
      if (r.id !== activeRoom.id) return r;
      return {
        ...r,
        points: updatedPoints,
        items: nextItems
      };
    });

    setRooms(updatedRooms);
    persistRooms(updatedRooms);
  };

  // Open cable edit modal
  const handleOpenCableEdit = () => {
    if (!activeRoom) return;
    const cable = activeRoom.cableRoute || { length: 24, unit: 'm', route: 'DB to switchboard', notes: '' };
    setCableLengthInput(String(cable.length || '24'));
    setCableRouteInput(cable.route || '');
    setCableNotesInput(cable.notes || '');
    setCableModalVisible(true);
  };

  // Save cable route modal
  const handleSaveCableEdit = () => {
    if (!activeRoom) return;
    const lengthVal = Math.max(0, parseFloat(cableLengthInput) || 0);
    const updatedCable = {
      length: lengthVal,
      unit: 'm',
      route: cableRouteInput.trim(),
      notes: cableNotesInput.trim()
    };

    const items = activeRoom.items || [];
    const cableIdx = items.findIndex(it => it.workTypeId === 'cable');
    let nextItems = [...items];

    const cableItem = calculateMeasurementItem({
      id: cableIdx >= 0 ? items[cableIdx].id : ('it-el-cable-' + Date.now().toString(36)),
      workTypeId: 'cable',
      workTypeName: `${activeRoom.name} — ${t.workflowCableRoute || 'Cable Route'}`,
      mode: 'length',
      length: lengthVal,
      unit: 'm',
      dimensionUnit: 'm',
      rate: cableIdx >= 0 ? items[cableIdx].rate : 60,
      note: cableRouteInput.trim(),
      saved: true
    });

    if (cableIdx >= 0) {
      nextItems[cableIdx] = cableItem;
    } else {
      nextItems.push(cableItem);
    }

    const updatedRooms = rooms.map(r => {
      if (r.id !== activeRoom.id) return r;
      return {
        ...r,
        cableRoute: updatedCable,
        items: nextItems
      };
    });

    setRooms(updatedRooms);
    persistRooms(updatedRooms);
    setCableModalVisible(false);
  };

  // Add custom work item to room
  const handleAddCustomWorkItem = () => {
    const trimmed = customWorkName.trim();
    if (!trimmed) {
      alert(appLang === 'te' ? 'పని ఐటమ్ పేరు నమోదు చేయండి' : appLang === 'hi' ? 'कार्य का नाम दर्ज करें' : 'Enter work item name');
      return;
    }
    const newCi = {
      id: 'ci-' + Date.now().toString(36),
      name: trimmed,
      qty: Math.max(1, parseInt(customWorkQty || '1', 10) || 1),
      rate: Math.max(0, parseFloat(customWorkRate || '0') || 0),
      unit: customWorkUnit.trim() || 'point'
    };

    const newItem = calculateMeasurementItem({
      id: 'it-ci-' + Date.now().toString(36),
      workTypeId: 'custom',
      workTypeName: `${activeRoom.name} — ${trimmed}`,
      mode: 'qty',
      qty: newCi.qty,
      rate: newCi.rate,
      unit: newCi.unit,
      saved: true
    });

    const updatedRooms = rooms.map(r => {
      if (r.id !== activeRoom.id) return r;
      return {
        ...r,
        customItems: [...(r.customItems || []), newCi],
        items: [...(r.items || []), newItem]
      };
    });

    setRooms(updatedRooms);
    persistRooms(updatedRooms);
    setCustomWorkModalVisible(false);
    setCustomWorkName('');
    setCustomWorkQty('1');
    setCustomWorkRate('650');
  };

  // Add new room
  const handleAddRoom = nameToAdd => {
    const defaultTerm = svcConfig.areaTerm[appLang] || svcConfig.areaTerm.en;
    const finalName = (nameToAdd || '').trim() || `${defaultTerm} ${rooms.length + 1}`;
    const newId = 'room-' + Date.now().toString(36);

    const isElect = service === 'electrical';
    const initialItem = calculateMeasurementItem({
      id: 'it-' + Date.now().toString(36),
      workTypeId: isElect ? 'wiring' : activeWorkType.id,
      workTypeName: `${finalName} — ${isElect ? (t.workflowLightPowerPoints || 'Light & power points') : (activeWorkType.name[appLang] || activeWorkType.name.en)}`,
      mode: isElect ? 'qty' : activeWorkType.mode,
      length: isElect ? 0 : 10,
      width: isElect ? 0 : 10,
      qty: isElect ? 8 : 1,
      rate: isElect ? 650 : activeWorkType.defaultRate,
      unit: isElect ? 'point' : activeWorkType.defaultUnit,
      dimensionUnit: isElect ? 'm' : (activeWorkType.dimensionUnit || 'ft'),
      saved: true
    });

    const newRoom = {
      id: newId,
      name: finalName,
      workType: isElect ? 'wiring' : activeWorkType.id,
      isMainSupply: false,
      points: { light: 4, fan: 1, socket: 3 },
      cableRoute: { length: 20, unit: 'm', route: 'DB to room switchboard', notes: '' },
      customItems: [],
      items: [initialItem]
    };

    const nextRooms = [...rooms, newRoom];
    setRooms(nextRooms);
    setActiveRoomId(newId);
    persistRooms(nextRooms);
    setAddRoomModalVisible(false);
    setNewRoomName('');
  };

  // Delete room
  const handleDeleteRoom = roomId => {
    if (rooms.length <= 1) {
      if (notify) notify('At least one room is required');
      return;
    }
    const filtered = rooms.filter(r => r.id !== roomId);
    setRooms(filtered);
    if (activeRoomId === roomId) {
      setActiveRoomId(filtered[0]?.id || '');
    }
    persistRooms(filtered);
  };

  // Grand totals across all rooms (grouped strictly by unit to avoid summing incompatible units!)
  const { unitSummaries, grandTotalAmount, totalPointsCount, totalCableMeters } = useMemo(() => {
    let sumAmount = 0;
    const unitMap = {};
    let pts = 0;
    let cable = 0;

    for (const r of rooms) {
      // Add points
      const l = Number(r.points?.light || 0);
      const fn = Number(r.points?.fan || 0);
      const sk = Number(r.points?.socket || 0);
      pts += (l + fn + sk);

      // Add cable
      cable += Number(r.cableRoute?.length || 0);

      for (const it of r.items || []) {
        const calc = calculateMeasurementItem(it);
        sumAmount += calc.amount || 0;
        const u = calc.unit || 'pcs';
        unitMap[u] = (unitMap[u] || 0) + (calc.netQty || 0);
      }
    }

    const summaries = Object.entries(unitMap).map(([unit, qty]) => ({
      unit,
      qty: round2(qty)
    }));

    return {
      unitSummaries: summaries,
      grandTotalAmount: round2(sumAmount),
      totalPointsCount: pts,
      totalCableMeters: cable
    };
  }, [rooms]);

  // Work Summary Text for sharing
  const workSummaryString = useMemo(() => {
    return rooms.map(r => {
      if (service === 'electrical') {
        const l = r.points?.light || 0;
        const fn = r.points?.fan || 0;
        const sk = r.points?.socket || 0;
        const c = r.cableRoute?.length || 0;
        const parts = [];
        if (l) parts.push(`${l} light`);
        if (fn) parts.push(`${fn} fan`);
        if (sk) parts.push(`${sk} socket`);
        if (c) parts.push(`${c}m cable`);
        return `${r.name}${parts.length ? ` (${parts.join(', ')})` : ''}`;
      }
      return `${r.name} (${(r.items || []).length} items)`;
    }).join(', ');
  }, [rooms, service]);

  // Create Bill with Measurements
  const handleCreateBill = (kind = 'invoice') => {
    const lines = formatMeasurementBillLines(rooms, service);
    if (!lines.length || grandTotalAmount <= 0) {
      if (notify) notify('దయచేసి కొలతలను సరిగ్గా నమోదు చేయండి (Enter valid measurements first)', true);
      return;
    }
    if (openDocument) {
      const bizTitle = business?.name || 'TileBill Pro';
      const svcTitle = svcConfig.areaTerm[appLang] || 'Work';
      openDocument({
        kind,
        service,
        items: lines,
        title: `${bizTitle} - ${svcTitle} ${t.dashTabBills}`
      });
    }
  };

  const handleProceedToMaterials = () => {
    if (selectedMaterials.length === 0) {
      const defaults = (defaultTradeMaterials || []).filter(m => (!m.service || m.service === service) && m.isFavorite);
      const preSelected = defaults.slice(0, 4).map((m, idx) => ({
        ...m,
        qty: idx === 0 ? 2 : idx === 1 ? 1 : idx === 2 ? 12 : 6
      }));
      if (preSelected.length > 0) {
        setSelectedMaterials(preSelected);
      }
    }
    setCurrentScreen('choose_materials');
  };

  // If in Choose Materials Screen, render ChooseMaterialsPicker
  if (currentScreen === 'choose_materials') {
    const effectiveCatalog = Array.isArray(catalog) && catalog.length > 0 ? catalog : (defaultTradeMaterials || []).filter(m => !m.service || m.service === service);
    return (
      <View style={{ flex: 1 }}>
        <ChooseMaterialsPicker
          service={service}
          appLang={appLang}
          customer={activeCust}
          siteLocation={activeCust?.siteLocation || activeCust?.address || ''}
          catalog={effectiveCatalog}
          initialSelected={selectedMaterials}
          onBack={() => {
            if (initialScreen === 'choose_materials' && onBack) {
              onBack();
            } else {
              setCurrentScreen('rooms_work');
            }
          }}
          onReview={(selectedList, showPrices) => {
            setSelectedMaterials(selectedList);
            setShowPricesInShare(showPrices);
            setReadyShareModalVisible(true);
          }}
          onSaveToCatalog={onSaveToCatalog}
          onSwitchCustomer={() => setCustomerModalOpen(true)}
          notify={notify}
        />

        {/* Ready To Share Modal */}
        <ReadyToShareMaterialsModal
          visible={readyShareModalVisible}
          service={service}
          appLang={appLang}
          customer={activeCust}
          siteLocation={activeCust?.siteLocation || activeCust?.address || ''}
          business={business}
          materials={selectedMaterials}
          rooms={rooms}
          workSummary={workSummaryString}
          initialShowPrices={showPricesInShare}
          onBack={() => setReadyShareModalVisible(false)}
          onEditMaterials={() => setReadyShareModalVisible(false)}
          onSaveMaterialList={onSaveMaterialList}
          onCreateLabourDocument={openDocument}
          onClose={() => setReadyShareModalVisible(false)}
          notify={notify}
        />

        {/* Customer Switcher Modal */}
        {renderCustomerPickerModal()}
      </View>
    );
  }

  // Render Customer Picker Modal
  function renderCustomerPickerModal() {
    return (
      <Modal visible={customerModalOpen} transparent animationType="fade" onRequestClose={() => setCustomerModalOpen(false)}>
        <Pressable style={styles.modalOverlay} onPress={() => setCustomerModalOpen(false)}>
          <Pressable style={styles.pickerCard} onPress={e => e.stopPropagation()}>
            <View style={styles.pickerHeader}>
              <Text style={styles.pickerTitle}>📍 {t.workflowSelectCustomer || 'Select site / customer'}</Text>
              <Pressable onPress={() => setCustomerModalOpen(false)}>
                <I name="close" size={20} color="#64748B" />
              </Pressable>
            </View>

            <ScrollView style={{ maxHeight: 240 }}>
              {(customers || []).map(c => (
                <Pressable
                  key={c.id}
                  onPress={() => {
                    setActiveCust(c);
                    setCustomerModalOpen(false);
                  }}
                  style={[styles.custOptionRow, activeCust?.id === c.id && styles.custOptionRowActive]}
                >
                  <View style={{ flex: 1 }}>
                    <Text style={styles.custOptionName}>{c.name}</Text>
                    <Text style={styles.custOptionSite}>{c.siteLocation || c.address || 'Site'}</Text>
                  </View>
                  {activeCust?.id === c.id && <I name="checkmark" size={16} color="#854D0E" />}
                </Pressable>
              ))}
            </ScrollView>

            <View style={{ marginTop: 10, borderTopWidth: 1, borderTopColor: '#F1F5F9', paddingTop: 10 }}>
              <Text style={styles.custOrLabel}>OR enter new site / house name:</Text>
              <View style={{ flexDirection: 'row', gap: 6, marginTop: 4 }}>
                <TextInput
                  style={[styles.custInput, { flex: 1 }]}
                  placeholder="e.g. Ravi House"
                  value={customSiteInput}
                  onChangeText={setCustomSiteInput}
                />
                <Pressable
                  style={styles.custSetBtn}
                  onPress={() => {
                    if (customSiteInput.trim()) {
                      setActiveCust({ name: customSiteInput.trim(), siteLocation: customSiteInput.trim() });
                      setCustomerModalOpen(false);
                      setCustomSiteInput('');
                    }
                  }}
                >
                  <Text style={styles.custSetBtnText}>Set</Text>
                </Pressable>
              </View>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    );
  }

  // -------------------------------------------------------------
  // SCREEN 1: ROOMS & WORK (Ref 1)
  // -------------------------------------------------------------
  return (
    <View style={styles.screenContainer}>
      {/* 1. TOP BAR: Back Arrow • Customer & Site Chip • Trade Switcher */}
      <View style={styles.topBar}>
        <Pressable onPress={onBack} style={styles.backBtn}>
          <I name="arrow-back" size={20} color="#0F172A" />
        </Pressable>

        <Pressable onPress={() => setCustomerModalOpen(true)} style={styles.customerChip}>
          <Text style={{ fontSize: 12 }}>📍</Text>
          <Text style={styles.customerChipText} numberOfLines={1}>
            {activeCust?.name || (activeCust?.siteLocation ? activeCust.siteLocation : (t.workflowSelectCustomer || 'Select site / customer'))}
          </Text>
          <I name="chevron-down" size={13} color="#475569" />
        </Pressable>

        <View style={styles.tradeBadge}>
          <Text style={styles.tradeBadgeText}>
            {service === 'electrical' ? '⚡ ' : service === 'tiles' ? '📐 ' : '🔧 '}
            {service.charAt(0).toUpperCase() + service.slice(1)}
          </Text>
        </View>
      </View>

      <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.scrollContent}>
        {/* 2. HEADER: 🔌 Rooms & work • Shortcut: "Skip to materials →" */}
        <View style={styles.screenHeader}>
          <Text style={styles.screenTitle}>
            {service === 'electrical' ? '🔌 ' : '📐 '}
            {t.workflowRoomsWork || 'Rooms & work'}
          </Text>

          <Pressable
            onPress={handleProceedToMaterials}
            style={styles.skipLink}
          >
            <Text style={styles.skipLinkText}>{t.workflowSkipToMaterials || 'Skip to materials →'}</Text>
          </Pressable>
        </View>

        {/* 3. ROOM CHIPS: Bedroom • Kitchen • + Room • Main supply */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.roomChipsScroll}
        >
          {rooms.map(room => {
            const isActive = room.id === activeRoomId;
            return (
              <Pressable
                key={room.id}
                onPress={() => {
                  setActiveRoomId(room.id);
                  setActiveWorkTypeId(room.workType || 'wiring');
                }}
                style={[styles.roomChip, isActive && styles.roomChipActive]}
              >
                <Text style={[styles.roomChipText, isActive && styles.roomChipTextActive]}>
                  {room.isMainSupply ? '⚡ ' : ''}{room.name}
                </Text>
                {isActive && rooms.length > 1 && (
                  <Pressable
                    onPress={e => {
                      e.stopPropagation();
                      handleDeleteRoom(room.id);
                    }}
                    style={{ padding: 2, marginLeft: 2 }}
                  >
                    <I name="close-circle" size={13} color="#FACC15" />
                  </Pressable>
                )}
              </Pressable>
            );
          })}

          {/* + Room Chip */}
          <Pressable
            onPress={() => setAddRoomModalVisible(true)}
            style={styles.addRoomChip}
          >
            <I name="add" size={14} color="#0F172A" />
            <Text style={styles.addRoomChipText}>{t.workflowAddRoom || '+ Room'}</Text>
          </Pressable>
        </ScrollView>

        {/* 4. WORK CONTENT FOR ACTIVE ROOM */}
        {activeRoom && service === 'electrical' ? (
          /* =================== ELECTRICAL MODE =================== */
          <View>
            {/* CARD 1: LIGHT & POWER POINTS */}
            {!activeRoom.isMainSupply && (
              <View style={styles.workCard}>
                <View style={styles.workCardHeader}>
                  <Text style={styles.workCardTitle}>💡 {t.workflowLightPowerPoints || 'Light & power points'}</Text>
                </View>

                {/* Light points stepper */}
                <View style={styles.stepperRow}>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.stepperLabel}>{t.workflowLightPoints || 'Light points'}</Text>
                  </View>
                  <View style={styles.stepperActions}>
                    <Pressable
                      style={styles.stepperBtn}
                      onPress={() => handleUpdateElectricalPoint('light', -1)}
                    >
                      <I name="remove" size={14} color="#0F172A" />
                    </Pressable>
                    <Text style={styles.stepperValText}>{activeRoom.points?.light ?? 4}</Text>
                    <Pressable
                      style={styles.stepperBtn}
                      onPress={() => handleUpdateElectricalPoint('light', 1)}
                    >
                      <I name="add" size={14} color="#0F172A" />
                    </Pressable>
                  </View>
                </View>

                {/* Fan points stepper */}
                <View style={styles.stepperRow}>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.stepperLabel}>{t.workflowFanPoints || 'Fan points'}</Text>
                  </View>
                  <View style={styles.stepperActions}>
                    <Pressable
                      style={styles.stepperBtn}
                      onPress={() => handleUpdateElectricalPoint('fan', -1)}
                    >
                      <I name="remove" size={14} color="#0F172A" />
                    </Pressable>
                    <Text style={styles.stepperValText}>{activeRoom.points?.fan ?? 1}</Text>
                    <Pressable
                      style={styles.stepperBtn}
                      onPress={() => handleUpdateElectricalPoint('fan', 1)}
                    >
                      <I name="add" size={14} color="#0F172A" />
                    </Pressable>
                  </View>
                </View>

                {/* Socket points stepper */}
                <View style={[styles.stepperRow, { borderBottomWidth: 0 }]}>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.stepperLabel}>{t.workflowSocketPoints || 'Socket points'}</Text>
                  </View>
                  <View style={styles.stepperActions}>
                    <Pressable
                      style={styles.stepperBtn}
                      onPress={() => handleUpdateElectricalPoint('socket', -1)}
                    >
                      <I name="remove" size={14} color="#0F172A" />
                    </Pressable>
                    <Text style={styles.stepperValText}>{activeRoom.points?.socket ?? 3}</Text>
                    <Pressable
                      style={styles.stepperBtn}
                      onPress={() => handleUpdateElectricalPoint('socket', 1)}
                    >
                      <I name="add" size={14} color="#0F172A" />
                    </Pressable>
                  </View>
                </View>
              </View>
            )}

            {/* CARD 2: CABLE ROUTE */}
            <View style={styles.workCard}>
              <View style={styles.workCardHeader}>
                <Text style={styles.workCardTitle}>🔌 {t.workflowCableRoute || 'Cable route'}</Text>
                <Pressable onPress={handleOpenCableEdit} style={styles.editCardBtn}>
                  <I name="pencil" size={13} color="#475569" />
                  <Text style={styles.editCardBtnText}>{t.workflowEdit || 'Edit'}</Text>
                </Pressable>
              </View>

              <View style={styles.cableInfoRow}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.cableLengthLabel}>
                    {t.workflowMeasuredLength || 'Measured length'}:{' '}
                    <Text style={styles.cableLengthBold}>{activeRoom.cableRoute?.length ?? 24} m</Text>
                  </Text>
                  <Text style={styles.cableRouteDesc}>
                    {activeRoom.cableRoute?.route || 'DB to Bedroom switchboard'}
                  </Text>
                  {!!activeRoom.cableRoute?.notes && (
                    <Text style={styles.cableNotesText}>• {activeRoom.cableRoute.notes}</Text>
                  )}
                </View>
              </View>
            </View>

            {/* CARD 3: CUSTOM WORK ITEMS (IF ANY) */}
            {(activeRoom.customItems || []).length > 0 && (
              <View style={styles.workCard}>
                <View style={styles.workCardHeader}>
                  <Text style={styles.workCardTitle}>🏷️ Custom work</Text>
                </View>
                {activeRoom.customItems.map(ci => (
                  <View key={ci.id} style={styles.customWorkRow}>
                    <Text style={styles.customWorkName}>{ci.name}</Text>
                    <Text style={styles.customWorkQty}>{ci.qty} {ci.unit || 'point'}</Text>
                  </View>
                ))}
              </View>
            )}

            {/* + ADD WORK ITEM BUTTON */}
            <Pressable
              style={styles.addWorkItemBtn}
              onPress={() => setCustomWorkModalVisible(true)}
            >
              <I name="add-circle-outline" size={18} color="#0F172A" />
              <Text style={styles.addWorkItemText}>{t.workflowAddWorkItem || '⊕ Add work item'}</Text>
            </Pressable>
          </View>
        ) : (
          /* =================== TILES & OTHER TRADES =================== */
          <View>
            {/* Work type cards */}
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 12 }}>
              <View style={{ flexDirection: 'row', gap: 8 }}>
                {workTypes.map(wt => {
                  const isSel = wt.id === activeWorkTypeId;
                  return (
                    <Pressable
                      key={wt.id}
                      onPress={() => {
                        setActiveWorkTypeId(wt.id);
                        const itemExists = (activeRoom.items || []).some(it => it.workTypeId === wt.id);
                        if (!itemExists) {
                          const newItem = calculateMeasurementItem({
                            id: 'it-' + Date.now().toString(36),
                            workTypeId: wt.id,
                            workTypeName: wt.name[appLang] || wt.name.en,
                            mode: wt.mode,
                            length: 10,
                            width: 10,
                            rate: wt.defaultRate,
                            unit: wt.defaultUnit,
                            dimensionUnit: wt.dimensionUnit || 'ft',
                            saved: true
                          });
                          const nextRooms = rooms.map(r => r.id === activeRoom.id ? { ...r, items: [...(r.items || []), newItem] } : r);
                          setRooms(nextRooms);
                          persistRooms(nextRooms);
                        }
                      }}
                      style={[styles.smallWtChip, isSel && styles.smallWtChipActive]}
                    >
                      <Text style={[styles.smallWtText, isSel && styles.smallWtTextActive]}>
                        {wt.name[appLang] || wt.name.en}
                      </Text>
                    </Pressable>
                  );
                })}
              </View>
            </ScrollView>

            {/* Only show floorplan diagram if service is tiles & mode is area */}
            {service === 'tiles' && activeItem?.mode === 'area' && (
              <View style={styles.diagramWrapper}>
                <Image source={measureRoomGuide} style={{ width: '100%', height: 100 }} resizeMode="cover" />
              </View>
            )}

            {/* Dimension Inputs */}
            {activeItem && (
              <View style={styles.workCard}>
                <View style={{ flexDirection: 'row', gap: 8, marginBottom: 8 }}>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.stepperLabel}>{t.measureLengthLabel || 'Length'} ({activeItem.dimensionUnit || 'ft'})</Text>
                    <TextInput
                      style={styles.dimInput}
                      keyboardType="decimal-pad"
                      value={String(activeItem.length || '')}
                      onChangeText={v => updateActiveItem({ length: v.replace(/[^0-9.]/g, '') })}
                    />
                  </View>

                  {activeItem.mode === 'area' && (
                    <View style={{ flex: 1 }}>
                      <Text style={styles.stepperLabel}>{t.measureWidthLabel || 'Width'} ({activeItem.dimensionUnit || 'ft'})</Text>
                      <TextInput
                        style={styles.dimInput}
                        keyboardType="decimal-pad"
                        value={String(activeItem.width || '')}
                        onChangeText={v => updateActiveItem({ width: v.replace(/[^0-9.]/g, '') })}
                      />
                    </View>
                  )}
                </View>

                {/* Net quantity and rate */}
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#F8FAFC', borderRadius: 8, padding: 8 }}>
                  <Text style={{ fontSize: 12, fontWeight: '700', color: '#475569' }}>
                    Net: {activeItem.netQty || 0} {activeItem.unit}
                  </Text>
                  <Text style={{ fontSize: 13, fontWeight: '800', color: '#0F172A' }}>
                    {money(activeItem.amount || 0)}
                  </Text>
                </View>
              </View>
            )}
          </View>
        )}

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* 5. BOTTOM STICKY SUMMARY & CTA: "🛒 Choose materials →" */}
      <View style={styles.stickyFooter}>
        <View style={styles.summaryCol}>
          {/* Unit-separated summary: Never sum incompatible units! */}
          <Text style={styles.summaryUnitsText}>
            {service === 'electrical'
              ? `${totalPointsCount} ${t.workflowLightPoints || 'points'} • ${totalCableMeters} m cable`
              : unitSummaries.map(u => `${u.qty} ${u.unit}`).join(' • ')}
          </Text>
          <Text style={styles.summaryAmountText}>
            {money(grandTotalAmount)}
          </Text>
        </View>

        <Pressable
          style={styles.chooseMaterialsBtn}
          onPress={handleProceedToMaterials}
        >
          <Text style={styles.chooseMaterialsBtnText}>
            {t.workflowChooseMaterials || 'Choose materials →'}
          </Text>
        </Pressable>
      </View>

      {/* MODAL: ADD ROOM */}
      <Modal visible={addRoomModalVisible} transparent animationType="fade" onRequestClose={() => setAddRoomModalVisible(false)}>
        <Pressable style={styles.modalOverlay} onPress={() => setAddRoomModalVisible(false)}>
          <Pressable style={styles.addRoomCard} onPress={e => e.stopPropagation()}>
            <Text style={styles.modalTitle}>{t.workflowAddRoom || '+ Add room'}</Text>
            <TextInput
              style={styles.custInput}
              placeholder="e.g. Living room / Balcony"
              value={newRoomName}
              onChangeText={setNewRoomName}
            />
            <View style={{ flexDirection: 'row', gap: 8, marginTop: 12 }}>
              <Pressable style={styles.modalCancelBtn} onPress={() => setAddRoomModalVisible(false)}>
                <Text style={styles.modalCancelBtnText}>{t.workflowCancel || 'Cancel'}</Text>
              </Pressable>
              <Pressable style={styles.modalSubmitBtn} onPress={() => handleAddRoom(newRoomName)}>
                <Text style={styles.modalSubmitBtnText}>Add</Text>
              </Pressable>
            </View>
          </Pressable>
        </Pressable>
      </Modal>

      {/* MODAL: CABLE ROUTE EDIT */}
      <Modal visible={cableModalVisible} transparent animationType="fade" onRequestClose={() => setCableModalVisible(false)}>
        <Pressable style={styles.modalOverlay} onPress={() => setCableModalVisible(false)}>
          <Pressable style={styles.addRoomCard} onPress={e => e.stopPropagation()}>
            <Text style={styles.modalTitle}>🔌 {t.workflowCableRoute || 'Cable Route'}</Text>

            <View style={{ marginVertical: 8 }}>
              <Text style={styles.stepperLabel}>{t.workflowMeasuredLength || 'Measured length'} (m):</Text>
              <TextInput
                style={styles.custInput}
                keyboardType="decimal-pad"
                value={cableLengthInput}
                onChangeText={setCableLengthInput}
              />
            </View>

            <View style={{ marginVertical: 8 }}>
              <Text style={styles.stepperLabel}>{t.workflowRouteDesc || 'Route description'}:</Text>
              <TextInput
                style={styles.custInput}
                placeholder="e.g. DB to Bedroom switchboard"
                value={cableRouteInput}
                onChangeText={setCableRouteInput}
              />
            </View>

            <View style={{ marginVertical: 8 }}>
              <Text style={styles.stepperLabel}>Notes (optional):</Text>
              <TextInput
                style={styles.custInput}
                placeholder="e.g. Through 25mm conduit"
                value={cableNotesInput}
                onChangeText={setCableNotesInput}
              />
            </View>

            <View style={{ flexDirection: 'row', gap: 8, marginTop: 12 }}>
              <Pressable style={styles.modalCancelBtn} onPress={() => setCableModalVisible(false)}>
                <Text style={styles.modalCancelBtnText}>{t.workflowCancel || 'Cancel'}</Text>
              </Pressable>
              <Pressable style={styles.modalSubmitBtn} onPress={handleSaveCableEdit}>
                <Text style={styles.modalSubmitBtnText}>Save</Text>
              </Pressable>
            </View>
          </Pressable>
        </Pressable>
      </Modal>

      {/* MODAL: ADD CUSTOM WORK ITEM */}
      <Modal visible={customWorkModalVisible} transparent animationType="fade" onRequestClose={() => setCustomWorkModalVisible(false)}>
        <Pressable style={styles.modalOverlay} onPress={() => setCustomWorkModalVisible(false)}>
          <Pressable style={styles.addRoomCard} onPress={e => e.stopPropagation()}>
            <Text style={styles.modalTitle}>⊕ {t.workflowAddWorkItem || 'Add work item'}</Text>

            <View style={{ marginVertical: 8 }}>
              <Text style={styles.stepperLabel}>{t.workflowCustomItemName || 'Item name'}:</Text>
              <TextInput
                style={styles.custInput}
                placeholder="e.g. AC Point / Geyser Point"
                value={customWorkName}
                onChangeText={setCustomWorkName}
              />
            </View>

            <View style={{ flexDirection: 'row', gap: 8, marginVertical: 8 }}>
              <View style={{ flex: 1 }}>
                <Text style={styles.stepperLabel}>Quantity:</Text>
                <TextInput
                  style={styles.custInput}
                  keyboardType="number-pad"
                  value={customWorkQty}
                  onChangeText={setCustomWorkQty}
                />
              </View>

              <View style={{ flex: 1 }}>
                <Text style={styles.stepperLabel}>Rate (₹):</Text>
                <TextInput
                  style={styles.custInput}
                  keyboardType="decimal-pad"
                  value={customWorkRate}
                  onChangeText={setCustomWorkRate}
                />
              </View>
            </View>

            <View style={{ flexDirection: 'row', gap: 8, marginTop: 12 }}>
              <Pressable style={styles.modalCancelBtn} onPress={() => setCustomWorkModalVisible(false)}>
                <Text style={styles.modalCancelBtnText}>{t.workflowCancel || 'Cancel'}</Text>
              </Pressable>
              <Pressable style={styles.modalSubmitBtn} onPress={handleAddCustomWorkItem}>
                <Text style={styles.modalSubmitBtnText}>Add</Text>
              </Pressable>
            </View>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Customer Switcher Modal */}
      {renderCustomerPickerModal()}
    </View>
  );
}

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: '#FCF9F6'
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 14,
    paddingVertical: 10,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9'
  },
  backBtn: {
    padding: 6,
    borderRadius: 8
  },
  customerChip: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#F8FAFC',
    borderRadius: 16,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: '#E2E8F0'
  },
  customerChipText: {
    flex: 1,
    fontSize: 12,
    fontWeight: '700',
    color: '#0F172A'
  },
  tradeBadge: {
    backgroundColor: '#FEF9C3',
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: '#FEF08A'
  },
  tradeBadgeText: {
    fontSize: 11,
    fontWeight: '800',
    color: '#854D0E'
  },
  scrollContent: {
    padding: 14
  },
  screenHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12
  },
  screenTitle: {
    fontSize: 18,
    fontWeight: '900',
    color: '#0F172A',
    letterSpacing: -0.3
  },
  skipLink: {
    paddingVertical: 4,
    paddingHorizontal: 8
  },
  skipLinkText: {
    fontSize: 12.5,
    fontWeight: '800',
    color: '#CA8A04'
  },
  roomChipsScroll: {
    gap: 8,
    paddingBottom: 12
  },
  roomChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 7,
    paddingHorizontal: 14,
    borderRadius: 14,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E2E8F0'
  },
  roomChipActive: {
    backgroundColor: '#1E293B',
    borderColor: '#1E293B'
  },
  roomChipText: {
    fontSize: 12.5,
    fontWeight: '700',
    color: '#475569'
  },
  roomChipTextActive: {
    color: '#FFD500'
  },
  addRoomChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingVertical: 7,
    paddingHorizontal: 12,
    borderRadius: 14,
    backgroundColor: '#FFFFFF',
    borderWidth: 1.2,
    borderColor: '#CBD5E1',
    borderStyle: 'dashed'
  },
  addRoomChipText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#0F172A'
  },
  workCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    padding: 14,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.03,
    shadowRadius: 4,
    elevation: 1
  },
  workCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#F8FAFC',
    paddingBottom: 8,
    marginBottom: 10
  },
  workCardTitle: {
    fontSize: 13.5,
    fontWeight: '800',
    color: '#0F172A'
  },
  editCardBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingVertical: 2,
    paddingHorizontal: 6
  },
  editCardBtnText: {
    fontSize: 11.5,
    fontWeight: '700',
    color: '#475569'
  },
  stepperRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F8FAFC'
  },
  stepperLabel: {
    fontSize: 13,
    fontWeight: '700',
    color: '#334155'
  },
  stepperActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6
  },
  stepperBtn: {
    width: 28,
    height: 28,
    borderRadius: 8,
    backgroundColor: '#F1F5F9',
    borderWidth: 1,
    borderColor: '#CBD5E1',
    alignItems: 'center',
    justifyContent: 'center'
  },
  stepperValText: {
    width: 28,
    textAlign: 'center',
    fontSize: 14,
    fontWeight: '900',
    color: '#0F172A'
  },
  cableInfoRow: {
    gap: 4
  },
  cableLengthLabel: {
    fontSize: 12.5,
    color: '#475569'
  },
  cableLengthBold: {
    fontSize: 14,
    fontWeight: '900',
    color: '#0F172A'
  },
  cableRouteDesc: {
    fontSize: 12,
    fontWeight: '600',
    color: '#0F172A',
    marginTop: 2
  },
  cableNotesText: {
    fontSize: 11,
    color: '#64748B',
    fontStyle: 'italic',
    marginTop: 2
  },
  customWorkRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 5
  },
  customWorkName: {
    fontSize: 12.5,
    fontWeight: '600',
    color: '#0F172A'
  },
  customWorkQty: {
    fontSize: 12.5,
    fontWeight: '800',
    color: '#0F172A'
  },
  addWorkItemBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    borderWidth: 1.2,
    borderColor: '#CBD5E1',
    borderStyle: 'dashed',
    paddingVertical: 11,
    marginBottom: 14
  },
  addWorkItemText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#0F172A'
  },
  stickyFooter: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#E2E8F0',
    paddingHorizontal: 16,
    paddingVertical: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 8
  },
  summaryCol: {
    flex: 1
  },
  summaryUnitsText: {
    fontSize: 12,
    fontWeight: '800',
    color: '#854D0E'
  },
  summaryAmountText: {
    fontSize: 15,
    fontWeight: '900',
    color: '#0F172A',
    marginTop: 1
  },
  chooseMaterialsBtn: {
    backgroundColor: '#FFD500',
    borderRadius: 12,
    paddingVertical: 11,
    paddingHorizontal: 18,
    alignItems: 'center',
    justifyContent: 'center'
  },
  chooseMaterialsBtnText: {
    fontSize: 13.5,
    fontWeight: '900',
    color: '#0F172A'
  },
  diagramWrapper: {
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 12,
    backgroundColor: '#F5F5F4'
  },
  smallWtChip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E2E8F0'
  },
  smallWtChipActive: {
    backgroundColor: '#FEF9C3',
    borderColor: '#FACC15'
  },
  smallWtText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#475569'
  },
  smallWtTextActive: {
    fontWeight: '800',
    color: '#854D0E'
  },
  dimInput: {
    backgroundColor: '#F8FAFC',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    padding: 8,
    fontSize: 13,
    color: '#0F172A',
    marginTop: 4
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(15, 23, 42, 0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16
  },
  pickerCard: {
    width: '100%',
    maxWidth: 380,
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 16
  },
  pickerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10
  },
  pickerTitle: {
    fontSize: 15,
    fontWeight: '800',
    color: '#0F172A'
  },
  custOptionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F8FAFC'
  },
  custOptionRowActive: {
    backgroundColor: '#FEF9E7',
    borderRadius: 8,
    paddingHorizontal: 6
  },
  custOptionName: {
    fontSize: 13,
    fontWeight: '700',
    color: '#0F172A'
  },
  custOptionSite: {
    fontSize: 11,
    color: '#64748B'
  },
  custOrLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: '#64748B'
  },
  custInput: {
    backgroundColor: '#F8FAFC',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    paddingHorizontal: 10,
    paddingVertical: 6,
    fontSize: 12.5,
    color: '#0F172A'
  },
  custSetBtn: {
    backgroundColor: '#FFD500',
    borderRadius: 8,
    paddingHorizontal: 12,
    justifyContent: 'center'
  },
  custSetBtnText: {
    fontSize: 12,
    fontWeight: '800',
    color: '#0F172A'
  },
  addRoomCard: {
    width: '100%',
    maxWidth: 360,
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 16
  },
  modalTitle: {
    fontSize: 15,
    fontWeight: '800',
    color: '#0F172A',
    marginBottom: 8
  },
  modalCancelBtn: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#CBD5E1',
    alignItems: 'center',
    justifyContent: 'center'
  },
  modalCancelBtnText: {
    fontSize: 12.5,
    fontWeight: '700',
    color: '#475569'
  },
  modalSubmitBtn: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: '#FFD500',
    alignItems: 'center',
    justifyContent: 'center'
  },
  modalSubmitBtnText: {
    fontSize: 12.5,
    fontWeight: '800',
    color: '#0F172A'
  }
});
