import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  Modal,
  ScrollView,
  Pressable,
  TextInput,
  Image,
  StyleSheet
} from 'react-native';
import { I } from './ui';
import { money, defaultTradeMaterials } from './domain.cjs';
import { getStrings } from './i18n';
import ProductImageModal from './ProductImageModal';

export default function MyMaterialsCatalogModal({
  visible,
  service = 'electrical',
  appLang = 'en',
  catalog = [],
  onSaveMaterial,
  onDeleteMaterial,
  onClose,
  notify
}) {
  const t = getStrings(appLang);

  const [search, setSearch] = useState('');
  const [selectedCat, setSelectedCat] = useState('All');

  // Photo modal state
  const [photoModalVisible, setPhotoModalVisible] = useState(false);
  const [activePhotoMaterialId, setActivePhotoMaterialId] = useState(null);

  // Edit / Add modal state
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [name, setName] = useState('');
  const [category, setCategory] = useState('Other');
  const [specs, setSpecs] = useState('');
  const [brand, setBrand] = useState('');
  const [unit, setUnit] = useState('pcs');
  const [defaultRate, setDefaultRate] = useState('');

  const categories = useMemo(() => {
    if (service === 'electrical') {
      return ['All', 'Wires', 'Switches', 'Pipes', 'Other'];
    } else if (service === 'tiles') {
      return ['All', 'Tiles', 'Adhesives', 'Grout', 'Spacers', 'Other'];
    } else if (service === 'plumbing') {
      return ['All', 'Pipes', 'Fittings', 'Valves', 'Other'];
    } else if (service === 'painting') {
      return ['All', 'Putty', 'Primer', 'Paint', 'Tools', 'Other'];
    }
    return ['All', 'General', 'Other'];
  }, [service]);

  const effectiveCatalog = useMemo(() => {
    if (Array.isArray(catalog) && catalog.length > 0) return catalog;
    return (defaultTradeMaterials || []).filter(m => !m.service || m.service === service);
  }, [catalog, service]);

  const filteredCatalog = useMemo(() => {
    const q = search.trim().toLowerCase();
    return effectiveCatalog.filter(m => {
      const matchCat = selectedCat === 'All' || m.category === selectedCat;
      if (!matchCat) return false;
      if (!q) return true;
      const nm = (m.name || '').toLowerCase();
      const sp = (m.specs || '').toLowerCase();
      const br = (m.brand || '').toLowerCase();
      return nm.includes(q) || sp.includes(q) || br.includes(q);
    });
  }, [effectiveCatalog, selectedCat, search]);

  const handleOpenEdit = (item = null) => {
    setEditingItem(item);
    setName(item ? item.name : '');
    setCategory(item ? item.category || 'Other' : (categories[1] || 'Other'));
    setSpecs(item ? item.specs || '' : '');
    setBrand(item ? item.brand || '' : '');
    setUnit(item ? item.unit || 'pcs' : 'pcs');
    setDefaultRate(item ? String(item.defaultRate || item.rate || '') : '');
    setEditModalVisible(true);
  };

  const handleSaveItem = () => {
    const trimmed = name.trim();
    if (!trimmed) {
      alert(appLang === 'te' ? 'దయచేసి మెటీరియల్ పేరు నమోదు చేయండి' : appLang === 'hi' ? 'कृपया सामग्री का नाम दर्ज करें' : 'Please enter material name');
      return;
    }
    const itemData = {
      id: editingItem ? editingItem.id : ('mat-cat-' + Date.now().toString(36)),
      service,
      name: trimmed,
      category,
      specs: specs.trim(),
      brand: brand.trim(),
      unit: unit.trim() || 'pcs',
      defaultRate: parseFloat(defaultRate) || 0,
      imageUri: editingItem ? editingItem.imageUri : ''
    };

    if (onSaveMaterial) {
      onSaveMaterial(itemData);
    }
    setEditModalVisible(false);
    if (notify) {
      notify(appLang === 'te' ? 'మెటీరియల్ కేటలాగ్ అప్‌డేట్ అయింది' : appLang === 'hi' ? 'सामग्री कैटलॉग अपडेट हुआ' : 'Catalog updated');
    }
  };

  const handleSavePhoto = imageDataUrl => {
    if (!activePhotoMaterialId) return;
    const target = (catalog || []).find(m => m.id === activePhotoMaterialId);
    if (target && onSaveMaterial) {
      onSaveMaterial({ ...target, imageUri: imageDataUrl });
    }
    if (notify) {
      notify(appLang === 'te' ? 'ఫోటో సేవ్ చేయబడింది' : appLang === 'hi' ? 'फोटो सुरक्षित किया गया' : 'Photo saved');
    }
  };

  if (!visible) return null;

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <View style={styles.container}>
        {/* Top Header */}
        <View style={styles.topBar}>
          <Pressable onPress={onClose} style={styles.closeBtn}>
            <I name="arrow-back" size={20} color="#0F172A" />
          </Pressable>
          <View style={{ flex: 1, paddingHorizontal: 8 }}>
            <Text style={styles.topBarTitle}>📦 {t.workflowMyMaterials || 'My Materials'}</Text>
            <Text style={styles.topBarSub}>
              {service.charAt(0).toUpperCase() + service.slice(1)} • {catalog.length} {appLang === 'te' ? 'ఐటమ్స్ కేటలాగ్' : appLang === 'hi' ? 'सामग्री कैटलॉग' : 'items in catalog'}
            </Text>
          </View>
          <Pressable onPress={() => handleOpenEdit(null)} style={styles.addBtn}>
            <I name="add" size={18} color="#0F172A" />
            <Text style={styles.addBtnText}>+ New</Text>
          </Pressable>
        </View>

        {/* Search Bar */}
        <View style={styles.searchRow}>
          <View style={styles.searchBox}>
            <I name="search" size={17} color="#64748B" />
            <TextInput
              style={styles.searchInput}
              placeholder={t.workflowSearchOrSpeak || 'Search catalog'}
              placeholderTextColor="#94A3B8"
              value={search}
              onChangeText={setSearch}
            />
            {!!search && (
              <Pressable onPress={() => setSearch('')} style={{ padding: 4 }}>
                <I name="close-circle" size={16} color="#94A3B8" />
              </Pressable>
            )}
          </View>
        </View>

        {/* Category Pills */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={styles.catScrollView}
          contentContainerStyle={styles.catScroll}
        >
          {categories.map(c => (
            <Pressable
              key={c}
              onPress={() => setSelectedCat(c)}
              style={[styles.catPill, selectedCat === c && styles.catPillSelected]}
            >
              <Text style={[styles.catPillText, selectedCat === c && styles.catPillTextSelected]}>
                {c === 'All' ? (t.workflowCatAll || 'All') : c}
              </Text>
            </Pressable>
          ))}
        </ScrollView>

        {/* Materials List */}
        <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.listContent}>
          {filteredCatalog.map(m => (
            <View key={m.id} style={styles.materialCard}>
              <Pressable
                onPress={() => {
                  setActivePhotoMaterialId(m.id);
                  setPhotoModalVisible(true);
                }}
                style={styles.thumbWrapper}
              >
                {m.imageUri ? (
                  <Image source={{ uri: m.imageUri }} style={styles.thumbImage} resizeMode="cover" />
                ) : (
                  <I name="cube-outline" size={22} color="#64748B" />
                )}
                <View style={styles.cameraBadge}>
                  <I name="camera" size={10} color="#FFFFFF" />
                </View>
              </Pressable>

              <View style={{ flex: 1, paddingHorizontal: 10 }}>
                <Text style={styles.matTitle} numberOfLines={1}>
                  {appLang === 'te' && m.teName ? m.teName : appLang === 'hi' && m.hiName ? m.hiName : m.name}
                </Text>
                {!!m.specs && <Text style={styles.matSpecs} numberOfLines={1}>{m.specs}</Text>}
                <Text style={styles.matRate}>
                  {Number(m.defaultRate || m.rate || 0) > 0 ? money(m.defaultRate || m.rate) : 'Rate not set'}
                  <Text style={{ fontSize: 10.5, color: '#64748B' }}> / {m.unit || 'pcs'}</Text>
                </Text>
              </View>

              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <Pressable onPress={() => handleOpenEdit(m)} style={styles.iconActionBtn}>
                  <I name="pencil" size={15} color="#475569" />
                </Pressable>

                {onDeleteMaterial && (
                  <Pressable
                    onPress={() => {
                      if (confirm(appLang === 'te' ? 'ఈ మెటీరియల్‌ను తొలగించాలా?' : appLang === 'hi' ? 'क्या इस सामग्री को हटाएं?' : 'Delete this material from catalog?')) {
                        onDeleteMaterial(m.id);
                      }
                    }}
                    style={styles.iconActionBtn}
                  >
                    <I name="trash-outline" size={15} color="#EF4444" />
                  </Pressable>
                )}
              </View>
            </View>
          ))}

          {filteredCatalog.length === 0 && (
            <View style={styles.emptyView}>
              <Text style={{ fontSize: 24, marginBottom: 6 }}>📦</Text>
              <Text style={{ fontSize: 13, color: '#64748B', fontWeight: '600' }}>No materials in this category</Text>
            </View>
          )}

          <View style={{ height: 40 }} />
        </ScrollView>

        {/* Photo Modal */}
        <ProductImageModal
          visible={photoModalVisible}
          initialImage={catalog.find(m => m.id === activePhotoMaterialId)?.imageUri || ''}
          title={catalog.find(m => m.id === activePhotoMaterialId)?.name || ''}
          appLang={appLang}
          onSave={handleSavePhoto}
          onClose={() => setPhotoModalVisible(false)}
        />

        {/* Edit / Add Sheet Modal */}
        <Modal visible={editModalVisible} transparent animationType="slide" onRequestClose={() => setEditModalVisible(false)}>
          <Pressable style={styles.modalOverlay} onPress={() => setEditModalVisible(false)}>
            <Pressable style={styles.editSheet} onPress={e => e.stopPropagation()}>
              <View style={styles.sheetHeader}>
                <Text style={styles.sheetTitle}>{editingItem ? 'Edit Material' : 'Add Material to Catalog'}</Text>
                <Pressable onPress={() => setEditModalVisible(false)}>
                  <I name="close" size={20} color="#64748B" />
                </Pressable>
              </View>

              <ScrollView showsVerticalScrollIndicator={false}>
                <View style={styles.fieldGroup}>
                  <Text style={styles.fieldLabel}>Material Name *</Text>
                  <TextInput style={styles.fieldInput} value={name} onChangeText={setName} placeholder="e.g. 1.5 sq mm Copper Wire" />
                </View>

                <View style={styles.fieldGroup}>
                  <Text style={styles.fieldLabel}>Category</Text>
                  <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
                    {categories.filter(c => c !== 'All').map(c => (
                      <Pressable
                        key={c}
                        onPress={() => setCategory(c)}
                        style={[styles.smallChip, category === c && styles.smallChipSelected]}
                      >
                        <Text style={[styles.smallChipText, category === c && styles.smallChipTextSelected]}>{c}</Text>
                      </Pressable>
                    ))}
                  </View>
                </View>

                <View style={styles.fieldGroup}>
                  <Text style={styles.fieldLabel}>Specifications</Text>
                  <TextInput style={styles.fieldInput} value={specs} onChangeText={setSpecs} placeholder="e.g. 90m roll, red/blue" />
                </View>

                <View style={styles.fieldGroup}>
                  <Text style={styles.fieldLabel}>Brand</Text>
                  <TextInput style={styles.fieldInput} value={brand} onChangeText={setBrand} placeholder="e.g. Polycab / Havells" />
                </View>

                <View style={{ flexDirection: 'row', gap: 10 }}>
                  <View style={[styles.fieldGroup, { flex: 1 }]}>
                    <Text style={styles.fieldLabel}>Unit</Text>
                    <TextInput style={styles.fieldInput} value={unit} onChangeText={setUnit} placeholder="pcs, roll, m" />
                  </View>

                  <View style={[styles.fieldGroup, { flex: 1 }]}>
                    <Text style={styles.fieldLabel}>Default Rate (₹)</Text>
                    <TextInput style={styles.fieldInput} keyboardType="decimal-pad" value={defaultRate} onChangeText={setDefaultRate} placeholder="0" />
                  </View>
                </View>

                <View style={{ height: 14 }} />
              </ScrollView>

              <View style={{ flexDirection: 'row', gap: 10, marginTop: 8 }}>
                <Pressable style={styles.cancelBtn} onPress={() => setEditModalVisible(false)}>
                  <Text style={styles.cancelBtnText}>{t.workflowCancel || 'Cancel'}</Text>
                </Pressable>
                <Pressable style={styles.submitBtn} onPress={handleSaveItem}>
                  <Text style={styles.submitBtnText}>{editingItem ? 'Save Changes' : 'Add to Catalog'}</Text>
                </Pressable>
              </View>
            </Pressable>
          </Pressable>
        </Modal>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FCF9F6'
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9'
  },
  closeBtn: {
    padding: 6,
    borderRadius: 8
  },
  topBarTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: '#0F172A'
  },
  topBarSub: {
    fontSize: 11,
    color: '#64748B',
    marginTop: 1
  },
  addBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#FFD500',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12
  },
  addBtnText: {
    fontSize: 12.5,
    fontWeight: '800',
    color: '#0F172A'
  },
  searchRow: {
    paddingHorizontal: 14,
    paddingVertical: 10
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: '#E2E8F0'
  },
  searchInput: {
    flex: 1,
    fontSize: 13,
    color: '#0F172A',
    fontWeight: '600',
    padding: 0
  },
  catScrollView: {
    flexGrow: 0,
    height: 40,
    marginBottom: 8
  },
  catScroll: {
    paddingHorizontal: 14,
    gap: 6,
    alignItems: 'center'
  },
  catPill: {
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    alignItems: 'center',
    justifyContent: 'center'
  },
  catPillSelected: {
    backgroundColor: '#1E293B',
    borderColor: '#1E293B'
  },
  catPillText: {
    fontSize: 11.5,
    fontWeight: '700',
    color: '#475569'
  },
  catPillTextSelected: {
    color: '#FFD500'
  },
  listContent: {
    paddingHorizontal: 14,
    gap: 8
  },
  materialCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 10,
    borderWidth: 1,
    borderColor: '#E2E8F0'
  },
  thumbWrapper: {
    position: 'relative',
    width: 42,
    height: 42,
    borderRadius: 8,
    backgroundColor: '#F1F5F9',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden'
  },
  thumbImage: {
    width: '100%',
    height: '100%'
  },
  cameraBadge: {
    position: 'absolute',
    bottom: 2,
    right: 2,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    alignItems: 'center',
    justifyContent: 'center'
  },
  matTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: '#0F172A'
  },
  matSpecs: {
    fontSize: 11,
    color: '#64748B',
    marginTop: 1
  },
  matRate: {
    fontSize: 11.5,
    fontWeight: '700',
    color: '#0F172A',
    marginTop: 2
  },
  iconActionBtn: {
    padding: 6,
    borderRadius: 8,
    backgroundColor: '#F8FAFC'
  },
  emptyView: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 32
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(15, 23, 42, 0.6)',
    justifyContent: 'flex-end'
  },
  editSheet: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 18,
    maxHeight: '85%'
  },
  sheetHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12
  },
  sheetTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: '#0F172A'
  },
  fieldGroup: {
    marginBottom: 10
  },
  fieldLabel: {
    fontSize: 12,
    fontWeight: '700',
    color: '#334155',
    marginBottom: 4
  },
  fieldInput: {
    backgroundColor: '#F8FAFC',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    paddingHorizontal: 10,
    paddingVertical: 8,
    fontSize: 13,
    color: '#0F172A'
  },
  smallChip: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
    backgroundColor: '#F1F5F9',
    borderWidth: 1,
    borderColor: '#E2E8F0'
  },
  smallChipSelected: {
    backgroundColor: '#FEF08A',
    borderColor: '#EAB308'
  },
  smallChipText: {
    fontSize: 11.5,
    fontWeight: '600',
    color: '#475569'
  },
  smallChipTextSelected: {
    color: '#854D0E',
    fontWeight: '800'
  },
  cancelBtn: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#CBD5E1',
    alignItems: 'center',
    justifyContent: 'center'
  },
  cancelBtnText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#475569'
  },
  submitBtn: {
    flex: 1.5,
    paddingVertical: 10,
    borderRadius: 10,
    backgroundColor: '#FFD500',
    alignItems: 'center',
    justifyContent: 'center'
  },
  submitBtnText: {
    fontSize: 13,
    fontWeight: '900',
    color: '#0F172A'
  }
});
