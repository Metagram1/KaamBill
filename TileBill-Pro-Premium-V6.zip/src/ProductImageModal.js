import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Modal,
  Image,
  Pressable,
  Platform,
  StyleSheet,
  ScrollView
} from 'react-native';
import { I } from './ui';
import { getStrings } from './i18n';

export default function ProductImageModal({
  visible,
  initialImage = '',
  title = '',
  appLang = 'en',
  onSave,
  onClose
}) {
  const t = getStrings(appLang);
  const [preview, setPreview] = useState(initialImage);

  useEffect(() => {
    setPreview(initialImage);
  }, [initialImage, visible]);

  const handlePickFile = (captureCamera = false) => {
    if (Platform.OS === 'web' && typeof document !== 'undefined') {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      if (captureCamera) {
        input.capture = 'environment';
      }
      input.onchange = e => {
        const file = e.target?.files?.[0];
        if (!file) return;
        if (file.size > 3 * 1024 * 1024) {
          alert(appLang === 'te' ? 'చిత్రం పరిమాణం 3MB కంటే తక్కువగా ఉండాలి' : appLang === 'hi' ? 'छवि 3MB से कम होनी चाहिए' : 'Image must be under 3MB');
          return;
        }
        const reader = new FileReader();
        reader.onload = ev => {
          setPreview(ev.target?.result || '');
        };
        reader.readAsDataURL(file);
      };
      input.click();
    }
  };

  const handleSave = () => {
    if (onSave) onSave(preview);
    if (onClose) onClose();
  };

  const handleCancel = () => {
    setPreview(initialImage);
    if (onClose) onClose();
  };

  if (!visible) return null;

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={handleCancel}>
      <Pressable style={styles.overlay} onPress={handleCancel}>
        <Pressable style={styles.card} onPress={e => e.stopPropagation()}>
          {/* Header */}
          <View style={styles.header}>
            <View style={{ flex: 1 }}>
              <Text style={styles.title}>{t.workflowPhotoModalTitle || 'Material Photo'}</Text>
              {!!title && <Text style={styles.subtitle} numberOfLines={1}>{title}</Text>}
            </View>
            <Pressable onPress={handleCancel} style={styles.closeBtn}>
              <I name="close" size={20} color="#64748B" />
            </Pressable>
          </View>

          {/* Preview Canvas */}
          <View style={styles.previewBox}>
            {preview ? (
              <Image source={{ uri: preview }} style={styles.previewImage} resizeMode="contain" />
            ) : (
              <View style={styles.emptyPlaceholder}>
                <View style={styles.emptyIconCircle}>
                  <I name="image-outline" size={36} color="#94A3B8" />
                </View>
                <Text style={styles.emptyText}>
                  {appLang === 'te' ? 'ఫోటో ఏదీ ఎంచుకోలేదు' : appLang === 'hi' ? 'कोई फोटो नहीं चुनी गई' : 'No photo selected'}
                </Text>
              </View>
            )}
          </View>

          {/* Action Buttons */}
          <View style={styles.actionsContainer}>
            <Pressable
              style={({ pressed }) => [styles.actionButton, pressed && { opacity: 0.8 }]}
              onPress={() => handlePickFile(true)}
            >
              <I name="camera-outline" size={18} color="#0F172A" />
              <Text style={styles.actionBtnText}>{t.workflowTakePhoto || 'Take Photo'}</Text>
            </Pressable>

            <Pressable
              style={({ pressed }) => [styles.actionButton, pressed && { opacity: 0.8 }]}
              onPress={() => handlePickFile(false)}
            >
              <I name="cloud-upload-outline" size={18} color="#0F172A" />
              <Text style={styles.actionBtnText}>{t.workflowUploadFile || 'Upload File'}</Text>
            </Pressable>

            {!!preview && (
              <Pressable
                style={({ pressed }) => [styles.actionButtonDanger, pressed && { opacity: 0.8 }]}
                onPress={() => setPreview('')}
              >
                <I name="trash-outline" size={18} color="#EF4444" />
                <Text style={styles.actionBtnTextDanger}>{t.workflowRemovePhoto || 'Remove Photo'}</Text>
              </Pressable>
            )}
          </View>

          {/* Footer Save & Cancel */}
          <View style={styles.footer}>
            <Pressable style={styles.cancelBtn} onPress={handleCancel}>
              <Text style={styles.cancelBtnText}>{t.workflowCancel || 'Cancel'}</Text>
            </Pressable>

            <Pressable style={styles.saveBtn} onPress={handleSave}>
              <Text style={styles.saveBtnText}>{t.workflowSavePhoto || 'Save Photo'}</Text>
            </Pressable>
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(15, 23, 42, 0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16
  },
  card: {
    width: '100%',
    maxWidth: 420,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.15,
    shadowRadius: 16,
    elevation: 8
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14
  },
  title: {
    fontSize: 16,
    fontWeight: '800',
    color: '#0F172A'
  },
  subtitle: {
    fontSize: 12,
    color: '#64748B',
    marginTop: 2
  },
  closeBtn: {
    padding: 6,
    borderRadius: 8
  },
  previewBox: {
    width: '100%',
    height: 200,
    backgroundColor: '#F8FAFC',
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: '#E2E8F0',
    borderStyle: 'dashed',
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
    marginBottom: 14
  },
  previewImage: {
    width: '100%',
    height: '100%'
  },
  emptyPlaceholder: {
    alignItems: 'center',
    justifyContent: 'center'
  },
  emptyIconCircle: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#E2E8F0',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8
  },
  emptyText: {
    fontSize: 12,
    color: '#64748B',
    fontWeight: '600'
  },
  actionsContainer: {
    gap: 8,
    marginBottom: 16
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#F1F5F9',
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 14
  },
  actionBtnText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#0F172A'
  },
  actionButtonDanger: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#FEF2F2',
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 14
  },
  actionBtnTextDanger: {
    fontSize: 13,
    fontWeight: '700',
    color: '#EF4444'
  },
  footer: {
    flexDirection: 'row',
    gap: 10,
    borderTopWidth: 1,
    borderTopColor: '#F1F5F9',
    paddingTop: 12
  },
  cancelBtn: {
    flex: 1,
    paddingVertical: 11,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#CBD5E1',
    alignItems: 'center',
    justifyContent: 'center'
  },
  cancelBtnText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#475569'
  },
  saveBtn: {
    flex: 1.5,
    paddingVertical: 11,
    borderRadius: 12,
    backgroundColor: '#FFD500',
    alignItems: 'center',
    justifyContent: 'center'
  },
  saveBtnText: {
    fontSize: 13.5,
    fontWeight: '900',
    color: '#0F172A'
  }
});
