import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  View,
  Text,
  Modal,
  ScrollView,
  Pressable,
  TextInput,
  Image,
  Platform,
  Linking,
  StyleSheet
} from 'react-native';
import { I } from './ui';
import { money, materialListHtml, labourBillHtml } from './domain.cjs';
import { getStrings } from './i18n';

export default function ReadyToShareMaterialsModal({
  visible,
  service = 'electrical',
  appLang = 'en',
  customer,
  siteLocation = '',
  business,
  materials = [],
  rooms = [],
  workSummary = '',
  initialShowPrices = false,
  onBack,
  onEditMaterials,
  onSaveMaterialList,
  onCreateLabourDocument,
  onClose,
  notify
}) {
  const t = getStrings(appLang);

  // Active Tab: 'materials' | 'labour'
  const [activeTab, setActiveTab] = useState('materials');

  // Materials tab state
  const [docLanguage, setDocLanguage] = useState(appLang || 'en');
  const [instructions, setInstructions] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Labour billing tab state
  const [billingBasis, setBillingBasis] = useState('per_point'); // 'per_point' | 'per_length' | 'room_lump' | 'project_lump'
  const [ratePerPoint, setRatePerPoint] = useState('650');
  const [ratePerMeter, setRatePerMeter] = useState('60');
  const [projectLumpSum, setProjectLumpSum] = useState('12000');
  const [roomLumpSums, setRoomLumpSums] = useState({});

  // Preview / Print modal state
  const [htmlPreviewVisible, setHtmlPreviewVisible] = useState(false);
  const [htmlContent, setHtmlContent] = useState('');

  // Total points and cable length computed from rooms
  const { totalPoints, totalCableLength, workAreasText } = useMemo(() => {
    let pts = 0;
    let cable = 0;
    const areas = [];

    (rooms || []).forEach(r => {
      const light = Number(r.points?.light || 0);
      const fan = Number(r.points?.fan || 0);
      const socket = Number(r.points?.socket || 0);
      const custom = (r.customItems || []).reduce((sum, ci) => sum + Number(ci.qty || 0), 0);
      const roomPts = light + fan + socket + custom;
      pts += roomPts;

      const roomCable = Number(r.cableRoute?.length || 0);
      cable += roomCable;

      const ptParts = [];
      if (light > 0) ptParts.push(`${light} light`);
      if (fan > 0) ptParts.push(`${fan} fan`);
      if (socket > 0) ptParts.push(`${socket} socket`);
      if (custom > 0) ptParts.push(`${custom} custom`);
      if (roomCable > 0) ptParts.push(`${roomCable}m cable`);

      areas.push(`${r.name}${ptParts.length ? ` (${ptParts.join(', ')})` : ''}`);
    });

    return {
      totalPoints: pts || 8,
      totalCableLength: cable || 24,
      workAreasText: workSummary || areas.join(', ') || 'Bedroom, Kitchen, Main supply'
    };
  }, [rooms, workSummary]);

  // Labour total calculation based on basis
  const labourCalculations = useMemo(() => {
    const pRate = parseFloat(ratePerPoint) || 0;
    const mRate = parseFloat(ratePerMeter) || 0;
    const projLump = parseFloat(projectLumpSum) || 0;

    let items = [];
    let grandTotal = 0;

    if (billingBasis === 'per_point') {
      const amount = totalPoints * pRate;
      grandTotal = amount;
      items.push({
        name: `${totalPoints} Points wiring & fitting labour`,
        basis: 'Per point',
        qty: totalPoints,
        unit: 'point',
        rate: pRate,
        amount
      });
    } else if (billingBasis === 'per_length') {
      const cableAmount = totalCableLength * mRate;
      grandTotal = cableAmount;
      items.push({
        name: `Main cable laying (${totalCableLength} m)`,
        basis: 'Per meter',
        qty: totalCableLength,
        unit: 'm',
        rate: mRate,
        amount: cableAmount
      });
    } else if (billingBasis === 'room_lump') {
      (rooms || []).forEach(r => {
        const lump = parseFloat(roomLumpSums[r.id]) || (r.name.includes('Main') ? 2500 : 3500);
        grandTotal += lump;
        items.push({
          name: `${r.name} complete electrical labour`,
          basis: 'Room lump sum',
          qty: 1,
          unit: 'room',
          rate: lump,
          amount: lump
        });
      });
    } else if (billingBasis === 'project_lump') {
      grandTotal = projLump;
      items.push({
        name: 'Full project electrical contract (Lump sum)',
        basis: 'Project lump sum',
        qty: 1,
        unit: 'job',
        rate: projLump,
        amount: projLump
      });
    }

    return { items, grandTotal };
  }, [billingBasis, ratePerPoint, ratePerMeter, projectLumpSum, roomLumpSums, totalPoints, totalCableLength, rooms]);

  // Text-To-Speech Read-aloud using Web Speech API
  const handleListenToList = () => {
    if (Platform.OS !== 'web' || typeof window === 'undefined' || !window.speechSynthesis) {
      alert('Speech audio is available in web browser');
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const custName = customer?.name || 'Customer';
    let speechText = '';

    if (docLanguage === 'te') {
      speechText = `${custName} గారి కోసం కొనుగోలు చేయవలసిన సామాగ్రి జాబితా. `;
      materials.forEach((m, idx) => {
        speechText += `${idx + 1}. ${m.teName || m.name}, ${m.qty} ${m.unit || ''}. `;
      });
      if (instructions) speechText += `షాప్ సూచనలు: ${instructions}. `;
    } else if (docLanguage === 'hi') {
      speechText = `${custName} के लिए खरीदी जाने वाली सामग्री सूची। `;
      materials.forEach((m, idx) => {
        speechText += `${idx + 1}. ${m.hiName || m.name}, ${m.qty} ${m.unit || ''}. `;
      });
      if (instructions) speechText += `निर्देश: ${instructions}. `;
    } else {
      speechText = `Materials to purchase list for ${custName}. `;
      materials.forEach((m, idx) => {
        speechText += `Item ${idx + 1}: ${m.name}, ${m.qty} ${m.unit || 'pieces'}. `;
      });
      if (instructions) speechText += `Instructions: ${instructions}. `;
    }

    const utterance = new SpeechSynthesisUtterance(speechText);
    utterance.lang = docLanguage === 'te' ? 'te-IN' : docLanguage === 'hi' ? 'hi-IN' : 'en-IN';
    utterance.rate = 0.95;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  // Preview & Share Material List
  const handlePreviewShare = () => {
    const listObj = {
      number: 'TB-MAT-' + String(Math.floor(1000 + Math.random() * 9000)),
      date: new Date().toISOString().slice(0, 10),
      language: docLanguage,
      customer: customer || { name: 'Customer' },
      siteLocation: siteLocation || customer?.siteLocation || customer?.address || 'Site Office',
      workAreasSummary: workAreasText,
      items: materials,
      showPrices: initialShowPrices,
      instructions
    };

    if (onSaveMaterialList) {
      onSaveMaterialList(listObj);
    }

    const html = materialListHtml(listObj, business, { language: docLanguage, showPrices: initialShowPrices });
    setHtmlContent(html);
    setHtmlPreviewVisible(true);
  };

  // Create Labour Document in TileBill Pro
  const handleCreateLabourDocument = (kind = 'quotation') => {
    const docData = {
      kind,
      service,
      customerId: customer?.id,
      customer: customer || null,
      siteLocation: siteLocation || customer?.siteLocation || '',
      title: `${customer?.name || 'Project'} • Electrical Labour Charges`,
      language: docLanguage,
      items: labourCalculations.items
    };

    if (onCreateLabourDocument) {
      onCreateLabourDocument(docData);
    }
  };

  // WhatsApp Share Text
  const handleShareWhatsApp = () => {
    const custName = customer?.name || 'Customer';
    let text = `*📋 TILEBILL PRO - MATERIALS TO PURCHASE*\n`;
    text += `*Customer:* ${custName}\n`;
    text += `*Site:* ${siteLocation || customer?.siteLocation || 'Site'}\n`;
    text += `*Work Areas:* ${workAreasText}\n\n`;
    text += `*Required Materials:*\n`;
    materials.forEach((m, idx) => {
      text += `${idx + 1}. ${m.name} - *${m.qty} ${m.unit || 'pcs'}*`;
      if (m.specs) text += ` (${m.specs})`;
      text += `\n`;
    });
    if (instructions) {
      text += `\n*Instructions:* ${instructions}\n`;
    }
    text += `\n_Prepared with TileBill Pro_`;

    const phone = customer?.phone ? customer.phone.replace(/\D/g, '').slice(-10) : '';
    const url = phone ? `https://wa.me/91${phone}?text=${encodeURIComponent(text)}` : `https://wa.me/?text=${encodeURIComponent(text)}`;
    Linking.openURL(url).catch(() => {
      alert('Could not open WhatsApp');
    });
  };

  if (!visible) return null;

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <View style={styles.container}>
        {/* 1. TOP BAR */}
        <View style={styles.topBar}>
          <Pressable onPress={onBack || onClose} style={styles.backBtn}>
            <I name="arrow-back" size={20} color="#0F172A" />
          </Pressable>
          <Text style={styles.topBarTitle}>{t.workflowReadyToShare || 'Ready to share'}</Text>
          <View style={{ width: 36 }} />
        </View>

        {/* 2. SEGMENTED TABS: [ Materials list ] [ Labour bill ] */}
        <View style={styles.tabsContainer}>
          <Pressable
            style={[styles.tabButton, activeTab === 'materials' && styles.tabButtonActive]}
            onPress={() => setActiveTab('materials')}
          >
            <Text style={{ fontSize: 13 }}>📄</Text>
            <Text style={[styles.tabButtonText, activeTab === 'materials' && styles.tabButtonTextActive]}>
              {t.workflowTabMaterialsList || 'Materials list'}
            </Text>
          </Pressable>

          <Pressable
            style={[styles.tabButton, activeTab === 'labour' && styles.tabButtonActive]}
            onPress={() => setActiveTab('labour')}
          >
            <Text style={{ fontSize: 13 }}>👷</Text>
            <Text style={[styles.tabButtonText, activeTab === 'labour' && styles.tabButtonTextActive]}>
              {t.workflowTabLabourBill || 'Labour bill'}
            </Text>
          </Pressable>
        </View>

        <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.scrollContent}>
          {activeTab === 'materials' ? (
            /* =================== TAB 1: MATERIALS LIST =================== */
            <View>
              {/* Document Preview Card */}
              <View style={styles.docCard}>
                <View style={styles.docCardHeader}>
                  <Text style={styles.docCardTitle}>🛒 {t.workflowMaterialsToPurchase || 'Materials to purchase'}</Text>
                  <Text style={styles.docCardSub}>{customer?.name || 'Customer'} • {service.toUpperCase()}</Text>
                </View>

                {/* Work areas summary chip */}
                <View style={styles.workAreasBanner}>
                  <Text style={styles.workAreasLabel}>📍 {t.agreeWhereUsedLabel || 'Work areas'}:</Text>
                  <Text style={styles.workAreasValue}>{workAreasText}</Text>
                </View>

                {/* Items List */}
                <View style={styles.docTable}>
                  {materials.map((it, idx) => (
                    <View key={it.id || idx} style={styles.docRow}>
                      <View style={styles.docRowThumb}>
                        {it.imageUri ? (
                          <Image source={{ uri: it.imageUri }} style={{ width: 32, height: 32, borderRadius: 6 }} resizeMode="cover" />
                        ) : (
                          <I name="cube-outline" size={18} color="#64748B" />
                        )}
                      </View>
                      <View style={{ flex: 1, paddingHorizontal: 8 }}>
                        <Text style={styles.docRowName}>{it.name}</Text>
                        {!!it.specs && <Text style={styles.docRowSpecs}>{it.specs}</Text>}
                      </View>
                      <View style={{ alignItems: 'flex-end' }}>
                        <Text style={styles.docRowQty}>{it.qty} <Text style={{ fontSize: 10, color: '#64748B' }}>{it.unit || 'pcs'}</Text></Text>
                        {initialShowPrices && Number(it.rate || 0) > 0 && (
                          <Text style={styles.docRowPrice}>{money(Number(it.qty || 1) * Number(it.rate || 0))}</Text>
                        )}
                      </View>
                    </View>
                  ))}
                </View>
              </View>

              {/* ⚠️ Confirm Specifications Notice */}
              <View style={styles.alertNotice}>
                <View style={{ flex: 1 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                    <Text style={{ fontSize: 14 }}>⚠️</Text>
                    <Text style={styles.alertTitle}>{t.workflowConfirmSpecs || 'Confirm specifications'}</Text>
                  </View>
                  <Text style={styles.alertDesc}>
                    {t.workflowConfirmSpecsDesc || 'Check wire gauges, brands, and switch models before purchasing'}
                  </Text>
                </View>
                <Pressable onPress={onEditMaterials} style={styles.alertEditBtn}>
                  <Text style={styles.alertEditText}>{t.workflowEdit || 'Edit'}</Text>
                </Pressable>
              </View>

              {/* Brand / Shop Instructions Box */}
              <View style={styles.instructionsCard}>
                <Text style={styles.instructionsLabel}>🏪 {t.workflowBrandShopInstructions || 'Brand / shop instructions (optional)'}</Text>
                <TextInput
                  style={styles.instructionsInput}
                  multiline
                  numberOfLines={3}
                  placeholder={t.workflowShopInstructionsPlaceholder || 'e.g. Buy from Sri Venkateswara Electricals, Main Road'}
                  placeholderTextColor="#94A3B8"
                  value={instructions}
                  onChangeText={setInstructions}
                />
              </View>

              {/* Options: PDF Language & Speech Read-Aloud */}
              <View style={styles.optionsCard}>
                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
                  <Text style={styles.optionsLabel}>{t.workflowPdfLanguage || 'PDF Language'}</Text>
                  <View style={{ flexDirection: 'row', gap: 6 }}>
                    {[
                      { id: 'en', label: 'English' },
                      { id: 'te', label: 'తెలుగు' },
                      { id: 'hi', label: 'हिन्दी' }
                    ].map(l => (
                      <Pressable
                        key={l.id}
                        onPress={() => setDocLanguage(l.id)}
                        style={[styles.langChip, docLanguage === l.id && styles.langChipSelected]}
                      >
                        <Text style={[styles.langChipText, docLanguage === l.id && styles.langChipTextSelected]}>
                          {l.label}
                        </Text>
                      </Pressable>
                    ))}
                  </View>
                </View>

                {/* Listen to List Audio Trigger */}
                <Pressable
                  onPress={handleListenToList}
                  style={[styles.listenBtn, isSpeaking && styles.listenBtnSpeaking]}
                >
                  <I name={isSpeaking ? 'pause-circle' : 'volume-high-outline'} size={18} color="#854D0E" />
                  <Text style={styles.listenBtnText}>
                    {isSpeaking
                      ? (appLang === 'te' ? 'ఆడియో ప్లే అవుతోంది… ఆపండి' : appLang === 'hi' ? 'ऑडियो चल रहा है… रोकें' : 'Playing audio… Tap to stop')
                      : (t.workflowListenToList || 'Listen to list')}
                  </Text>
                </Pressable>
              </View>

              {/* WhatsApp direct shortcut */}
              <Pressable onPress={handleShareWhatsApp} style={styles.whatsappShortcutBtn}>
                <I name="logo-whatsapp" size={18} color="#FFFFFF" />
                <Text style={styles.whatsappShortcutText}>Share list on WhatsApp</Text>
              </Pressable>
            </View>
          ) : (
            /* =================== TAB 2: LABOUR BILL =================== */
            <View>
              {/* Billing Basis Selector */}
              <View style={styles.basisCard}>
                <Text style={styles.basisCardTitle}>⚙️ {t.workflowLabourBillingBasis || 'Billing Basis'}</Text>
                <View style={{ gap: 8, marginTop: 8 }}>
                  {[
                    { id: 'per_point', label: t.workflowBasisPerPoint || 'Per point', desc: `${totalPoints} points recorded` },
                    { id: 'per_length', label: t.workflowBasisPerLength || 'Per length / route', desc: `${totalCableLength} m cable recorded` },
                    { id: 'room_lump', label: t.workflowBasisRoomLumpSum || 'Room lump sum', desc: `${(rooms || []).length} rooms` },
                    { id: 'project_lump', label: t.workflowBasisProjectLumpSum || 'Total project lump sum', desc: 'Single fixed contract' }
                  ].map(b => (
                    <Pressable
                      key={b.id}
                      onPress={() => setBillingBasis(b.id)}
                      style={[styles.basisOption, billingBasis === b.id && styles.basisOptionSelected]}
                    >
                      <View style={[styles.radioCircle, billingBasis === b.id && styles.radioCircleActive]}>
                        {billingBasis === b.id && <View style={styles.radioDot} />}
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={styles.basisOptionLabel}>{b.label}</Text>
                        <Text style={styles.basisOptionDesc}>{b.desc}</Text>
                      </View>
                    </Pressable>
                  ))}
                </View>
              </View>

              {/* Basis Rate Configuration Inputs */}
              <View style={styles.rateConfigCard}>
                {billingBasis === 'per_point' && (
                  <View style={styles.rateRow}>
                    <Text style={styles.rateLabel}>Rate per point (₹):</Text>
                    <TextInput
                      style={styles.rateInput}
                      keyboardType="decimal-pad"
                      value={ratePerPoint}
                      onChangeText={setRatePerPoint}
                    />
                  </View>
                )}

                {billingBasis === 'per_length' && (
                  <View style={styles.rateRow}>
                    <Text style={styles.rateLabel}>Rate per meter (₹):</Text>
                    <TextInput
                      style={styles.rateInput}
                      keyboardType="decimal-pad"
                      value={ratePerMeter}
                      onChangeText={setRatePerMeter}
                    />
                  </View>
                )}

                {billingBasis === 'project_lump' && (
                  <View style={styles.rateRow}>
                    <Text style={styles.rateLabel}>Project lump sum amount (₹):</Text>
                    <TextInput
                      style={styles.rateInput}
                      keyboardType="decimal-pad"
                      value={projectLumpSum}
                      onChangeText={setProjectLumpSum}
                    />
                  </View>
                )}
              </View>

              {/* Labour Calculation Summary Card */}
              <View style={styles.labourSummaryCard}>
                <Text style={styles.labourSummaryTitle}>👷 Labour Summary</Text>
                {labourCalculations.items.map((it, idx) => (
                  <View key={idx} style={styles.labourSummaryRow}>
                    <Text style={styles.labourItemName}>{it.name}</Text>
                    <Text style={styles.labourItemAmount}>{money(it.amount)}</Text>
                  </View>
                ))}
                <View style={styles.labourTotalRow}>
                  <Text style={styles.labourTotalLabel}>Total Labour Charges:</Text>
                  <Text style={styles.labourTotalAmount}>{money(labourCalculations.grandTotal)}</Text>
                </View>
              </View>

              {/* Create TileBill Document Button */}
              <Pressable
                onPress={() => handleCreateLabourDocument('invoice')}
                style={styles.createDocBtn}
              >
                <I name="receipt-outline" size={18} color="#0F172A" />
                <Text style={styles.createDocBtnText}>{t.workflowCreateDocBtn || 'Create Bill / Quotation'}</Text>
              </Pressable>
            </View>
          )}

          <View style={{ height: 90 }} />
        </ScrollView>

        {/* 3. FOOTER ACTIONS */}
        <View style={styles.footerBar}>
          <Pressable style={styles.editBtn} onPress={onEditMaterials}>
            <I name="pencil-outline" size={16} color="#0F172A" />
            <Text style={styles.editBtnText}>{t.workflowEditMaterials || 'Edit materials'}</Text>
          </Pressable>

          <Pressable style={styles.previewBtn} onPress={handlePreviewShare}>
            <Text style={styles.previewBtnText}>{t.workflowPreviewShare || 'Preview & share ➔'}</Text>
          </Pressable>
        </View>

        {/* HTML PREVIEW / PRINT MODAL */}
        <Modal visible={htmlPreviewVisible} animationType="slide" onRequestClose={() => setHtmlPreviewVisible(false)}>
          <View style={{ flex: 1, backgroundColor: '#FFFFFF' }}>
            <View style={styles.previewModalTopBar}>
              <Pressable onPress={() => setHtmlPreviewVisible(false)} style={{ padding: 6 }}>
                <I name="close" size={22} color="#0F172A" />
              </Pressable>
              <Text style={{ fontSize: 16, fontWeight: '800', color: '#0F172A' }}>Document Preview</Text>
              <Pressable
                onPress={() => {
                  if (Platform.OS === 'web' && typeof window !== 'undefined') {
                    const printWindow = window.open('', '_blank');
                    if (printWindow) {
                      printWindow.document.write(htmlContent);
                      printWindow.document.close();
                      printWindow.focus();
                      setTimeout(() => printWindow.print(), 250);
                    }
                  }
                }}
                style={styles.printBtn}
              >
                <I name="print-outline" size={18} color="#0F172A" />
                <Text style={{ fontSize: 12, fontWeight: '700', color: '#0F172A' }}>Print / PDF</Text>
              </Pressable>
            </View>

            {Platform.OS === 'web' ? (
              <iframe
                srcDoc={htmlContent}
                style={{ flex: 1, width: '100%', height: '100%', border: 'none' }}
                title="Material List Document"
              />
            ) : (
              <ScrollView style={{ flex: 1, padding: 16 }}>
                <Text style={{ fontSize: 13, color: '#64748B' }}>Document generated. Tap Print / PDF above to save.</Text>
              </ScrollView>
            )}
          </View>
        </Modal>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FCF9F6'
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9'
  },
  backBtn: {
    padding: 6,
    borderRadius: 8
  },
  topBarTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: '#0F172A'
  },
  tabsContainer: {
    flexDirection: 'row',
    padding: 8,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
    gap: 8
  },
  tabButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 9,
    borderRadius: 12,
    backgroundColor: '#F8FAFC'
  },
  tabButtonActive: {
    backgroundColor: '#FEF08A'
  },
  tabButtonText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#64748B'
  },
  tabButtonTextActive: {
    color: '#854D0E',
    fontWeight: '900'
  },
  scrollContent: {
    padding: 14
  },
  docCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    padding: 14,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 6,
    elevation: 2
  },
  docCardHeader: {
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
    paddingBottom: 8,
    marginBottom: 10
  },
  docCardTitle: {
    fontSize: 15,
    fontWeight: '900',
    color: '#0F172A'
  },
  docCardSub: {
    fontSize: 11.5,
    color: '#64748B',
    marginTop: 2
  },
  workAreasBanner: {
    backgroundColor: '#FEF9E7',
    borderWidth: 1,
    borderColor: '#FEF08A',
    borderRadius: 8,
    padding: 8,
    marginBottom: 12
  },
  workAreasLabel: {
    fontSize: 10.5,
    fontWeight: '700',
    color: '#854D0E',
    textTransform: 'uppercase'
  },
  workAreasValue: {
    fontSize: 12,
    fontWeight: '700',
    color: '#0F172A',
    marginTop: 2
  },
  docTable: {
    gap: 8
  },
  docRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
    borderBottomWidth: 1,
    borderBottomColor: '#F8FAFC'
  },
  docRowThumb: {
    width: 32,
    height: 32,
    borderRadius: 6,
    backgroundColor: '#F1F5F9',
    alignItems: 'center',
    justifyContent: 'center'
  },
  docRowName: {
    fontSize: 12.5,
    fontWeight: '700',
    color: '#0F172A'
  },
  docRowSpecs: {
    fontSize: 10.5,
    color: '#64748B'
  },
  docRowQty: {
    fontSize: 13,
    fontWeight: '800',
    color: '#0F172A'
  },
  docRowPrice: {
    fontSize: 11,
    fontWeight: '600',
    color: '#64748B',
    marginTop: 1
  },
  alertNotice: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#FEF2F2',
    borderWidth: 1,
    borderColor: '#FECACA',
    borderRadius: 14,
    padding: 12,
    marginBottom: 12
  },
  alertTitle: {
    fontSize: 12.5,
    fontWeight: '800',
    color: '#991B1B'
  },
  alertDesc: {
    fontSize: 11,
    color: '#B91C1C',
    marginTop: 2
  },
  alertEditBtn: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#FCA5A5',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8
  },
  alertEditText: {
    fontSize: 11.5,
    fontWeight: '800',
    color: '#991B1B'
  },
  instructionsCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    padding: 12,
    marginBottom: 12
  },
  instructionsLabel: {
    fontSize: 12,
    fontWeight: '700',
    color: '#0F172A',
    marginBottom: 6
  },
  instructionsInput: {
    backgroundColor: '#F8FAFC',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    padding: 8,
    fontSize: 12.5,
    color: '#0F172A',
    minHeight: 54
  },
  optionsCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    padding: 12,
    marginBottom: 12
  },
  optionsLabel: {
    fontSize: 12,
    fontWeight: '700',
    color: '#0F172A'
  },
  langChip: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: '#F1F5F9',
    borderWidth: 1,
    borderColor: '#E2E8F0'
  },
  langChipSelected: {
    backgroundColor: '#FEF08A',
    borderColor: '#EAB308'
  },
  langChipText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#475569'
  },
  langChipTextSelected: {
    color: '#854D0E',
    fontWeight: '800'
  },
  listenBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: '#FEF9E7',
    borderWidth: 1,
    borderColor: '#FEF08A',
    borderRadius: 10,
    paddingVertical: 9
  },
  listenBtnSpeaking: {
    backgroundColor: '#FDE047'
  },
  listenBtnText: {
    fontSize: 12.5,
    fontWeight: '800',
    color: '#854D0E'
  },
  whatsappShortcutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#25D366',
    borderRadius: 12,
    paddingVertical: 11,
    marginBottom: 12
  },
  whatsappShortcutText: {
    fontSize: 13,
    fontWeight: '800',
    color: '#FFFFFF'
  },
  basisCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    padding: 12,
    marginBottom: 12
  },
  basisCardTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: '#0F172A'
  },
  basisOption: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: '#F8FAFC',
    borderRadius: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: '#E2E8F0'
  },
  basisOptionSelected: {
    backgroundColor: '#FEF9E7',
    borderColor: '#FACC15'
  },
  radioCircle: {
    width: 18,
    height: 18,
    borderRadius: 9,
    borderWidth: 1.5,
    borderColor: '#94A3B8',
    alignItems: 'center',
    justifyContent: 'center'
  },
  radioCircleActive: {
    borderColor: '#CA8A04'
  },
  radioDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#CA8A04'
  },
  basisOptionLabel: {
    fontSize: 12.5,
    fontWeight: '700',
    color: '#0F172A'
  },
  basisOptionDesc: {
    fontSize: 11,
    color: '#64748B'
  },
  rateConfigCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    padding: 12,
    marginBottom: 12
  },
  rateRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10
  },
  rateLabel: {
    fontSize: 12.5,
    fontWeight: '700',
    color: '#0F172A'
  },
  rateInput: {
    width: 90,
    backgroundColor: '#F8FAFC',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#CBD5E1',
    paddingHorizontal: 8,
    paddingVertical: 6,
    fontSize: 14,
    fontWeight: '800',
    color: '#0F172A',
    textAlign: 'right'
  },
  labourSummaryCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    padding: 12,
    marginBottom: 12
  },
  labourSummaryTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: '#0F172A',
    marginBottom: 8
  },
  labourSummaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 4
  },
  labourItemName: {
    fontSize: 12,
    color: '#475569'
  },
  labourItemAmount: {
    fontSize: 12.5,
    fontWeight: '700',
    color: '#0F172A'
  },
  labourTotalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: '#F1F5F9',
    paddingTop: 8,
    marginTop: 6
  },
  labourTotalLabel: {
    fontSize: 13,
    fontWeight: '800',
    color: '#0F172A'
  },
  labourTotalAmount: {
    fontSize: 16,
    fontWeight: '900',
    color: '#0F172A'
  },
  createDocBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#FFD500',
    borderRadius: 12,
    paddingVertical: 12
  },
  createDocBtnText: {
    fontSize: 13.5,
    fontWeight: '900',
    color: '#0F172A'
  },
  footerBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#E2E8F0',
    paddingHorizontal: 16,
    paddingVertical: 10,
    flexDirection: 'row',
    gap: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 8
  },
  editBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#CBD5E1',
    paddingVertical: 11
  },
  editBtnText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#0F172A'
  },
  previewBtn: {
    flex: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFD500',
    borderRadius: 12,
    paddingVertical: 11
  },
  previewBtnText: {
    fontSize: 13.5,
    fontWeight: '900',
    color: '#0F172A'
  },
  previewModalTopBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0'
  },
  printBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#FEF08A',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 6
  }
});
