import React, { useState, useEffect } from 'react';
import {
  View,
  Text as T,
  TextInput,
  Pressable,
  Modal,
  ScrollView,
  ActivityIndicator,
  Platform
} from 'react-native';
import { Ionicons as I } from '@expo/vector-icons';
import { getApiUrl, setApiUrl, testApiConnection } from './api';

export default function ServerSettingsModal({
  visible = true,
  onClose,
  onSaved,
  appLang = 'te'
}) {
  const [urlInput, setUrlInput] = useState('');
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null); // { ok: bool, msg: string }
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (visible) {
      setUrlInput(getApiUrl());
      setTestResult(null);
    }
  }, [visible]);

  const labels = {
    en: {
      title: 'Admin: Server Configuration',
      subtitle: 'Configure the backend server endpoint. Restricted to administrative and diagnostic use.',
      urlLabel: 'Backend Server URL',
      testBtn: 'Test Connection',
      saveBtn: 'Save & Apply',
      cancelBtn: 'Close',
      resetDefault: 'Reset to Cloud Default',
      cloudGuideTitle: 'Cloud Deployment Guide',
      cloudGuideDesc: 'To use the app 24/7 on mobile data without your computer turned on, deploy the included Dockerfile or render.yaml to Render or Railway.',
      successMsg: 'Connected successfully! (Server ready)'
    },
    te: {
      title: 'అడ్మిన్: సర్వర్ కాన్ఫిగరేషన్',
      subtitle: 'బ్యాకెండ్ సర్వర్ ఎండ్‌పాయింట్ కాన్ఫిగర్ చేయండి. అడ్మిన్ లేదా డెవలపర్ అవసరాలకు మాత్రమే.',
      urlLabel: 'బ్యాకెండ్ సర్వర్ URL',
      testBtn: 'కనెక్షన్ పరీక్షించండి (Test)',
      saveBtn: 'సేవ్ చేసి వర్తింపజేయండి',
      cancelBtn: 'మూసివేయి',
      resetDefault: 'డిఫాల్ట్ సర్వర్‌కు రీసెట్ చేయండి',
      cloudGuideTitle: 'క్లౌడ్ సర్వర్ సెటప్',
      cloudGuideDesc: 'కంప్యూటర్ లేకుండా ఎల్లప్పుడూ 24/7 మొబైల్ డేటాలో వాడటానికి, render.yaml లేదా Dockerfile ఉపయోగించి Render లేదా Railway లో హోస్ట్ చేసుకోవచ్చు.',
      successMsg: 'సర్వర్‌తో విజయవంతంగా కనెక్ట్ అయ్యింది! (Server Ready)'
    },
    hi: {
      title: 'व्यवस्थापक: सर्वर कॉन्फ़िगरेशन',
      subtitle: 'बैकएंड सर्वर एंडपॉइंट कॉन्फ़िगर करें। केवल प्रशासनिक उपयोग के लिए।',
      urlLabel: 'बैकएंड सर्वर URL',
      testBtn: 'कनेक्शन जांचें (Test)',
      saveBtn: 'सहेजें और लागू करें',
      cancelBtn: 'बंद करें',
      resetDefault: 'डिफ़ॉल्ट पर रीसेट करें',
      cloudGuideTitle: 'क्लाउड सर्वर गाइड',
      cloudGuideDesc: 'कंप्यूटर के बिना 24/7 मोबाइल डेटा पर उपयोग करने के लिए, render.yaml या Dockerfile को Render या Railway पर तैनात करें।',
      successMsg: 'सर्वर से सफलतापूर्वक जुड़ गया! (Server Ready)'
    }
  }[appLang] || {
    title: 'Admin: Server Configuration',
    subtitle: 'Configure the backend server URL.',
    urlLabel: 'Backend Server URL',
    testBtn: 'Test Connection',
    saveBtn: 'Save & Apply',
    cancelBtn: 'Close',
    resetDefault: 'Reset to Cloud Default',
    cloudGuideTitle: 'Cloud Deployment Guide',
    cloudGuideDesc: 'Deploy to Render or Railway.',
    successMsg: 'Connected successfully!'
  };

  const handleTest = async () => {
    if (!urlInput.trim()) {
      setTestResult({ ok: false, msg: 'Please enter a URL' });
      return;
    }
    setTesting(true);
    setTestResult(null);
    try {
      const res = await testApiConnection(urlInput.trim());
      if (res.ok) {
        setTestResult({ ok: true, msg: labels.successMsg });
      } else {
        setTestResult({ ok: false, msg: res.error || 'Connection failed' });
      }
    } catch (e) {
      setTestResult({ ok: false, msg: e.message || 'Connection failed' });
    } finally {
      setTesting(false);
    }
  };

  const handleSave = async () => {
    const clean = urlInput.trim().replace(/\/+$/, '');
    if (!clean) return;
    setSaving(true);
    try {
      await setApiUrl(clean);
      if (onSaved) onSaved(clean);
      if (onClose) onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: 'rgba(15,23,42,0.7)', justifyContent: 'center', padding: 16 }}>
        <View style={{ backgroundColor: '#FFFFFF', borderRadius: 16, maxHeight: '90%', overflow: 'hidden', elevation: 24 }}>
          {/* Header */}
          <View style={{ backgroundColor: '#0F172A', paddingHorizontal: 18, paddingVertical: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 }}>
              <View style={{ width: 34, height: 34, borderRadius: 8, backgroundColor: '#1E293B', alignItems: 'center', justifyContent: 'center' }}>
                <I name="server-outline" size={18} color="#FFD500" />
              </View>
              <T style={{ fontSize: 16, fontWeight: '800', color: '#FFFFFF', flex: 1 }}>
                {labels.title}
              </T>
            </View>
            <Pressable onPress={onClose} style={{ padding: 6 }}>
              <I name="close" size={22} color="#94A3B8" />
            </Pressable>
          </View>

          <ScrollView contentContainerStyle={{ padding: 18 }}>
            <T style={{ fontSize: 13, color: '#64748B', lineHeight: 19, marginBottom: 16 }}>
              {labels.subtitle}
            </T>

            {/* URL Input */}
            <T style={{ fontSize: 12.5, fontWeight: '700', color: '#334155', marginBottom: 6 }}>
              {labels.urlLabel}
            </T>
            <TextInput
              value={urlInput}
              onChangeText={setUrlInput}
              placeholder="https://your-backend-service.com"
              placeholderTextColor="#94A3B8"
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="url"
              style={{
                backgroundColor: '#F8FAFC',
                borderWidth: 1.5,
                borderColor: '#CBD5E1',
                borderRadius: 10,
                paddingHorizontal: 12,
                paddingVertical: 10,
                fontSize: 14,
                color: '#0F172A',
                marginBottom: 10
              }}
            />

            {/* Quick Action */}
            <View style={{ flexDirection: 'row', gap: 8, marginBottom: 16, flexWrap: 'wrap' }}>
              <Pressable
                onPress={() => setUrlInput(process.env.EXPO_PUBLIC_API_URL || '')}
                style={{ backgroundColor: '#F1F5F9', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 6, borderWidth: 1, borderColor: '#E2E8F0' }}
              >
                <T style={{ fontSize: 11.5, color: '#475569', fontWeight: '600' }}>
                  {labels.resetDefault}
                </T>
              </Pressable>
            </View>

            {/* Test Connection Button */}
            <Pressable
              onPress={handleTest}
              disabled={testing}
              style={({ pressed }) => [{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 8,
                backgroundColor: '#F8FAFC',
                borderWidth: 1.5,
                borderColor: '#0284C7',
                paddingVertical: 11,
                borderRadius: 10,
                opacity: (pressed || testing) ? 0.7 : 1,
                marginBottom: 12
              }]}
            >
              {testing ? (
                <ActivityIndicator size="small" color="#0284C7" />
              ) : (
                <I name="pulse-outline" size={17} color="#0284C7" />
              )}
              <T style={{ fontSize: 13.5, fontWeight: '700', color: '#0284C7' }}>
                {labels.testBtn}
              </T>
            </Pressable>

            {/* Test Result Feedback */}
            {testResult && (
              <View style={{
                padding: 12,
                borderRadius: 8,
                marginBottom: 16,
                backgroundColor: testResult.ok ? '#F0FDF4' : '#FEF2F2',
                borderWidth: 1,
                borderColor: testResult.ok ? '#86EFAC' : '#FCA5A5'
              }}>
                <T style={{
                  fontSize: 12.5,
                  fontWeight: '600',
                  color: testResult.ok ? '#15803D' : '#B91C1C',
                  lineHeight: 18
                }}>
                  {testResult.ok ? '✅ ' : '❌ '}{testResult.msg}
                </T>
              </View>
            )}

            {/* Cloud Deployment Info Card */}
            <View style={{ backgroundColor: '#FFFBEB', borderWidth: 1, borderColor: '#FDE68A', borderRadius: 10, padding: 12, marginBottom: 16 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                <I name="cloud-upload-outline" size={16} color="#B45309" />
                <T style={{ fontSize: 12.5, fontWeight: '800', color: '#92400E' }}>
                  {labels.cloudGuideTitle}
                </T>
              </View>
              <T style={{ fontSize: 11.5, color: '#78350F', lineHeight: 16 }}>
                {labels.cloudGuideDesc}
              </T>
            </View>

            {/* Action Buttons */}
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <Pressable
                onPress={onClose}
                style={{ flex: 1, paddingVertical: 12, borderRadius: 10, borderWidth: 1.5, borderColor: '#CBD5E1', alignItems: 'center' }}
              >
                <T style={{ fontSize: 13.5, fontWeight: '700', color: '#475569' }}>
                  {labels.cancelBtn}
                </T>
              </Pressable>
              <Pressable
                onPress={handleSave}
                disabled={saving}
                style={({ pressed }) => [{
                  flex: 1.6,
                  backgroundColor: '#0F172A',
                  paddingVertical: 12,
                  borderRadius: 10,
                  alignItems: 'center',
                  opacity: (pressed || saving) ? 0.8 : 1
                }]}
              >
                {saving ? (
                  <ActivityIndicator size="small" color="#FFFFFF" />
                ) : (
                  <T style={{ fontSize: 13.5, fontWeight: '800', color: '#FFD500' }}>
                    {labels.saveBtn}
                  </T>
                )}
              </Pressable>
            </View>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}
