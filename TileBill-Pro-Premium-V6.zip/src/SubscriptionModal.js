import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  Image,
  Pressable,
  ScrollView,
  Animated,
  Easing,
  Modal,
  Platform,
  Dimensions,
  ActivityIndicator
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getStrings } from './i18n';

const brandLogo = require('../assets/brand-logo.png');
const crownReceiptImg = require('../assets/sub-crown-receipt.png');
const calendarClockImg = require('../assets/sub-calendar-clock.png');
const referralGiftImg = require('../assets/sub-referral-gift.png');

export default function SubscriptionModal({
  visible,
  onClose,
  user,
  api,
  adopt,
  notify,
  appLang = 'te'
}) {
  const [mounted, setMounted] = useState(visible);
  const [working, setWorking] = useState(false);
  const animValue = useRef(new Animated.Value(0)).current;
  const str = getStrings(appLang);

  useEffect(() => {
    if (visible) {
      setMounted(true);
      Animated.timing(animValue, {
        toValue: 1,
        duration: 310,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: Platform.OS !== 'web'
      }).start();
    } else if (mounted) {
      Animated.timing(animValue, {
        toValue: 0,
        duration: 200,
        easing: Easing.in(Easing.cubic),
        useNativeDriver: Platform.OS !== 'web'
      }).start(() => {
        setMounted(false);
      });
    }
  }, [visible]);

  const handleClose = () => {
    Animated.timing(animValue, {
      toValue: 0,
      duration: 200,
      easing: Easing.in(Easing.cubic),
      useNativeDriver: Platform.OS !== 'web'
    }).start(() => {
      setMounted(false);
      onClose && onClose();
    });
  };

  if (!mounted && !visible) return null;

  const isPaid = user?.access?.type === 'test-paid' || user?.access?.type === 'paid' || user?.access?.type === 'free' || user?.role === 'admin';
  const isTrialActive = user?.access?.type === 'trial' && user?.active;
  const trialUsed = !!user?.trialUsed;

  // Calculate days left in trial if active
  let trialDaysLeft = 3;
  if (isTrialActive && user?.access?.expiresAt) {
    const diffMs = new Date(user.access.expiresAt) - new Date();
    trialDaysLeft = Math.max(1, Math.ceil(diffMs / 86400000));
  }

  // Handle 3-day free trial start
  const handleStartTrial = async () => {
    if (isPaid || isTrialActive || trialUsed || working) return;
    setWorking(true);
    try {
      const res = await api('/billing/trial', {});
      if (res?.user) {
        adopt && adopt(res);
        notify && notify(
          appLang === 'te' ? '3 రోజుల ఉచిత ట్రయల్ ప్రారంభమైంది! పూర్తి యాక్సెస్ లభించింది.' :
          appLang === 'hi' ? '3 दिन का मुफ्त ट्रायल शुरू हो गया! पूर्ण एक्सेस उपलब्ध है।' :
          '3-day free trial activated! Full access unlocked.'
        );
        handleClose();
      }
    } catch (e) {
      notify && notify(e.message, true);
    } finally {
      setWorking(false);
    }
  };

  // Handle Annual Plan purchase (₹1,000)
  const handlePurchase = async () => {
    if (working) return;
    setWorking(true);
    try {
      const key = 'pay-' + Date.now() + '-' + Math.random().toString(36).slice(2);
      const res = await api('/billing/pay', {
        key,
        result: 'success'
      });
      if (res?.user) {
        adopt && adopt(res);
        notify && notify(
          appLang === 'te' ? 'వార్షిక ప్రీమియం ప్లాన్ విజయవంతంగా సక్రియం చేయబడింది!' :
          appLang === 'hi' ? 'वार्षिक प्रीमियम प्लान सफलतापूर्वक सक्रिय हो गया!' :
          'Annual Premium plan activated for 365 days!'
        );
        handleClose();
      } else {
        notify && notify(res?.message || 'Payment simulation failed', true);
      }
    } catch (e) {
      notify && notify(e.message, true);
    } finally {
      setWorking(false);
    }
  };

  // Determine secondary trial button label and state
  let trialBtnLabel = str.subStartTrialBtn;
  let trialBtnDisabled = false;
  if (isPaid) {
    trialBtnLabel = str.subPlanActiveBtn;
    trialBtnDisabled = true;
  } else if (isTrialActive) {
    trialBtnLabel = str.subTrialDaysLeft ? str.subTrialDaysLeft.replace('{days}', trialDaysLeft) : `${str.subTrialActiveBtn} (${trialDaysLeft}d)`;
    trialBtnDisabled = true;
  } else if (trialUsed) {
    trialBtnLabel = str.subTrialExpiredBtn;
    trialBtnDisabled = true;
  }

  const screenHeight = Dimensions.get('window').height;
  const translateY = animValue.interpolate({
    inputRange: [0, 1],
    outputRange: [650, 0]
  });
  const backdropOpacity = animValue.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 0.52]
  });

  return (
    <Modal
      transparent
      visible={mounted}
      animationType="none"
      onRequestClose={handleClose}
      statusBarTranslucent
    >
      <View style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: 'transparent' }}>
        {/* Dimmed backdrop */}
        <Animated.View
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: '#000000',
            opacity: backdropOpacity
          }}
        >
          <Pressable style={{ flex: 1 }} onPress={handleClose} />
        </Animated.View>

        {/* Bottom Sheet */}
        <Animated.View
          style={{
            transform: [{ translateY }],
            backgroundColor: '#FAF9F6',
            borderTopLeftRadius: 30,
            borderTopRightRadius: 30,
            width: '100%',
            maxWidth: Platform.OS === 'web' ? 490 : '100%',
            alignSelf: 'center',
            maxHeight: screenHeight * 0.92,
            shadowColor: '#000',
            shadowOffset: { width: 0, height: -4 },
            shadowOpacity: 0.18,
            shadowRadius: 16,
            elevation: 24,
            overflow: 'hidden'
          }}
        >
          {/* Centered Drag Handle */}
          <View style={{ alignItems: 'center', paddingTop: 10, paddingBottom: 6 }}>
            <View
              style={{
                width: 38,
                height: 4.5,
                borderRadius: 2.5,
                backgroundColor: '#D1D5DB'
              }}
            />
          </View>

          {/* Top Header Bar: Brand Logo & Close Button */}
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              paddingHorizontal: 20,
              paddingTop: 4,
              paddingBottom: 10
            }}
          >
            <Image
              source={brandLogo}
              style={{ width: 136, height: 36 }}
              resizeMode="contain"
            />
            <Pressable
              onPress={handleClose}
              hitSlop={12}
              style={{
                width: 32,
                height: 32,
                borderRadius: 16,
                backgroundColor: '#EDECE8',
                alignItems: 'center',
                justifyContent: 'center',
                borderWidth: 1,
                borderColor: '#E2E0D9'
              }}
            >
              <Ionicons name="close" size={18} color="#27272A" />
            </Pressable>
          </View>

          <ScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{
              paddingHorizontal: 20,
              paddingBottom: Platform.OS === 'ios' ? 36 : 24
            }}
          >
            {/* Hero Heading Row with 3D Crown & Receipt illustration */}
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: 16,
                marginTop: 2
              }}
            >
              <View style={{ flex: 1, paddingRight: 10 }}>
                <Text
                  style={{
                    fontSize: 24,
                    fontWeight: '800',
                    color: '#171817',
                    letterSpacing: -0.4,
                    lineHeight: 33
                  }}
                >
                  {str.subHeading}
                </Text>
              </View>
              <Image
                source={crownReceiptImg}
                style={{ width: 70, height: 70 }}
                resizeMode="contain"
              />
            </View>

            {/* CARD 1: Dark Annual Plan Card */}
            <View
              style={{
                backgroundColor: '#18181B',
                borderRadius: 20,
                padding: 18,
                marginBottom: 12,
                borderWidth: 1,
                borderColor: '#27272A',
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 4 },
                shadowOpacity: 0.12,
                shadowRadius: 8,
                elevation: 4
              }}
            >
              {/* Badge */}
              <View
                style={{
                  backgroundColor: '#FFD500',
                  paddingHorizontal: 10,
                  paddingVertical: 3.5,
                  borderRadius: 12,
                  alignSelf: 'flex-start',
                  marginBottom: 10
                }}
              >
                <Text
                  style={{
                    color: '#171817',
                    fontWeight: '700',
                    fontSize: 11.5,
                    letterSpacing: 0.2
                  }}
                >
                  {str.subBadgeAnnual}
                </Text>
              </View>

              {/* Price & Duration */}
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'baseline',
                  marginBottom: 4
                }}
              >
                <Text
                  style={{
                    fontSize: 32,
                    fontWeight: '900',
                    color: '#FFFFFF',
                    letterSpacing: -0.6
                  }}
                >
                  ₹1,000
                </Text>
                <Text
                  style={{
                    fontSize: 14,
                    fontWeight: '500',
                    color: '#A1A1AA',
                    marginLeft: 6
                  }}
                >
                  {appLang === 'te' ? '/ సంవత్సరం' : appLang === 'hi' ? '/ वर्ष' : '/ year'}
                </Text>
              </View>

              <Text
                style={{
                  fontSize: 12.5,
                  color: '#9CA3AF',
                  marginBottom: 14
                }}
              >
                {str.subDurationYear}
              </Text>

              {/* Divider */}
              <View
                style={{
                  height: 1,
                  backgroundColor: '#27272A',
                  marginBottom: 12
                }}
              />

              {/* 2x2 Benefits Grid */}
              <View
                style={{
                  flexDirection: 'row',
                  flexWrap: 'wrap',
                  justifyContent: 'space-between',
                  rowGap: 10
                }}
              >
                <View
                  style={{
                    width: '48%',
                    flexDirection: 'row',
                    alignItems: 'center',
                    gap: 6
                  }}
                >
                  <Ionicons name="checkmark-circle" size={17} color="#FFD500" />
                  <Text
                    style={{
                      color: '#E4E4E7',
                      fontSize: 12.5,
                      fontWeight: '500',
                      flexShrink: 1
                    }}
                  >
                    {str.subFeatureServices}
                  </Text>
                </View>

                <View
                  style={{
                    width: '48%',
                    flexDirection: 'row',
                    alignItems: 'center',
                    gap: 6
                  }}
                >
                  <Ionicons name="checkmark-circle" size={17} color="#FFD500" />
                  <Text
                    style={{
                      color: '#E4E4E7',
                      fontSize: 12.5,
                      fontWeight: '500',
                      flexShrink: 1
                    }}
                  >
                    {str.subFeatureUsers}
                  </Text>
                </View>

                <View
                  style={{
                    width: '48%',
                    flexDirection: 'row',
                    alignItems: 'center',
                    gap: 6
                  }}
                >
                  <Ionicons name="checkmark-circle" size={17} color="#FFD500" />
                  <Text
                    style={{
                      color: '#E4E4E7',
                      fontSize: 12.5,
                      fontWeight: '500',
                      flexShrink: 1
                    }}
                  >
                    {str.subFeatureDocs}
                  </Text>
                </View>

                <View
                  style={{
                    width: '48%',
                    flexDirection: 'row',
                    alignItems: 'center',
                    gap: 6
                  }}
                >
                  <Ionicons name="checkmark-circle" size={17} color="#FFD500" />
                  <Text
                    style={{
                      color: '#E4E4E7',
                      fontSize: 12.5,
                      fontWeight: '500',
                      flexShrink: 1
                    }}
                  >
                    {str.subFeatureLanguages}
                  </Text>
                </View>
              </View>
            </View>

            {/* CARD 2: Pale-Yellow 3-Day Free Trial Card */}
            <View
              style={{
                backgroundColor: '#FEF9C3',
                borderColor: '#FDE047',
                borderWidth: 1,
                borderRadius: 18,
                padding: 13,
                marginBottom: 12,
                flexDirection: 'row',
                alignItems: 'center',
                gap: 12,
                shadowColor: '#854D0E',
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.05,
                shadowRadius: 4,
                elevation: 2
              }}
            >
              <Image
                source={calendarClockImg}
                style={{ width: 52, height: 52 }}
                resizeMode="contain"
              />
              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontSize: 15.5,
                    fontWeight: '700',
                    color: '#171817'
                  }}
                >
                  {str.subTrialCardTitle}
                </Text>
                <Text
                  style={{
                    fontSize: 12,
                    color: '#4B5563',
                    lineHeight: 16.5,
                    marginTop: 2
                  }}
                >
                  {str.subTrialCardDesc}
                </Text>
                <Text
                  style={{
                    fontSize: 11,
                    color: '#854D0E',
                    fontWeight: '600',
                    marginTop: 3
                  }}
                >
                  {str.subTrialCardNote}
                </Text>
              </View>
            </View>

            {/* CARD 3: Referral Offer Card */}
            <View
              style={{
                backgroundColor: '#FFFFFF',
                borderColor: '#E5E7EB',
                borderWidth: 1,
                borderRadius: 18,
                padding: 13,
                marginBottom: 18,
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.04,
                shadowRadius: 4,
                elevation: 2
              }}
            >
              {/* Badge */}
              <View
                style={{
                  backgroundColor: '#FEF3C7',
                  paddingHorizontal: 8,
                  paddingVertical: 2.5,
                  borderRadius: 8,
                  alignSelf: 'flex-start',
                  marginBottom: 8
                }}
              >
                <Text
                  style={{
                    color: '#92400E',
                    fontSize: 11,
                    fontWeight: '700'
                  }}
                >
                  {str.subReferralBadge}
                </Text>
              </View>

              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: 12
                }}
              >
                <Image
                  source={referralGiftImg}
                  style={{ width: 50, height: 44 }}
                  resizeMode="contain"
                />
                <View style={{ flex: 1 }}>
                  <Text
                    style={{
                      fontSize: 14.5,
                      fontWeight: '700',
                      color: '#171817'
                    }}
                  >
                    {str.subReferralTitle}
                  </Text>
                  <Text
                    style={{
                      fontSize: 11.5,
                      color: '#4B5563',
                      lineHeight: 16,
                      marginTop: 2
                    }}
                  >
                    {str.subReferralDesc}
                  </Text>
                  <Text
                    style={{
                      fontSize: 10.5,
                      color: '#6B7280',
                      marginTop: 3
                    }}
                  >
                    {str.subReferralNote}
                  </Text>
                </View>
              </View>
            </View>

            {/* BUTTON 1: Primary Yellow Purchase Button */}
            <Pressable
              onPress={handlePurchase}
              disabled={working || isPaid}
              style={({ pressed }) => ({
                backgroundColor: isPaid ? '#E5E7EB' : '#FFD500',
                borderRadius: 14,
                height: 50,
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: 10,
                opacity: (working || pressed) ? 0.88 : 1,
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.08,
                shadowRadius: 4,
                elevation: 2
              })}
            >
              {working ? (
                <ActivityIndicator color="#171817" size="small" />
              ) : (
                <Text
                  style={{
                    fontSize: 15.5,
                    fontWeight: '800',
                    color: isPaid ? '#9CA3AF' : '#171817'
                  }}
                >
                  {str.subPrimaryBtn}
                </Text>
              )}
            </Pressable>

            {/* BUTTON 2: Outlined Free Trial Button */}
            <Pressable
              onPress={handleStartTrial}
              disabled={working || trialBtnDisabled}
              style={({ pressed }) => ({
                backgroundColor: '#FFFFFF',
                borderWidth: 1.5,
                borderColor: trialBtnDisabled ? '#D1D5DB' : '#18181B',
                borderRadius: 14,
                height: 48,
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: 14,
                opacity: (working || pressed) ? 0.85 : 1
              })}
            >
              <Text
                style={{
                  fontSize: 14.5,
                  fontWeight: '700',
                  color: trialBtnDisabled ? '#9CA3AF' : '#18181B'
                }}
              >
                {trialBtnLabel}
              </Text>
            </Pressable>

            {/* Small Secure Payment Footer */}
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 5,
                paddingTop: 2
              }}
            >
              <Text
                style={{
                  fontSize: 12,
                  color: '#6B7280',
                  fontWeight: '500'
                }}
              >
                {str.subSecureFooter}
              </Text>
            </View>
          </ScrollView>
        </Animated.View>
      </View>
    </Modal>
  );
}
