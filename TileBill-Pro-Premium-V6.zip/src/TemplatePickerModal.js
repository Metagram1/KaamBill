import React, { useState } from 'react';
import {
  View,
  Text as T,
  Pressable,
  ScrollView,
  Modal,
  Dimensions,
  Platform
} from 'react-native';
import { Ionicons as I } from '@expo/vector-icons';
import { documentTemplates, resolveTemplate } from './domain.cjs';
import { getStrings } from './i18n';

// Miniature visual previews for the 10 templates matching reference screenshots
function MiniaturePreview({ templateId, selected }) {
  const isSelected = selected;
  
  if (templateId === 'classic_ledger') {
    // Reference 02: Double box ledger, pure clean borders
    return (
      <View style={{ width: '100%', height: 110, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#171817', padding: 4 }}>
        <View style={{ alignItems: 'center', marginBottom: 2 }}>
          <T style={{ fontSize: 6.5, fontWeight: '900', color: '#171817' }}>QUOTATION</T>
        </View>
        <View style={{ flexDirection: 'row', borderWidth: 0.8, borderColor: '#171817', height: 26, marginBottom: 3 }}>
          <View style={{ width: '50%', borderRightWidth: 0.8, borderColor: '#171817', padding: 2 }}>
            <View style={{ width: 30, height: 2.5, backgroundColor: '#171817', marginBottom: 2 }} />
            <View style={{ width: 22, height: 2, backgroundColor: '#94A3B8' }} />
          </View>
          <View style={{ width: '50%', padding: 2 }}>
            <View style={{ width: 26, height: 2, backgroundColor: '#171817', marginBottom: 1 }} />
            <View style={{ width: 20, height: 2, backgroundColor: '#64748B' }} />
          </View>
        </View>
        <View style={{ borderWidth: 0.8, borderColor: '#171817', height: 42 }}>
          <View style={{ height: 8, backgroundColor: '#F8FAFC', borderBottomWidth: 0.8, borderColor: '#171817', flexDirection: 'row', paddingHorizontal: 2, alignItems: 'center' }}>
            <View style={{ width: 8, height: 2, backgroundColor: '#171817' }} />
            <View style={{ flex: 1, height: 2, backgroundColor: '#171817', marginLeft: 4 }} />
            <View style={{ width: 14, height: 2, backgroundColor: '#171817' }} />
          </View>
          {[1, 2, 3].map(i => (
            <View key={i} style={{ height: 7, borderBottomWidth: 0.5, borderColor: '#CBD5E1', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 2 }}>
              <View style={{ width: 6, height: 1.5, backgroundColor: '#64748B' }} />
              <View style={{ flex: 1, height: 1.5, backgroundColor: '#94A3B8', marginLeft: 4 }} />
              <View style={{ width: 12, height: 1.5, backgroundColor: '#171817' }} />
            </View>
          ))}
          <View style={{ height: 9, backgroundColor: '#F8FAFC', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 2, justifyContent: 'space-between' }}>
            <View style={{ width: 12, height: 2, backgroundColor: '#171817' }} />
            <View style={{ width: 16, height: 2, backgroundColor: '#171817' }} />
          </View>
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 3 }}>
          <View style={{ width: 34, height: 10, borderWidth: 0.6, borderColor: '#171817' }} />
          <View style={{ width: 24, height: 10, borderWidth: 0.6, borderColor: '#171817' }} />
        </View>
      </View>
    );
  }

  if (templateId === 'amber_grid') {
    // Reference 02: Orange/Amber banner & grid
    return (
      <View style={{ width: '100%', height: 110, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#EA580C', padding: 4 }}>
        <View style={{ backgroundColor: '#EA580C', height: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 4, marginBottom: 3 }}>
          <T style={{ fontSize: 6.5, fontWeight: '900', color: '#FFFFFF' }}>QUOTATION</T>
          <T style={{ fontSize: 5, fontWeight: '700', color: '#FEF08A' }}>LOGO</T>
        </View>
        <View style={{ flexDirection: 'row', borderWidth: 0.6, borderColor: '#FDBA74', height: 24, marginBottom: 3 }}>
          <View style={{ width: '50%', backgroundColor: '#FFF7ED', borderRightWidth: 0.6, borderColor: '#FDBA74', padding: 2 }} />
          <View style={{ width: '50%', padding: 2 }} />
        </View>
        <View style={{ borderWidth: 0.6, borderColor: '#FDBA74', height: 42 }}>
          <View style={{ height: 8, backgroundColor: '#FFEDD5', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 2 }} />
          {[1, 2, 3].map(i => (
            <View key={i} style={{ height: 7, borderBottomWidth: 0.5, borderColor: '#FED7AA' }} />
          ))}
          <View style={{ height: 9, backgroundColor: '#EA580C' }} />
        </View>
      </View>
    );
  }

  if (templateId === 'olive_grid') {
    // Reference 02: Olive green header
    return (
      <View style={{ width: '100%', height: 110, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#65A30D', padding: 4 }}>
        <View style={{ backgroundColor: '#65A30D', height: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 4, marginBottom: 3 }}>
          <T style={{ fontSize: 6.5, fontWeight: '900', color: '#FFFFFF' }}>QUOTATION</T>
          <T style={{ fontSize: 5, fontWeight: '700', color: '#ECFCCB' }}>LOGO</T>
        </View>
        <View style={{ flexDirection: 'row', borderWidth: 0.6, borderColor: '#BEF264', height: 24, marginBottom: 3 }}>
          <View style={{ width: '50%', backgroundColor: '#F7FEE7', borderRightWidth: 0.6, borderColor: '#BEF264', padding: 2 }} />
          <View style={{ width: '50%', padding: 2 }} />
        </View>
        <View style={{ borderWidth: 0.6, borderColor: '#BEF264', height: 42 }}>
          <View style={{ height: 8, backgroundColor: '#ECFCCB' }} />
          {[1, 2, 3].map(i => (
            <View key={i} style={{ height: 7, borderBottomWidth: 0.5, borderColor: '#D9F99D' }} />
          ))}
          <View style={{ height: 9, backgroundColor: '#4D7C0F' }} />
        </View>
      </View>
    );
  }

  if (templateId === 'compact_trade') {
    // Reference 4: Blue Commercial Form (sales-invoice-D383)
    return (
      <View style={{ width: '100%', height: 110, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#0066B2', padding: 4 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 2 }}>
          <View>
            <View style={{ width: 28, height: 2.5, backgroundColor: '#171817', marginBottom: 1.5 }} />
            <View style={{ width: 36, height: 1.5, backgroundColor: '#64748B' }} />
          </View>
          <T style={{ fontSize: 7, fontWeight: '900', fontStyle: 'italic', color: '#000000' }}>Invoice</T>
        </View>
        <View style={{ flexDirection: 'row', height: 14, marginVertical: 2, gap: 4 }}>
          <View style={{ flex: 1, borderBottomWidth: 0.5, borderColor: '#CBD5E1' }} />
          <View style={{ flex: 1, borderBottomWidth: 0.5, borderColor: '#CBD5E1' }} />
        </View>
        <View style={{ backgroundColor: '#0066B2', height: 6, marginBottom: 2 }} />
        <View style={{ borderWidth: 0.8, borderColor: '#000000', height: 44 }}>
          <View style={{ height: 8, backgroundColor: '#0066B2', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 2 }}>
            <View style={{ width: 12, height: 2, backgroundColor: '#FFFFFF' }} />
            <View style={{ flex: 1, height: 2, backgroundColor: '#FFFFFF', marginLeft: 4 }} />
            <View style={{ width: 14, height: 2, backgroundColor: '#FFFFFF' }} />
          </View>
          {[1, 2, 3].map(i => (
            <View key={i} style={{ height: 7, borderBottomWidth: 0.5, borderColor: '#CBD5E1', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 2 }}>
              <View style={{ width: 8, height: 1.5, backgroundColor: '#94A3B8' }} />
              <View style={{ flex: 1, height: 1.5, backgroundColor: '#CBD5E1', marginLeft: 4 }} />
              <View style={{ width: 10, height: 1.5, backgroundColor: '#171817' }} />
            </View>
          ))}
          <View style={{ height: 8, borderTopWidth: 0.8, borderColor: '#000000', flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center', paddingRight: 4 }}>
            <View style={{ width: 18, height: 2.5, backgroundColor: '#0066B2' }} />
          </View>
        </View>
        <View style={{ alignItems: 'center', marginTop: 3 }}>
          <View style={{ width: 45, height: 2, backgroundColor: '#0066B2' }} />
        </View>
      </View>
    );
  }

  if (templateId === 'blue_timesheet') {
    // Reference 3: Teal Minimal (simple-blue-timesheet-invoice)
    return (
      <View style={{ width: '100%', height: 110, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#1A5B78', overflow: 'hidden' }}>
        <View style={{ backgroundColor: '#1A5B78', height: 22, paddingHorizontal: 4, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <T style={{ fontSize: 7, fontWeight: '900', color: '#FFFFFF', letterSpacing: 0.5 }}>INVOICE</T>
          <View style={{ alignItems: 'flex-end' }}>
            <View style={{ width: 24, height: 2, backgroundColor: '#FFFFFF', marginBottom: 1 }} />
            <View style={{ width: 18, height: 1.5, backgroundColor: '#BAE6FD' }} />
          </View>
        </View>
        <View style={{ padding: 4 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 3 }}>
            <View style={{ width: 26, height: 8, borderLeftWidth: 1, borderColor: '#CBD5E1', paddingLeft: 2 }} />
            <View style={{ width: 26, height: 8, borderRightWidth: 1, borderColor: '#CBD5E1' }} />
          </View>
          <View style={{ borderTopWidth: 1, borderTopColor: '#1A5B78', height: 42 }}>
            <View style={{ height: 7, borderBottomWidth: 0.6, borderColor: '#1A5B78', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 2 }}>
              <View style={{ width: 8, height: 1.5, backgroundColor: '#1A5B78' }} />
              <View style={{ flex: 1, height: 1.5, backgroundColor: '#1A5B78', marginLeft: 4 }} />
              <View style={{ width: 12, height: 1.5, backgroundColor: '#1A5B78' }} />
            </View>
            {[1, 2, 3].map(i => (
              <View key={i} style={{ height: 7, backgroundColor: i % 2 === 0 ? '#F0F7F9' : '#FFFFFF', borderBottomWidth: 0.5, borderColor: '#E2E8F0', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 2 }}>
                <View style={{ width: 6, height: 1.5, backgroundColor: '#94A3B8' }} />
                <View style={{ flex: 1, height: 1.5, backgroundColor: '#CBD5E1', marginLeft: 4 }} />
                <View style={{ width: 10, height: 1.5, backgroundColor: '#171817' }} />
              </View>
            ))}
            <View style={{ height: 8, flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center', paddingRight: 4, marginTop: 1 }}>
              <View style={{ width: 20, height: 5, backgroundColor: '#D8EDF4', borderRadius: 2 }} />
            </View>
          </View>
        </View>
        <View style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 6, backgroundColor: '#1A5B78' }} />
      </View>
    );
  }

  if (templateId === 'sales_detail') {
    // Reference 06: Detailed tax grid with double column
    return (
      <View style={{ width: '100%', height: 110, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#2563EB', padding: 4 }}>
        <View style={{ backgroundColor: '#DBEAFE', height: 13, alignItems: 'center', justifyContent: 'center', marginBottom: 3 }}>
          <T style={{ fontSize: 6.5, fontWeight: '900', color: '#1D4ED8' }}>QUOTATION</T>
        </View>
        <View style={{ flexDirection: 'row', height: 24, marginBottom: 3, borderWidth: 0.6, borderColor: '#93C5FD' }}>
          <View style={{ width: '50%', borderRightWidth: 0.6, borderColor: '#93C5FD' }} />
          <View style={{ width: '50%' }} />
        </View>
        <View style={{ borderWidth: 0.6, borderColor: '#93C5FD', height: 44 }}>
          <View style={{ height: 8, backgroundColor: '#EFF6FF' }} />
          {[1, 2, 3].map(i => (
            <View key={i} style={{ height: 7, borderBottomWidth: 0.5, borderColor: '#DBEAFE' }} />
          ))}
          <View style={{ height: 9, backgroundColor: '#1D4ED8' }} />
        </View>
      </View>
    );
  }

  if (templateId === 'corporate_sales') {
    // Reference 5: Compact Spreadsheet (sales-invoice-template)
    return (
      <View style={{ width: '100%', height: 110, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#3B5998', padding: 4 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 2 }}>
          <View style={{ width: 32, height: 2.5, backgroundColor: '#1E293B', marginBottom: 1 }} />
          <T style={{ fontSize: 6.5, fontWeight: '800', color: '#6B8EA9' }}>INVOICE</T>
        </View>
        <View style={{ flexDirection: 'row', gap: 3, marginBottom: 2 }}>
          <View style={{ flex: 1, height: 5, backgroundColor: '#3B5998' }} />
          <View style={{ flex: 1, height: 5, backgroundColor: '#3B5998' }} />
        </View>
        <View style={{ backgroundColor: '#3B5998', height: 4, marginBottom: 2 }} />
        <View style={{ borderWidth: 0.6, borderColor: '#CBD5E1', height: 44 }}>
          <View style={{ height: 7, backgroundColor: '#3B5998', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 2 }}>
            <View style={{ width: 10, height: 1.5, backgroundColor: '#FFFFFF' }} />
            <View style={{ flex: 1, height: 1.5, backgroundColor: '#FFFFFF', marginLeft: 4 }} />
            <View style={{ width: 12, height: 1.5, backgroundColor: '#FFFFFF' }} />
          </View>
          {[1, 2, 3].map(i => (
            <View key={i} style={{ height: 7, borderBottomWidth: 0.5, borderColor: '#E2E8F0', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 2 }}>
              <View style={{ width: 8, height: 1.5, backgroundColor: '#94A3B8' }} />
              <View style={{ flex: 1, height: 1.5, backgroundColor: '#CBD5E1', marginLeft: 4 }} />
              <View style={{ width: 12, height: 1.5, backgroundColor: '#1E293B' }} />
            </View>
          ))}
          <View style={{ height: 8, flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center', paddingRight: 4 }}>
            <View style={{ width: 16, height: 5, backgroundColor: '#3B5998' }} />
          </View>
        </View>
        <View style={{ alignItems: 'center', marginTop: 2 }}>
          <View style={{ width: 36, height: 1.5, backgroundColor: '#94A3B8' }} />
        </View>
      </View>
    );
  }

  if (templateId === 'contractor_detail') {
    // Reference 03 & Reference 05: Split Materials & Labour yellow sections
    return (
      <View style={{ width: '100%', height: 110, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#EAB308', padding: 4 }}>
        <View style={{ height: 2.5, backgroundColor: '#FFD500', marginBottom: 3 }} />
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 3 }}>
          <View style={{ width: 35, height: 3, backgroundColor: '#171817' }} />
          <T style={{ fontSize: 6.5, fontWeight: '900', color: '#171817' }}>QUOTATION</T>
        </View>
        {/* Materials banner */}
        <View style={{ backgroundColor: '#FEF3C7', height: 6, marginBottom: 1, paddingHorizontal: 2, justifyContent: 'center' }}>
          <T style={{ fontSize: 4, fontWeight: '800', color: '#92400E' }}>MATERIALS</T>
        </View>
        <View style={{ height: 16, borderBottomWidth: 0.6, borderColor: '#FDE047', marginBottom: 2 }}>
          <View style={{ height: 5, backgroundColor: '#FAFAFA' }} />
          <View style={{ height: 5, backgroundColor: '#FFFFFF' }} />
        </View>
        {/* Labour banner */}
        <View style={{ backgroundColor: '#FEF3C7', height: 6, marginBottom: 1, paddingHorizontal: 2, justifyContent: 'center' }}>
          <T style={{ fontSize: 4, fontWeight: '800', color: '#92400E' }}>LABOUR</T>
        </View>
        <View style={{ height: 16, borderBottomWidth: 0.6, borderColor: '#FDE047', marginBottom: 3 }}>
          <View style={{ height: 5, backgroundColor: '#FAFAFA' }} />
          <View style={{ height: 5, backgroundColor: '#FFFFFF' }} />
        </View>
        {/* Grand Total */}
        <View style={{ backgroundColor: '#FFD500', height: 8, justifyContent: 'center', paddingHorizontal: 4 }}>
          <T style={{ fontSize: 5, fontWeight: '900', color: '#171817' }}>GRAND TOTAL</T>
        </View>
      </View>
    );
  }

  if (templateId === 'project_summary') {
    // Reference 03: Milestone & scope summary
    return (
      <View style={{ width: '100%', height: 110, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#475569', padding: 4 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 3 }}>
          <T style={{ fontSize: 6.5, fontWeight: '900', color: '#334155' }}>QUOTATION</T>
          <View style={{ width: 18, height: 2, backgroundColor: '#94A3B8' }} />
        </View>
        <View style={{ height: 18, borderBottomWidth: 0.6, borderColor: '#E2E8F0', marginBottom: 3 }} />
        <View style={{ height: 22, backgroundColor: '#F8FAFC', borderWidth: 0.6, borderColor: '#E2E8F0', marginBottom: 3 }} />
        <View style={{ height: 22, backgroundColor: '#F8FAFC', borderWidth: 0.6, borderColor: '#E2E8F0', marginBottom: 3 }} />
        <View style={{ height: 8, backgroundColor: '#334155' }} />
      </View>
    );
  }

  // templateId === 'tilebill_classic' (Reference 03)
  return (
    <View style={{ width: '100%', height: 110, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#FACC15', padding: 4 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 }}>
        <View style={{ width: 28, height: 2.5, backgroundColor: '#854D0E' }} />
        <T style={{ fontSize: 6.5, fontWeight: '900', color: '#854D0E' }}>QUOTATION</T>
      </View>
      <View style={{ height: 20, marginBottom: 3, borderWidth: 0.6, borderColor: '#FEF08A' }} />
      <View style={{ borderWidth: 0.6, borderColor: '#FACC15', height: 44 }}>
        <View style={{ height: 8, backgroundColor: '#FEF9C3' }} />
        {[1, 2, 3].map(i => (
          <View key={i} style={{ height: 7, borderBottomWidth: 0.5, borderColor: '#FEF08A' }} />
        ))}
        <View style={{ height: 9, backgroundColor: '#EAB308' }} />
      </View>
    </View>
  );
}

export default function TemplatePickerModal({
  visible,
  onClose,
  appliedTemplate = 'classic_ledger',
  selectedTemplateId,
  onApply,
  onSelectTemplate,
  onOpenPreview,
  kind = 'quotation',
  docKind,
  onKindChange,
  appLang = 'te',
  pageSize = 'a4'
}) {
  const t = getStrings(appLang);
  const initialId = selectedTemplateId || appliedTemplate || 'classic_ledger';
  const [selectedId, setSelectedId] = useState(initialId);
  const [activePage, setActivePage] = useState(1);
  const [activeKind, setActiveKind] = useState(docKind || kind || 'quotation');

  // Filter templates by page
  // Page 1: Exactly 6 cards (2 cols x 3 rows): classic_ledger to sales_detail
  // Page 2: Exactly 4 cards (2 cols x 2 rows): corporate_sales to tilebill_classic
  const page1Templates = documentTemplates.slice(0, 6);
  const page2Templates = documentTemplates.slice(6, 10);
  const currentTemplates = activePage === 1 ? page1Templates : page2Templates;

  const handleSelect = (tmplId) => {
    setSelectedId(tmplId);
    if (onSelectTemplate) {
      onSelectTemplate(tmplId);
    }
  };

  const handleApply = () => {
    if (onSelectTemplate) {
      onSelectTemplate(selectedId);
    }
    if (onApply) {
      onApply(selectedId);
    }
    if (onClose) {
      onClose();
    }
  };

  const handleCancel = () => {
    setSelectedId(appliedTemplate); // restore
    if (onClose) {
      onClose();
    }
  };

  const selectedTemplateObj = resolveTemplate(selectedId);
  const selectedName = t[`tmpl${selectedTemplateObj.id === 'classic_ledger' ? '01' : selectedTemplateObj.id === 'amber_grid' ? '02' : selectedTemplateObj.id === 'olive_grid' ? '03' : selectedTemplateObj.id === 'compact_trade' ? '04' : selectedTemplateObj.id === 'blue_timesheet' ? '05' : selectedTemplateObj.id === 'sales_detail' ? '06' : selectedTemplateObj.id === 'corporate_sales' ? '07' : selectedTemplateObj.id === 'contractor_detail' ? '08' : selectedTemplateObj.id === 'project_summary' ? '09' : '10'}Name`] || selectedTemplateObj.name;

  if (!visible) return null;

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={handleCancel}
    >
      <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end', alignItems: 'center' }}>
        <View
          style={{
            backgroundColor: '#FAF9F6',
            width: '100%',
            maxWidth: 480,
            maxHeight: '92%',
            borderTopLeftRadius: 28,
            borderTopRightRadius: 28,
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column'
          }}
        >
          {/* 1. Drag Handle on Top */}
          <View style={{ width: '100%', alignItems: 'center', paddingTop: 8, paddingBottom: 4 }}>
            <View style={{ width: 44, height: 4, borderRadius: 2, backgroundColor: '#CBD5E1' }} />
          </View>

          {/* 2. Modal Header */}
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 8 }}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Back"
              onPress={handleCancel}
              style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 20 }}
            >
              <I name="chevron-back" size={24} color="#171817" />
            </Pressable>

            <View style={{ alignItems: 'center' }}>
              <T style={{ fontSize: 20, fontWeight: '800', color: '#171817' }}>
                {t.chooseTemplateTitle || 'Choose Template'}
              </T>
              <T style={{ fontSize: 12, color: '#667085', marginTop: 1 }}>
                {t.chooseTemplateSub || 'మీ PDF డిజైన్ ఎంచుకోండి'}
              </T>
            </View>

            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Close"
              onPress={handleCancel}
              style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 20 }}
            >
              <I name="close" size={22} color="#171817" />
            </Pressable>
          </View>

          {/* 3. Document Type Filter Bar: Quotation / Invoice */}
          <View style={{ paddingHorizontal: 16, marginBottom: 8 }}>
            <View style={{ flexDirection: 'row', backgroundColor: '#F1F5F9', borderRadius: 14, padding: 3 }}>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Quotation"
                onPress={() => {
                  setActiveKind('quotation');
                  if (onKindChange) onKindChange('quotation');
                }}
                style={{
                  flex: 1,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 6,
                  paddingVertical: 10,
                  borderRadius: 12,
                  backgroundColor: activeKind === 'quotation' ? '#FFD500' : 'transparent',
                  shadowColor: '#000',
                  shadowOpacity: activeKind === 'quotation' ? 0.08 : 0,
                  shadowRadius: 2,
                  elevation: activeKind === 'quotation' ? 1 : 0
                }}
              >
                <I name="document-text-outline" size={17} color="#171817" />
                <View style={{ alignItems: 'center' }}>
                  <T style={{ fontSize: 13, fontWeight: '800', color: '#171817' }}>
                    {appLang === 'te' ? 'కొటేషన్' : appLang === 'hi' ? 'कोटेशन' : 'QUOTATION'}
                  </T>
                </View>
              </Pressable>

              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Invoice"
                onPress={() => {
                  setActiveKind('invoice');
                  if (onKindChange) onKindChange('invoice');
                }}
                style={{
                  flex: 1,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 6,
                  paddingVertical: 10,
                  borderRadius: 12,
                  backgroundColor: activeKind === 'invoice' ? '#FFD500' : 'transparent',
                  shadowColor: '#000',
                  shadowOpacity: activeKind === 'invoice' ? 0.08 : 0,
                  shadowRadius: 2,
                  elevation: activeKind === 'invoice' ? 1 : 0
                }}
              >
                <I name="receipt-outline" size={17} color="#171817" />
                <View style={{ alignItems: 'center' }}>
                  <T style={{ fontSize: 13, fontWeight: '800', color: '#171817' }}>
                    {appLang === 'te' ? 'ఇన్వాయిస్' : appLang === 'hi' ? 'इनवॉयस' : 'INVOICE'}
                  </T>
                </View>
              </Pressable>
            </View>

            {/* Subtitle helper notice */}
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4, marginTop: 6 }}>
              <T style={{ fontSize: 11.5, color: '#667085' }}>
                {t.templateChangeNotice || 'డిజైన్ మారినా మీ వివరాలు అలాగే ఉంటాయి'}
              </T>
              <I name="information-circle-outline" size={14} color="#667085" />
            </View>
          </View>

          {/* 4. Grid of Cards: Scrollable Area */}
          <ScrollView
            style={{ flex: 1, paddingHorizontal: 16 }}
            contentContainerStyle={{ paddingBottom: 16 }}
            showsVerticalScrollIndicator={false}
          >
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 12 }}>
              {currentTemplates.map((tmpl) => {
                const isSelected = selectedId === tmpl.id;
                const tmplKey = tmpl.id === 'classic_ledger' ? '01' : tmpl.id === 'amber_grid' ? '02' : tmpl.id === 'olive_grid' ? '03' : tmpl.id === 'compact_trade' ? '04' : tmpl.id === 'blue_timesheet' ? '05' : tmpl.id === 'sales_detail' ? '06' : tmpl.id === 'corporate_sales' ? '07' : tmpl.id === 'contractor_detail' ? '08' : tmpl.id === 'project_summary' ? '09' : '10';
                const localizedTmplName = t[`tmpl${tmplKey}Name`] || tmpl.name;

                return (
                  <Pressable
                    key={tmpl.id}
                    accessibilityRole="button"
                    accessibilityLabel={localizedTmplName}
                    onPress={() => handleSelect(tmpl.id)}
                    style={({ pressed }) => [{
                      width: '48%',
                      backgroundColor: '#FFFFFF',
                      borderRadius: 16,
                      borderWidth: isSelected ? 2 : 1,
                      borderColor: isSelected ? '#FACC15' : '#E2E8F0',
                      padding: 8,
                      position: 'relative',
                      shadowColor: '#000',
                      shadowOffset: { width: 0, height: 1 },
                      shadowOpacity: isSelected ? 0.12 : 0.04,
                      shadowRadius: 4,
                      elevation: isSelected ? 3 : 1,
                      opacity: pressed ? 0.88 : 1
                    }]}
                  >
                    {/* Top right yellow checkmark badge if selected */}
                    {isSelected && (
                      <View style={{ position: 'absolute', top: 6, right: 6, zIndex: 10, width: 22, height: 22, borderRadius: 11, backgroundColor: '#FFD500', alignItems: 'center', justifyContent: 'center' }}>
                        <I name="checkmark" size={14} color="#171817" />
                      </View>
                    )}

                    {/* Miniature document preview */}
                    <View style={{ borderRadius: 8, overflow: 'hidden', marginBottom: 8 }}>
                      <MiniaturePreview templateId={tmpl.id} selected={isSelected} />
                    </View>

                    {/* Template Name */}
                    <T numberOfLines={1} style={{ fontSize: 13, fontWeight: '800', color: '#171817', marginBottom: 2 }}>
                      {localizedTmplName}
                    </T>

                    {/* Sub-label */}
                    <T numberOfLines={1} style={{ fontSize: 10.5, color: '#667085', fontWeight: '500' }}>
                      {activeKind === 'invoice' ? 'INVOICE' : 'QUOTATION'}
                    </T>

                    {/* Zoom / Preview icon in bottom right */}
                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel={'Preview ' + localizedTmplName}
                      onPress={() => {
                        handleSelect(tmpl.id);
                        if (onOpenPreview) onOpenPreview(tmpl.id);
                      }}
                      style={{
                        position: 'absolute',
                        bottom: 8,
                        right: 8,
                        width: 26,
                        height: 26,
                        borderRadius: 13,
                        backgroundColor: '#171817',
                        alignItems: 'center',
                        justifyContent: 'center',
                        opacity: 0.85
                      }}
                    >
                      <I name="search" size={13} color="#FFFFFF" />
                    </Pressable>
                  </Pressable>
                );
              })}
            </View>

            {/* 5. Pagination Controls */}
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 12, marginTop: 16 }}>
              <T style={{ fontSize: 12, fontWeight: '600', color: '#667085', marginRight: 4 }}>
                {activePage === 1 ? '1 - 6 of 10' : '7 - 10 of 10'}
              </T>

              {/* Prev Button */}
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Previous page"
                disabled={activePage === 1}
                onPress={() => setActivePage(1)}
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: 8,
                  backgroundColor: activePage === 1 ? '#F1F5F9' : '#FFFFFF',
                  borderWidth: 1,
                  borderColor: '#E2E8F0',
                  alignItems: 'center',
                  justifyContent: 'center',
                  opacity: activePage === 1 ? 0.4 : 1
                }}
              >
                <I name="chevron-back" size={16} color="#171817" />
              </Pressable>

              {/* Page 1 Button */}
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Page 1"
                onPress={() => setActivePage(1)}
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: 8,
                  backgroundColor: activePage === 1 ? '#FFD500' : '#FFFFFF',
                  borderWidth: 1,
                  borderColor: activePage === 1 ? '#FACC15' : '#E2E8F0',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                <T style={{ fontSize: 13, fontWeight: '800', color: '#171817' }}>1</T>
              </Pressable>

              {/* Page 2 Button */}
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Page 2"
                onPress={() => setActivePage(2)}
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: 8,
                  backgroundColor: activePage === 2 ? '#FFD500' : '#FFFFFF',
                  borderWidth: 1,
                  borderColor: activePage === 2 ? '#FACC15' : '#E2E8F0',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                <T style={{ fontSize: 13, fontWeight: '800', color: '#171817' }}>2</T>
              </Pressable>

              {/* Next Button */}
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Next page"
                disabled={activePage === 2}
                onPress={() => setActivePage(2)}
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: 8,
                  backgroundColor: activePage === 2 ? '#F1F5F9' : '#FFFFFF',
                  borderWidth: 1,
                  borderColor: '#E2E8F0',
                  alignItems: 'center',
                  justifyContent: 'center',
                  opacity: activePage === 2 ? 0.4 : 1
                }}
              >
                <I name="chevron-forward" size={16} color="#171817" />
              </Pressable>
            </View>
          </ScrollView>

          {/* 6. Bottom Bar: Selected template summary & Apply button */}
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              paddingHorizontal: 16,
              paddingVertical: 12,
              backgroundColor: '#FFFFFF',
              borderTopWidth: 1,
              borderColor: '#E2E8F0'
            }}
          >
            <View style={{ flex: 1, minWidth: 0, paddingRight: 8 }}>
              <T numberOfLines={1} style={{ fontSize: 14, fontWeight: '800', color: '#171817' }}>
                {selectedName} • {pageSize.toUpperCase()}
              </T>
            </View>

            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Apply Template"
              onPress={handleApply}
              style={({ pressed }) => [{
                backgroundColor: '#FFD500',
                borderRadius: 14,
                paddingVertical: 12,
                paddingHorizontal: 18,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 6,
                shadowColor: '#EAB308',
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.25,
                shadowRadius: 4,
                elevation: 3,
                opacity: pressed ? 0.88 : 1
              }]}
            >
              <T style={{ fontSize: 14, fontWeight: '900', color: '#171817' }}>
                {t.btnUseThisTemplate || 'ఈ టెంప్లేట్ వాడండి'}
              </T>
              <I name="arrow-forward" size={16} color="#171817" />
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
}
