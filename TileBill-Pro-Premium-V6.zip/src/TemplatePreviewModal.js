import React, { useState, useEffect } from 'react';
import {
  View,
  Text as T,
  Pressable,
  ScrollView,
  Modal,
  Platform,
  useWindowDimensions
} from 'react-native';
import { Ionicons as I } from '@expo/vector-icons';
import { resolveTemplate, documentTemplates, pageSizes, documentHtml, numberToIndianWords } from './domain.cjs';
import { getStrings } from './i18n';

export default function TemplatePreviewModal({
  visible,
  onClose,
  doc = {},
  business = {},
  templateId = 'classic_ledger',
  onTemplateChange,
  onEdit,
  onUseTemplate,
  printDoc,
  appLang = 'te'
}) {
  const t = getStrings(appLang);
  const { width: windowWidth } = useWindowDimensions();
  const isDesktop = windowWidth >= 768;

  const [activeTmplId, setActiveTmplId] = useState(templateId || 'classic_ledger');
  const [docKind, setDocKind] = useState(doc.kind || 'quotation');
  const [docLanguage, setDocLanguage] = useState(doc.language || appLang || 'en');
  const [pageSize, setPageSize] = useState(doc.pageSize || 'a4');
  const [attachAgreement, setAttachAgreement] = useState(Boolean(doc.attachAgreement ?? true));
  const [zoomMode, setZoomMode] = useState('fit'); // 'fit' | '100%'
  const [gstAccordionOpen, setGstAccordionOpen] = useState(false);

  useEffect(() => {
    if (templateId) {
      setActiveTmplId(templateId);
    }
  }, [templateId]);

  if (!visible) return null;

  const currentTemplate = resolveTemplate(activeTmplId);
  const isQuotation = docKind === 'quotation';
  const docTitle = isQuotation ? 'QUOTATION' : 'TAX INVOICE';
  const bizName = business.name || 'Mahesh Constructions';
  const custName = doc.customer?.name || 'Jai Siva';
  const siteLocation = doc.customer?.siteLocation || doc.customer?.address || 'Kailasapuram';
  const quoteNumber = doc.number || 'QT-0001';
  const issueDate = doc.date || '18-Oct-2026';
  const validTillDate = doc.dueDate || '25-Oct-2026';
  const workTitle = doc.title || (isQuotation ? 'టైల్స్ పని అంచనా' : 'టైల్స్ బిల్లు');

  // Sample items if empty
  const defaultItems = [
    { id: '1', name: 'Hall floor tiles (Labour)', measuredQty: 120, qty: 120, unit: 'sq.ft', rate: 45, amount: 5400, basis: 'Labour only' },
    { id: '2', name: 'Bedroom floor tiles (Labour)', measuredQty: 100, qty: 100, unit: 'sq.ft', rate: 45, amount: 4500, basis: 'Labour only' }
  ];

  const items = (doc.items && doc.items.length > 0) ? doc.items : defaultItems;
  const totalAmount = (doc.total && doc.total > 0) ? doc.total : items.reduce((s, it) => s + (Number(it.amount) || 0), 0);

  // Construct complete document representation for exact HTML rendering
  const previewDoc = {
    ...doc,
    number: quoteNumber,
    date: issueDate,
    dueDate: validTillDate,
    kind: docKind,
    language: docLanguage,
    pageSize: pageSize,
    template: currentTemplate.id,
    attachAgreement: attachAgreement,
    items: items,
    total: totalAmount,
    title: doc.title || workTitle,
    customer: doc.customer || { name: custName, siteLocation: siteLocation, address: siteLocation }
  };

  const previewHtml = documentHtml(previewDoc, business || {});

  const handleSwitchTemplate = (newId) => {
    setActiveTmplId(newId);
    if (onTemplateChange) onTemplateChange(newId);
  };

  const currentTemplateIndex = documentTemplates.findIndex(x => x.id === currentTemplate.id);
  const safeIndex = currentTemplateIndex >= 0 ? currentTemplateIndex : 0;

  const prevTemplate = () => {
    const prevIdx = (safeIndex - 1 + documentTemplates.length) % documentTemplates.length;
    handleSwitchTemplate(documentTemplates[prevIdx].id);
  };

  const nextTemplate = () => {
    const nextIdx = (safeIndex + 1) % documentTemplates.length;
    handleSwitchTemplate(documentTemplates[nextIdx].id);
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: isDesktop ? 'center' : 'flex-end', alignItems: 'center', padding: isDesktop ? 20 : 0 }}>
        <View
          style={{
            backgroundColor: '#FAF9F6',
            width: isDesktop ? Math.min(windowWidth - 40, 840) : '100%',
            height: isDesktop ? '92%' : '96%',
            borderRadius: isDesktop ? 20 : 28,
            borderBottomLeftRadius: isDesktop ? 20 : 0,
            borderBottomRightRadius: isDesktop ? 20 : 0,
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column',
            boxShadow: '0 20px 40px rgba(0,0,0,0.25)'
          }}
        >
          {/* 1. Header with Back, Brand Logo, and Close */}
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 10, borderBottomWidth: 1, borderColor: '#F1F5F9', backgroundColor: '#FFFFFF' }}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Back"
              onPress={onClose}
              style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 20 }}
            >
              <I name="chevron-back" size={24} color="#171817" />
            </Pressable>

            {/* TileBill PRO Brand Logo */}
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
              <T style={{ fontSize: 18, fontWeight: '900', color: '#171817', letterSpacing: -0.3 }}>TileBill</T>
              <View style={{ backgroundColor: '#FFD500', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 }}>
                <T style={{ fontSize: 11, fontWeight: '900', color: '#171817' }}>PRO</T>
              </View>
            </View>

            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Close"
              onPress={onClose}
              style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 20 }}
            >
              <I name="close" size={22} color="#171817" />
            </Pressable>
          </View>

          {/* 2. Interactive Template Switcher Strip */}
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 8, backgroundColor: '#FFFFFF', borderBottomWidth: 1, borderColor: '#E2E8F0' }}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Previous Template"
              onPress={prevTemplate}
              style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: '#F1F5F9', alignItems: 'center', justifyContent: 'center' }}
            >
              <I name="chevron-back" size={18} color="#171817" />
            </Pressable>

            <View style={{ alignItems: 'center', flex: 1, paddingHorizontal: 8 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <T numberOfLines={1} style={{ fontSize: 14, fontWeight: '900', color: '#171817' }}>
                  {currentTemplate.name}
                </T>
                <View style={{ backgroundColor: '#FEF08A', paddingHorizontal: 6, paddingVertical: 1.5, borderRadius: 6 }}>
                  <T style={{ fontSize: 10, fontWeight: '800', color: '#854D0E' }}>
                    {safeIndex + 1} / {documentTemplates.length}
                  </T>
                </View>
              </View>
              <T numberOfLines={1} style={{ fontSize: 11, color: '#64748B', marginTop: 1 }}>
                {currentTemplate.desc}
              </T>
            </View>

            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Next Template"
              onPress={nextTemplate}
              style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: '#F1F5F9', alignItems: 'center', justifyContent: 'center' }}
            >
              <I name="chevron-forward" size={18} color="#171817" />
            </Pressable>
          </View>

          {/* 3. Top Quick Format Selectors Bar */}
          <View style={{ flexDirection: 'row', gap: 8, paddingHorizontal: 16, paddingVertical: 8, backgroundColor: '#FAF9F6' }}>
            {/* Document Kind Selector */}
            <Pressable
              accessibilityRole="button"
              onPress={() => setDocKind(isQuotation ? 'invoice' : 'quotation')}
              style={{ flex: 1, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 10, paddingHorizontal: 8, paddingVertical: 6, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}
            >
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5, flex: 1, minWidth: 0 }}>
                <I name="document-text-outline" size={15} color="#171817" />
                <View style={{ flex: 1, minWidth: 0 }}>
                  <T style={{ fontSize: 9, color: '#667085' }}>{t.labelDocKind || 'డాక్యుమెంట్ రకం'}</T>
                  <T numberOfLines={1} style={{ fontSize: 11.5, fontWeight: '800', color: '#171817' }}>
                    {isQuotation ? (appLang === 'te' ? 'కొటేషన్' : appLang === 'hi' ? 'कोटेशन' : 'Quotation') : (appLang === 'te' ? 'ఇన్వాయిస్' : appLang === 'hi' ? 'इनవాయ్స్' : 'Invoice')}
                  </T>
                </View>
              </View>
              <I name="chevron-down" size={13} color="#667085" />
            </Pressable>

            {/* Document Language Selector */}
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Switch document language"
              onPress={() => {
                const langs = ['en', 'te', 'hi'];
                const next = langs[(langs.indexOf(docLanguage) + 1) % langs.length];
                setDocLanguage(next);
              }}
              style={{ flex: 1, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 10, paddingHorizontal: 8, paddingVertical: 6, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}
            >
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5, flex: 1, minWidth: 0 }}>
                <I name="language-outline" size={15} color="#171817" />
                <View style={{ flex: 1, minWidth: 0 }}>
                  <T style={{ fontSize: 9, color: '#667085' }}>{t.labelDocLanguage || 'భాష'}</T>
                  <T numberOfLines={1} style={{ fontSize: 11.5, fontWeight: '800', color: '#171817' }}>
                    {docLanguage === 'te' ? 'తెలుగు' : docLanguage === 'hi' ? 'हिन्दी' : 'English'}
                  </T>
                </View>
              </View>
              <I name="chevron-down" size={13} color="#667085" />
            </Pressable>

            {/* Paper Size Selector */}
            <Pressable
              accessibilityRole="button"
              onPress={() => {
                const sizes = ['a4', 'a5', 'letter', 'thermal'];
                const next = sizes[(sizes.indexOf(pageSize) + 1) % sizes.length];
                setPageSize(next);
              }}
              style={{ flex: 1, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 10, paddingHorizontal: 8, paddingVertical: 6, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}
            >
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5, flex: 1, minWidth: 0 }}>
                <I name="newspaper-outline" size={15} color="#171817" />
                <View style={{ flex: 1, minWidth: 0 }}>
                  <T style={{ fontSize: 9, color: '#667085' }}>{t.labelPaperSize || 'పేపర్ సైజ్'}</T>
                  <T numberOfLines={1} style={{ fontSize: 11.5, fontWeight: '800', color: '#171817' }}>
                    {pageSize.toUpperCase()}
                  </T>
                </View>
              </View>
              <I name="chevron-down" size={13} color="#667085" />
            </Pressable>

            {/* Zoom / Fit Toggle */}
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Toggle zoom mode"
              onPress={() => setZoomMode(zoomMode === 'fit' ? '100%' : 'fit')}
              style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 10, paddingHorizontal: 10, paddingVertical: 6, alignItems: 'center', justifyContent: 'center' }}
            >
              <T style={{ fontSize: 9, color: '#667085' }}>విక్షణ</T>
              <T style={{ fontSize: 11.5, fontWeight: '800', color: '#171817' }}>
                {zoomMode === 'fit' ? 'Fit' : '100%'}
              </T>
            </Pressable>
          </View>

          {/* 4. Live Rendered Document Viewport */}
          <View style={{ flex: 1, backgroundColor: '#E2E8F0', padding: 8, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
            <View
              style={{
                width: zoomMode === 'fit' ? '100%' : 780,
                maxWidth: '100%',
                height: '100%',
                backgroundColor: '#FFFFFF',
                borderRadius: 4,
                boxShadow: '0 4px 20px rgba(0,0,0,0.18)',
                overflow: 'hidden'
              }}
            >
              {Platform.OS === 'web' ? (
                <iframe
                  srcDoc={previewHtml}
                  title="Document Live Preview"
                  style={{
                    width: '100%',
                    height: '100%',
                    border: 'none',
                    backgroundColor: '#FFFFFF'
                  }}
                />
              ) : (
                <ScrollView style={{ flex: 1, padding: 12 }}>
                  <T style={{ fontSize: 13, fontWeight: '700', color: '#171817' }}>
                    {currentTemplate.name} ({pageSize.toUpperCase()})
                  </T>
                  <T style={{ fontSize: 12, color: '#64748B', marginTop: 4 }}>
                    Tap "PDF / Print" below to generate the exact layout on mobile.
                  </T>
                </ScrollView>
              )}
            </View>
          </View>

          {/* 5. Annexure Switch & Options Strip */}
          <View style={{ backgroundColor: '#FFFFFF', borderTopWidth: 1, borderColor: '#E2E8F0', paddingHorizontal: 16, paddingVertical: 8 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <View style={{ flex: 1, paddingRight: 8 }}>
                <T style={{ fontSize: 12.5, fontWeight: '800', color: '#171817' }}>
                  {t.agreeAnnexureToggleTitle || 'మెటీరియల్స్ అగ్రిమెంట్ జతచేయండి'}
                </T>
                <T style={{ fontSize: 11, color: '#64748B' }}>
                  {t.agreeAnnexureToggleSub || 'ప్రత్యేక పేజీగా జోడించండి (Annexure)'}
                </T>
              </View>
              <Pressable
                accessibilityRole="switch"
                accessibilityLabel="Attach Materials Agreement as separate page"
                accessibilityState={{ checked: attachAgreement }}
                onPress={() => setAttachAgreement(!attachAgreement)}
                style={{
                  width: 44,
                  height: 26,
                  borderRadius: 13,
                  backgroundColor: attachAgreement ? '#FFD500' : '#E2E8F0',
                  padding: 2.5,
                  justifyContent: 'center',
                  alignItems: attachAgreement ? 'flex-end' : 'flex-start'
                }}
              >
                <View style={{ width: 21, height: 21, borderRadius: 10.5, backgroundColor: '#FFFFFF', boxShadow: '0 1px 3px rgba(0,0,0,0.2)' }} />
              </Pressable>
            </View>

            {/* Helper Info Notice Banner */}
            <View style={{ backgroundColor: '#FEF9C3', borderRadius: 8, paddingVertical: 6, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 6 }}>
              <I name="checkmark-circle" size={15} color="#854D0E" />
              <T style={{ fontSize: 11.5, fontWeight: '700', color: '#713F12' }}>
                {t.previewThisPdfNotice || 'ఇదే డిజైన్ PDFలో వస్తుంది (Exact PDF Output)'}
              </T>
            </View>
          </View>

          {/* 6. Footer Action Buttons */}
          <View
            style={{
              flexDirection: 'row',
              gap: 10,
              paddingHorizontal: 16,
              paddingVertical: 10,
              backgroundColor: '#FFFFFF',
              borderTopWidth: 1,
              borderColor: '#E2E8F0'
            }}
          >
            {/* Edit Button */}
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Edit Document Details"
              onPress={() => {
                if (onEdit) onEdit();
                else onClose();
              }}
              style={({ pressed }) => [{
                flex: 1,
                borderWidth: 1.5,
                borderColor: '#CBD5E1',
                borderRadius: 12,
                paddingVertical: 10,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 6,
                backgroundColor: pressed ? '#F8FAFC' : '#FFFFFF'
              }]}
            >
              <I name="create-outline" size={16} color="#171817" />
              <T style={{ fontSize: 13, fontWeight: '800', color: '#171817' }}>
                {t.btnEditDetails || 'మార్చండి'}
              </T>
            </Pressable>

            {/* Direct PDF / Print Button */}
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Print or Export PDF"
              onPress={() => {
                if (printDoc) {
                  printDoc(previewDoc);
                }
              }}
              style={({ pressed }) => [{
                flex: 1.2,
                borderWidth: 1.5,
                borderColor: '#171817',
                borderRadius: 12,
                paddingVertical: 10,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 6,
                backgroundColor: pressed ? '#F1F5F9' : '#FFFFFF'
              }]}
            >
              <I name="print-outline" size={16} color="#171817" />
              <T style={{ fontSize: 13, fontWeight: '800', color: '#171817' }}>
                PDF / Print
              </T>
            </Pressable>

            {/* Use Template / Confirm Button */}
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Use this template"
              onPress={() => {
                if (onUseTemplate) {
                  onUseTemplate(currentTemplate.id, { attachAgreement, docKind, docLanguage, pageSize });
                } else if (printDoc) {
                  printDoc({ ...previewDoc, template: currentTemplate.id });
                }
                onClose();
              }}
              style={({ pressed }) => [{
                flex: 1.8,
                backgroundColor: '#FFD500',
                borderRadius: 12,
                paddingVertical: 10,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 6,
                boxShadow: '0 2px 6px rgba(234,179,8,0.3)',
                opacity: pressed ? 0.88 : 1
              }]}
            >
              <I name="checkmark" size={17} color="#171817" />
              <T style={{ fontSize: 13.5, fontWeight: '900', color: '#171817' }}>
                {t.btnConfirmTemplate || 'ఈ టెంప్లేట్ వాడండి'}
              </T>
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
}
