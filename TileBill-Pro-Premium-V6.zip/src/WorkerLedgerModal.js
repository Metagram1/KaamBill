import React, { useState } from 'react';
import {
  View,
  Text,
  Pressable,
  ScrollView,
  Platform,
  useWindowDimensions
} from 'react-native';
import { I, T, Empty } from './ui';
import { money } from './domain.cjs';
import { getStrings } from './i18n';
import { formatTeluguDate } from './CustomersPage';

export default function WorkerLedgerModal({
  visible,
  worker,
  w,
  service,
  busy,
  appLang = 'te',
  onClose,
  onOpenPayment,
  onEditWorker,
  onVoidPayout
}) {
  if (!visible || !worker) return null;

  const t = getStrings(appLang);
  const { width } = useWindowDimensions();
  const isDesktop = width >= 768;

  const [activeFilter, setActiveFilter] = useState('all'); // 'all' | 'attendance' | 'payments'
  const [menuOpen, setMenuOpen] = useState(false);

  // Filter attendance and payouts
  const workerAtt = (w?.attendance || [])
    .filter(a => a.workerId === worker.id)
    .sort((a, b) => (b.date || '').localeCompare(a.date || ''));

  const workerPayouts = (w?.payouts || [])
    .filter(p => p.workerId === worker.id)
    .sort((a, b) => (b.date || '').localeCompare(a.date || ''));

  const fullDays = workerAtt.filter(a => a.status === 'present').length;
  const halfDays = workerAtt.filter(a => a.status === 'half').length;
  const effectiveDays = fullDays + (halfDays * 0.5);

  const totalEarned = workerAtt.reduce((sum, a) => {
    const rate = a.dailyRate ?? worker.dailyRate ?? 0;
    return sum + (a.earned ?? (rate * (a.status === 'present' ? 1 : a.status === 'half' ? 0.5 : 0)));
  }, 0);

  const activePayouts = workerPayouts.filter(p => !p.void);
  const totalPaid = activePayouts.reduce((sum, p) => sum + (p.amount || 0), 0);
  const balance = totalEarned - totalPaid;
  const isDue = balance >= 0;

  // Combine attendance and payouts into a unified timeline
  const timeline = [];
  if (activeFilter === 'all' || activeFilter === 'attendance') {
    workerAtt.forEach(a => {
      const rate = a.dailyRate ?? worker.dailyRate ?? 0;
      const earned = a.earned ?? (rate * (a.status === 'present' ? 1 : a.status === 'half' ? 0.5 : 0));
      timeline.push({
        id: a.id || `att-${a.date}`,
        type: 'attendance',
        date: a.date,
        status: a.status,
        rate,
        amount: earned,
        data: a
      });
    });
  }

  if (activeFilter === 'all' || activeFilter === 'payments') {
    workerPayouts.forEach(p => {
      timeline.push({
        id: p.id || `pay-${p.date}`,
        type: 'payout',
        date: p.date,
        method: p.method,
        purpose: p.purpose || 'advance',
        amount: p.amount,
        split: p.split,
        ref: p.ref,
        note: p.note,
        void: Boolean(p.void),
        data: p
      });
    });
  }

  timeline.sort((a, b) => (b.date || '').localeCompare(a.date || ''));

  return (
    <View
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(15, 23, 42, 0.48)',
        zIndex: 9998,
        justifyContent: 'flex-end',
        alignItems: isDesktop ? 'center' : 'stretch',
        ...(isDesktop ? { justifyContent: 'center', padding: 20 } : {})
      }}
    >
      <Pressable
        onPress={onClose}
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0
        }}
      />

      <View
        style={{
          backgroundColor: '#FAF9F6',
          borderTopLeftRadius: isDesktop ? 22 : 26,
          borderTopRightRadius: isDesktop ? 22 : 26,
          borderBottomLeftRadius: isDesktop ? 22 : 0,
          borderBottomRightRadius: isDesktop ? 22 : 0,
          width: isDesktop ? 600 : '100%',
          maxHeight: '94%',
          paddingBottom: Platform.OS === 'ios' ? 36 : 18,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: -4 },
          shadowOpacity: 0.14,
          shadowRadius: 18,
          elevation: 24
        }}
      >
        {/* Drag Handle */}
        <View style={{ alignItems: 'center', paddingTop: 10, paddingBottom: 6 }}>
          <View style={{ width: 42, height: 4.5, borderRadius: 3, backgroundColor: '#D1D5DB' }} />
        </View>

        {/* Modal Header */}
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            paddingHorizontal: 20,
            paddingVertical: 12,
            borderBottomWidth: 1,
            borderColor: '#EFEFEA'
          }}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 11, flex: 1 }}>
            {/* Avatar with yellow hardhat icon badge */}
            <View style={{ position: 'relative' }}>
              <View
                style={{
                  width: 42,
                  height: 42,
                  borderRadius: 21,
                  backgroundColor: '#1E293B',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                <T style={{ fontSize: 16, fontWeight: '800', color: '#F8FAFC' }}>
                  {(worker.name || 'W')[0]?.toUpperCase()}
                </T>
              </View>
              <View
                style={{
                  position: 'absolute',
                  bottom: -2,
                  right: -2,
                  backgroundColor: '#FFD500',
                  borderRadius: 8,
                  width: 17,
                  height: 17,
                  alignItems: 'center',
                  justifyContent: 'center',
                  borderWidth: 1.5,
                  borderColor: '#FAF9F6'
                }}
              >
                <I name="construct" size={10} color="#171817" />
              </View>
            </View>

            <View style={{ flex: 1 }}>
              <T numberOfLines={1} style={{ fontSize: 17, fontWeight: '800', color: '#171817' }}>
                {worker.name} • {t.workerBtnLedger || 'కూలి లెక్కలు'}
              </T>
              <T numberOfLines={1} style={{ fontSize: 12, color: '#667085', marginTop: 1 }}>
                {worker.role} • రోజు ₹{worker.dailyRate}
              </T>
            </View>
          </View>

          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Menu"
              onPress={() => setMenuOpen(!menuOpen)}
              style={{
                width: 32,
                height: 32,
                borderRadius: 16,
                backgroundColor: '#ECEAE4',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              <I name="ellipsis-vertical" size={16} color="#4B5563" />
            </Pressable>

            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Close"
              onPress={onClose}
              hitSlop={10}
              style={{
                width: 32,
                height: 32,
                borderRadius: 16,
                backgroundColor: '#ECEAE4',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              <I name="close" size={17} color="#4B5563" />
            </Pressable>
          </View>
        </View>

        {/* Overflow Menu Dropdown */}
        {menuOpen && (
          <View
            style={{
              position: 'absolute',
              top: 56,
              right: 20,
              backgroundColor: '#FFFFFF',
              borderRadius: 12,
              padding: 6,
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 4 },
              shadowOpacity: 0.15,
              shadowRadius: 12,
              elevation: 10,
              zIndex: 100,
              borderWidth: 1,
              borderColor: '#E5E7EB',
              width: 170
            }}
          >
            <Pressable
              onPress={() => {
                setMenuOpen(false);
                onEditWorker(worker);
              }}
              style={{ paddingVertical: 8, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 8 }}
            >
              <I name="create-outline" size={15} color="#171817" />
              <T style={{ fontSize: 13, fontWeight: '600', color: '#171817' }}>
                {t.ledgerBtnEditWorker || 'సవరించండి'}
              </T>
            </Pressable>
            <Pressable
              onPress={() => {
                setMenuOpen(false);
                onOpenPayment(worker);
              }}
              style={{ paddingVertical: 8, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 8 }}
            >
              <I name="wallet-outline" size={15} color="#171817" />
              <T style={{ fontSize: 13, fontWeight: '600', color: '#171817' }}>
                {t.ledgerBtnNewPayment || '+ కొత్త చెల్లింపు'}
              </T>
            </Pressable>
          </View>
        )}

        <ScrollView
          style={{ paddingHorizontal: 20 }}
          contentContainerStyle={{ paddingTop: 14, paddingBottom: 16 }}
          showsVerticalScrollIndicator={false}
        >
          {/* 3 Summary KPI Cards matching screenshot media_1792056618807_ab53cca6.png */}
          <View style={{ gap: 8, marginBottom: 16 }}>
            {/* Card 1: Days Worked */}
            <View
              style={{
                backgroundColor: '#FFFFFF',
                borderRadius: 14,
                padding: 12,
                borderWidth: 1,
                borderColor: '#EFEFEA',
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between'
              }}
            >
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 9 }}>
                <View
                  style={{
                    width: 34,
                    height: 34,
                    borderRadius: 10,
                    backgroundColor: '#EFF6FF',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  <I name="calendar-outline" size={17} color="#2563EB" />
                </View>
                <View>
                  <T style={{ fontSize: 11, color: '#64748B', fontWeight: '600' }}>
                    {t.ledgerCardDays || 'పని చేసిన రోజులు'}
                  </T>
                  <T style={{ fontSize: 13.5, fontWeight: '800', color: '#171817' }}>
                    {effectiveDays} రోజులు × ₹{worker.dailyRate}
                  </T>
                </View>
              </View>
              <T style={{ fontSize: 15, fontWeight: '900', color: '#171817' }}>
                {money(totalEarned)}
              </T>
            </View>

            {/* Card 2: Advance Paid */}
            <View
              style={{
                backgroundColor: '#FFFFFF',
                borderRadius: 14,
                padding: 12,
                borderWidth: 1,
                borderColor: '#EFEFEA',
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between'
              }}
            >
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 9 }}>
                <View
                  style={{
                    width: 34,
                    height: 34,
                    borderRadius: 10,
                    backgroundColor: '#ECFDF5',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  <I name="briefcase-outline" size={17} color="#059669" />
                </View>
                <View>
                  <T style={{ fontSize: 11, color: '#64748B', fontWeight: '600' }}>
                    {t.ledgerCardAdvance || 'అడ్వాన్స్ ఇచ్చింది'}
                  </T>
                  <T style={{ fontSize: 13.5, fontWeight: '800', color: '#065F46' }}>
                    {activePayouts.length} చెల్లింపులు
                  </T>
                </View>
              </View>
              <T style={{ fontSize: 15, fontWeight: '900', color: '#059669' }}>
                {money(totalPaid)}
              </T>
            </View>

            {/* Card 3: Balance Due */}
            <View
              style={{
                backgroundColor: isDue && balance > 0 ? '#FEF9C3' : '#F1F5F9',
                borderRadius: 14,
                padding: 12,
                borderWidth: 1.2,
                borderColor: isDue && balance > 0 ? '#FDE047' : '#E2E8F0',
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between'
              }}
            >
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 9 }}>
                <View
                  style={{
                    width: 34,
                    height: 34,
                    borderRadius: 10,
                    backgroundColor: isDue && balance > 0 ? '#FEF08A' : '#E2E8F0',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  <I name="wallet-outline" size={17} color={isDue && balance > 0 ? '#854D0E' : '#475569'} />
                </View>
                <View>
                  <T style={{ fontSize: 11, color: isDue && balance > 0 ? '#854D0E' : '#64748B', fontWeight: '700' }}>
                    {isDue ? (balance > 0 ? (t.ledgerCardDue || 'ఇంకా ఇవ్వాలి') : 'పూర్తిగా క్లియర్') : 'అడ్వాన్స్ మిగిలినది'}
                  </T>
                  <T style={{ fontSize: 13, fontWeight: '700', color: '#171817' }}>
                    {isDue && balance > 0 ? 'బకాయి మొత్తం' : 'క్లియర్ చేయబడింది'}
                  </T>
                </View>
              </View>
              <T style={{ fontSize: 17, fontWeight: '900', color: isDue ? (balance > 0 ? '#B45309' : '#059669') : '#2563EB' }}>
                {money(Math.abs(balance))}
              </T>
            </View>
          </View>

          {/* Filter Pills */}
          <View style={{ flexDirection: 'row', gap: 6, marginBottom: 12 }}>
            {[
              { id: 'all', label: `అన్నీ (${timeline.length})` },
              { id: 'attendance', label: `హాజరు (${workerAtt.length})` },
              { id: 'payments', label: `చెల్లింపులు (${workerPayouts.length})` }
            ].map(f => {
              const active = activeFilter === f.id;
              return (
                <Pressable
                  key={f.id}
                  onPress={() => setActiveFilter(f.id)}
                  style={{
                    paddingHorizontal: 12,
                    paddingVertical: 6,
                    borderRadius: 16,
                    backgroundColor: active ? '#171817' : '#FFFFFF',
                    borderWidth: 1,
                    borderColor: active ? '#171817' : '#E5E7EB'
                  }}
                >
                  <T style={{ fontSize: 11.5, fontWeight: active ? '700' : '500', color: active ? '#FFFFFF' : '#4B5563' }}>
                    {f.label}
                  </T>
                </Pressable>
              );
            })}
          </View>

          {/* Timeline List */}
          {timeline.length > 0 ? (
            <View style={{ gap: 8, marginBottom: 16 }}>
              {timeline.map((item, idx) => {
                if (item.type === 'payout') {
                  const isVoid = item.void;
                  return (
                    <View
                      key={item.id}
                      style={{
                        backgroundColor: '#FFFFFF',
                        borderRadius: 12,
                        padding: 11,
                        borderWidth: 1,
                        borderColor: isVoid ? '#FECACA' : '#EFEFEA',
                        opacity: isVoid ? 0.6 : 1
                      }}
                    >
                      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                          <View
                            style={{
                              width: 28,
                              height: 28,
                              borderRadius: 8,
                              backgroundColor: '#ECFDF5',
                              alignItems: 'center',
                              justifyContent: 'center'
                            }}
                          >
                            <I name="wallet" size={14} color="#059669" />
                          </View>
                          <View>
                            <T style={{ fontSize: 13, fontWeight: '700', color: '#171817' }}>
                              {formatTeluguDate(item.date, appLang)} • {item.purpose === 'wage' ? 'కూలి' : 'అడ్వాన్స్'}
                            </T>
                            <T style={{ fontSize: 11, color: '#64748B' }}>
                              {item.method} {item.split ? `(Cash ₹${item.split.cash} + UPI ₹${item.split.upi})` : ''}
                              {item.ref ? ` • Ref: ${item.ref}` : ''}
                            </T>
                          </View>
                        </View>

                        <View style={{ alignItems: 'flex-end' }}>
                          <T style={{ fontSize: 14, fontWeight: '800', color: isVoid ? '#9CA3AF' : '#059669', textDecorationLine: isVoid ? 'line-through' : 'none' }}>
                            {money(item.amount)}
                          </T>
                          {onVoidPayout && (
                            <Pressable
                              onPress={() => onVoidPayout(item.data)}
                              hitSlop={6}
                              style={{ marginTop: 2 }}
                            >
                              <T style={{ fontSize: 10, color: isVoid ? '#2563EB' : '#DC2626', fontWeight: '600' }}>
                                {isVoid ? 'పునరుద్ధరించు' : 'రద్దు చేయి'}
                              </T>
                            </Pressable>
                          )}
                        </View>
                      </View>
                      {!!item.note && (
                        <T style={{ fontSize: 11, color: '#6B7280', marginTop: 4, paddingLeft: 36 }}>
                          "{item.note}"
                        </T>
                      )}
                    </View>
                  );
                }

                // Attendance item
                const isPres = item.status === 'present';
                const isHalf = item.status === 'half';
                return (
                  <View
                    key={item.id}
                    style={{
                      backgroundColor: '#FFFFFF',
                      borderRadius: 12,
                      padding: 11,
                      borderWidth: 1,
                      borderColor: '#EFEFEA'
                    }}
                  >
                    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                        <View
                          style={{
                            width: 28,
                            height: 28,
                            borderRadius: 8,
                            backgroundColor: isPres ? '#ECFDF5' : isHalf ? '#FFFBEB' : '#FEF2F2',
                            alignItems: 'center',
                            justifyContent: 'center'
                          }}
                        >
                          <I
                            name={isPres ? 'checkmark' : isHalf ? 'time' : 'close'}
                            size={14}
                            color={isPres ? '#059669' : isHalf ? '#D97706' : '#DC2626'}
                          />
                        </View>
                        <View>
                          <T style={{ fontSize: 13, fontWeight: '700', color: '#171817' }}>
                            {formatTeluguDate(item.date, appLang)}
                          </T>
                          <T style={{ fontSize: 11, color: '#64748B' }}>
                            {isPres ? '✓ పూర్తి రోజు' : isHalf ? '◐ సగం రోజు' : '✕ రాలేదు'} • రేటు ₹{item.rate}/రోజు
                          </T>
                        </View>
                      </View>

                      <T style={{ fontSize: 14, fontWeight: '800', color: isPres || isHalf ? '#171817' : '#9CA3AF' }}>
                        {money(item.amount)}
                      </T>
                    </View>
                  </View>
                );
              })}
            </View>
          ) : (
            <View style={{ padding: 24, alignItems: 'center', backgroundColor: '#FFFFFF', borderRadius: 14, borderWidth: 1, borderColor: '#EFEFEA', marginBottom: 16 }}>
              <I name="calendar-outline" size={32} color="#9CA3AF" />
              <T style={{ fontSize: 14, fontWeight: '700', color: '#4B5563', marginTop: 8 }}>
                {t.ledgerEmpty || 'ఇంకా ఎటువంటి రికార్డులు లేవు'}
              </T>
            </View>
          )}

          {/* Quick Pay Action Button */}
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={t.workerBtnPay}
            disabled={busy}
            onPress={() => onOpenPayment(worker)}
            style={({ pressed }) => [{
              backgroundColor: '#FFD500',
              borderRadius: 14,
              paddingVertical: 14,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 8,
              shadowColor: '#CA8A04',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.16,
              shadowRadius: 4,
              elevation: 2,
              opacity: pressed || busy ? 0.8 : 1
            }]}
          >
            <I name="wallet" size={17} color="#171817" />
            <T style={{ fontSize: 15, fontWeight: '800', color: '#171817' }}>
              {t.ledgerBtnNewPayment || '+ కొత్త చెల్లింపు'}
            </T>
          </Pressable>
        </ScrollView>
      </View>
    </View>
  );
}
