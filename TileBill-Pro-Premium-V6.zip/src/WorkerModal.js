import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Platform,
  useWindowDimensions
} from 'react-native';
import { I, T } from './ui';
import { getStrings } from './i18n';

export default function WorkerModal({
  visible,
  initial = null,
  w,
  service,
  busy,
  appLang = 'te',
  onClose,
  onSave
}) {
  if (!visible) return null;

  const t = getStrings(appLang);
  const isEdit = Boolean(initial?.id);
  const { width } = useWindowDimensions();
  const isDesktop = width >= 768;

  const [name, setName] = useState(initial?.name || '');
  const [phone, setPhone] = useState(initial?.phone || '');
  const [role, setRole] = useState(initial?.role || t.workerRoleHelper || 'Helper');
  const [pattern, setPattern] = useState(initial?.pattern || 'regular'); // 'regular' | 'occasional'
  const [dailyWage, setDailyWage] = useState(String(initial?.dailyRate ?? (appLang === 'te' ? '800' : '800')));
  const [projectId, setProjectId] = useState(initial?.projectId || '');
  const [notes, setNotes] = useState(initial?.notes || '');
  const [err, setErr] = useState('');

  const roles = [
    { id: 'painter', label: t.workerRolePainter || 'Painter' },
    { id: 'helper', label: t.workerRoleHelper || 'Helper' },
    { id: 'tile', label: t.workerRoleTileWorker || 'Tile Worker' },
    { id: 'mason', label: t.workerRoleMason || 'Mason' },
    { id: 'plumber', label: t.workerRolePlumber || 'Plumber' },
    { id: 'electrician', label: t.workerRoleElectrician || 'Electrician' },
    { id: 'carpenter', label: t.workerRoleCarpenter || 'Carpenter' },
    { id: 'other', label: t.workerRoleOther || 'Other' }
  ];

  const projects = (w?.projects || []).filter(p => !service || p.service === service);

  const handleSave = async () => {
    if (!name.trim()) {
      setErr(appLang === 'te' ? 'పని మనిషి పేరు నమోదు చేయండి' : appLang === 'hi' ? 'मजदूर का नाम दर्ज करें' : 'Please enter worker name');
      return;
    }
    const wageNum = parseFloat(dailyWage) || 0;
    if (wageNum <= 0) {
      setErr(appLang === 'te' ? 'చెల్లుబాటు అయ్యే రోజు కూలి నమోదు చేయండి' : appLang === 'hi' ? 'मान्य दैनिक मजदूरी दर्ज करें' : 'Please enter a valid daily wage');
      return;
    }
    setErr('');
    await onSave({
      id: initial?.id,
      name: name.trim(),
      phone: phone.trim(),
      role,
      pattern,
      dailyRate: wageNum,
      projectId: projectId || '',
      notes: notes.trim(),
      service
    });
  };

  return (
    <View
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(15, 23, 42, 0.45)',
        zIndex: 9999,
        justifyContent: 'flex-end',
        alignItems: isDesktop ? 'center' : 'stretch',
        ...(isDesktop ? { justifyContent: 'center', padding: 20 } : {})
      }}
    >
      <Pressable
        onPress={onClose}
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0
        }}
      />

      <View
        style={{
          backgroundColor: '#FAF9F6',
          borderTopLeftRadius: isDesktop ? 20 : 24,
          borderTopRightLeft: isDesktop ? 20 : 24,
          borderTopRightRadius: isDesktop ? 20 : 24,
          borderBottomLeftRadius: isDesktop ? 20 : 0,
          borderBottomRightRadius: isDesktop ? 20 : 0,
          width: isDesktop ? 540 : '100%',
          maxHeight: '92%',
          paddingBottom: Platform.OS === 'ios' ? 36 : 20,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: -4 },
          shadowOpacity: 0.12,
          shadowRadius: 16,
          elevation: 20
        }}
      >
        {/* Handle */}
        <View style={{ alignItems: 'center', paddingTop: 10, paddingBottom: 4 }}>
          <View style={{ width: 42, height: 4.5, borderRadius: 3, backgroundColor: '#D1D5DB' }} />
        </View>

        {/* Header */}
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            paddingHorizontal: 20,
            paddingVertical: 12,
            borderBottomWidth: 1,
            borderColor: '#EFEFEA'
          }}
        >
          <View style={{ flex: 1 }}>
            <T style={{ fontSize: 18, fontWeight: '800', color: '#171817' }}>
              {isEdit ? t.workerModalEditTitle : t.workerModalAddTitle}
            </T>
            <T style={{ fontSize: 12, color: '#667085', marginTop: 2 }}>
              {t.workerModalSub}
            </T>
          </View>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Close"
            onPress={onClose}
            hitSlop={10}
            style={{
              width: 32,
              height: 32,
              borderRadius: 16,
              backgroundColor: '#ECEAE4',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            <I name="close" size={17} color="#4B5563" />
          </Pressable>
        </View>

        <ScrollView
          style={{ paddingHorizontal: 20 }}
          contentContainerStyle={{ paddingTop: 14, paddingBottom: 16 }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {err ? (
            <View style={{ backgroundColor: '#FEE2E2', borderWidth: 1, borderColor: '#FCA5A5', padding: 10, borderRadius: 10, marginBottom: 12 }}>
              <T style={{ fontSize: 12.5, color: '#B91C1C', fontWeight: '600' }}>{err}</T>
            </View>
          ) : null}

          {/* Worker Name */}
          <View style={{ marginBottom: 14 }}>
            <T style={{ fontSize: 12.5, fontWeight: '700', color: '#374151', marginBottom: 5 }}>
              {t.workerNameLabel}
            </T>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                backgroundColor: '#FFFFFF',
                borderWidth: 1.2,
                borderColor: '#E5E7EB',
                borderRadius: 12,
                paddingHorizontal: 12,
                height: 46
              }}
            >
              <I name="person-outline" size={17} color="#9CA3AF" />
              <TextInput
                accessibilityLabel={t.workerNameLabel}
                placeholder={t.workerNamePlaceholder}
                placeholderTextColor="#9CA3AF"
                value={name}
                onChangeText={setName}
                style={{ flex: 1, marginLeft: 8, fontSize: 14.5, color: '#171817', ...(Platform.OS === 'web' ? { outlineStyle: 'none' } : {}) }}
              />
            </View>
          </View>

          {/* Mobile Number */}
          <View style={{ marginBottom: 14 }}>
            <T style={{ fontSize: 12.5, fontWeight: '700', color: '#374151', marginBottom: 5 }}>
              {t.workerPhoneLabel}
            </T>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                backgroundColor: '#FFFFFF',
                borderWidth: 1.2,
                borderColor: '#E5E7EB',
                borderRadius: 12,
                paddingHorizontal: 12,
                height: 46
              }}
            >
              <I name="call-outline" size={17} color="#9CA3AF" />
              <TextInput
                accessibilityLabel={t.workerPhoneLabel}
                placeholder={t.workerPhonePlaceholder}
                placeholderTextColor="#9CA3AF"
                value={phone}
                onChangeText={setPhone}
                keyboardType="phone-pad"
                maxLength={10}
                style={{ flex: 1, marginLeft: 8, fontSize: 14.5, color: '#171817', ...(Platform.OS === 'web' ? { outlineStyle: 'none' } : {}) }}
              />
            </View>
          </View>

          {/* Role / Trade Chips */}
          <View style={{ marginBottom: 14 }}>
            <T style={{ fontSize: 12.5, fontWeight: '700', color: '#374151', marginBottom: 7 }}>
              {t.workerRoleLabel}
            </T>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 7 }}>
              {roles.map(r => {
                const active = role.toLowerCase() === r.label.toLowerCase() || role.toLowerCase() === r.id;
                return (
                  <Pressable
                    key={r.id}
                    onPress={() => setRole(r.label)}
                    style={{
                      paddingHorizontal: 12,
                      paddingVertical: 7,
                      borderRadius: 10,
                      backgroundColor: active ? '#171817' : '#FFFFFF',
                      borderWidth: 1,
                      borderColor: active ? '#171817' : '#E5E7EB'
                    }}
                  >
                    <T style={{ fontSize: 12.5, fontWeight: active ? '700' : '600', color: active ? '#FFFFFF' : '#374151' }}>
                      {r.label}
                    </T>
                  </Pressable>
                );
              })}
            </View>
          </View>

          {/* Attendance Pattern (Regular vs Occasional) */}
          <View style={{ marginBottom: 14 }}>
            <T style={{ fontSize: 12.5, fontWeight: '700', color: '#374151', marginBottom: 7 }}>
              {t.workerPatternLabel}
            </T>
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <Pressable
                onPress={() => setPattern('regular')}
                style={{
                  flex: 1,
                  padding: 11,
                  borderRadius: 12,
                  backgroundColor: pattern === 'regular' ? '#FEF9C3' : '#FFFFFF',
                  borderWidth: 1.5,
                  borderColor: pattern === 'regular' ? '#EAB308' : '#E5E7EB'
                }}
              >
                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 3 }}>
                  <T style={{ fontSize: 13.5, fontWeight: '800', color: '#171817' }}>
                    {t.workerPatternRegular}
                  </T>
                  {pattern === 'regular' && <I name="checkmark-circle" size={16} color="#854D0E" />}
                </View>
                <T style={{ fontSize: 11, color: '#667085', lineHeight: 14 }}>
                  {t.workerPatternRegularDesc}
                </T>
              </Pressable>

              <Pressable
                onPress={() => setPattern('occasional')}
                style={{
                  flex: 1,
                  padding: 11,
                  borderRadius: 12,
                  backgroundColor: pattern === 'occasional' ? '#FEF9C3' : '#FFFFFF',
                  borderWidth: 1.5,
                  borderColor: pattern === 'occasional' ? '#EAB308' : '#E5E7EB'
                }}
              >
                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 3 }}>
                  <T style={{ fontSize: 13.5, fontWeight: '800', color: '#171817' }}>
                    {t.workerPatternOccasional}
                  </T>
                  {pattern === 'occasional' && <I name="checkmark-circle" size={16} color="#854D0E" />}
                </View>
                <T style={{ fontSize: 11, color: '#667085', lineHeight: 14 }}>
                  {t.workerPatternOccasionalDesc}
                </T>
              </Pressable>
            </View>
          </View>

          {/* Daily Wage Rate */}
          <View style={{ marginBottom: 14 }}>
            <T style={{ fontSize: 12.5, fontWeight: '700', color: '#374151', marginBottom: 5 }}>
              {t.workerWageLabel}
            </T>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                backgroundColor: '#FFFFFF',
                borderWidth: 1.2,
                borderColor: '#E5E7EB',
                borderRadius: 12,
                paddingHorizontal: 12,
                height: 48
              }}
            >
              <T style={{ fontSize: 16, fontWeight: '800', color: '#171817', marginRight: 4 }}>₹</T>
              <TextInput
                accessibilityLabel={t.workerWageLabel}
                placeholder={t.workerWagePlaceholder}
                placeholderTextColor="#9CA3AF"
                value={dailyWage}
                onChangeText={setDailyWage}
                keyboardType="numeric"
                style={{ flex: 1, fontSize: 16, fontWeight: '700', color: '#171817', ...(Platform.OS === 'web' ? { outlineStyle: 'none' } : {}) }}
              />
              <T style={{ fontSize: 12, color: '#6B7280', fontWeight: '600' }}>/ day</T>
            </View>
            {isEdit && (
              <T style={{ fontSize: 11, color: '#6B7280', marginTop: 4 }}>
                {appLang === 'te'
                  ? 'గమనిక: కొత్త రేటు భవిష్యత్ హాజరులకు మాత్రమే వర్తిస్తుంది; గత రికార్డులు మారవు.'
                  : 'Note: Rate updates apply to future attendance; historical wage records remain unchanged.'}
              </T>
            )}
          </View>

          {/* Assigned Project / Site */}
          {projects.length > 0 && (
            <View style={{ marginBottom: 14 }}>
              <T style={{ fontSize: 12.5, fontWeight: '700', color: '#374151', marginBottom: 6 }}>
                {t.workerSiteLabel}
              </T>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexDirection: 'row' }}>
                <Pressable
                  onPress={() => setProjectId('')}
                  style={{
                    paddingHorizontal: 12,
                    paddingVertical: 7,
                    borderRadius: 10,
                    marginRight: 6,
                    backgroundColor: !projectId ? '#171817' : '#FFFFFF',
                    borderWidth: 1,
                    borderColor: !projectId ? '#171817' : '#E5E7EB'
                  }}
                >
                  <T style={{ fontSize: 12, fontWeight: !projectId ? '700' : '500', color: !projectId ? '#FFFFFF' : '#374151' }}>
                    {appLang === 'te' ? 'సైట్ ఏదీ లేదు' : 'None / All'}
                  </T>
                </Pressable>
                {projects.map(p => {
                  const active = projectId === p.id;
                  return (
                    <Pressable
                      key={p.id}
                      onPress={() => setProjectId(p.id)}
                      style={{
                        paddingHorizontal: 12,
                        paddingVertical: 7,
                        borderRadius: 10,
                        marginRight: 6,
                        backgroundColor: active ? '#171817' : '#FFFFFF',
                        borderWidth: 1,
                        borderColor: active ? '#171817' : '#E5E7EB'
                      }}
                    >
                      <T style={{ fontSize: 12, fontWeight: active ? '700' : '500', color: active ? '#FFFFFF' : '#374151' }}>
                        {p.name}
                      </T>
                    </Pressable>
                  );
                })}
              </ScrollView>
            </View>
          )}

          {/* Notes */}
          <View style={{ marginBottom: 18 }}>
            <T style={{ fontSize: 12.5, fontWeight: '700', color: '#374151', marginBottom: 5 }}>
              {t.workerNotesLabel}
            </T>
            <View
              style={{
                backgroundColor: '#FFFFFF',
                borderWidth: 1.2,
                borderColor: '#E5E7EB',
                borderRadius: 12,
                paddingHorizontal: 12,
                paddingVertical: 8,
                minHeight: 64
              }}
            >
              <TextInput
                accessibilityLabel={t.workerNotesLabel}
                placeholder={t.workerNotesPlaceholder}
                placeholderTextColor="#9CA3AF"
                value={notes}
                onChangeText={setNotes}
                multiline
                numberOfLines={2}
                style={{ fontSize: 13.5, color: '#171817', ...(Platform.OS === 'web' ? { outlineStyle: 'none' } : {}) }}
              />
            </View>
          </View>

          {/* Save Button */}
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={t.workerBtnSave}
            disabled={busy}
            onPress={handleSave}
            style={({ pressed }) => [{
              backgroundColor: '#FFD500',
              borderRadius: 14,
              paddingVertical: 14,
              alignItems: 'center',
              justifyContent: 'center',
              shadowColor: '#CA8A04',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.15,
              shadowRadius: 4,
              elevation: 2,
              opacity: pressed || busy ? 0.85 : 1
            }]}
          >
            <T style={{ fontSize: 15, fontWeight: '800', color: '#171817' }}>
              {busy ? (appLang === 'te' ? 'సేవ్ అవుతోంది…' : 'Saving…') : t.workerBtnSave}
            </T>
          </Pressable>
        </ScrollView>
      </View>
    </View>
  );
}
