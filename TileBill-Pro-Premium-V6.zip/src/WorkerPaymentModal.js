import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Platform,
  useWindowDimensions
} from 'react-native';
import { I, T } from './ui';
import { money } from './domain.cjs';
import { getStrings } from './i18n';
import { formatTeluguDate } from './CustomersPage';

export default function WorkerPaymentModal({
  visible,
  worker,
  w,
  service,
  busy,
  appLang = 'te',
  onClose,
  onSave
}) {
  if (!visible || !worker) return null;

  const t = getStrings(appLang);
  const { width } = useWindowDimensions();
  const isDesktop = width >= 768;

  // Calculate worker's financial baseline
  const workerAtt = (w?.attendance || []).filter(a => a.workerId === worker.id);
  const workerPayouts = (w?.payouts || []).filter(p => p.workerId === worker.id && !p.void);

  const totalEarned = workerAtt.reduce((sum, a) => {
    const rate = a.dailyRate ?? worker.dailyRate ?? 0;
    return sum + (a.earned ?? (rate * (a.status === 'present' ? 1 : a.status === 'half' ? 0.5 : 0)));
  }, 0);

  const totalPaid = workerPayouts.reduce((sum, p) => sum + (p.amount || 0), 0);
  const previousBalance = totalEarned - totalPaid;

  // Form State
  const [amountStr, setAmountStr] = useState('1000');
  const [method, setMethod] = useState('Split'); // 'Cash' | 'UPI' | 'Split'
  const [cashStr, setCashStr] = useState('400');
  const [upiStr, setUpiStr] = useState('600');
  const [purpose, setPurpose] = useState('advance'); // 'advance' | 'wage'
  const [upiRef, setUpiRef] = useState('');
  const [payDate, setPayDate] = useState(() => {
    try {
      return new Date().toISOString().slice(0, 10);
    } catch {
      return '2026-10-15';
    }
  });
  const [showNote, setShowNote] = useState(false);
  const [note, setNote] = useState('');
  const [err, setErr] = useState('');

  // Auto-balance Split when total amount changes if in Split mode
  const currentTotal = parseFloat(amountStr) || 0;
  const currentCash = parseFloat(cashStr) || 0;
  const currentUpi = parseFloat(upiStr) || 0;

  const isSplitMatch = method !== 'Split' || Math.abs(currentCash + currentUpi - currentTotal) < 0.01;
  const splitDiff = Math.abs(currentCash + currentUpi - currentTotal);

  // Impact Preview
  const remainingAfterPayment = previousBalance - currentTotal;
  const isDueAfter = remainingAfterPayment >= 0;

  const handleTotalChange = (val) => {
    setAmountStr(val);
    const n = parseFloat(val) || 0;
    if (method === 'Split') {
      // Default to 40% cash, 60% upi or clean split
      const c = Math.round(n * 0.4);
      const u = n - c;
      setCashStr(String(c > 0 ? c : 0));
      setUpiStr(String(u > 0 ? u : 0));
    }
  };

  const handleCashChange = (val) => {
    setCashStr(val);
    const c = parseFloat(val) || 0;
    const remaining = Math.max(0, currentTotal - c);
    setUpiStr(String(remaining));
  };

  const handleUpiChange = (val) => {
    setUpiStr(val);
    const u = parseFloat(val) || 0;
    const remaining = Math.max(0, currentTotal - u);
    setCashStr(String(remaining));
  };

  const handleSavePayment = async () => {
    if (currentTotal <= 0) {
      setErr(appLang === 'te' ? 'దయచేసి చెల్లుబాటు అయ్యే మొత్తం నమోదు చేయండి' : 'Please enter a valid payment amount');
      return;
    }
    if (method === 'Split' && !isSplitMatch) {
      setErr(appLang === 'te' ? 'Cash మరియు UPI మొత్తం కలిసి మొత్తం చెల్లింపునకు సమానంగా ఉండాలి' : 'Cash and UPI amounts must equal total amount');
      return;
    }

    setErr('');
    await onSave({
      workerId: worker.id,
      service,
      date: payDate,
      amount: currentTotal,
      purpose,
      method,
      split: method === 'Split' ? { cash: currentCash, upi: currentUpi } : null,
      ref: upiRef.trim(),
      note: note.trim()
    });
  };

  return (
    <View
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(15, 23, 42, 0.48)',
        zIndex: 9999,
        justifyContent: 'flex-end',
        alignItems: isDesktop ? 'center' : 'stretch',
        ...(isDesktop ? { justifyContent: 'center', padding: 20 } : {})
      }}
    >
      <Pressable
        onPress={onClose}
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0
        }}
      />

      <View
        style={{
          backgroundColor: '#FAF9F6',
          borderTopLeftRadius: isDesktop ? 22 : 26,
          borderTopRightRadius: isDesktop ? 22 : 26,
          borderBottomLeftRadius: isDesktop ? 22 : 0,
          borderBottomRightRadius: isDesktop ? 22 : 0,
          width: isDesktop ? 520 : '100%',
          maxHeight: '94%',
          paddingBottom: Platform.OS === 'ios' ? 36 : 18,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: -4 },
          shadowOpacity: 0.14,
          shadowRadius: 18,
          elevation: 24
        }}
      >
        {/* Drag Handle */}
        <View style={{ alignItems: 'center', paddingTop: 10, paddingBottom: 6 }}>
          <View style={{ width: 42, height: 4.5, borderRadius: 3, backgroundColor: '#D1D5DB' }} />
        </View>

        {/* Modal Header */}
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            paddingHorizontal: 20,
            paddingVertical: 10,
            borderBottomWidth: 1,
            borderColor: '#EFEFEA'
          }}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 11, flex: 1 }}>
            <View
              style={{
                width: 38,
                height: 38,
                borderRadius: 12,
                backgroundColor: '#FEF9C3',
                borderWidth: 1,
                borderColor: '#FDE047',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              <I name="receipt-outline" size={20} color="#854D0E" />
            </View>
            <View style={{ flex: 1 }}>
              <T style={{ fontSize: 17.5, fontWeight: '800', color: '#171817' }}>
                {t.payModalTitle || 'చెల్లింపు నమోదు'}
              </T>
              <T numberOfLines={1} style={{ fontSize: 12, color: '#667085', marginTop: 1 }}>
                {t.payModalSub || 'ఈ కార్మికుడికి ఇచ్చిన డబ్బును నమోదు చేయండి'}
              </T>
            </View>
          </View>

          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Close"
            onPress={onClose}
            hitSlop={10}
            style={{
              width: 32,
              height: 32,
              borderRadius: 16,
              backgroundColor: '#ECEAE4',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            <I name="close" size={17} color="#4B5563" />
          </Pressable>
        </View>

        <ScrollView
          style={{ paddingHorizontal: 20 }}
          contentContainerStyle={{ paddingTop: 14, paddingBottom: 16 }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {err ? (
            <View style={{ backgroundColor: '#FEE2E2', borderWidth: 1, borderColor: '#FCA5A5', padding: 10, borderRadius: 10, marginBottom: 12 }}>
              <T style={{ fontSize: 12.5, color: '#B91C1C', fontWeight: '600' }}>{err}</T>
            </View>
          ) : null}

          {/* Worker Context Card */}
          <View
            style={{
              backgroundColor: '#FFFFFF',
              borderRadius: 12,
              padding: 10,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: 14,
              borderWidth: 1,
              borderColor: '#EFEFEA'
            }}
          >
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 9 }}>
              <View
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: 16,
                  backgroundColor: '#EFF6FF',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                <T style={{ fontSize: 13, fontWeight: '800', color: '#2563EB' }}>
                  {(worker.name || 'W')[0]?.toUpperCase()}
                </T>
              </View>
              <View>
                <T style={{ fontSize: 14, fontWeight: '700', color: '#171817' }}>{worker.name}</T>
                <T style={{ fontSize: 11.5, color: '#667085' }}>{worker.role} • రోజు ₹{worker.dailyRate}</T>
              </View>
            </View>

            <View style={{ alignItems: 'flex-end' }}>
              <T style={{ fontSize: 10.5, color: '#667085' }}>
                {previousBalance >= 0 ? (appLang === 'te' ? 'ఇవ్వాల్సిన బాకీ' : 'Current Due') : (appLang === 'te' ? 'అడ్వాన్స్ ఉంది' : 'Advance Paid')}
              </T>
              <T style={{ fontSize: 13.5, fontWeight: '800', color: previousBalance > 0 ? '#B45309' : '#059669' }}>
                {money(Math.abs(previousBalance))}
              </T>
            </View>
          </View>

          {/* Amount Input */}
          <View style={{ marginBottom: 16 }}>
            <T style={{ fontSize: 12.5, fontWeight: '700', color: '#374151', marginBottom: 6 }}>
              {t.payAmountLabel || 'చెల్లింపు మొత్తం'}
            </T>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                backgroundColor: '#FFFFFF',
                borderWidth: 1.5,
                borderColor: '#E5E7EB',
                borderRadius: 14,
                paddingHorizontal: 16,
                height: 56
              }}
            >
              <T style={{ fontSize: 24, fontWeight: '900', color: '#171817', marginRight: 6 }}>₹</T>
              <TextInput
                accessibilityLabel="Payment Amount"
                value={amountStr}
                onChangeText={handleTotalChange}
                keyboardType="numeric"
                style={{
                  flex: 1,
                  fontSize: 24,
                  fontWeight: '800',
                  color: '#171817',
                  ...(Platform.OS === 'web' ? { outlineStyle: 'none' } : {})
                }}
              />
              {amountStr.length > 0 && (
                <Pressable onPress={() => handleTotalChange('')} hitSlop={10}>
                  <I name="close-circle" size={18} color="#9CA3AF" />
                </Pressable>
              )}
            </View>
          </View>

          {/* Method Selector: Cash / UPI / Split */}
          <View style={{ marginBottom: 14 }}>
            <View style={{ flexDirection: 'row', backgroundColor: '#FFFFFF', borderRadius: 12, padding: 3, borderWidth: 1, borderColor: '#E5E7EB' }}>
              {[
                { id: 'Cash', label: '💵 Cash' },
                { id: 'UPI', label: '⚡ UPI' },
                { id: 'Split', label: '⇄ Split' }
              ].map(m => {
                const active = method === m.id;
                return (
                  <Pressable
                    key={m.id}
                    onPress={() => {
                      setMethod(m.id);
                      if (m.id === 'Split') {
                        const n = parseFloat(amountStr) || 0;
                        const c = Math.round(n * 0.4);
                        setCashStr(String(c));
                        setUpiStr(String(n - c));
                      }
                    }}
                    style={{
                      flex: 1,
                      paddingVertical: 9,
                      borderRadius: 9,
                      backgroundColor: active ? '#171817' : 'transparent',
                      alignItems: 'center',
                      justifyContent: 'center'
                    }}
                  >
                    <T style={{ fontSize: 13, fontWeight: active ? '800' : '600', color: active ? '#FFFFFF' : '#4B5563' }}>
                      {m.label}
                    </T>
                  </Pressable>
                );
              })}
            </View>
          </View>

          {/* When Split is selected: Cash + UPI Breakdown */}
          {method === 'Split' && (
            <View
              style={{
                backgroundColor: '#FFFFFF',
                borderRadius: 14,
                padding: 12,
                borderWidth: 1,
                borderColor: '#EFEFEA',
                marginBottom: 14
              }}
            >
              <View style={{ flexDirection: 'row', gap: 10, marginBottom: 10 }}>
                {/* Cash Column */}
                <View style={{ flex: 1 }}>
                  <T style={{ fontSize: 11.5, fontWeight: '700', color: '#4B5563', marginBottom: 4 }}>
                    💵 Cash
                  </T>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      backgroundColor: '#FAF9F6',
                      borderWidth: 1,
                      borderColor: '#D1D5DB',
                      borderRadius: 10,
                      paddingHorizontal: 10,
                      height: 42
                    }}
                  >
                    <T style={{ fontSize: 13.5, fontWeight: '700', color: '#171817', marginRight: 3 }}>₹</T>
                    <TextInput
                      accessibilityLabel="Cash amount"
                      value={cashStr}
                      onChangeText={handleCashChange}
                      keyboardType="numeric"
                      style={{
                        flex: 1,
                        fontSize: 14,
                        fontWeight: '700',
                        color: '#171817',
                        ...(Platform.OS === 'web' ? { outlineStyle: 'none' } : {})
                      }}
                    />
                    {cashStr.length > 0 && (
                      <Pressable onPress={() => handleCashChange('0')} hitSlop={6}>
                        <I name="close-circle" size={14} color="#9CA3AF" />
                      </Pressable>
                    )}
                  </View>
                </View>

                {/* UPI Column */}
                <View style={{ flex: 1 }}>
                  <T style={{ fontSize: 11.5, fontWeight: '700', color: '#4B5563', marginBottom: 4 }}>
                    ⚡ UPI
                  </T>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      backgroundColor: '#FAF9F6',
                      borderWidth: 1,
                      borderColor: '#D1D5DB',
                      borderRadius: 10,
                      paddingHorizontal: 10,
                      height: 42
                    }}
                  >
                    <T style={{ fontSize: 13.5, fontWeight: '700', color: '#171817', marginRight: 3 }}>₹</T>
                    <TextInput
                      accessibilityLabel="UPI amount"
                      value={upiStr}
                      onChangeText={handleUpiChange}
                      keyboardType="numeric"
                      style={{
                        flex: 1,
                        fontSize: 14,
                        fontWeight: '700',
                        color: '#171817',
                        ...(Platform.OS === 'web' ? { outlineStyle: 'none' } : {})
                      }}
                    />
                    {upiStr.length > 0 && (
                      <Pressable onPress={() => handleUpiChange('0')} hitSlop={6}>
                        <I name="close-circle" size={14} color="#9CA3AF" />
                      </Pressable>
                    )}
                  </View>
                </View>
              </View>

              {/* Math Validation Badge */}
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 6,
                  paddingVertical: 6,
                  paddingHorizontal: 10,
                  borderRadius: 8,
                  backgroundColor: isSplitMatch ? '#ECFDF5' : '#FEF2F2',
                  borderWidth: 1,
                  borderColor: isSplitMatch ? '#A7F3D0' : '#FECACA'
                }}
              >
                <I
                  name={isSplitMatch ? 'checkmark-circle' : 'alert-circle'}
                  size={15}
                  color={isSplitMatch ? '#059669' : '#DC2626'}
                />
                <T
                  style={{
                    fontSize: 12,
                    fontWeight: '700',
                    color: isSplitMatch ? '#065F46' : '#991B1B'
                  }}
                >
                  {isSplitMatch
                    ? `✓ ₹${currentCash} + ₹${currentUpi} = ₹${currentTotal}`
                    : `⚠️ ₹${currentCash} + ₹${currentUpi} ≠ ₹${currentTotal} (తేడా: ₹${splitDiff})`}
                </T>
              </View>
            </View>
          )}

          {/* UPI Reference (if UPI or Split) */}
          {(method === 'UPI' || method === 'Split') && (
            <View style={{ marginBottom: 14 }}>
              <T style={{ fontSize: 12, fontWeight: '700', color: '#374151', marginBottom: 5 }}>
                {t.payUpiRefLabel || 'UPI రిఫరెన్స్ (ఐచ్ఛికం)'}
              </T>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  backgroundColor: '#FFFFFF',
                  borderWidth: 1.2,
                  borderColor: '#E5E7EB',
                  borderRadius: 12,
                  paddingHorizontal: 12,
                  height: 44
                }}
              >
                <I name="barcode-outline" size={16} color="#9CA3AF" />
                <TextInput
                  accessibilityLabel="UPI Reference"
                  placeholder={t.payUpiRefPlaceholder || 'ఉదా: 123456789012'}
                  placeholderTextColor="#9CA3AF"
                  value={upiRef}
                  onChangeText={setUpiRef}
                  style={{ flex: 1, marginLeft: 8, fontSize: 13.5, color: '#171817', ...(Platform.OS === 'web' ? { outlineStyle: 'none' } : {}) }}
                />
              </View>
            </View>
          )}

          {/* Date Selector */}
          <View style={{ marginBottom: 14 }}>
            <T style={{ fontSize: 12, fontWeight: '700', color: '#374151', marginBottom: 5 }}>
              {t.payDateLabel || 'తేదీ'}
            </T>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                backgroundColor: '#FFFFFF',
                borderWidth: 1.2,
                borderColor: '#E5E7EB',
                borderRadius: 12,
                paddingHorizontal: 12,
                height: 44
              }}
            >
              <I name="calendar-outline" size={16} color="#4B5563" />
              <TextInput
                accessibilityLabel="Date (YYYY-MM-DD)"
                value={payDate}
                onChangeText={setPayDate}
                placeholder="YYYY-MM-DD"
                placeholderTextColor="#9CA3AF"
                style={{ flex: 1, marginLeft: 8, fontSize: 13.5, fontWeight: '600', color: '#171817', ...(Platform.OS === 'web' ? { outlineStyle: 'none' } : {}) }}
              />
              <T style={{ fontSize: 12, color: '#6B7280', fontWeight: '500' }}>
                {formatTeluguDate(payDate, appLang)}
              </T>
            </View>
          </View>

          {/* Optional Note Toggle */}
          <View
            style={{
              backgroundColor: '#FFFFFF',
              borderRadius: 12,
              paddingHorizontal: 14,
              paddingVertical: 10,
              borderWidth: 1,
              borderColor: '#E5E7EB',
              marginBottom: 14
            }}
          >
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <I name="document-text-outline" size={17} color="#4B5563" />
                <T style={{ fontSize: 13, fontWeight: '700', color: '#171817' }}>
                  {t.payNoteToggleLabel || '📄 నోట్ జోడించండి (ఐచ్ఛికం)'}
                </T>
              </View>
              <Pressable
                accessibilityRole="switch"
                accessibilityState={{ checked: showNote }}
                onPress={() => setShowNote(!showNote)}
                style={{
                  width: 44,
                  height: 24,
                  borderRadius: 12,
                  backgroundColor: showNote ? '#171817' : '#E5E7EB',
                  padding: 2,
                  justifyContent: 'center'
                }}
              >
                <View
                  style={{
                    width: 20,
                    height: 20,
                    borderRadius: 10,
                    backgroundColor: '#FFFFFF',
                    transform: [{ translateX: showNote ? 20 : 0 }]
                  }}
                />
              </Pressable>
            </View>

            {showNote && (
              <View style={{ marginTop: 10, paddingTop: 10, borderTopWidth: 1, borderColor: '#F3F4F6' }}>
                <TextInput
                  accessibilityLabel="Payment note"
                  placeholder={t.payNotePlaceholder || 'అడ్వాన్స్ లేదా కూలి వివరాలు…'}
                  placeholderTextColor="#9CA3AF"
                  value={note}
                  onChangeText={setNote}
                  multiline
                  numberOfLines={2}
                  style={{ fontSize: 13, color: '#171817', minHeight: 48, ...(Platform.OS === 'web' ? { outlineStyle: 'none' } : {}) }}
                />
              </View>
            )}
          </View>

          {/* Remaining Balance Impact Preview Banner */}
          <View
            style={{
              backgroundColor: '#F8FAFC',
              borderRadius: 14,
              padding: 12,
              borderWidth: 1.2,
              borderColor: '#E2E8F0',
              marginBottom: 16
            }}
          >
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 7, marginBottom: 3 }}>
              <I name="time-outline" size={16} color="#475569" />
              <T style={{ fontSize: 13.5, fontWeight: '800', color: '#171817' }}>
                {isDueAfter
                  ? `${t.payRemainingImpactLabel || 'ఇచ్చిన తర్వాత మిగిలేది'} ₹${Math.abs(remainingAfterPayment).toLocaleString('en-IN')}`
                  : `ఇచ్చిన తర్వాత అడ్వాన్స్ మిగిలేది ₹${Math.abs(remainingAfterPayment).toLocaleString('en-IN')}`}
              </T>
            </View>
            <T style={{ fontSize: 11.5, color: '#64748B', lineHeight: 16 }}>
              (మొత్తం ₹{totalEarned.toLocaleString('en-IN')} - అడ్వాన్స్ ₹{totalPaid.toLocaleString('en-IN')} - ఇప్పుడు ₹{currentTotal.toLocaleString('en-IN')})
            </T>
          </View>

          {/* Primary Submit Button */}
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={t.payBtnSave}
            disabled={busy || !isSplitMatch || currentTotal <= 0}
            onPress={handleSavePayment}
            style={({ pressed }) => [{
              backgroundColor: '#FFD500',
              borderRadius: 14,
              paddingVertical: 14,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 8,
              shadowColor: '#CA8A04',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.16,
              shadowRadius: 4,
              elevation: 2,
              opacity: pressed || busy || !isSplitMatch || currentTotal <= 0 ? 0.75 : 1
            }]}
          >
            <I name="receipt" size={18} color="#171817" />
            <T style={{ fontSize: 15.5, fontWeight: '800', color: '#171817' }}>
              {busy ? (appLang === 'te' ? 'సేవ్ అవుతోంది…' : 'Saving…') : (t.payBtnSave || '📄 చెల్లింపు సేవ్ చేయండి')}
            </T>
          </Pressable>
        </ScrollView>
      </View>
    </View>
  );
}
