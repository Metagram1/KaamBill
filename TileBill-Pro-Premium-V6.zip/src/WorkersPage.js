import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Platform,
  useWindowDimensions
} from 'react-native';
import { I, T, Empty } from './ui';
import { money } from './domain.cjs';
import { getStrings } from './i18n';
import { formatTeluguDate } from './CustomersPage';
import WorkerModal from './WorkerModal';
import WorkerPaymentModal from './WorkerPaymentModal';
import WorkerLedgerModal from './WorkerLedgerModal';

export default function WorkersPage({
  w,
  service,
  appLang = 'te',
  busy,
  onSaveAttendance,
  onSaveWorker,
  onSavePayout,
  onVoidPayout
}) {
  const t = getStrings(appLang);
  const { width } = useWindowDimensions();
  const isDesktop = width >= 1060;

  // Selected Date Navigator (Defaults to Today)
  const todayStr = () => {
    try {
      return new Date().toISOString().slice(0, 10);
    } catch {
      return '2026-10-15';
    }
  };

  const [selectedDate, setSelectedDate] = useState(todayStr);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('attendance'); // 'attendance' | 'payments' | 'all'

  // Modals state
  const [workerModalOpen, setWorkerModalOpen] = useState(false);
  const [editingWorker, setEditingWorker] = useState(null);
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [payingWorker, setPayingWorker] = useState(null);
  const [ledgerModalOpen, setLedgerModalOpen] = useState(false);
  const [ledgerWorker, setLedgerWorker] = useState(null);
  const [activeMenuWorkerId, setActiveMenuWorkerId] = useState(null);

  // Shift date forward / backward
  const shiftSelectedDate = (days) => {
    try {
      const d = new Date(selectedDate);
      d.setDate(d.getDate() + days);
      setSelectedDate(d.toISOString().slice(0, 10));
    } catch {}
  };

  // Filter workers by service and query
  const allWorkers = (w?.workers || []).filter(v => !service || v.service === service);
  const nonArchivedWorkers = allWorkers.filter(v => !v.archived);

  // KPIs calculation for the selected date
  const dateAttendance = (w?.attendance || []).filter(a => a.date === selectedDate && allWorkers.some(v => v.id === a.workerId));
  const presentCount = dateAttendance.filter(a => a.status === 'present').length;
  const halfCount = dateAttendance.filter(a => a.status === 'half').length;

  const dateWagesEarned = allWorkers.reduce((sum, v) => {
    const att = dateAttendance.find(a => a.workerId === v.id);
    if (!att) return sum;
    const rate = att.dailyRate ?? v.dailyRate ?? 0;
    return sum + (att.earned ?? (rate * (att.status === 'present' ? 1 : att.status === 'half' ? 0.5 : 0)));
  }, 0);

  // Overall financial due across all workers in this trade
  const totalWagesOwed = allWorkers.reduce((sum, v) => {
    const wAtt = (w?.attendance || []).filter(a => a.workerId === v.id);
    const wPay = (w?.payouts || []).filter(p => p.workerId === v.id && !p.void);
    const earned = wAtt.reduce((s, a) => {
      const rate = a.dailyRate ?? v.dailyRate ?? 0;
      return s + (a.earned ?? (rate * (a.status === 'present' ? 1 : a.status === 'half' ? 0.5 : 0)));
    }, 0);
    const paid = wPay.reduce((s, p) => s + (p.amount || 0), 0);
    const bal = earned - paid;
    return sum + (bal > 0 ? bal : 0);
  }, 0);

  // Filter by search query and tab
  const filteredWorkers = nonArchivedWorkers.filter(v => {
    const textToMatch = `${v.name} ${v.role || ''} ${v.phone || ''} ${v.pattern || ''}`.toLowerCase();
    const matchesSearch = textToMatch.includes(searchQuery.trim().toLowerCase());
    if (!matchesSearch) return false;

    if (activeTab === 'attendance') return true;
    if (activeTab === 'payments') {
      const hasPayouts = (w?.payouts || []).some(p => p.workerId === v.id);
      return hasPayouts || true;
    }
    return true;
  });

  return (
    <View style={{ flex: 1, backgroundColor: '#FAF9F6' }}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 16,
          paddingTop: 16,
          paddingBottom: 40,
          maxWidth: 900,
          width: '100%',
          alignSelf: 'center'
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header matching media_1792056618877_41c911df.png */}
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: 14
          }}
        >
          <View style={{ flex: 1, paddingRight: 10 }}>
            <T style={{ fontSize: 22, fontWeight: '900', color: '#171817', letterSpacing: -0.3 }}>
              {t.workerPageTitle || 'పని వాళ్లు'}
            </T>
            <T style={{ fontSize: 13, color: '#667085', marginTop: 2 }}>
              {t.workerPageSub || 'రోజువారీ కూలి పని వాళ్ల వివరాలు'}
            </T>
          </View>

          {/* Yellow Action Button "+ జోడించండి" */}
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={t.workerBtnAdd}
            onPress={() => {
              setEditingWorker(null);
              setWorkerModalOpen(true);
            }}
            style={({ pressed }) => [{
              backgroundColor: '#FFD500',
              borderRadius: 20,
              paddingVertical: 9,
              paddingHorizontal: 14,
              flexDirection: 'row',
              alignItems: 'center',
              gap: 6,
              shadowColor: '#CA8A04',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.16,
              shadowRadius: 4,
              elevation: 2,
              opacity: pressed ? 0.85 : 1
            }]}
          >
            <I name="person-add" size={16} color="#171817" />
            <T style={{ fontSize: 13.5, fontWeight: '800', color: '#171817' }}>
              {t.workerBtnAdd || '+ జోడించండి'}
            </T>
          </Pressable>
        </View>

        {/* Date Navigator Bar matching media_1792056618877_41c911df.png: ‹ 📅 15 అక్టో 2026 నమూనా › */}
        <View
          style={{
            backgroundColor: '#FFFFFF',
            borderRadius: 14,
            paddingVertical: 10,
            paddingHorizontal: 14,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            borderWidth: 1,
            borderColor: '#EFEFEA',
            marginBottom: 12,
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 1 },
            shadowOpacity: 0.04,
            shadowRadius: 4,
            elevation: 1
          }}
        >
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Previous Day"
            onPress={() => shiftSelectedDate(-1)}
            hitSlop={10}
            style={{
              width: 34,
              height: 34,
              borderRadius: 17,
              backgroundColor: '#F3F4F6',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            <I name="chevron-back" size={18} color="#171817" />
          </Pressable>

          <Pressable
            onPress={() => setSelectedDate(todayStr())}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 7 }}
          >
            <I name="calendar" size={16} color="#854D0E" />
            <T style={{ fontSize: 14, fontWeight: '800', color: '#171817' }}>
              {formatTeluguDate(selectedDate, appLang)}
              {selectedDate === todayStr() ? (appLang === 'te' ? ' (ఈరోజు)' : ' (Today)') : ''}
            </T>
          </Pressable>

          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Next Day"
            onPress={() => shiftSelectedDate(1)}
            hitSlop={10}
            style={{
              width: 34,
              height: 34,
              borderRadius: 17,
              backgroundColor: '#F3F4F6',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            <I name="chevron-forward" size={18} color="#171817" />
          </Pressable>
        </View>

        {/* 4 Team KPI Cards (2x2 Grid) matching screenshot */}
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 14 }}>
          {/* Card 1: Total Workers */}
          <View
            style={{
              backgroundColor: '#FFFFFF',
              borderRadius: 14,
              padding: 12,
              borderWidth: 1,
              borderColor: '#EFEFEA',
              width: isDesktop ? '23.8%' : '48.5%',
              flexGrow: 1
            }}
          >
            <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: '#EFF6FF', alignItems: 'center', justifyContent: 'center', marginBottom: 8 }}>
              <I name="people-outline" size={17} color="#2563EB" />
            </View>
            <T style={{ fontSize: 14.5, fontWeight: '800', color: '#171817' }}>
              మొత్తం {allWorkers.length} పని వాళ్లు
            </T>
            <T style={{ fontSize: 11, color: '#667085', marginTop: 2 }}>
              {t.workerKpiRegisteredSub || 'రిజిస్టర్ అయిన వాళ్లు'}
            </T>
          </View>

          {/* Card 2: Present Today */}
          <View
            style={{
              backgroundColor: '#FFFFFF',
              borderRadius: 14,
              padding: 12,
              borderWidth: 1,
              borderColor: '#EFEFEA',
              width: isDesktop ? '23.8%' : '48.5%',
              flexGrow: 1
            }}
          >
            <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: '#ECFDF5', alignItems: 'center', justifyContent: 'center', marginBottom: 8 }}>
              <I name="checkmark-circle-outline" size={17} color="#059669" />
            </View>
            <T style={{ fontSize: 14.5, fontWeight: '800', color: '#171817' }}>
              ఈరోజు హాజరు {presentCount + (halfCount ? 0.5 : 0)} / {allWorkers.length} లో
            </T>
            <T style={{ fontSize: 11, color: '#667085', marginTop: 2 }}>
              {halfCount} హాఫ్ డే
            </T>
          </View>

          {/* Card 3: Today's Wages */}
          <View
            style={{
              backgroundColor: '#FFFFFF',
              borderRadius: 14,
              padding: 12,
              borderWidth: 1,
              borderColor: '#EFEFEA',
              width: isDesktop ? '23.8%' : '48.5%',
              flexGrow: 1
            }}
          >
            <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: '#FFFBEB', alignItems: 'center', justifyContent: 'center', marginBottom: 8 }}>
              <I name="time-outline" size={17} color="#D97706" />
            </View>
            <T style={{ fontSize: 14.5, fontWeight: '800', color: '#171817' }}>
              ఈరోజు కూలి {money(dateWagesEarned)}
            </T>
            <T style={{ fontSize: 11, color: '#667085', marginTop: 2 }}>
              {t.workerKpiTodayWagesSub || 'హాజరు అయిన కూలి'}
            </T>
          </View>

          {/* Card 4: Outstanding Due */}
          <View
            style={{
              backgroundColor: '#FFFFFF',
              borderRadius: 14,
              padding: 12,
              borderWidth: 1,
              borderColor: '#EFEFEA',
              width: isDesktop ? '23.8%' : '48.5%',
              flexGrow: 1
            }}
          >
            <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: totalWagesOwed > 0 ? '#FEF9C3' : '#F1F5F9', alignItems: 'center', justifyContent: 'center', marginBottom: 8 }}>
              <I name="wallet-outline" size={17} color={totalWagesOwed > 0 ? '#854D0E' : '#475569'} />
            </View>
            <T style={{ fontSize: 14.5, fontWeight: '800', color: totalWagesOwed > 0 ? '#B45309' : '#059669' }}>
              ఇవ్వాల్సినవి {money(totalWagesOwed)}
            </T>
            <T style={{ fontSize: 11, color: '#667085', marginTop: 2 }}>
              {t.workerKpiDueSub || 'బాకీ ఉన్న మొత్తం'}
            </T>
          </View>
        </View>

        {/* Search Input Bar */}
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            backgroundColor: '#FFFFFF',
            borderRadius: 14,
            paddingHorizontal: 12,
            height: 46,
            borderWidth: 1,
            borderColor: '#EFEFEA',
            marginBottom: 12
          }}
        >
          <I name="search-outline" size={18} color="#9CA3AF" />
          <TextInput
            accessibilityLabel={t.workerSearchPlaceholder}
            placeholder={t.workerSearchPlaceholder || 'పేరు లేదా పని వెతకండి…'}
            placeholderTextColor="#9CA3AF"
            value={searchQuery}
            onChangeText={setSearchQuery}
            style={{
              flex: 1,
              marginLeft: 8,
              fontSize: 14,
              color: '#171817',
              ...(Platform.OS === 'web' ? { outlineStyle: 'none' } : {})
            }}
          />
          {searchQuery.length > 0 && (
            <Pressable onPress={() => setSearchQuery('')} hitSlop={8}>
              <I name="close-circle" size={16} color="#9CA3AF" />
            </Pressable>
          )}
        </View>

        {/* 3 Navigation Tabs: 👥 హాజరు | 📄 చెల్లింపులు | 👥 అందరూ */}
        <View style={{ flexDirection: 'row', gap: 8, marginBottom: 14 }}>
          {[
            { id: 'attendance', icon: 'people', label: t.workerTabAttendance || 'హాజరు' },
            { id: 'payments', icon: 'receipt', label: t.workerTabPayments || 'చెల్లింపులు' },
            { id: 'all', icon: 'people-outline', label: t.workerTabAll || 'అందరూ' }
          ].map(tab => {
            const active = activeTab === tab.id;
            return (
              <Pressable
                key={tab.id}
                onPress={() => setActiveTab(tab.id)}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: 6,
                  paddingHorizontal: 14,
                  paddingVertical: 8,
                  borderRadius: 20,
                  backgroundColor: active ? '#18181B' : '#FFFFFF',
                  borderWidth: 1,
                  borderColor: active ? '#18181B' : '#EFEFEA'
                }}
              >
                <I name={tab.icon} size={14} color={active ? '#FFFFFF' : '#4B5563'} />
                <T style={{ fontSize: 13, fontWeight: active ? '800' : '600', color: active ? '#FFFFFF' : '#4B5563' }}>
                  {tab.label}
                </T>
              </Pressable>
            );
          })}
        </View>

        {/* Worker Cards List */}
        {filteredWorkers.length > 0 ? (
          <View style={{ gap: 12, marginBottom: 16 }}>
            {filteredWorkers.map(worker => {
              const att = (w?.attendance || []).find(a => a.workerId === worker.id && a.date === selectedDate);
              const workerAllAtt = (w?.attendance || []).filter(a => a.workerId === worker.id);
              const workerAllPay = (w?.payouts || []).filter(p => p.workerId === worker.id && !p.void);

              const fullDaysCount = workerAllAtt.filter(a => a.status === 'present').length;
              const halfDaysCount = workerAllAtt.filter(a => a.status === 'half').length;
              const totalDaysWorked = fullDaysCount + (halfDaysCount * 0.5);

              const totalEarned = workerAllAtt.reduce((sum, a) => {
                const rate = a.dailyRate ?? worker.dailyRate ?? 0;
                return sum + (a.earned ?? (rate * (a.status === 'present' ? 1 : a.status === 'half' ? 0.5 : 0)));
              }, 0);

              const totalPaid = workerAllPay.reduce((sum, p) => sum + (p.amount || 0), 0);
              const balance = totalEarned - totalPaid;
              const isDue = balance >= 0;

              const isPres = att?.status === 'present';
              const isHalf = att?.status === 'half';
              const isAbs = att?.status === 'absent';

              const isMenuOpen = activeMenuWorkerId === worker.id;

              return (
                <View
                  key={worker.id}
                  style={{
                    backgroundColor: '#FFFFFF',
                    borderRadius: 16,
                    padding: 14,
                    borderWidth: 1,
                    borderColor: '#EFEFEA',
                    shadowColor: '#000',
                    shadowOffset: { width: 0, height: 2 },
                    shadowOpacity: 0.04,
                    shadowRadius: 6,
                    elevation: 2
                  }}
                >
                  {/* Top Card Row */}
                  <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 }}>
                      {/* Avatar */}
                      <View
                        style={{
                          width: 38,
                          height: 38,
                          borderRadius: 19,
                          backgroundColor: worker.name.startsWith('శ్రీ') ? '#ECFDF5' : '#EFF6FF',
                          borderWidth: 1,
                          borderColor: worker.name.startsWith('శ్రీ') ? '#A7F3D0' : '#BFDBFE',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}
                      >
                        <T style={{ fontSize: 15, fontWeight: '800', color: worker.name.startsWith('శ్రీ') ? '#059669' : '#2563EB' }}>
                          {(worker.name || 'W')[0]?.toUpperCase()}
                        </T>
                      </View>

                      {/* Name & Role */}
                      <View style={{ flex: 1 }}>
                        <T numberOfLines={1} style={{ fontSize: 16, fontWeight: '800', color: '#171817' }}>
                          {worker.name}
                        </T>
                        <T numberOfLines={1} style={{ fontSize: 12, color: '#667085', marginTop: 1 }}>
                          {worker.role} • {worker.pattern === 'occasional' ? 'అవసరమైనప్పుడు' : 'రెగ్యులర్'}
                        </T>
                      </View>
                    </View>

                    {/* Edit Pencil & Overflow 3-Dots */}
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                      <Pressable
                        accessibilityRole="button"
                        accessibilityLabel="Edit Worker"
                        onPress={() => {
                          setEditingWorker(worker);
                          setWorkerModalOpen(true);
                        }}
                        style={{
                          width: 30,
                          height: 30,
                          borderRadius: 15,
                          backgroundColor: '#F3F4F6',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}
                      >
                        <I name="pencil" size={14} color="#4B5563" />
                      </Pressable>

                      <Pressable
                        accessibilityRole="button"
                        accessibilityLabel="More options"
                        onPress={() => setActiveMenuWorkerId(isMenuOpen ? null : worker.id)}
                        style={{
                          width: 30,
                          height: 30,
                          borderRadius: 15,
                          backgroundColor: '#F3F4F6',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}
                      >
                        <I name="ellipsis-vertical" size={14} color="#4B5563" />
                      </Pressable>
                    </View>
                  </View>

                  {/* Worker Context Menu Dropdown */}
                  {isMenuOpen && (
                    <View
                      style={{
                        position: 'absolute',
                        top: 52,
                        right: 14,
                        backgroundColor: '#FFFFFF',
                        borderRadius: 12,
                        padding: 6,
                        shadowColor: '#000',
                        shadowOffset: { width: 0, height: 4 },
                        shadowOpacity: 0.15,
                        shadowRadius: 10,
                        elevation: 10,
                        zIndex: 100,
                        borderWidth: 1,
                        borderColor: '#E5E7EB',
                        width: 160
                      }}
                    >
                      <Pressable
                        onPress={() => {
                          setActiveMenuWorkerId(null);
                          setEditingWorker(worker);
                          setWorkerModalOpen(true);
                        }}
                        style={{ paddingVertical: 8, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 8 }}
                      >
                        <I name="create-outline" size={14} color="#171817" />
                        <T style={{ fontSize: 12.5, fontWeight: '600', color: '#171817' }}>సవరించండి</T>
                      </Pressable>
                      <Pressable
                        onPress={() => {
                          setActiveMenuWorkerId(null);
                          setLedgerWorker(worker);
                          setLedgerModalOpen(true);
                        }}
                        style={{ paddingVertical: 8, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 8 }}
                      >
                        <I name="document-text-outline" size={14} color="#171817" />
                        <T style={{ fontSize: 12.5, fontWeight: '600', color: '#171817' }}>లెక్కల వివరాలు</T>
                      </Pressable>
                    </View>
                  )}

                  {/* Daily Wage Badge row: ₹ రోజు కూలి ₹800 ✎ */}
                  <View style={{ marginBottom: 12 }}>
                    <Pressable
                      onPress={() => {
                        setEditingWorker(worker);
                        setWorkerModalOpen(true);
                      }}
                      style={{
                        alignSelf: 'flex-start',
                        flexDirection: 'row',
                        alignItems: 'center',
                        gap: 5,
                        backgroundColor: '#FEF9C3',
                        borderWidth: 1,
                        borderColor: '#FDE047',
                        paddingHorizontal: 9,
                        paddingVertical: 4.5,
                        borderRadius: 8
                      }}
                    >
                      <I name="cash-outline" size={13} color="#854D0E" />
                      <T style={{ fontSize: 12, fontWeight: '800', color: '#854D0E' }}>
                        {t.workerDailyWage || 'రోజు కూలి'} ₹{worker.dailyRate}
                      </T>
                      <I name="pencil" size={11} color="#854D0E" />
                    </Pressable>
                  </View>

                  {/* 3 Attendance Toggle Status Pills for Selected Date */}
                  <View style={{ flexDirection: 'row', gap: 8, marginBottom: 12 }}>
                    {/* Full Day */}
                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel="Full day"
                      disabled={busy}
                      onPress={() => {
                        onSaveAttendance({
                          workerId: worker.id,
                          date: selectedDate,
                          status: isPres ? 'clear' : 'present',
                          projectId: worker.projectId || ''
                        });
                      }}
                      style={({ pressed }) => [{
                        flex: 1,
                        paddingVertical: 9,
                        borderRadius: 10,
                        alignItems: 'center',
                        justifyContent: 'center',
                        flexDirection: 'row',
                        gap: 5,
                        backgroundColor: isPres ? '#059669' : '#ECFDF5',
                        borderWidth: 1,
                        borderColor: isPres ? '#059669' : '#A7F3D0',
                        opacity: pressed ? 0.8 : 1
                      }]}
                    >
                      <I name="checkmark" size={15} color={isPres ? '#FFFFFF' : '#059669'} />
                      <T style={{ fontSize: 12.5, fontWeight: '700', color: isPres ? '#FFFFFF' : '#065F46' }}>
                        {t.workerAttendanceFull || 'పూర్తి రోజు'}
                      </T>
                    </Pressable>

                    {/* Half Day */}
                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel="Half day"
                      disabled={busy}
                      onPress={() => {
                        onSaveAttendance({
                          workerId: worker.id,
                          date: selectedDate,
                          status: isHalf ? 'clear' : 'half',
                          projectId: worker.projectId || ''
                        });
                      }}
                      style={({ pressed }) => [{
                        flex: 1,
                        paddingVertical: 9,
                        borderRadius: 10,
                        alignItems: 'center',
                        justifyContent: 'center',
                        flexDirection: 'row',
                        gap: 5,
                        backgroundColor: isHalf ? '#D97706' : '#FFFBEB',
                        borderWidth: 1,
                        borderColor: isHalf ? '#D97706' : '#FDE68A',
                        opacity: pressed ? 0.8 : 1
                      }]}
                    >
                      <I name="contrast" size={14} color={isHalf ? '#FFFFFF' : '#D97706'} />
                      <T style={{ fontSize: 12.5, fontWeight: '700', color: isHalf ? '#FFFFFF' : '#92400E' }}>
                        {t.workerAttendanceHalf || 'సగం రోజు'}
                      </T>
                    </Pressable>

                    {/* Absent */}
                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel="Absent"
                      disabled={busy}
                      onPress={() => {
                        onSaveAttendance({
                          workerId: worker.id,
                          date: selectedDate,
                          status: isAbs ? 'clear' : 'absent',
                          projectId: worker.projectId || ''
                        });
                      }}
                      style={({ pressed }) => [{
                        flex: 1,
                        paddingVertical: 9,
                        borderRadius: 10,
                        alignItems: 'center',
                        justifyContent: 'center',
                        flexDirection: 'row',
                        gap: 5,
                        backgroundColor: isAbs ? '#DC2626' : '#FEF2F2',
                        borderWidth: 1,
                        borderColor: isAbs ? '#DC2626' : '#FECACA',
                        opacity: pressed ? 0.8 : 1
                      }]}
                    >
                      <I name="close" size={15} color={isAbs ? '#FFFFFF' : '#DC2626'} />
                      <T style={{ fontSize: 12.5, fontWeight: '700', color: isAbs ? '#FFFFFF' : '#991B1B' }}>
                        {t.workerAttendanceAbsent || 'రాలేదు'}
                      </T>
                    </Pressable>
                  </View>

                  {/* Financial Summary Row */}
                  <View
                    style={{
                      backgroundColor: '#FAF9F6',
                      borderRadius: 12,
                      padding: 10,
                      borderWidth: 1,
                      borderColor: '#EFEFEA',
                      marginBottom: 12
                    }}
                  >
                    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
                      <T style={{ fontSize: 12, color: '#4B5563', fontWeight: '600' }}>
                        📅 {totalDaysWorked} రోజులు • ₹{totalEarned.toLocaleString('en-IN')} మొత్తం పని చేసినవి
                      </T>
                    </View>
                    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                      <T style={{ fontSize: 12, color: '#059669', fontWeight: '700' }}>
                        💰 చెల్లించినవి ₹{totalPaid.toLocaleString('en-IN')}
                      </T>
                      <T style={{ fontSize: 12.5, fontWeight: '800', color: isDue ? (balance > 0 ? '#B45309' : '#059669') : '#2563EB' }}>
                        {isDue ? (balance > 0 ? `ఇంకా ఇవ్వాలి ₹${balance.toLocaleString('en-IN')}` : 'పూర్తిగా క్లియర్') : `అడ్వాన్స్ ₹${Math.abs(balance).toLocaleString('en-IN')}`}
                      </T>
                    </View>
                  </View>

                  {/* 2 Action Buttons: 📄 లెక్కలు | ₹ చెల్లించండి */}
                  <View style={{ flexDirection: 'row', gap: 8 }}>
                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel="Ledger"
                      onPress={() => {
                        setLedgerWorker(worker);
                        setLedgerModalOpen(true);
                      }}
                      style={({ pressed }) => [{
                        flex: 1,
                        backgroundColor: '#FFFFFF',
                        borderWidth: 1.2,
                        borderColor: '#E5E7EB',
                        borderRadius: 12,
                        paddingVertical: 10,
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: 6,
                        opacity: pressed ? 0.8 : 1
                      }]}
                    >
                      <I name="document-text-outline" size={15} color="#171817" />
                      <T style={{ fontSize: 13, fontWeight: '700', color: '#171817' }}>
                        {t.workerBtnLedger || '📄 లెక్కలు'}
                      </T>
                    </Pressable>

                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel="Pay wage"
                      onPress={() => {
                        setPayingWorker(worker);
                        setPaymentModalOpen(true);
                      }}
                      style={({ pressed }) => [{
                        flex: 1,
                        backgroundColor: '#FFFFFF',
                        borderWidth: 1.2,
                        borderColor: '#E5E7EB',
                        borderRadius: 12,
                        paddingVertical: 10,
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: 6,
                        opacity: pressed ? 0.8 : 1
                      }]}
                    >
                      <I name="wallet-outline" size={15} color="#171817" />
                      <T style={{ fontSize: 13, fontWeight: '700', color: '#171817' }}>
                        {t.workerBtnPay || '₹ చెల్లించండి'}
                      </T>
                    </Pressable>
                  </View>
                </View>
              );
            })}
          </View>
        ) : (
          <View
            style={{
              backgroundColor: '#FFFFFF',
              borderRadius: 16,
              padding: 28,
              alignItems: 'center',
              borderWidth: 1,
              borderColor: '#EFEFEA',
              marginBottom: 16
            }}
          >
            <I name="people-outline" size={36} color="#9CA3AF" />
            <T style={{ fontSize: 15, fontWeight: '800', color: '#171817', marginTop: 10 }}>
              {t.workerEmptyTitle || 'పని వాళ్లు ఎవరూ లేరు'}
            </T>
            <T style={{ fontSize: 12.5, color: '#667085', textAlign: 'center', marginTop: 4, maxWidth: 280 }}>
              {t.workerEmptySub || 'రోజువారీ హాజరు మరియు కూలి లెక్కల కోసం కొత్త పని మనిషిని జోడించండి.'}
            </T>
            <Pressable
              onPress={() => {
                setEditingWorker(null);
                setWorkerModalOpen(true);
              }}
              style={{
                marginTop: 14,
                backgroundColor: '#FFD500',
                paddingVertical: 9,
                paddingHorizontal: 16,
                borderRadius: 12
              }}
            >
              <T style={{ fontSize: 13, fontWeight: '800', color: '#171817' }}>
                {t.workerBtnAdd || '+ జోడించండి'}
              </T>
            </Pressable>
          </View>
        )}

        {/* Bottom Helper Note Banner matching media_1792056618877_41c911df.png */}
        <View
          style={{
            backgroundColor: '#EFF6FF',
            borderRadius: 12,
            paddingVertical: 10,
            paddingHorizontal: 14,
            flexDirection: 'row',
            alignItems: 'center',
            gap: 8,
            borderWidth: 1,
            borderColor: '#DBEAFE'
          }}
        >
          <I name="information-circle" size={16} color="#2563EB" />
          <T style={{ fontSize: 12, color: '#1E40AF', fontWeight: '600', flex: 1 }}>
            {t.workerBottomNotice || 'హాజరైన రోజులకే కూలి లెక్క. నెల జీతాలు కావు.'}
          </T>
        </View>
      </ScrollView>

      {/* Add / Edit Worker Modal */}
      {workerModalOpen && (
        <WorkerModal
          visible={workerModalOpen}
          initial={editingWorker}
          w={w}
          service={service}
          busy={busy}
          appLang={appLang}
          onClose={() => {
            setWorkerModalOpen(false);
            setEditingWorker(null);
          }}
          onSave={async (workerData) => {
            const success = await onSaveWorker(workerData);
            if (success !== false) {
              setWorkerModalOpen(false);
              setEditingWorker(null);
            }
          }}
        />
      )}

      {/* Record Payment Modal */}
      {paymentModalOpen && (
        <WorkerPaymentModal
          visible={paymentModalOpen}
          worker={payingWorker}
          w={w}
          service={service}
          busy={busy}
          appLang={appLang}
          onClose={() => {
            setPaymentModalOpen(false);
            setPayingWorker(null);
          }}
          onSave={async (payData) => {
            const success = await onSavePayout(payData);
            if (success !== false) {
              setPaymentModalOpen(false);
              setPayingWorker(null);
            }
          }}
        />
      )}

      {/* Worker Ledger Modal */}
      {ledgerModalOpen && (
        <WorkerLedgerModal
          visible={ledgerModalOpen}
          worker={ledgerWorker}
          w={w}
          service={service}
          busy={busy}
          appLang={appLang}
          onClose={() => {
            setLedgerModalOpen(false);
            setLedgerWorker(null);
          }}
          onOpenPayment={(wObj) => {
            setLedgerModalOpen(false);
            setPayingWorker(wObj);
            setPaymentModalOpen(true);
          }}
          onEditWorker={(wObj) => {
            setLedgerModalOpen(false);
            setEditingWorker(wObj);
            setWorkerModalOpen(true);
          }}
          onVoidPayout={onVoidPayout}
        />
      )}
    </View>
  );
}
