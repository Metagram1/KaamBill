import { Platform } from 'react-native';
import Constants from 'expo-constants';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';

export const isObsoleteLocalIp = (url) => {
  if (!url || typeof url !== 'string') return false;
  // If an external production URL is configured, purge leftover local IPs
  if (process.env.EXPO_PUBLIC_API_URL && !__DEV__ && !/(localhost|127\.0\.0\.1|192\.168\.\d+\.\d+|10\.\d+\.\d+\.\d+|172\.(1[6-9]|2\d|3[0-1])\.\d+\.\d+|\.local)/i.test(process.env.EXPO_PUBLIC_API_URL)) {
    return /(localhost|127\.0\.0\.1|192\.168\.\d+\.\d+|10\.\d+\.\d+\.\d+|172\.(1[6-9]|2\d|3[0-1])\.\d+\.\d+|\.local)/i.test(url);
  }
  return false;
};

const devHost = (__DEV__ && Constants.expoConfig?.hostUri) ? Constants.expoConfig.hostUri.split(':')[0] : null;
let dynamicApiUrl = process.env.EXPO_PUBLIC_API_URL || (
  Platform.OS === 'web'
    ? (typeof window !== 'undefined' && window.location.port === '8081'
        ? `${window.location.protocol}//${window.location.hostname}:4000`
        : (typeof window !== 'undefined' ? window.location.origin : ''))
    : (devHost ? `http://${devHost}:4000` : '')
);

export let API = dynamicApiUrl;
export function getApiUrl() { return dynamicApiUrl; }

export async function setApiUrl(u) {
  if (u) {
    dynamicApiUrl = u.replace(/\/+$/, '');
    API = dynamicApiUrl;
    try {
      await AsyncStorage.setItem('TB_API_URL_OVERRIDE', dynamicApiUrl);
      if (Platform.OS !== 'web') {
        try { await SecureStore.setItemAsync('TB_API_URL_OVERRIDE', dynamicApiUrl); } catch {}
      }
    } catch {}
  }
}

export async function clearApiUrlOverride() {
  dynamicApiUrl = process.env.EXPO_PUBLIC_API_URL || (
    Platform.OS === 'web' && typeof window !== 'undefined' ? window.location.origin : ''
  );
  API = dynamicApiUrl;
  try {
    await AsyncStorage.removeItem('TB_API_URL_OVERRIDE');
    if (Platform.OS !== 'web') {
      try { await SecureStore.deleteItemAsync('TB_API_URL_OVERRIDE'); } catch {}
    }
  } catch {}
}

export async function initApiUrl() {
  try {
    let saved = await AsyncStorage.getItem('TB_API_URL_OVERRIDE');
    if (!saved && Platform.OS !== 'web') {
      try { saved = await SecureStore.getItemAsync('TB_API_URL_OVERRIDE'); } catch {}
    }
    // Safely migrate obsolete local IP overrides
    if (saved && isObsoleteLocalIp(saved)) {
      console.log('[TileBill API] Migrating obsolete local IP override:', saved);
      await clearApiUrlOverride();
      saved = null;
    }
    if (saved && saved.startsWith('http')) {
      dynamicApiUrl = saved.replace(/\/+$/, '');
      API = dynamicApiUrl;
    }
  } catch {}
  return dynamicApiUrl;
}

export async function testApiConnection(testUrl) {
  if (!testUrl || !testUrl.trim()) return { ok: false, error: 'URL cannot be empty' };
  const cleanUrl = testUrl.trim().replace(/\/+$/, '');
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 6000);
  try {
    const res = await fetch(`${cleanUrl}/health`, {
      method: 'GET',
      headers: { 'Accept': 'application/json' },
      signal: ctrl.signal
    });
    if (!res.ok) {
      return { ok: false, error: `Server returned HTTP ${res.status}` };
    }
    const data = await res.json().catch(() => ({}));
    return { ok: true, data };
  } catch (err) {
    if (err.name === 'AbortError') {
      return { ok: false, error: 'Connection timed out (no response within 6s)' };
    }
    return { ok: false, error: err.message || 'Cannot reach server' };
  } finally {
    clearTimeout(timer);
  }
}

// Call on startup
initApiUrl().catch(() => {});

let token = '';

export async function loadToken() {
  token = Platform.OS === 'web'
    ? await AsyncStorage.getItem('TB4_SESSION')
    : await SecureStore.getItemAsync('TB4_SESSION');
  return token;
}

export async function setToken(t) {
  token = t || '';
  if (Platform.OS === 'web') {
    if (t) await AsyncStorage.setItem('TB4_SESSION', t);
    else await AsyncStorage.removeItem('TB4_SESSION');
  } else {
    if (t) await SecureStore.setItemAsync('TB4_SESSION', t);
    else await SecureStore.deleteItemAsync('TB4_SESSION');
  }
}

export function arrayBufferToBase64(buffer) {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
  const chunkSize = 8192;
  for (let i = 0; i < len; i += chunkSize) {
    const chunk = bytes.subarray(i, Math.min(i + chunkSize, len));
    binary += String.fromCharCode.apply(null, chunk);
  }
  if (typeof btoa === 'function') {
    return btoa(binary);
  }
  if (typeof Buffer !== 'undefined') {
    return Buffer.from(buffer).toString('base64');
  }
  return '';
}

export async function api(path, body) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 15000);
  try {
    const url = (dynamicApiUrl || API) + path;
    const res = await fetch(url, {
      method: body === undefined ? 'GET' : 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: 'Bearer ' + token } : {})
      },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: ctrl.signal
    });
    const textResp = await res.text();
    let data = {};
    try {
      data = textResp ? JSON.parse(textResp) : {};
    } catch {
      data = { error: textResp || ('Server returned HTTP ' + res.status) };
    }
    if (!res.ok) {
      const e = new Error(data.error || 'Request failed');
      e.status = res.status;
      throw e;
    }
    return data;
  } catch (e) {
    if (e.name === 'AbortError' || e.message === 'Failed to fetch' || e.message === 'Network request failed') {
      throw new Error('Cannot reach TileBill server. Please check your internet connection or try again later.');
    }
    throw e;
  } finally {
    clearTimeout(timer);
  }
}
