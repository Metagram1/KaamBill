/**
 * TileBill PRO Build Configuration
 *
 * OFFLINE_TEST_MODE:
 * When enabled (true):
 * - Operates 100% locally on-device without any server or network dependency.
 * - Local onboarding flow: Choose Language -> Start Testing -> Business Profile -> Dashboard.
 * - Local database (AsyncStorage with structured schema) is the source of truth.
 * - Zero network requests block startup or data saves.
 * - Zero "Cannot reach TileBill server" errors.
 * - Full test entitlement granted without remote billing checks.
 * - 100% on-device PDF generation via expo-print.
 *
 * For future production builds with a hosted server:
 * Change IS_OFFLINE_TEST_MODE to false and set EXPO_PUBLIC_API_URL.
 */

export const IS_OFFLINE_TEST_MODE = false;
export const APP_VERSION = '6.0.4';
export const APP_BUILD = 12;
export const SCHEMA_VERSION = 6;
