const zlib = require('zlib');
const { numberToIndianWords, resolveTemplate, formatItemSubtitle } = require('./domain.cjs');

function xmlEscape(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

// Minimal, zero-dependency pure Node.js ZIP archive generator
function createZip(files) {
  const fileEntries = [];
  let offset = 0;

  const localHeaders = [];
  for (const f of files) {
    const filenameBuf = Buffer.from(f.path, 'utf8');
    const contentBuf = Buffer.isBuffer(f.content) ? f.content : Buffer.from(f.content, 'utf8');
    const crc = zlib.crc32(contentBuf);
    const compressed = zlib.deflateRawSync(contentBuf);
    const useDeflate = compressed.length < contentBuf.length;
    const data = useDeflate ? compressed : contentBuf;
    const method = useDeflate ? 8 : 0;

    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(0x04034b50, 0);
    localHeader.writeUInt16LE(20, 4);
    localHeader.writeUInt16LE(0, 6);
    localHeader.writeUInt16LE(method, 8);
    localHeader.writeUInt16LE(0, 10);
    localHeader.writeUInt16LE(0, 12);
    localHeader.writeUInt32LE(crc, 14);
    localHeader.writeUInt32LE(data.length, 18);
    localHeader.writeUInt32LE(contentBuf.length, 22);
    localHeader.writeUInt16LE(filenameBuf.length, 26);
    localHeader.writeUInt16LE(0, 28);

    fileEntries.push({
      path: f.path,
      filenameBuf,
      crc,
      compressedSize: data.length,
      uncompressedSize: contentBuf.length,
      method,
      offset
    });

    localHeaders.push(localHeader, filenameBuf, data);
    offset += localHeader.length + filenameBuf.length + data.length;
  }

  const centralDirOffset = offset;
  const centralHeaders = [];
  for (const entry of fileEntries) {
    const cdHeader = Buffer.alloc(46);
    cdHeader.writeUInt32LE(0x02014b50, 0);
    cdHeader.writeUInt16LE(20, 4);
    cdHeader.writeUInt16LE(20, 6);
    cdHeader.writeUInt16LE(0, 8);
    cdHeader.writeUInt16LE(entry.method, 10);
    cdHeader.writeUInt16LE(0, 12);
    cdHeader.writeUInt16LE(0, 14);
    cdHeader.writeUInt32LE(entry.crc, 16);
    cdHeader.writeUInt32LE(entry.compressedSize, 20);
    cdHeader.writeUInt32LE(entry.uncompressedSize, 24);
    cdHeader.writeUInt16LE(entry.filenameBuf.length, 28);
    cdHeader.writeUInt16LE(0, 30);
    cdHeader.writeUInt16LE(0, 32);
    cdHeader.writeUInt16LE(0, 34);
    cdHeader.writeUInt16LE(0, 36);
    cdHeader.writeUInt32LE(0, 38);
    cdHeader.writeUInt32LE(entry.offset, 42);

    centralHeaders.push(cdHeader, entry.filenameBuf);
    offset += cdHeader.length + entry.filenameBuf.length;
  }
  const centralDirSize = offset - centralDirOffset;

  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(0, 4);
  eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(fileEntries.length, 8);
  eocd.writeUInt16LE(fileEntries.length, 10);
  eocd.writeUInt32LE(centralDirSize, 12);
  eocd.writeUInt32LE(centralDirOffset, 16);
  eocd.writeUInt16LE(0, 20);

  return Buffer.concat([...localHeaders, ...centralHeaders, eocd]);
}

// Generate genuine OOXML .docx document for TileBill Pro
function generateDocx(doc = {}, business = {}) {
  const isAgreement = Boolean(doc.isAgreement || doc.kind === 'agreement');
  const isQuotation = doc.kind === 'quotation';
  const docTitle = isAgreement
    ? 'MATERIAL SPECIFICATION AGREEMENT'
    : (isQuotation ? 'QUOTATION' : 'TAX INVOICE');

  const bizName = business.name || 'TileBill Pro Contractor';
  const bizPhone = business.phone || '';
  const bizEmail = business.email || '';
  const bizAddress = [business.address, business.city, business.state].filter(Boolean).join(', ');
  const bizGstin = business.gstin || '';

  const custName = doc.customer?.name || 'Customer';
  const custPhone = doc.customer?.phone || '';
  const custSite = doc.siteLocation || doc.projectSite || doc.customer?.siteLocation || doc.customer?.address || 'Site Office';
  const custGstin = doc.customer?.gstin || doc.custGstin || '';

  const docNumber = doc.number || (isAgreement ? 'AG-0001' : isQuotation ? 'QT-0001' : 'INV-0001');
  const docDate = doc.date || new Date().toISOString().slice(0, 10);
  const dueDate = doc.dueDate || '';

  const templateObj = resolveTemplate(doc.template || 'classic_ledger');
  // Accent color for table header based on template
  let headerFill = 'F1F5F9';
  let headerTextColor = '0F172A';
  if (templateObj.id === 'amber_grid') {
    headerFill = 'E65100';
    headerTextColor = 'FFFFFF';
  } else if (templateObj.id === 'blue_timesheet') {
    headerFill = '1A5B78';
    headerTextColor = 'FFFFFF';
  } else if (templateObj.id === 'compact_trade') {
    headerFill = '0066B2';
    headerTextColor = 'FFFFFF';
  } else if (templateObj.id === 'corporate_sales') {
    headerFill = '3B5998';
    headerTextColor = 'FFFFFF';
  }

  let bodyXml = '';

  // 1. Header: Document Title & Business Information
  bodyXml += `
    <w:p>
      <w:pPr>
        <w:jc w:val="center"/>
        <w:spacing w:before="120" w:after="80"/>
      </w:pPr>
      <w:r>
        <w:rPr>
          <w:b/>
          <w:sz w:val="36"/>
          <w:color w:val="${headerFill === 'F1F5F9' ? '0F172A' : headerFill}"/>
        </w:rPr>
        <w:t>${xmlEscape(docTitle)}</w:t>
      </w:r>
    </w:p>
    <w:p>
      <w:pPr>
        <w:jc w:val="center"/>
        <w:spacing w:after="160"/>
      </w:pPr>
      <w:r>
        <w:rPr>
          <w:b/>
          <w:sz w:val="24"/>
          <w:color w:val="171817"/>
        </w:rPr>
        <w:t>${xmlEscape(bizName)}</w:t>
      </w:r>
    </w:p>
    <w:p>
      <w:pPr>
        <w:jc w:val="center"/>
        <w:spacing w:after="240"/>
      </w:pPr>
      <w:r>
        <w:rPr><w:sz w:val="18"/><w:color w:val="64748B"/></w:rPr>
        <w:t>${xmlEscape(bizAddress)}${bizPhone ? ' • Tel: ' + xmlEscape(bizPhone) : ''}${bizEmail ? ' • ' + xmlEscape(bizEmail) : ''}${bizGstin ? ' • GSTIN: ' + xmlEscape(bizGstin) : ''}</w:t>
      </w:r>
    </w:p>`;

  // 2. Metadata / Bill To Information Table
  bodyXml += `
    <w:tbl>
      <w:tblPr>
        <w:tblW w:w="10000" w:type="pct"/>
        <w:tblBorders>
          <w:top w:val="single" w:sz="6" w:space="0" w:color="CBD5E1"/>
          <w:left w:val="single" w:sz="6" w:space="0" w:color="CBD5E1"/>
          <w:bottom w:val="single" w:sz="6" w:space="0" w:color="CBD5E1"/>
          <w:right w:val="single" w:sz="6" w:space="0" w:color="CBD5E1"/>
          <w:insideH w:val="none"/>
          <w:insideV w:val="single" w:sz="6" w:space="0" w:color="CBD5E1"/>
        </w:tblBorders>
      </w:tblPr>
      <w:tr>
        <w:tc>
          <w:tcPr><w:tcW w:w="5000" w:type="pct"/><w:shd w:val="clear" w:color="auto" w:fill="F8FAFC"/></w:tcPr>
          <w:p><w:r><w:rPr><w:b/><w:sz w:val="18"/><w:color w:val="64748B"/></w:rPr><w:t>${isAgreement ? 'CLIENT DETAILS' : 'BILL TO / CUSTOMER'}</w:t></w:r></w:p>
          <w:p><w:r><w:rPr><w:b/><w:sz w:val="22"/><w:color w:val="0F172A"/></w:rPr><w:t>${xmlEscape(custName)}</w:t></w:r></w:p>
          <w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="475569"/></w:rPr><w:t>Site: ${xmlEscape(custSite)}</w:t></w:r></w:p>
          ${custPhone ? `<w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="475569"/></w:rPr><w:t>Phone: ${xmlEscape(custPhone)}</w:t></w:r></w:p>` : ''}
          ${custGstin ? `<w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="475569"/></w:rPr><w:t>GSTIN: ${xmlEscape(custGstin)}</w:t></w:r></w:p>` : ''}
        </w:tc>
        <w:tc>
          <w:tcPr><w:tcW w:w="5000" w:type="pct"/><w:shd w:val="clear" w:color="auto" w:fill="F8FAFC"/></w:tcPr>
          <w:p><w:r><w:rPr><w:b/><w:sz w:val="18"/><w:color w:val="64748B"/></w:rPr><w:t>DOCUMENT DETAILS</w:t></w:r></w:p>
          <w:p><w:r><w:rPr><w:b/><w:sz w:val="20"/><w:color w:val="0F172A"/></w:rPr><w:t>Number: ${xmlEscape(docNumber)}</w:t></w:r></w:p>
          <w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="475569"/></w:rPr><w:t>Date: ${xmlEscape(docDate)}</w:t></w:r></w:p>
          ${dueDate ? `<w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="475569"/></w:rPr><w:t>Valid Until: ${xmlEscape(dueDate)}</w:t></w:r></w:p>` : ''}
          <w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="475569"/></w:rPr><w:t>Template: ${xmlEscape(templateObj.name)}</w:t></w:r></w:p>
        </w:tc>
      </w:tr>
    </w:tbl>
    <w:p><w:pPr><w:spacing w:before="180"/></w:pPr></w:p>`;

  // 3. Document Specific Tables
  if (isAgreement) {
    // =========================================================================
    // MATERIALS SPECIFICATION AGREEMENT (Strictly NO prices, taxes, or totals)
    // =========================================================================
    const materials = doc.materials || doc.items || [];

    bodyXml += `
      <w:p>
        <w:pPr><w:spacing w:before="120" w:after="80"/></w:pPr>
        <w:r><w:rPr><w:b/><w:sz w:val="22"/><w:color w:val="0F172A"/></w:rPr><w:t>Material Specifications &amp; Supply Scope</w:t></w:r>
      </w:p>
      <w:tbl>
        <w:tblPr>
          <w:tblW w:w="10000" w:type="pct"/>
          <w:tblBorders>
            <w:top w:val="single" w:sz="8" w:space="0" w:color="0F172A"/>
            <w:left w:val="single" w:sz="6" w:space="0" w:color="CBD5E1"/>
            <w:bottom w:val="single" w:sz="8" w:space="0" w:color="0F172A"/>
            <w:right w:val="single" w:sz="6" w:space="0" w:color="CBD5E1"/>
            <w:insideH w:val="single" w:sz="4" w:space="0" w:color="E2E8F0"/>
            <w:insideV w:val="single" w:sz="4" w:space="0" w:color="E2E8F0"/>
          </w:tblBorders>
        </w:tblPr>
        <w:tr>
          <w:tc><w:tcPr><w:tcW w:w="600" w:type="pct"/><w:shd w:val="clear" w:color="auto" w:fill="${headerFill}"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="18"/><w:color w:val="${headerTextColor}"/></w:rPr><w:t>#</w:t></w:r></w:p></w:tc>
          <w:tc><w:tcPr><w:tcW w:w="2600" w:type="pct"/><w:shd w:val="clear" w:color="auto" w:fill="${headerFill}"/></w:tcPr><w:p><w:r><w:rPr><w:b/><w:sz w:val="18"/><w:color w:val="${headerTextColor}"/></w:rPr><w:t>Material Name &amp; Category</w:t></w:r></w:p></w:tc>
          <w:tc><w:tcPr><w:tcW w:w="2000" w:type="pct"/><w:shd w:val="clear" w:color="auto" w:fill="${headerFill}"/></w:tcPr><w:p><w:r><w:rPr><w:b/><w:sz w:val="18"/><w:color w:val="${headerTextColor}"/></w:rPr><w:t>Brand / Grade</w:t></w:r></w:p></w:tc>
          <w:tc><w:tcPr><w:tcW w:w="2000" w:type="pct"/><w:shd w:val="clear" w:color="auto" w:fill="${headerFill}"/></w:tcPr><w:p><w:r><w:rPr><w:b/><w:sz w:val="18"/><w:color w:val="${headerTextColor}"/></w:rPr><w:t>Dimensions / Sizes</w:t></w:r></w:p></w:tc>
          <w:tc><w:tcPr><w:tcW w:w="1600" w:type="pct"/><w:shd w:val="clear" w:color="auto" w:fill="${headerFill}"/></w:tcPr><w:p><w:r><w:rPr><w:b/><w:sz w:val="18"/><w:color w:val="${headerTextColor}"/></w:rPr><w:t>Where Used</w:t></w:r></w:p></w:tc>
          <w:tc><w:tcPr><w:tcW w:w="1200" w:type="pct"/><w:shd w:val="clear" w:color="auto" w:fill="${headerFill}"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="18"/><w:color w:val="${headerTextColor}"/></w:rPr><w:t>Supplied By</w:t></w:r></w:p></w:tc>
        </w:tr>`;

    materials.forEach((m, idx) => {
      const sizesText = Array.isArray(m.sizes) ? m.sizes.join(', ') : (m.sizes || m.specs || 'Standard');
      const brandGrade = [m.brand, m.grade].filter(Boolean).join(' • ') || 'As specified';
      const suppliedText = m.suppliedBy === 'customer' ? 'Customer' : 'Contractor';

      bodyXml += `
        <w:tr>
          <w:tc><w:tcPr><w:tcW w:w="600" w:type="pct"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:sz w:val="18"/></w:rPr><w:t>${idx + 1}</w:t></w:r></w:p></w:tc>
          <w:tc><w:tcPr><w:tcW w:w="2600" w:type="pct"/></w:tcPr><w:p><w:r><w:rPr><w:b/><w:sz w:val="18"/><w:color w:val="0F172A"/></w:rPr><w:t>${xmlEscape(m.name)}</w:t></w:r></w:p>${m.category ? `<w:p><w:r><w:rPr><w:sz w:val="16"/><w:color w:val="64748B"/></w:rPr><w:t>${xmlEscape(m.category)}</w:t></w:r></w:p>` : ''}</w:tc>
          <w:tc><w:tcPr><w:tcW w:w="2000" w:type="pct"/></w:tcPr><w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="334155"/></w:rPr><w:t>${xmlEscape(brandGrade)}</w:t></w:r></w:p></w:tc>
          <w:tc><w:tcPr><w:tcW w:w="2000" w:type="pct"/></w:tcPr><w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="334155"/></w:rPr><w:t>${xmlEscape(sizesText)}</w:t></w:r></w:p></w:tc>
          <w:tc><w:tcPr><w:tcW w:w="1600" w:type="pct"/></w:tcPr><w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="334155"/></w:rPr><w:t>${xmlEscape(m.whereUsed || 'As per site plan')}</w:t></w:r></w:p></w:tc>
          <w:tc><w:tcPr><w:tcW w:w="1200" w:type="pct"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="18"/><w:color w:val="${m.suppliedBy === 'customer' ? '0284C7' : '16A34A'}"/></w:rPr><w:t>${xmlEscape(suppliedText)}</w:t></w:r></w:p></w:tc>
        </w:tr>`;
    });

    bodyXml += `</w:tbl>`;

    // Agreement Terms
    bodyXml += `
      <w:p><w:pPr><w:spacing w:before="240" w:after="80"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="20"/><w:color w:val="0F172A"/></w:rPr><w:t>Terms &amp; Material Guidelines</w:t></w:r></w:p>
      <w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="475569"/></w:rPr><w:t>${xmlEscape(doc.terms || '1. Material brand or specification changes require prior mutual written approval.\n2. Any extra materials returned undamaged remain the respective party’s property.')}</w:t></w:r></w:p>`;

    // Dual Signatures
    bodyXml += `
      <w:p><w:pPr><w:spacing w:before="400"/></w:pPr></w:p>
      <w:tbl>
        <w:tblPr><w:tblW w:w="10000" w:type="pct"/><w:tblBorders><w:top w:val="none"/><w:left w:val="none"/><w:bottom w:val="none"/><w:right w:val="none"/><w:insideH w:val="none"/><w:insideV w:val="none"/></w:tblBorders></w:tblPr>
        <w:tr>
          <w:tc><w:tcPr><w:tcW w:w="5000" w:type="pct"/></w:tcPr>
            <w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="64748B"/></w:rPr><w:t>_____________________________________</w:t></w:r></w:p>
            <w:p><w:r><w:rPr><w:b/><w:sz w:val="20"/><w:color w:val="0F172A"/></w:rPr><w:t>Contractor Signature</w:t></w:r></w:p>
            <w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="64748B"/></w:rPr><w:t>For ${xmlEscape(bizName)}</w:t></w:r></w:p>
          </w:tc>
          <w:tc><w:tcPr><w:tcW w:w="5000" w:type="pct"/></w:tcPr>
            <w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="64748B"/></w:rPr><w:t>_____________________________________</w:t></w:r></w:p>
            <w:p><w:r><w:rPr><w:b/><w:sz w:val="20"/><w:color w:val="0F172A"/></w:rPr><w:t>Customer Acknowledgment</w:t></w:r></w:p>
            <w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="64748B"/></w:rPr><w:t>${xmlEscape(custName)}</w:t></w:r></w:p>
          </w:tc>
        </w:tr>
      </w:tbl>`;

  } else {
    // =========================================================================
    // INVOICE / QUOTATION (Itemized billing with amounts, GST, and totals)
    // =========================================================================
    const items = doc.items || [];
    const subtotal = Number(doc.subtotal || 0);
    const tax = Number(doc.tax || 0);
    const taxPercent = Number(doc.taxPercent || 0);
    const discount = Number(doc.discount || 0);
    const total = Number(doc.total || (subtotal - discount + tax));

    bodyXml += `
      <w:tbl>
        <w:tblPr>
          <w:tblW w:w="10000" w:type="pct"/>
          <w:tblBorders>
            <w:top w:val="single" w:sz="8" w:space="0" w:color="0F172A"/>
            <w:left w:val="single" w:sz="6" w:space="0" w:color="CBD5E1"/>
            <w:bottom w:val="single" w:sz="8" w:space="0" w:color="0F172A"/>
            <w:right w:val="single" w:sz="6" w:space="0" w:color="CBD5E1"/>
            <w:insideH w:val="single" w:sz="4" w:space="0" w:color="E2E8F0"/>
            <w:insideV w:val="single" w:sz="4" w:space="0" w:color="E2E8F0"/>
          </w:tblBorders>
        </w:tblPr>
        <w:tr>
          <w:tc><w:tcPr><w:tcW w:w="600" w:type="pct"/><w:shd w:val="clear" w:color="auto" w:fill="${headerFill}"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="18"/><w:color w:val="${headerTextColor}"/></w:rPr><w:t>#</w:t></w:r></w:p></w:tc>
          <w:tc><w:tcPr><w:tcW w:w="4400" w:type="pct"/><w:shd w:val="clear" w:color="auto" w:fill="${headerFill}"/></w:tcPr><w:p><w:r><w:rPr><w:b/><w:sz w:val="18"/><w:color w:val="${headerTextColor}"/></w:rPr><w:t>Item Description</w:t></w:r></w:p></w:tc>
          <w:tc><w:tcPr><w:tcW w:w="1000" w:type="pct"/><w:shd w:val="clear" w:color="auto" w:fill="${headerFill}"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="18"/><w:color w:val="${headerTextColor}"/></w:rPr><w:t>HSN</w:t></w:r></w:p></w:tc>
          <w:tc><w:tcPr><w:tcW w:w="1200" w:type="pct"/><w:shd w:val="clear" w:color="auto" w:fill="${headerFill}"/></w:tcPr><w:p><w:pPr><w:jc w:val="right"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="18"/><w:color w:val="${headerTextColor}"/></w:rPr><w:t>Quantity</w:t></w:r></w:p></w:tc>
          <w:tc><w:tcPr><w:tcW w:w="1300" w:type="pct"/><w:shd w:val="clear" w:color="auto" w:fill="${headerFill}"/></w:tcPr><w:p><w:pPr><w:jc w:val="right"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="18"/><w:color w:val="${headerTextColor}"/></w:rPr><w:t>Rate (₹)</w:t></w:r></w:p></w:tc>
          <w:tc><w:tcPr><w:tcW w:w="1500" w:type="pct"/><w:shd w:val="clear" w:color="auto" w:fill="${headerFill}"/></w:tcPr><w:p><w:pPr><w:jc w:val="right"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="18"/><w:color w:val="${headerTextColor}"/></w:rPr><w:t>Amount (₹)</w:t></w:r></w:p></w:tc>
        </w:tr>`;

    items.forEach((it, idx) => {
      const qtyStr = `${Number(it.measuredQty || it.qty || 0).toFixed(0)} ${it.unit || 'sq.ft'}`;
      const rateStr = Number(it.rate || 0).toFixed(2);
      const amtStr = Number(it.amount || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

      bodyXml += `
        <w:tr>
          <w:tc><w:tcPr><w:tcW w:w="600" w:type="pct"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:sz w:val="18"/></w:rPr><w:t>${idx + 1}</w:t></w:r></w:p></w:tc>
          <w:tc><w:tcPr><w:tcW w:w="4400" w:type="pct"/></w:tcPr>
            <w:p><w:r><w:rPr><w:b/><w:sz w:val="18"/><w:color w:val="0F172A"/></w:rPr><w:t>${xmlEscape(it.name)}</w:t></w:r></w:p>
            ${(() => {
              const specLine = formatItemSubtitle ? formatItemSubtitle(it) : '';
              const extraLine = [it.basis, it.note, specLine].filter(Boolean).join(' • ');
              return extraLine ? `<w:p><w:r><w:rPr><w:sz w:val="16"/><w:color w:val="64748B"/></w:rPr><w:t>${xmlEscape(extraLine)}</w:t></w:r></w:p>` : '';
            })()}
          </w:tc>
          <w:tc><w:tcPr><w:tcW w:w="1000" w:type="pct"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="64748B"/></w:rPr><w:t>${xmlEscape(it.hsn || '9954')}</w:t></w:r></w:p></w:tc>
          <w:tc><w:tcPr><w:tcW w:w="1200" w:type="pct"/></w:tcPr><w:p><w:pPr><w:jc w:val="right"/></w:pPr><w:r><w:rPr><w:sz w:val="18"/></w:rPr><w:t>${xmlEscape(qtyStr)}</w:t></w:r></w:p></w:tc>
          <w:tc><w:tcPr><w:tcW w:w="1300" w:type="pct"/></w:tcPr><w:p><w:pPr><w:jc w:val="right"/></w:pPr><w:r><w:rPr><w:sz w:val="18"/></w:rPr><w:t>${xmlEscape(rateStr)}</w:t></w:r></w:p></w:tc>
          <w:tc><w:tcPr><w:tcW w:w="1500" w:type="pct"/></w:tcPr><w:p><w:pPr><w:jc w:val="right"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="18"/><w:color w:val="0F172A"/></w:rPr><w:t>${xmlEscape(amtStr)}</w:t></w:r></w:p></w:tc>
        </w:tr>`;
    });

    bodyXml += `</w:tbl>`;

    // Calculations Summary Box
    bodyXml += `
      <w:p><w:pPr><w:spacing w:before="140"/></w:pPr></w:p>
      <w:tbl>
        <w:tblPr><w:tblW w:w="10000" w:type="pct"/><w:tblBorders><w:top w:val="none"/><w:left w:val="none"/><w:bottom w:val="none"/><w:right w:val="none"/><w:insideH w:val="none"/><w:insideV w:val="none"/></w:tblBorders></w:tblPr>
        <w:tr>
          <w:tc><w:tcPr><w:tcW w:w="5500" w:type="pct"/></w:tcPr>
            <w:p><w:r><w:rPr><w:b/><w:sz w:val="18"/><w:color w:val="64748B"/></w:rPr><w:t>Amount in Words:</w:t></w:r></w:p>
            <w:p><w:r><w:rPr><w:b/><w:sz w:val="20"/><w:color w:val="0F172A"/></w:rPr><w:t>${xmlEscape(numberToIndianWords(total))}</w:t></w:r></w:p>
            ${business.bankName ? `
            <w:p><w:pPr><w:spacing w:before="120"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="18"/><w:color w:val="64748B"/></w:rPr><w:t>Bank Payment Details:</w:t></w:r></w:p>
            <w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="334155"/></w:rPr><w:t>Bank: ${xmlEscape(business.bankName)} • A/C: ${xmlEscape(business.accountNo || '—')} • IFSC: ${xmlEscape(business.ifsc || '—')}</w:t></w:r></w:p>
            ${business.upiId ? `<w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="334155"/></w:rPr><w:t>UPI ID: ${xmlEscape(business.upiId)}</w:t></w:r></w:p>` : ''}` : ''}
          </w:tc>
          <w:tc><w:tcPr><w:tcW w:w="4500" w:type="pct"/><w:shd w:val="clear" w:color="auto" w:fill="F8FAFC"/></w:tcPr>
            <w:p><w:pPr><w:jc w:val="right"/></w:pPr><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="64748B"/></w:rPr><w:t>Subtotal: ₹ ${subtotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</w:t></w:r></w:p>
            ${discount ? `<w:p><w:pPr><w:jc w:val="right"/></w:pPr><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="DC2626"/></w:rPr><w:t>Discount: - ₹ ${discount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</w:t></w:r></w:p>` : ''}
            ${tax ? `<w:p><w:pPr><w:jc w:val="right"/></w:pPr><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="64748B"/></w:rPr><w:t>GST (${taxPercent}%): ₹ ${tax.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</w:t></w:r></w:p>` : ''}
            <w:p><w:pPr><w:jc w:val="right"/><w:spacing w:before="60"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="24"/><w:color w:val="${headerFill === 'F1F5F9' ? '0F172A' : headerFill}"/></w:rPr><w:t>Grand Total: ₹ ${total.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</w:t></w:r></w:p>
          </w:tc>
        </w:tr>
      </w:tbl>`;

    // Terms & Signatures
    bodyXml += `
      <w:p><w:pPr><w:spacing w:before="240" w:after="60"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="20"/><w:color w:val="0F172A"/></w:rPr><w:t>Terms &amp; Conditions</w:t></w:r></w:p>
      <w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="475569"/></w:rPr><w:t>${xmlEscape(doc.terms || '1. Work undertaken as per the specifications above.\n2. Milestone payments as mutually agreed.\n3. Goods once delivered/installed cannot be returned.')}</w:t></w:r></w:p>
      
      <w:p><w:pPr><w:spacing w:before="400"/></w:pPr></w:p>
      <w:tbl>
        <w:tblPr><w:tblW w:w="10000" w:type="pct"/><w:tblBorders><w:top w:val="none"/><w:left w:val="none"/><w:bottom w:val="none"/><w:right w:val="none"/><w:insideH w:val="none"/><w:insideV w:val="none"/></w:tblBorders></w:tblPr>
        <w:tr>
          <w:tc><w:tcPr><w:tcW w:w="5000" w:type="pct"/></w:tcPr>
            <w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="64748B"/></w:rPr><w:t>_____________________________________</w:t></w:r></w:p>
            <w:p><w:r><w:rPr><w:b/><w:sz w:val="20"/><w:color w:val="0F172A"/></w:rPr><w:t>Authorized Signatory</w:t></w:r></w:p>
            <w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="64748B"/></w:rPr><w:t>For ${xmlEscape(bizName)}</w:t></w:r></w:p>
          </w:tc>
          <w:tc><w:tcPr><w:tcW w:w="5000" w:type="pct"/></w:tcPr>
            <w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="64748B"/></w:rPr><w:t>_____________________________________</w:t></w:r></w:p>
            <w:p><w:r><w:rPr><w:b/><w:sz w:val="20"/><w:color w:val="0F172A"/></w:rPr><w:t>Customer Signature</w:t></w:r></w:p>
            <w:p><w:r><w:rPr><w:sz w:val="18"/><w:color w:val="64748B"/></w:rPr><w:t>${xmlEscape(custName)}</w:t></w:r></w:p>
          </w:tc>
        </w:tr>
      </w:tbl>`;
  }

  // Page setup: A4 portrait
  bodyXml += `
    <w:sectPr>
      <w:pgSz w:w="11906" w:h="16838"/>
      <w:pgMar w:top="720" w:right="720" w:bottom="720" w:left="720"/>
    </w:sectPr>`;

  const contentTypesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>`;

  const relsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`;

  const docRelsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`;

  const stylesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:docDefaults>
    <w:rPrDefault>
      <w:rPr>
        <w:rFonts w:ascii="Segoe UI" w:hAnsi="Segoe UI" w:cs="Segoe UI"/>
        <w:sz w:val="20"/>
      </w:rPr>
    </w:rPrDefault>
  </w:docDefaults>
</w:styles>`;

  const documentXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    ${bodyXml}
  </w:body>
</w:document>`;

  return createZip([
    { path: '[Content_Types].xml', content: contentTypesXml },
    { path: '_rels/.rels', content: relsXml },
    { path: 'word/_rels/document.xml.rels', content: docRelsXml },
    { path: 'word/styles.xml', content: stylesXml },
    { path: 'word/document.xml', content: documentXml }
  ]);
}

module.exports = {
  generateDocx,
  xmlEscape
};
