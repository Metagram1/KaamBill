const services=[
 ['tiles','Tiles & stone','grid-outline','Flooring, skirting & marble','టైల్స్ & స్టోన్','टाइल्स और पत्थर'],
 ['construction','Construction','business-outline','Civil work & full contracts','నిర్మాణం','निर्माण'],
 ['plumbing','Plumbing','water-outline','Water lines & sanitary','ప్లంబింగ్','प्लंबिंग'],
 ['electrical','Electrical','flash-outline','Wiring, points & fittings','ఎలక్ట్రికల్','इलेक्ट्रिकल'],
 ['cement','Cement & materials','cube-outline','Bags, steel, sand & delivery','సిమెంట్ & మెటీరియల్స్','सीमेंट और सामग्री'],
 ['painting','Painting','color-palette-outline','Putty, primer & finishes','పెయింటింగ్','पेंटिंग'],
 ['carpentry','Carpentry','hammer-outline','Doors, cabinets & interiors','కార్పెంట్రీ','कारपेंट्री'],
 ['steel','Steel & fabrication','construct-outline','Grills, gates & structures','స్టీల్ ఫ్యాబ్రికేషన్','स्टील फ़ैब्रिकेशन'],
 ['roofing','Roofing','home-outline','Sheets, sheds & canopies','రూఫింగ్','रूफिंग'],
 ['waterproofing','Waterproofing','shield-checkmark-outline','Terraces, bathrooms & repairs','వాటర్‌ప్రూఫింగ్','वॉटरप्रूफिंग'],
 ['earthwork','Earthwork','layers-outline','Excavation, filling & levelling','మట్టి పనులు','मिट्टी का काम'],
 ['other','Other services','apps-outline','Your trade, your own items','ఇతర సేవలు','अन्य सेवाएँ']
].map(([id,name,icon,desc,te,hi])=>({id,name,icon,desc,te,hi}));
const rows={
 tiles:[['Floor tile laying','ఫ్లోర్ టైల్స్ అమరిక','फ़्लोर टाइल लगाना','sq.ft',45,'area'],['Wall tile laying','వాల్ టైల్స్ అమరిక','दीवार टाइल लगाना','sq.ft',55,'area'],['Skirting','స్కర్టింగ్','स्कर्टिंग','r.ft',35,'length'],['Granite installation','గ్రానైట్ అమరిక','ग्रेनाइट लगाना','sq.ft',90,'area'],['Stair tread','మెట్ల పని','सीढ़ी का काम','no',650,'qty']],
 construction:[['Brick masonry','ఇటుక పని','ईंट का काम','cu.ft',35,'volume'],['Internal plastering','లోపలి ప్లాస్టరింగ్','अंदर का प्लास्टर','sq.ft',28,'area'],['RCC concrete work','ఆర్‌సీసీ కాంక్రీట్','आरसीसी कंक्रीट','cu.m',6500,'volume'],['Shuttering labour','సెంట్రింగ్ పని','शटरिंग मज़दूरी','sq.ft',45,'area'],['Full construction contract','పూర్తి నిర్మాణ ఒప్పందం','पूर्ण निर्माण अनुबंध','sq.ft',2000,'area']],
 plumbing:[['Water pipe installation','నీటి పైపు అమరిక','पानी का पाइप लगाना','r.ft',55,'length'],['Sanitary point','శానిటరీ పాయింట్','सैनिटरी पॉइंट','point',850,'qty'],['WC installation','డబ్ల్యూసీ అమరిక','शौचालय लगाना','no',1500,'qty'],['Wash basin installation','వాష్ బేసిన్ అమరిక','वॉश बेसिन लगाना','no',800,'qty'],['Leak repair','లీకేజీ మరమ్మత్తు','लीक मरम्मत','job',500,'qty']],
 electrical:[['Wiring point','వైరింగ్ పాయింట్','वायरिंग पॉइंट','point',650,'qty'],['Light fitting','లైట్ అమరిక','लाइट फिटिंग','no',180,'qty'],['Fan installation','ఫ్యాన్ అమరిక','पंखा लगाना','no',350,'qty'],['Distribution board','డిస్ట్రిబ్యూషన్ బోర్డ్','डिस्ट्रिब्यूशन बोर्ड','no',2500,'qty'],['Cable laying','కేబుల్ అమరిక','केबल बिछाना','m',60,'length']],
 cement:[['Cement, 50 kg bag','సిమెంట్ 50 కిలోల బస్తా','सीमेंट 50 किलो बैग','bag',350,'qty'],['TMT steel','టీఎంటీ స్టీల్','टीएमटी स्टील','kg',65,'qty'],['Sand supply','ఇసుక సరఫరా','रेत आपूर्ति','cu.ft',55,'qty'],['Aggregate supply','కంకర సరఫరా','गिट्टी आपूर्ति','tonne',1200,'qty'],['Transport & unloading','రవాణా & అన్‌లోడింగ్','ढुलाई और उतराई','job',1500,'qty']],
 painting:[['Wall putty','వాల్ పుట్టీ','दीवार पुट्टी','sq.ft',14,'area'],['Primer coat','ప్రైమర్ కోట్','प्राइमर कोट','sq.ft',8,'area'],['Interior emulsion','లోపలి పెయింట్','अंदर का पेंट','sq.ft',18,'area'],['Exterior painting','బయటి పెయింటింగ్','बाहर की पेंटिंग','sq.ft',25,'area']],
 carpentry:[['Modular cabinet','మాడ్యులర్ క్యాబినెట్','मॉड्यूलर कैबिनेट','sq.ft',1600,'area'],['Door installation','తలుపు అమరిక','दरवाज़ा लगाना','no',1800,'qty'],['Wood polishing','వుడ్ పాలిషింగ్','लकड़ी पॉलिश','sq.ft',100,'area']],
 steel:[['MS grill fabrication','ఎంఎస్ గ్రిల్ పని','एमएस ग्रिल निर्माण','kg',110,'qty'],['Gate fabrication','గేటు తయారీ','गेट निर्माण','sq.ft',450,'area'],['Structural welding','స్ట్రక్చరల్ వెల్డింగ్','स्ट्रक्चरल वेल्डिंग','job',3000,'qty']],
 roofing:[['UPVC roofing sheets','యూపీవీసీ రూఫింగ్ షీట్లు','यूपीवीसी रूफिंग शीट','sq.ft',110,'area'],['Sheet installation labour','షీట్ల అమరిక కూలీ','शीट लगाने की मज़दूरी','sq.ft',25,'area'],['Rainwater gutter','వర్షపు నీటి గట్టర్','वर्षा जल गटर','r.ft',220,'length']],
 waterproofing:[['Terrace waterproofing','టెర్రస్ వాటర్‌ప్రూఫింగ్','छत वॉटरप्रूफिंग','sq.ft',65,'area'],['Bathroom waterproofing','బాత్రూమ్ వాటర్‌ప్రూఫింగ్','बाथरूम वॉटरप्रूफिंग','sq.ft',80,'area'],['Crack treatment','పగుళ్ల మరమ్మత్తు','दरार मरम्मत','r.ft',100,'length']],
 earthwork:[['Excavation','తవ్వకం','खुदाई','cu.m',350,'volume'],['Soil filling','మట్టి నింపడం','मिट्टी भरना','cu.m',450,'volume'],['Levelling','లెవెలింగ్','समतलीकरण','sq.ft',6,'area']],
 other:[['Custom service','కస్టమ్ సేవ','कस्टम सेवा','job',0,'qty']]
};
const catalogue=Object.entries(rows).flatMap(([service,items])=>items.map(([name,te,hi,unit,rate,mode],i)=>({id:service+'-'+i,service,name,te,hi,unit,rate,mode,basis:'labour / materials: confirm',sample:true})));
const districts=[
 'Andhra Pradesh: Alluri Sitharama Raju', 'Anakapalli', 'Anantapur', 'Annamayya', 'Bapatla', 'Chittoor', 'Dr. B. R. Ambedkar Konaseema', 'East Godavari', 'Eluru', 'Guntur', 'Kakinada', 'Krishna', 'Kurnool', 'Nandyal', 'NTR', 'Palnadu', 'Parvathipuram Manyam', 'Prakasam', 'Srikakulam', 'Sri Potti Sriramulu Nellore', 'Sri Sathya Sai', 'Tirupati', 'Visakhapatnam', 'Vizianagaram', 'West Godavari', 'YSR Kadapa',
 'Telangana: Hyderabad', 'Adilabad', 'Bhadradri Kothagudem', 'Hanamkonda', 'Jagtial', 'Jangaon', 'Jayashankar Bhupalpally', 'Jogulamba Gadwal', 'Kamareddy', 'Karimnagar', 'Khammam', 'Komaram Bheem Asifabad', 'Mahabubabad', 'Mahabubnagar', 'Mancherial', 'Medak', 'Medchal-Malkajgiri', 'Mulugu', 'Nagarkurnool', 'Nalgonda', 'Narayanpet', 'Nirmal', 'Nizamabad', 'Peddapalli', 'Rajanna Sircilla', 'Rangareddy', 'Sangareddy', 'Siddipet', 'Suryapet', 'Vikarabad', 'Wanaparthy', 'Warangal', 'Yadadri Bhuvanagiri',
 'Other / enter below'
];
const units=['sq.ft','sq.m','cu.ft','cu.m','r.ft','m','no','point','bag','kg','tonne','day','job'];
const round=n=>Math.round((n+Number.EPSILON)*100)/100;
const nonneg=(v,label='Value')=>{const n=Number(v);if(!Number.isFinite(n)||n<0||n>1e9)throw Error(label+' must be a valid non-negative number');return n};
function calcLine(l){const count=nonneg(l.qty??1,'Quantity'),rate=nonneg(l.rate,'Rate');let qty=count;const factor={ft:.3048,in:.0254,m:1}[l.dimensionUnit||'ft'];if(!factor)throw Error('Invalid dimension unit');if(!units.includes(l.unit))throw Error('Invalid billing unit');const hasDimensions=l.length!==undefined||l.width!==undefined;if(l.mode&&l.mode!=='qty'&&hasDimensions){const length=nonneg(l.length,'Length')*factor,width=nonneg(l.width||0,'Width')*factor,height=nonneg(l.height||0,'Height')*factor;let base;if(l.mode==='length'){if(!['r.ft','m'].includes(l.unit))throw Error('Length needs r.ft or m');base=length/(l.unit==='r.ft'?.3048:1)}else if(l.mode==='area'){if(!['sq.ft','sq.m'].includes(l.unit))throw Error('Area needs sq.ft or sq.m');base=length*width/(l.unit==='sq.ft'?.09290304:1)}else if(l.mode==='volume'){if(!['cu.ft','cu.m'].includes(l.unit))throw Error('Volume needs cu.ft or cu.m');base=length*width*height/(l.unit==='cu.ft'?.028316846592:1)}else throw Error('Invalid measurement mode');qty=base*count;}else if(l.measuredQty!==undefined){qty=Number(l.measuredQty)||count;}const deduction=nonneg(l.deduction||0,'Deduction');if(deduction>qty)throw Error('Deduction exceeds measured quantity');qty=round(qty-deduction);if(qty<=0)throw Error('Quantity must be greater than zero');return {...l,qty:count,measuredQty:qty,rate,amount:round(qty*rate)};}
function totals(items,discount=0,taxPercent=0,retentionPercent=0){const subtotal=round(items.reduce((s,l)=>s+calcLine(l).amount,0));discount=nonneg(discount,'Discount');if(discount>subtotal)throw Error('Discount exceeds subtotal');taxPercent=nonneg(taxPercent,'Tax');retentionPercent=nonneg(retentionPercent,'Retention');if(taxPercent>100||retentionPercent>100)throw Error('Percentage cannot exceed 100');const tax=round((subtotal-discount)*taxPercent/100),total=round(subtotal-discount+tax),retention=round(total*retentionPercent/100);return {subtotal,discount,tax,taxPercent,retentionPercent,retention,total,dueNow:round(total-retention)};}
const defaultTradeMaterials = [
  // Electrical
  { id: 'mat-el-1', service: 'electrical', category: 'Wires', name: '1.5 sq mm Copper Wire', teName: '1.5 స్క్వేర్ ఎంఎం రాగి వైర్', hiName: '1.5 वर्ग मिमी कॉपर वायर', specs: 'Polycab • Red / Blue • 90 m roll', brand: 'Polycab', unit: 'roll', defaultRate: 1450, isFavorite: true },
  { id: 'mat-el-2', service: 'electrical', category: 'Wires', name: '2.5 sq mm Copper Wire', teName: '2.5 స్క్వేర్ ఎంఎం రాగి వైర్', hiName: '2.5 वर्ग मिमी कॉपर वायर', specs: 'Havells • Red / Black • 90 m roll', brand: 'Havells', unit: 'roll', defaultRate: 2250, isFavorite: true },
  { id: 'mat-el-3', service: 'electrical', category: 'Switches', name: '6A Modular Switch', teName: '6A మాడ్యులర్ స్విచ్', hiName: '6A मॉड्यूलर स्विच', specs: 'Anchor Roma • 1-way white', brand: 'Anchor Roma', unit: 'pcs', defaultRate: 45, isFavorite: true },
  { id: 'mat-el-4', service: 'electrical', category: 'Switches', name: '16A Power Socket', teName: '16A పవర్ సాకెట్', hiName: '16A पावर सॉकेट', specs: 'Anchor Roma • 3-pin with switch', brand: 'Anchor Roma', unit: 'pcs', defaultRate: 160, isFavorite: true },
  { id: 'mat-el-5', service: 'electrical', category: 'Pipes', name: '25mm PVC Conduit Pipe', teName: '25mm పీవీసీ కండ్యూట్ పైప్', hiName: '25 मिमी पीवीसी कंड्यूट पाइप', specs: 'Sudhakar • Heavy 2mm • 3m', brand: 'Sudhakar', unit: 'length', defaultRate: 95, isFavorite: true },
  { id: 'mat-el-6', service: 'electrical', category: 'Pipes', name: 'Modular Metal Gang Box (6M)', teName: 'మాడ్యులర్ మెటల్ గ్యాంగ్ బాక్స్ (6M)', hiName: 'मॉड्यूलर मेटल गैंग बॉक्स (6M)', specs: 'Concealed GI metal box 6 module', brand: 'Anchor', unit: 'pcs', defaultRate: 120, isFavorite: false },
  { id: 'mat-el-7', service: 'electrical', category: 'Other', name: '32A Double Pole MCB', teName: '32A డబుల్ పోల్ ఎంసీబీ', hiName: '32A डबल पोल एमसीबी', specs: 'Legrand / Schneider • C-Curve', brand: 'Legrand', unit: 'pcs', defaultRate: 380, isFavorite: false },
  // Tiles
  { id: 'mat-tl-1', service: 'tiles', category: 'Adhesives', name: 'Tile Adhesive (Grey)', teName: 'టైల్ అడెసివ్ (గ్రే)', hiName: 'टाइल एडहेसिव (ग्रे)', specs: 'Roff T01 / Kerakoll • 20 kg bag', brand: 'Roff', unit: 'bag', defaultRate: 380, isFavorite: true },
  { id: 'mat-tl-2', service: 'tiles', category: 'Grout', name: 'Epoxy Tile Grout', teName: 'ఎపాక్సీ టైల్ గ్రౌట్', hiName: 'एपॉक्सी टाइल ग्राउट', specs: 'Laticrete Spectralock • 1 kg pack', brand: 'Laticrete', unit: 'kg', defaultRate: 450, isFavorite: true },
  { id: 'mat-tl-3', service: 'tiles', category: 'Spacers', name: '3mm Cross Tile Spacers', teName: '3mm క్రాస్ టైల్ స్పేసర్లు', hiName: '3 मिमी टाइल स्पेसर्स', specs: 'Heavy duty plastic • 200 pcs pack', brand: 'Standard', unit: 'pack', defaultRate: 120, isFavorite: true },
  { id: 'mat-tl-4', service: 'tiles', category: 'Tiles', name: '2x2 Vitrified Floor Tiles', teName: '2x2 విట్రిఫైడ్ ఫ్లోర్ టైల్స్', hiName: '2x2 विट्रीफाइड फ्लोर टाइल्स', specs: 'Kajaria / Somany • Glossy finish • Box of 4', brand: 'Kajaria', unit: 'box', defaultRate: 850, isFavorite: true },
  // Plumbing
  { id: 'mat-pl-1', service: 'plumbing', category: 'Pipes', name: '1 inch CPVC Pipe', teName: '1 ఇంచ్ సీపీవీసీ పైప్', hiName: '1 इंच सीपीवीसी पाइप', specs: 'Astral SDR 11 • 3m length', brand: 'Astral', unit: 'length', defaultRate: 320, isFavorite: true },
  { id: 'mat-pl-2', service: 'plumbing', category: 'Fittings', name: '1 inch CPVC Elbow 90°', teName: '1 ఇంచ్ సీపీవీసీ ఎల్బో 90°', hiName: '1 इंच सीपीवीसी एल्बो', specs: 'Astral SDR 11 heavy brass insert', brand: 'Astral', unit: 'pcs', defaultRate: 35, isFavorite: true },
  { id: 'mat-pl-3', service: 'plumbing', category: 'Valves', name: 'Concealed Stop Valve 15mm', teName: 'కన్సీల్డ్ స్టాప్ వాల్వ్ 15mm', hiName: 'कंसील्ड स्टॉप वाल्व', specs: 'Jaquar / Astral quarter turn brass', brand: 'Jaquar', unit: 'pcs', defaultRate: 420, isFavorite: true },
  { id: 'mat-pl-4', service: 'plumbing', category: 'Fittings', name: '1 inch CPVC Tee', teName: '1 ఇంచ్ సీపీవీసీ టీ', hiName: '1 इंच सीपीवीसी टी', specs: 'Astral SDR 11 standard', brand: 'Astral', unit: 'pcs', defaultRate: 48, isFavorite: false },
  // Painting
  { id: 'mat-pt-1', service: 'painting', category: 'Putty', name: 'Acrylic Wall Putty', teName: 'వాల్ పుట్టీ 40 కేజీల బస్తా', hiName: 'दीवार पुट्टी 40 किलो', specs: 'Birla White • Water resistant • 40 kg', brand: 'Birla White', unit: 'bag', defaultRate: 920, isFavorite: true },
  { id: 'mat-pt-2', service: 'painting', category: 'Primer', name: 'Interior Wall Primer', teName: 'ఇంటీరియర్ వాల్ ప్రైమర్', hiName: 'अंदर का वॉल प्राइमर', specs: 'Asian Paints Decoprime • 20 L bucket', brand: 'Asian Paints', unit: 'bucket', defaultRate: 2100, isFavorite: true },
  { id: 'mat-pt-3', service: 'painting', category: 'Paint', name: 'Premium Interior Emulsion', teName: 'ప్రీమియం ఇంటీరియర్ పెయింట్', hiName: 'प्रीमियम इंटीरियर इमल्शन', specs: 'Asian Paints Royale Luxury • 20 L', brand: 'Asian Paints', unit: 'bucket', defaultRate: 4800, isFavorite: true },
  { id: 'mat-pt-4', service: 'painting', category: 'Tools', name: '9 inch Paint Roller with Tray', teName: '9 ఇంచ్ పెయింట్ రోలర్ & ట్రే', hiName: '9 इंच पेंट रोलर व ट्रे', specs: 'High density foam with sturdy handle', brand: 'Asian Paints', unit: 'set', defaultRate: 260, isFavorite: false }
];

function emptyWorkspace(){return {schema:6,business:{name:'',owner:'',phone:'',address:'',district:'Kakinada',city:'',language:'en',prefix:'TB',service:'tiles',logo:'',signature:'',template:'executive',pageSize:'a4',upiId:''},onboarded:true,customers:[],projects:[],documents:[],payments:[],workers:[],attendance:[],payouts:[],feedback:[],rates:catalogue.map(x=>({...x})),nextNo:1,agreements:[],materialsCatalog:defaultTradeMaterials.map(x=>({...x})),materialLists:[]};}
const dict={en:{quotation:'QUOTATION',invoice:'INVOICE',customer:'Customer',project:'Project',description:'Description',quantity:'Quantity',rate:'Rate',amount:'Amount',subtotal:'Subtotal',discount:'Discount',tax:'Tax',total:'Grand total',paid:'Paid',balance:'Balance',terms:'Terms & scope',exclusions:'Exclusions',milestones:'Payment milestones',thanks:'Thank you for trusting us.',unit:'Unit',date:'Date',valid:'Valid until / due date',retention:'Retention',dueNow:'Due now',signature:'Authorised signature',measure:'Measurement',feedback:'Share your feedback'},te:{quotation:'కొటేషన్',invoice:'బిల్లు',customer:'కస్టమర్',project:'ప్రాజెక్ట్',description:'పని వివరాలు',quantity:'పరిమాణం',rate:'ధర',amount:'మొత్తం',subtotal:'ఉప మొత్తం',discount:'తగ్గింపు',tax:'పన్ను',total:'మొత్తం చెల్లింపు',paid:'చెల్లించినది',balance:'బాకీ',terms:'నిబంధనలు & పని పరిధి',exclusions:'మినహాయింపులు',milestones:'చెల్లింపు దశలు',thanks:'మాపై నమ్మకం ఉంచినందుకు ధన్యవాదాలు.',unit:'యూనిట్',date:'తేదీ',valid:'గడువు తేదీ',retention:'నిలుపుదల మొత్తం',dueNow:'ఇప్పుడు చెల్లించవలసినది',signature:'అధీకృత సంతకం',measure:'కొలతలు',feedback:'మీ అభిప్రాయం తెలియజేయండి'},hi:{quotation:'कोटेशन',invoice:'बिल',customer:'ग्राहक',project:'परियोजना',description:'काम का विवरण',quantity:'मात्रा',rate:'दर',amount:'राशि',subtotal:'उप योग',discount:'छूट',tax:'कर',total:'कुल राशि',paid:'भुगतान',balance:'बकाया',terms:'शर्तें और कार्यक्षेत्र',exclusions:'बहिष्करण',milestones:'भुगतान चरण',thanks:'हम पर भरोसा करने के लिए धन्यवाद।',unit:'इकाई',date:'तारीख',valid:'अंतिम तारीख',retention:'रोक राशि',dueNow:'अभी देय',signature:'अधिकृत हस्ताक्षर',measure:'माप',feedback:'अपनी प्रतिक्रिया दें'}};
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=n=>'₹'+Number(n||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});

const documentTemplates=[
 {id:'classic_ledger',name:'01 Classic Ledger',desc:'Clean, professional double-box ledger with reference dates & terms. Best for detailed print.',color:'#171817',accent:'#000000',page:1,ready:true},
 {id:'amber_grid',name:'02 Orange Trade Grid',desc:'Solid orange title banner, separate logo box & alternating item grid.',color:'#E65100',accent:'#F25C05',page:1,ready:true},
 {id:'olive_grid',name:'03 Olive Grid',desc:'Earthy olive green structured format with clean margins.',color:'#3F6212',accent:'#65A30D',page:1,ready:false},
 {id:'compact_trade',name:'04 Blue Commercial Form',desc:'Upper-right italic invoice title, commercial strip & structured blue table.',color:'#0066B2',accent:'#0080FF',page:1,ready:true},
 {id:'blue_timesheet',name:'05 Teal Minimal',desc:'Full-width deep teal header, clean rules & subtle alternating rows.',color:'#1A5B78',accent:'#227093',page:1,ready:true},
 {id:'sales_detail',name:'06 Sales Detail',desc:'Detailed sales & tax quotation with HSN/SAC columns.',color:'#1D4ED8',accent:'#60A5FA',page:1,ready:false},
 {id:'corporate_sales',name:'07 Compact Spreadsheet',desc:'Compact Excel-style spreadsheet with indigo header bars & grid.',color:'#3B5998',accent:'#2F4878',page:2,ready:true},
 {id:'contractor_detail',name:'08 Contractor Detail',desc:'Contractor detail with split Materials + Labour tables.',color:'#171817',accent:'#FFD500',page:2,ready:true},
 {id:'project_summary',name:'09 Project Summary',desc:'Clean bold summary with Work, Basis, Amount & optional materials annexure.',color:'#171817',accent:'#FFD500',page:2,ready:true},
 {id:'tilebill_classic',name:'10 TileBill Classic',desc:'Original signature TileBill gold accented quotation format.',color:'#854D0E',accent:'#FACC15',page:2,ready:true}
];

function resolveTemplate(id){
 const aliases={
  executive:'classic_ledger',
  modern:'corporate_sales',
  luxury:'tilebill_classic',
  fintech:'blue_timesheet',
  industrial:'contractor_detail',
  compact:'compact_trade',
  orange_grid:'amber_grid',
  teal_minimal:'blue_timesheet',
  blue_commercial:'compact_trade',
  compact_spreadsheet:'corporate_sales'
 };
 const resolved = aliases[id] || id;
 return documentTemplates.find(x=>x.id===resolved) || documentTemplates[0];
}

function numberToIndianWords(n){
 const num = Math.round(Number(n || 0));
 if (num === 0) return 'Zero Rupees Only';
 if (num < 0) return 'Minus ' + numberToIndianWords(-num);

 const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
  'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
 const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

 function convertBelowThousand(val) {
  let str = '';
  if (val >= 100) {
   str += ones[Math.floor(val / 100)] + ' Hundred ';
   val %= 100;
  }
  if (val >= 20) {
   str += tens[Math.floor(val / 10)] + ' ';
   val %= 10;
  }
  if (val > 0) {
   str += ones[val] + ' ';
  }
  return str.trim();
 }

 const crore = Math.floor(num / 10000000);
 const lakh = Math.floor((num % 10000000) / 100000);
 const thousand = Math.floor((num % 100000) / 1000);
 const remainder = num % 1000;

 let parts = [];
 if (crore > 0) parts.push(convertBelowThousand(crore) + ' Crore');
 if (lakh > 0) parts.push(convertBelowThousand(lakh) + ' Lakh');
 if (thousand > 0) parts.push(convertBelowThousand(thousand) + ' Thousand');
 if (remainder > 0) parts.push(convertBelowThousand(remainder));

 return parts.join(' ') + ' Rupees Only';
}

const pageSizes=[
 {id:'a4',name:'A4 Standard (Full page)',rule:'@page{size:A4;margin:12mm}'},
 {id:'letter',name:'Letter Standard',rule:'@page{size:letter;margin:12mm}'},
 {id:'a5',name:'A5 Compact (Half page)',rule:'@page{size:A5;margin:8mm}'},
 {id:'thermal',name:'Thermal 80mm (Slip)',rule:'@page{size:80mm auto;margin:4mm}'}
];

function generateBrandMonogramSvg(name='TileBill Pro',color='#0F2744',accent='#D97706'){
 const words=String(name||'TileBill Pro').trim().split(/\s+/).filter(Boolean);
 const initials=(words.length>=2?words[0][0]+words[1][0]:words[0]?.slice(0,2)||'TB').toUpperCase();
 return `<svg width="58" height="58" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" style="display:inline-block;vertical-align:middle;box-shadow:0 2px 6px rgba(0,0,0,0.12);border-radius:12px">
  <defs><linearGradient id="g_${initials}" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="${color}"/><stop offset="100%" stop-color="#050B14"/></linearGradient></defs>
  <rect width="100" height="100" rx="14" fill="url(#g_${initials})"/>
  <rect x="5" y="5" width="90" height="90" rx="10" fill="none" stroke="${accent}" stroke-width="2.5" opacity="0.8"/>
  <circle cx="50" cy="50" r="32" fill="none" stroke="${accent}" stroke-width="1.2" opacity="0.35"/>
  <text x="50" y="58" font-family="'Segoe UI',Inter,Arial,sans-serif" font-size="34" font-weight="700" fill="#FFFFFF" text-anchor="middle" letter-spacing="1.5">${initials}</text>
 </svg>`;
}

function computeUnitSummary(items){
 if(!items || !items.length) return '';
 const unitCounts = {};
 items.forEach(it => {
  const u = it.unit || 'sq.ft';
  unitCounts[u] = (unitCounts[u] || 0) + Number(it.measuredQty || it.qty || 0);
 });
 const keys = Object.keys(unitCounts);
 if (keys.length === 1) {
  return `${unitCounts[keys[0]].toFixed(0)} ${keys[0]}`;
 }
 if (keys.length <= 3) {
  return keys.map(k => `${unitCounts[k].toFixed(0)} ${k}`).join(', ');
 }
 return '';
}

function computeTaxDetails(doc){
 const taxable = Math.max(0, Number(doc.subtotal || 0) - Number(doc.discount || 0));
 const tax = Number(doc.tax || 0);
 const taxPercent = Number(doc.taxPercent || 0);
 const halfPercent = taxPercent ? (taxPercent / 2).toFixed(1) + '%' : '0%';
 const cgst = Math.round((tax / 2 + Number.EPSILON) * 100) / 100;
 const sgst = Math.round((tax - cgst + Number.EPSILON) * 100) / 100;
 const total = Number(doc.total || (taxable + tax));
 const roundOff = total ? Math.round((Math.round(total) - total + Number.EPSILON) * 100) / 100 : 0;
  return { taxable, tax, taxPercent, halfPercent, cgst, sgst, total, roundOff };
}

function formatItemSubtitle(l) {
  if (!l) return '';
  const parts = [];
  if (l.size) parts.push(`Size: ${l.size}`);
  if (l.brand) parts.push(`Brand: ${l.brand}`);
  if (l.model) parts.push(`Model: ${l.model}`);
  if (l.notes) {
    const n = String(l.notes).trim();
    parts.push(n.toLowerCase().startsWith('notes:') ? n : `Notes: ${n}`);
  }
  if (Array.isArray(l.customFields)) {
    l.customFields.forEach(cf => {
      if (cf && cf.label && cf.value) parts.push(`${cf.label}: ${cf.value}`);
    });
  }
  return parts.join(' · ');
}

function documentHtml(doc,business){
 const t=dict[doc.language]||dict.en;
 const paid=Number(doc.paid||0);
 const templateId=doc.template||business?.template||'classic_ledger';
 const pageSizeId=doc.pageSize||business?.pageSize||'a4';
 const theme=resolveTemplate(templateId);
 const sizeConfig=pageSizes.find(x=>x.id===pageSizeId)||pageSizes[0];
 const isQuotation = doc.kind !== 'invoice';
 const docTitle = isQuotation ? 'QUOTATION' : 'TAX INVOICE';
 const localizedHeader = doc.language && doc.language !== 'en' ? `${t[doc.kind]} (${docTitle})` : docTitle;
 const totalQty = (doc.items||[]).reduce((sum, it) => sum + Number(it.measuredQty || it.qty || 0), 0);
 const mainUnit = doc.items?.[0]?.unit || 'sq.ft';
 const qtySummary = computeUnitSummary(doc.items);
 const taxDetails = computeTaxDetails(doc);
 const roundOff = taxDetails.roundOff;
 const hasTax = Number(doc.tax || 0) > 0 || Number(doc.taxPercent || 0) > 0;
 const annexureHtml = doc.attachAgreement ? `\n<div style="page-break-before:always;padding-top:20px;margin-top:24px;border-top:2px dashed #CBD5E1;">\n  <div style="font-size:10px;text-transform:uppercase;letter-spacing:1px;color:#64748B;font-weight:700;margin-bottom:8px;">Annexure — Material Specifications</div>\n  ${renderAgreementContent(doc.agreement || doc.agreementData || {}, business, doc)}\n</div>` : '';

 // Shared CSS reset and A4 print foundation
 const basePrintCss = `${sizeConfig.rule}
*{box-sizing:border-box}
body{font:11.5px/1.4 'Segoe UI',Inter,-apple-system,BlinkMacSystemFont,Arial,'Noto Sans Telugu','Noto Sans Devanagari',sans-serif;color:#171817;margin:0;background:white;padding:${pageSizeId==='thermal'?'8px':'18px'};-webkit-font-smoothing:antialiased}
thead{display:table-header-group}
tr{break-inside:avoid;page-break-inside:avoid}
.avoid-break{break-inside:avoid;page-break-inside:avoid}
@media print{.no-print{display:none!important}}`;

 // 1. Layout: Classic Ledger (Reference 1: e-invoice-in-tallyprime)
 if (theme.id === 'classic_ledger') {
  const tableRows = (doc.items||[]).map((l, i) => {
   const entry=catalogue.find(x=>x.id===l.catalogueId);
   const name=entry&&l.name===entry.name&&doc.language!=='en'?entry[doc.language]||l.name:l.name;
   const subtitle = formatItemSubtitle(l);
   return `<tr>
    <td style="text-align:center;padding:6px;border:1px solid #171817;width:34px;">${i+1}</td>
    <td style="padding:6px 8px;border:1px solid #171817;">
     <div style="font-weight:700;font-size:12px;color:#171817;">${esc(name)}</div>
     ${subtitle ? `<div style="font-size:10px;color:#475569;margin-top:2px;">${esc(subtitle)}</div>` : ''}
     ${l.section?`<div style="font-size:10px;color:#64748B;">${esc(l.section)}</div>`:''}
     ${l.note?`<div style="font-size:10px;color:#64748B;">${esc(l.note)}</div>`:''}
    </td>
    <td style="text-align:center;padding:6px;border:1px solid #171817;width:60px;font-size:11px;">${esc(l.hsn||'9954')}</td>
    <td style="text-align:right;padding:6px;border:1px solid #171817;white-space:nowrap;width:60px;font-weight:600;">${Number(l.measuredQty||l.qty||0).toFixed(0)}</td>
    <td style="text-align:right;padding:6px;border:1px solid #171817;white-space:nowrap;width:65px;">${Number(l.rate||0).toFixed(2)}</td>
    <td style="text-align:center;padding:6px;border:1px solid #171817;width:40px;">${esc(l.unit||'sq.ft')}</td>
    <td style="text-align:right;padding:6px;border:1px solid #171817;width:50px;">${l.discount?Number(l.discount).toFixed(1)+'%':'—'}</td>
    <td style="text-align:right;padding:6px 8px;border:1px solid #171817;white-space:nowrap;font-weight:700;width:90px;">${Number(l.amount||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
   </tr>`;
  }).join('');

  const einvoiceHeaderHtml = (doc.irn && doc.qrCode) ? `
  <div style="display:flex;justify-content:space-between;align-items:flex-start;border:1px solid #171817;border-bottom:none;padding:8px 10px;font-size:10px;background:#FAFAFA;">
   <div style="line-height:1.6;">
    <div><b>IRN:</b> ${esc(doc.irn)}</div>
    <div><b>Ack No.:</b> ${esc(doc.ackNo||'—')} &nbsp;&nbsp;&nbsp; <b>Ack Date:</b> ${esc(doc.ackDate||doc.date)}</div>
   </div>
   <div style="text-align:right;">
    <div style="font-size:10px;font-weight:700;margin-bottom:2px;">e-Invoice</div>
    <img src="${esc(doc.qrCode)}" alt="e-Invoice QR" style="width:72px;height:72px;object-fit:contain;" />
   </div>
  </div>` : '';

  const taxSummaryHtml = hasTax ? `
  <table style="width:100%;border-collapse:collapse;border:1px solid #171817;border-top:none;font-size:10px;">
   <thead>
    <tr style="background:#F8FAFC;">
     <th style="border:1px solid #171817;padding:5px;width:70px;">HSN/SAC</th>
     <th style="border:1px solid #171817;padding:5px;text-align:right;">Taxable Value</th>
     <th style="border:1px solid #171817;padding:5px;text-align:right;">Central Tax (${taxDetails.halfPercent})</th>
     <th style="border:1px solid #171817;padding:5px;text-align:right;">State Tax (${taxDetails.halfPercent})</th>
     <th style="border:1px solid #171817;padding:5px;text-align:right;width:90px;">Total Tax</th>
    </tr>
   </thead>
   <tbody>
    <tr>
     <td style="border:1px solid #171817;padding:5px;text-align:center;">9954</td>
     <td style="border:1px solid #171817;padding:5px;text-align:right;">${taxDetails.taxable.toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
     <td style="border:1px solid #171817;padding:5px;text-align:right;">${taxDetails.cgst.toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
     <td style="border:1px solid #171817;padding:5px;text-align:right;">${taxDetails.sgst.toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
     <td style="border:1px solid #171817;padding:5px;text-align:right;font-weight:700;">${taxDetails.tax.toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
    </tr>
    <tr style="font-weight:700;background:#FAFAFA;">
     <td style="border:1px solid #171817;padding:5px;text-align:center;">Total</td>
     <td style="border:1px solid #171817;padding:5px;text-align:right;">${taxDetails.taxable.toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
     <td style="border:1px solid #171817;padding:5px;text-align:right;">${taxDetails.cgst.toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
     <td style="border:1px solid #171817;padding:5px;text-align:right;">${taxDetails.sgst.toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
     <td style="border:1px solid #171817;padding:5px;text-align:right;">${taxDetails.tax.toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
    </tr>
   </tbody>
  </table>
  <div style="border:1px solid #171817;border-top:none;padding:5px 8px;font-size:10.5px;">
   <b>Tax Amount (in words) :</b> ${numberToIndianWords(doc.tax||0)}
  </div>` : '';

  return `<!doctype html><html lang="${esc(doc.language)}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(doc.number)}</title><style>${basePrintCss}
h1.title{text-align:center;font-size:19px;font-family:'Times New Roman',serif,sans-serif;font-weight:900;letter-spacing:1px;margin:0 0 10px;color:#171817}
table.outer{width:100%;border-collapse:collapse;border:1px solid #171817;margin-bottom:0}
td.border-box{border:1px solid #171817;padding:7px 9px;vertical-align:top}
table.item-grid{width:100%;border-collapse:collapse;border:1px solid #171817;margin-top:-1px}
table.item-grid th{background:#FFFFFF;border:1px solid #171817;padding:6px;font-size:10.5px;font-weight:700;color:#171817}
.amount-words{border:1px solid #171817;border-top:none;padding:6px 9px;font-size:11px;background:#FFFFFF;display:flex;justify-content:space-between;align-items:flex-start}
table.bottom-box{width:100%;border-collapse:collapse;border:1px solid #171817;border-top:none;margin-bottom:6px}
</style></head><body>
<h1 class="title">${localizedHeader}</h1>
${einvoiceHeaderHtml}
<table class="outer">
 <tr>
  <td class="border-box" style="width:50%;">
   ${business?.logo ? `<div style="margin-bottom:6px;"><img src="${esc(business.logo)}" style="max-height:48px;max-width:140px;object-fit:contain;" /></div>` : ''}
   <div style="font-size:14px;font-weight:900;color:#171817;margin-bottom:4px;">${esc(business?.name||'Mahesh Constructions')}</div>
   <div style="font-size:10px;color:#475569;line-height:1.4;">
    ${esc(business?.address||'')}${business?.city?', '+esc(business.city):''}<br>
    <b>GSTIN/UIN:</b> ${esc(business?.gstin||'—')}<br>
    <b>State Name:</b> ${esc(business?.state||'Andhra Pradesh')}, Code: ${esc(business?.stateCode||'37')}
   </div>
   <div style="border-top:1px solid #171817;margin-top:6px;padding-top:4px;">
    <div style="font-size:9.5px;color:#64748B;">Consignee (Ship to)</div>
    <div style="font-size:12px;font-weight:800;color:#171817;">${esc(doc.customer?.name||'Jai Siva')}</div>
    <div style="font-size:10px;color:#475569;line-height:1.35;">
     ${esc(doc.customer?.siteLocation||doc.customer?.address||'Kailasapuram')}<br>
     <b>GSTIN/UIN:</b> ${esc(doc.customer?.gstin||doc.custGstin||'—')}<br>
     <b>State Name:</b> ${esc(doc.customer?.state||'Andhra Pradesh')}
    </div>
   </div>
   <div style="border-top:1px solid #171817;margin-top:6px;padding-top:4px;">
    <div style="font-size:9.5px;color:#64748B;">Buyer (Bill to)</div>
    <div style="font-size:12px;font-weight:800;color:#171817;">${esc(doc.customer?.name||'Jai Siva')}</div>
    <div style="font-size:10px;color:#475569;line-height:1.35;">
     ${esc(doc.customer?.address||doc.customer?.siteLocation||'Kailasapuram')}<br>
     <b>GSTIN/UIN:</b> ${esc(doc.customer?.gstin||doc.custGstin||'—')}<br>
     <b>State Name:</b> ${esc(doc.customer?.state||'Andhra Pradesh')}
    </div>
   </div>
  </td>
  <td class="border-box" style="width:50%;padding:0;">
   <table style="width:100%;border-collapse:collapse;font-size:10px;">
    <tr>
     <td style="padding:5px 7px;border-bottom:1px solid #171817;border-right:1px solid #171817;width:50%;">
      <div style="color:#64748B;font-size:9px;">${isQuotation?'Quotation No.':'Invoice No.'}</div>
      <div style="font-weight:800;font-size:11.5px;">${esc(doc.number||'QT-0001')}</div>
     </td>
     <td style="padding:5px 7px;border-bottom:1px solid #171817;">
      <div style="color:#64748B;font-size:9px;">Dated</div>
      <div style="font-weight:800;font-size:11.5px;">${esc(doc.date)}</div>
     </td>
    </tr>
    <tr>
     <td style="padding:4px 7px;border-bottom:1px solid #171817;border-right:1px solid #171817;color:#64748B;">Delivery Note</td>
     <td style="padding:4px 7px;border-bottom:1px solid #171817;"><b>Mode/Terms:</b> ${esc([doc.modeOfPayment ? 'Payment: ' + doc.modeOfPayment : '', doc.paymentTerms||doc.terms||'Immediate'].filter(Boolean).join(' • '))}</td>
    </tr>
    <tr>
     <td style="padding:4px 7px;border-bottom:1px solid #171817;border-right:1px solid #171817;color:#64748B;">Reference No. & Date</td>
     <td style="padding:4px 7px;border-bottom:1px solid #171817;color:#64748B;">${doc.ewayBillNo || doc.ewayBill ? '<b>E-Way Bill:</b> ' + esc(doc.ewayBillNo || doc.ewayBill) : 'Other References'}</td>
    </tr>
    <tr>
     <td style="padding:4px 7px;border-bottom:1px solid #171817;border-right:1px solid #171817;color:#64748B;">${doc.orderNumber || doc.orderNo ? '<b>Buyer Order:</b> ' + esc(doc.orderNumber || doc.orderNo) : "Buyer's Order No."}</td>
     <td style="padding:4px 7px;border-bottom:1px solid #171817;"><b>Valid Till:</b> ${esc(doc.dueDate||'—')}</td>
    </tr>
    <tr>
     <td style="padding:4px 7px;border-bottom:1px solid #171817;border-right:1px solid #171817;color:#64748B;">${doc.vehicleNo ? '<b>Vehicle No:</b> ' + esc(doc.vehicleNo) : 'Dispatch Doc No.'}</td>
     <td style="padding:4px 7px;border-bottom:1px solid #171817;color:#64748B;">${doc.driverPhone ? '<b>Driver Ph:</b> ' + esc(doc.driverPhone) : 'Delivery Note Date'}</td>
    </tr>
    <tr>
     <td style="padding:4px 7px;border-bottom:1px solid #171817;border-right:1px solid #171817;"><b>Dispatched through:</b> ${esc([doc.transporterName || doc.transporter, doc.vehicleNo].filter(Boolean).join(' / ') || 'Direct')}</td>
     <td style="padding:4px 7px;border-bottom:1px solid #171817;"><b>Destination:</b> ${esc(doc.destination||doc.customer?.siteLocation||doc.customer?.city||'Site')}</td>
    </tr>
    <tr>
     <td colspan="2" style="padding:5px 7px;color:#475569;">
      <b>Terms of Delivery:</b> ${esc(doc.terms||'Work will be executed as per mutually agreed terms.')}
     </td>
    </tr>
   </table>
  </td>
 </tr>
</table>

<table class="item-grid">
 <thead>
  <tr>
   <th style="width:34px;">SI No.</th>
   <th>Description of Goods / Services</th>
   <th style="width:60px;">HSN/SAC</th>
   <th style="width:60px;text-align:right;">Quantity</th>
   <th style="width:65px;text-align:right;">Rate</th>
   <th style="width:40px;">per</th>
   <th style="width:50px;text-align:right;">Disc. %</th>
   <th style="width:90px;text-align:right;">Amount</th>
  </tr>
 </thead>
 <tbody>
  ${tableRows}
  ${hasTax ? `
  <tr>
   <td style="border:1px solid #171817;"></td>
   <td style="border:1px solid #171817;text-align:right;padding:5px 8px;font-style:italic;">CGST (${taxDetails.halfPercent})</td>
   <td style="border:1px solid #171817;"></td>
   <td style="border:1px solid #171817;"></td>
   <td style="border:1px solid #171817;"></td>
   <td style="border:1px solid #171817;"></td>
   <td style="border:1px solid #171817;"></td>
   <td style="border:1px solid #171817;text-align:right;padding:5px 8px;font-weight:600;">${taxDetails.cgst.toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
  </tr>
  <tr>
   <td style="border:1px solid #171817;"></td>
   <td style="border:1px solid #171817;text-align:right;padding:5px 8px;font-style:italic;">SGST (${taxDetails.halfPercent})</td>
   <td style="border:1px solid #171817;"></td>
   <td style="border:1px solid #171817;"></td>
   <td style="border:1px solid #171817;"></td>
   <td style="border:1px solid #171817;"></td>
   <td style="border:1px solid #171817;"></td>
   <td style="border:1px solid #171817;text-align:right;padding:5px 8px;font-weight:600;">${taxDetails.sgst.toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
  </tr>` : ''}
  <tr>
   <td colspan="3" style="text-align:right;padding:6px 8px;border:1px solid #171817;font-weight:800;font-size:11.5px;">Total</td>
   <td style="text-align:right;padding:6px 8px;border:1px solid #171817;font-weight:800;font-size:11.5px;white-space:nowrap;">${qtySummary||totalQty.toFixed(0)+' '+esc(mainUnit)}</td>
   <td style="border:1px solid #171817;"></td>
   <td style="border:1px solid #171817;"></td>
   <td style="border:1px solid #171817;"></td>
   <td style="text-align:right;padding:6px 8px;border:1px solid #171817;font-weight:900;font-size:12.5px;white-space:nowrap;">₹ ${Number(doc.total||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
  </tr>
 </tbody>
</table>

<div class="amount-words">
 <div>
  <span style="color:#64748B;font-size:9.5px;">Amount Chargeable (in words):</span>
  <div style="font-weight:800;font-size:11.5px;color:#171817;margin-top:2px;">${numberToIndianWords(doc.total||0)}</div>
 </div>
 <div style="font-size:9.5px;color:#64748B;font-weight:700;">E. & O.E</div>
</div>

${taxSummaryHtml}

<table class="bottom-box">
 <tr>
  <td style="width:60%;border:1px solid #171817;padding:7px 9px;vertical-align:top;font-size:10px;line-height:1.45;">
   <div style="font-weight:700;color:#171817;margin-bottom:2px;">Declaration:</div>
   <div>We declare that this invoice shows the actual price of the goods and services described and that all particulars are true and correct.</div>
   ${business?.showBankDetails !== false && (business?.bankName || business?.bankAccount || business?.upiId) ? `
   <div style="margin-top:6px;padding-top:4px;border-top:1px dashed #94A3B8;font-size:9.5px;">
    <b>Bank Details:</b> ${business?.bankName ? esc(business.bankName) + ' · ' : ''}<b>A/C:</b> ${esc(business?.bankAccount || '—')} · <b>IFSC:</b> ${esc(business?.bankIfsc || '—')}${business?.bankHolder ? ' · <b>Holder:</b> ' + esc(business.bankHolder) : ''}${business?.upiId ? ' · <b>UPI:</b> ' + esc(business.upiId) : ''}
   </div>` : ''}
   ${(doc.terms || business?.terms) ? `<div style="margin-top:4px;"><b>Terms & Conditions:</b> ${esc(doc.terms || business.terms)}</div>` : ''}
   ${(doc.notes || business?.notes) ? `<div style="margin-top:2px;"><b>Notes:</b> ${esc(doc.notes || business.notes)}</div>` : ''}
   ${doc.dueDate?`<div style="margin-top:4px;color:#64748B;">Valid till: ${esc(doc.dueDate)}</div>`:''}
  </td>
  <td style="width:40%;border:1px solid #171817;padding:7px 9px;text-align:center;vertical-align:top;">
   <div style="font-size:10.5px;color:#64748B;">for <b style="color:#171817;">${esc(business?.name||'Mahesh Constructions')}</b></div>
   <div style="min-height:44px;display:flex;align-items:center;justify-content:center;">
    ${(doc.signature || business?.signature) ? `<img src="${esc(doc.signature || business.signature)}" style="max-height:42px;max-width:130px;object-fit:contain;" />` : `<div style="height:44px;"></div>`}
   </div>
   <div style="border-top:1px solid #171817;padding-top:4px;font-size:10.5px;font-weight:700;color:#171817;">${esc(business?.owner || 'Authorised Signatory')}</div>
  </td>
 </tr>
</table>

<div style="text-align:center;font-size:9.5px;color:#64748B;margin-top:6px;">This is a Computer Generated Quotation</div>
${annexureHtml}
</body></html>`;
 }

 // 2. Layout: Orange Trade Grid (Reference 2: Tally-Invoice-Format-05)
 if (theme.id === 'amber_grid') {
  const tableRows = (doc.items||[]).map((l, i) => {
   const entry=catalogue.find(x=>x.id===l.catalogueId);
   const name=entry&&l.name===entry.name&&doc.language!=='en'?entry[doc.language]||l.name:l.name;
   const subtitle = formatItemSubtitle(l);
   const rowBg = i % 2 === 1 ? '#FFF3E0' : '#FFFFFF';
   return `<tr style="background:${rowBg};">
    <td style="text-align:center;padding:5px 6px;border:1px solid #000;width:34px;">${i+1}</td>
    <td style="padding:5px 8px;border:1px solid #000;">
     <div style="font-weight:700;font-size:11.5px;color:#000;">${esc(name)}</div>
     ${subtitle ? `<div style="font-size:9.5px;color:#475569;margin-top:2px;">${esc(subtitle)}</div>` : ''}
     ${l.note?`<div style="font-size:9.5px;color:#64748B;">${esc(l.note)}</div>`:''}
    </td>
    <td style="text-align:center;padding:5px 6px;border:1px solid #000;width:60px;font-size:10.5px;">${esc(l.hsn||'9954')}</td>
    <td style="text-align:center;padding:5px 6px;border:1px solid #000;width:65px;font-weight:700;">${Number(l.measuredQty||l.qty||0).toFixed(0)}</td>
    <td style="text-align:center;padding:5px 6px;border:1px solid #000;width:45px;font-size:10.5px;">${esc(l.unit||'sq.ft')}</td>
    <td style="text-align:right;padding:5px 6px;border:1px solid #000;width:75px;font-weight:600;">₹ ${Number(l.rate||0).toFixed(2)}</td>
    <td style="text-align:right;padding:5px 8px;border:1px solid #000;width:85px;font-weight:700;">₹ ${Number(l.amount||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
   </tr>`;
  }).join('');

  return `<!doctype html><html lang="${esc(doc.language)}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(doc.number)}</title><style>${basePrintCss}
table.main-box{width:100%;border-collapse:collapse;border:1.5px solid #000;margin:0 auto}
.banner-orange{background:#E65100;color:#FFFFFF;padding:9px 14px;font-size:22px;font-weight:900;letter-spacing:1px}
.logo-cell{background:#FFFFFF;border-left:1.5px solid #000;width:24%;text-align:center;vertical-align:middle;padding:4px}
.grid-cell{border:1px solid #000;padding:4px 6px;font-size:9.5px}
.banner-sm{background:#E65100;color:#FFF;font-weight:900;text-align:center;font-size:11px;padding:5px}
</style></head><body>
<table class="main-box">
 <tr>
  <td class="banner-orange">${isQuotation ? 'Quotation' : 'Tax Invoice'}</td>
  <td class="logo-cell">
   ${business?.logo ? `<img src="${esc(business.logo)}" style="max-height:38px;max-width:110px;object-fit:contain;" />` : `<div style="font-size:15px;font-weight:900;letter-spacing:1.5px;color:#171817;">${esc(business?.name?.slice(0,8)||'LOGO')}</div>`}
  </td>
 </tr>
 <tr>
  <td style="width:52%;border-top:1.5px solid #000;border-right:1.5px solid #000;padding:8px 10px;vertical-align:top;font-size:10px;line-height:1.45;">
   <div style="font-size:13px;font-weight:900;color:#000;margin-bottom:4px;">${esc(business?.name||'Mahesh Constructions')}</div>
   <div><b>STREET ADDRESS:</b> ${esc(business?.address||'—')}</div>
   <div><b>CITY, DIST.:</b> ${esc(business?.city||'—')}${business?.district?', '+esc(business.district):''}</div>
   <div><b>STATE, PINCODE:</b> ${esc(business?.state||'Andhra Pradesh')}${business?.pincode?' - '+esc(business.pincode):''}</div>
   <div><b>GSTIN NO:</b> ${esc(business?.gstin||'—')}</div>
   <div><b>EMAIL ADDRESS:</b> ${esc(business?.email||'—')}</div>
   <div><b>PHONE NO:</b> ${esc(business?.phone||'—')}</div>
  </td>
  <td style="width:48%;border-top:1.5px solid #000;padding:0;vertical-align:top;">
   <table style="width:100%;border-collapse:collapse;font-size:9.5px;">
    <tr>
     <td class="grid-cell" style="width:50%;"><b>Invoice No:</b> ${esc(doc.number||'QT-0001')}</td>
     <td class="grid-cell"><b>Date:</b> ${esc(doc.date)}</td>
    </tr>
    <tr>
     <td class="grid-cell"><b>Due Date:</b> ${esc(doc.dueDate||'—')}</td>
     <td class="grid-cell"><b>Destination:</b> ${esc(doc.customer?.siteLocation||doc.customer?.city||'—')}</td>
    </tr>
    <tr>
     <td class="grid-cell"><b>Suppliers Ref:</b> ${esc(doc.supplierRef||'—')}</td>
     <td class="grid-cell"><b>Order No:</b> ${esc(doc.orderNo||'—')}</td>
    </tr>
    <tr>
     <td class="grid-cell"><b>Reference No:</b> ${esc(doc.refNo||'—')}</td>
     <td class="grid-cell"><b>Vehicle No:</b> ${esc(doc.vehicleNo||'—')}</td>
    </tr>
    <tr>
     <td class="grid-cell"><b>E-way Bill No:</b> ${esc(doc.ewayBill||'—')}</td>
     <td class="grid-cell"><b>Driver M.No:</b> ${esc(doc.driverPhone||'—')}</td>
    </tr>
    <tr>
     <td colspan="2" class="grid-cell"><b>Transporter Name:</b> ${esc(doc.transporter||'Direct Delivery')}</td>
    </tr>
    <tr>
     <td colspan="2" class="grid-cell"><b>Mode of payment:</b> ${esc(doc.paymentMode||'Cash / UPI / Bank Transfer')}</td>
    </tr>
   </table>
  </td>
 </tr>
 <tr>
  <td style="border-top:1.5px solid #000;border-right:1.5px solid #000;padding:8px 10px;vertical-align:top;font-size:10px;line-height:1.45;">
   <div style="font-weight:900;color:#000;margin-bottom:3px;font-size:11px;">BUYER DETAILS</div>
   <div><b>PARTY/COMPANY NAME:</b> <b>${esc(doc.customer?.name||'Customer')}</b></div>
   <div><b>STREET ADDRESS:</b> ${esc(doc.customer?.address||doc.customer?.siteLocation||'—')}</div>
   <div><b>CITY, DIST.:</b> ${esc(doc.customer?.city||'—')}</div>
   <div><b>STATE, PINCODE:</b> ${esc(doc.customer?.state||'Andhra Pradesh')}</div>
   <div><b>GSTIN NO:</b> ${esc(doc.customer?.gstin||doc.custGstin||'—')}</div>
   <div><b>EMAIL ADDRESS:</b> ${esc(doc.customer?.email||'—')}</div>
  </td>
  <td style="border-top:1.5px solid #000;background:#FFF7ED;padding:8px 10px;vertical-align:top;font-size:10px;line-height:1.45;">
   <div style="font-weight:900;color:#000;margin-bottom:3px;font-size:11px;">TERMS AND CONDITIONS:</div>
   <div>${esc(doc.terms||'1. Work executed as per approved specifications.\n2. Payment terms as agreed.')}</div>
   <div style="margin-top:6px;"><b>PHONE NO:</b> ${esc(doc.customer?.phone||'—')}</div>
  </td>
 </tr>
</table>

<table style="width:100%;border-collapse:collapse;border:1.5px solid #000;border-top:none;font-size:10.5px;">
 <thead>
  <tr style="background:#FFF;">
   <th style="border:1px solid #000;padding:6px;width:34px;">SL NO</th>
   <th style="border:1px solid #000;padding:6px;">ITEM / DESCRIPTION</th>
   <th style="border:1px solid #000;padding:6px;width:60px;">HSN</th>
   <th style="border:1px solid #000;padding:6px;width:65px;">QUANTITY</th>
   <th style="border:1px solid #000;padding:6px;width:45px;">UNIT</th>
   <th style="border:1px solid #000;padding:6px;width:75px;">PRICE/UNIT</th>
   <th style="border:1px solid #000;padding:6px;width:85px;">AMOUNT</th>
  </tr>
 </thead>
 <tbody>
  ${tableRows}
  <tr>
   <td colspan="3" class="banner-sm" style="text-align:right;padding-right:10px;">TOTAL QTY</td>
   <td style="text-align:center;font-weight:900;border:1px solid #000;background:#FFF;padding:5px;">${qtySummary||totalQty.toFixed(0)}</td>
   <td colspan="2" class="banner-sm" style="text-align:right;padding-right:10px;">Sub Total</td>
   <td style="text-align:right;font-weight:900;border:1px solid #000;background:#FFF;padding:5px 8px;">₹ ${Number(doc.subtotal||doc.total||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
  </tr>
 </tbody>
</table>

<table style="width:100%;border-collapse:collapse;border:1.5px solid #000;border-top:none;">
 <tr>
  <td style="width:52%;border-right:1.5px solid #000;padding:8px 10px;vertical-align:top;font-size:10px;line-height:1.45;">
   <div style="color:#475569;font-size:9px;font-weight:700;">TAX AMOUNT IN WORDS:</div>
   <div style="font-weight:800;color:#000;margin-bottom:8px;">${numberToIndianWords(doc.tax||0)}</div>
   <div style="color:#475569;font-size:9px;font-weight:700;">TOTAL AMOUNT IN WORDS:</div>
   <div style="font-weight:800;color:#000;">${numberToIndianWords(doc.total||0)}</div>
  </td>
  <td style="width:48%;padding:0;vertical-align:top;">
   <table style="width:100%;border-collapse:collapse;font-size:10px;">
    <tr>
     <td style="border-bottom:1px solid #000;padding:4px 6px;color:#475569;">TAX RATE(%)</td>
     <td style="border-bottom:1px solid #000;padding:4px 6px;text-align:center;font-weight:700;">${doc.taxPercent||0}%</td>
    </tr>
    ${hasTax ? `
    <tr>
     <td style="border-bottom:1px solid #000;padding:4px 6px;">OUTPUT CGST (${taxDetails.halfPercent})</td>
     <td style="border-bottom:1px solid #000;padding:4px 6px;text-align:right;">₹ ${taxDetails.cgst.toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
    </tr>
    <tr>
     <td style="border-bottom:1px solid #000;padding:4px 6px;">OUTPUT SGST (${taxDetails.halfPercent})</td>
     <td style="border-bottom:1px solid #000;padding:4px 6px;text-align:right;">₹ ${taxDetails.sgst.toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
    </tr>` : ''}
    <tr>
     <td style="border-bottom:1px solid #000;padding:4px 6px;">TOTAL AMOUNT</td>
     <td style="border-bottom:1px solid #000;padding:4px 6px;text-align:right;font-weight:700;">₹ ${Number(doc.total||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
    </tr>
    <tr>
     <td style="border-bottom:1.5px solid #000;padding:4px 6px;">ROUND OFF</td>
     <td style="border-bottom:1.5px solid #000;padding:4px 6px;text-align:right;">₹ ${roundOff}</td>
    </tr>
    <tr style="background:#E65100;color:#FFFFFF;font-weight:900;font-size:12px;">
     <td style="padding:6px 8px;">TOTAL</td>
     <td style="padding:6px 8px;text-align:right;">₹ ${Number(doc.total||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
    </tr>
   </table>
  </td>
 </tr>
 <tr>
  <td colspan="2" style="border-top:1.5px solid #000;padding:7px 10px;font-size:9.5px;color:#1E293B;line-height:1.4;">
   <b>DECLARATION:</b><br>
   We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct.
   ${business?.showBankDetails !== false && (business?.bankName || business?.bankAccount || business?.upiId) ? `
   <div style="margin-top:5px;padding-top:4px;border-top:1px dashed #E65100;">
     <b>Bank Details:</b> ${business?.bankName ? esc(business.bankName) + ' · ' : ''}<b>A/C:</b> ${esc(business?.bankAccount || '—')} · <b>IFSC:</b> ${esc(business?.bankIfsc || '—')}${business?.bankHolder ? ' · <b>Holder:</b> ' + esc(business.bankHolder) : ''}${business?.upiId ? ' · <b>UPI:</b> ' + esc(business.upiId) : ''}
   </div>` : ''}
   ${(doc.terms || business?.terms) ? `<div style="margin-top:3px;"><b>Terms:</b> ${esc(doc.terms || business.terms)}</div>` : ''}
   ${(doc.notes || business?.notes) ? `<div style="margin-top:2px;"><b>Notes:</b> ${esc(doc.notes || business.notes)}</div>` : ''}
   <div style="margin-top:8px;display:flex;justify-content:space-between;align-items:flex-end;">
     <div>${doc.dueDate ? '<b>Valid till:</b> ' + esc(doc.dueDate) : ''}</div>
     <div style="text-align:right;">
       ${(doc.signature || business?.signature) ? `<img src="${esc(doc.signature || business.signature)}" style="max-height:40px;max-width:120px;object-fit:contain;display:block;margin-left:auto;margin-bottom:2px;"/>` : `<div style="height:36px;"></div>`}
       <div style="border-top:1px solid #000;padding-top:2px;font-weight:700;font-size:10px;">for ${esc(business?.name || 'Authorised Signatory')}</div>
     </div>
   </div>
  </td>
 </tr>
</table>
<div style="text-align:center;font-size:9.5px;color:#64748B;margin-top:6px;">This is a Computer Generated Quotation</div>
${annexureHtml}
</body></html>`;
 }

 // 3. Layout: Teal Minimal (Reference 3: 3d7d2a70-f417...simple-blue-timesheet-invoice)
 if (theme.id === 'blue_timesheet') {
  const unitLabel = doc.service === 'electrical' ? 'Points / Qty' : doc.service === 'tiles' ? 'Area (sq.ft)' : 'Quantity / Unit';
  const tableRows = (doc.items||[]).map((l, i) => {
   const entry=catalogue.find(x=>x.id===l.catalogueId);
   const name=entry&&l.name===entry.name&&doc.language!=='en'?entry[doc.language]||l.name:l.name;
   const rowBg = i % 2 === 1 ? '#F0F7F9' : '#FFFFFF';
   return `<tr style="background:${rowBg};">
    <td style="padding:8px;border-bottom:1px solid #CBD5E1;width:34px;text-align:center;">${i+1}</td>
    <td style="padding:8px 10px;border-bottom:1px solid #CBD5E1;">
     <div style="font-weight:700;font-size:12px;color:#0F172A;">${esc(name)}</div>
     ${formatItemSubtitle(l)?`<div style="font-size:10px;color:#475569;margin-top:2px;">${esc(formatItemSubtitle(l))}</div>`:''}
     ${l.note?`<div style="font-size:10px;color:#64748B;">${esc(l.note)}</div>`:''}
    </td>
    <td style="text-align:center;padding:8px;border-bottom:1px solid #CBD5E1;width:100px;font-weight:600;">${Number(l.measuredQty||l.qty||0).toFixed(0)} ${esc(l.unit||'')}</td>
    <td style="text-align:right;padding:8px;border-bottom:1px solid #CBD5E1;width:80px;">₹${Number(l.rate||0).toFixed(2)}</td>
    <td style="text-align:right;padding:8px 10px;border-bottom:1px solid #CBD5E1;width:95px;font-weight:700;color:#0F172A;">₹${Number(l.amount||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
   </tr>`;
  }).join('');

  return `<!doctype html><html lang="${esc(doc.language)}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(doc.number)}</title><style>${basePrintCss}
.teal-header{background:#1A5B78;color:#FFFFFF;padding:18px 22px;display:flex;justify-content:space-between;align-items:flex-start}
.meta-row{display:flex;justify-content:space-between;padding:18px 22px 14px;background:#FFF}
table.clean-table{width:100%;border-collapse:collapse;margin:12px 0}
table.clean-table th{border-top:1.5px solid #1A5B78;border-bottom:1px solid #1A5B78;padding:8px;font-size:11px;font-weight:800;color:#1A5B78;text-align:left}
.teal-footer{background:#1A5B78;color:#FFFFFF;text-align:center;padding:9px;font-weight:700;font-size:12px;margin-top:28px}
</style></head><body>
<div class="teal-header">
 <div>
  <h1 style="font-size:32px;font-weight:900;letter-spacing:1px;margin:0;color:#FFF;line-height:1;">${isQuotation ? 'QUOTATION' : 'INVOICE'}</h1>
 </div>
 <div style="text-align:right;font-size:10.5px;color:#E0F2FE;line-height:1.45;">
  <div style="font-size:16px;font-weight:800;color:#FFF;margin-bottom:3px;">${esc(business?.name||'Mahesh Constructions')}</div>
  <div>${esc(business?.address||'')}${business?.city?', '+esc(business.city):''}</div>
  <div>${esc(business?.phone||'')} ${business?.email?' · '+esc(business.email):''}</div>
  ${business?.gstin?`<div>GSTIN: ${esc(business.gstin)}</div>`:''}
 </div>
</div>

<div class="meta-row">
 <div style="font-size:11px;line-height:1.6;">
  <div><b>Invoice No.</b> &nbsp;&nbsp;&nbsp; ${esc(doc.number||'QT-0001')}</div>
  <div><b>Date of Issue</b> &nbsp; ${esc(doc.date)}</div>
  <div><b>Due Date</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ${esc(doc.dueDate||'—')}</div>
 </div>
 <div style="text-align:right;font-size:11px;line-height:1.5;">
  <div style="font-weight:800;color:#1A5B78;font-size:12px;margin-bottom:2px;">Bill To</div>
  <div style="font-size:13px;font-weight:800;color:#0F172A;">${esc(doc.customer?.name||'Jai Siva')}</div>
  <div style="color:#475569;">${esc(doc.customer?.address||doc.customer?.siteLocation||'Kailasapuram')}</div>
  <div style="color:#475569;">${esc(doc.customer?.phone||'')}</div>
 </div>
</div>

<div style="padding:0 22px;">
 <table class="clean-table">
  <thead>
   <tr>
    <th style="width:34px;text-align:center;">Item</th>
    <th>Description</th>
    <th style="width:100px;text-align:center;">${unitLabel}</th>
    <th style="width:80px;text-align:right;">Rate</th>
    <th style="width:95px;text-align:right;">Amount</th>
   </tr>
  </thead>
  <tbody>
   ${tableRows}
  </tbody>
 </table>

 <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-top:14px;">
  <div style="width:48%;font-size:11px;color:#475569;line-height:1.5;">
   <div style="font-weight:800;color:#1A5B78;margin-bottom:3px;">Terms</div>
   <div>${esc(doc.terms||'Payment due upon receipt or as per agreed milestone schedule.')}</div>
  </div>
  <div style="width:42%;text-align:right;font-size:11px;">
   <div style="display:flex;justify-content:space-between;padding:3px 0;color:#475569;">
    <span>Subtotal</span>
    <b>₹${Number(doc.subtotal||doc.total||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</b>
   </div>
   ${doc.discount ? `
   <div style="display:flex;justify-content:space-between;padding:3px 0;color:#475569;">
    <span>Discount</span>
    <b>− ₹${Number(doc.discount).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</b>
   </div>` : ''}
   ${hasTax ? `
   <div style="display:flex;justify-content:space-between;padding:3px 0;color:#475569;">
    <span>Tax Rate</span>
    <span>${doc.taxPercent}%</span>
   </div>
   <div style="display:flex;justify-content:space-between;padding:3px 0;color:#475569;">
    <span>Tax</span>
    <b>₹${Number(doc.tax).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</b>
   </div>` : ''}
   <div style="display:flex;justify-content:space-between;align-items:center;border-top:1.5px solid #1A5B78;margin-top:6px;padding-top:6px;">
    <span style="font-weight:800;font-size:12px;color:#1A5B78;">Total</span>
    <span style="background:#D8EDF4;padding:4px 12px;font-weight:900;color:#1A5B78;font-size:15px;border-radius:4px;">₹${Number(doc.total||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</span>
   </div>
  </div>
 </div>
</div>

<div class="teal-footer">Thank you for your business!</div>
${annexureHtml}
</body></html>`;
 }

 // 4. Layout: Blue Commercial Form (Reference 4: sales-invoice-D383)
 if (theme.id === 'compact_trade') {
  const tableRows = (doc.items||[]).map((l, i) => {
   const entry=catalogue.find(x=>x.id===l.catalogueId);
   const name=entry&&l.name===entry.name&&doc.language!=='en'?entry[doc.language]||l.name:l.name;
   return `<tr>
    <td style="text-align:center;padding:7px;border:1px solid #000;width:90px;font-weight:700;">${Number(l.measuredQty||l.qty||0).toFixed(0)} ${esc(l.unit||'')}</td>
    <td style="padding:7px 10px;border:1px solid #000;">
     <div style="font-weight:700;font-size:12px;color:#000;">${esc(name)}</div>
     ${formatItemSubtitle(l)?`<div style="font-size:10px;color:#475569;margin-top:2px;">${esc(formatItemSubtitle(l))}</div>`:''}
     ${l.note?`<div style="font-size:10px;color:#475569;">${esc(l.note)}</div>`:''}
    </td>
    <td style="text-align:right;padding:7px;border:1px solid #000;width:95px;">₹ ${Number(l.rate||0).toFixed(2)}</td>
    <td style="text-align:right;padding:7px 10px;border:1px solid #000;width:105px;font-weight:700;">₹ ${Number(l.amount||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
   </tr>`;
  }).join('');

  return `<!doctype html><html lang="${esc(doc.language)}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(doc.number)}</title><style>${basePrintCss}
h1.inv-title{font-size:32px;font-style:italic;font-weight:900;color:#000;margin:0;letter-spacing:-0.5px;text-align:right;line-height:1}
.blue-strip th{background:#0066B2;color:#FFF;padding:5px 8px;font-size:10px;font-weight:800;letter-spacing:0.5px;border:1px solid #000;text-align:center}
.blue-table th{background:#0066B2;color:#FFF;padding:7px 10px;font-size:11px;font-weight:800;letter-spacing:0.5px;border:1px solid #000}
.addr-box{font-size:10.5px;line-height:1.55;color:#171817}
</style></head><body>
<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px;">
 <div style="font-size:11px;line-height:1.55;width:55%;">
  <div style="font-size:15px;font-weight:900;color:#000;margin-bottom:3px;">Company: ${esc(business?.name||'Mahesh Constructions')}</div>
  <div><b>Complete Address:</b> ${esc(business?.address||'')}${business?.city?', '+esc(business.city):''}${business?.district?', '+esc(business.district):''}</div>
  <div><b>Phone:</b> ${esc(business?.phone||'—')} &nbsp;&nbsp;&nbsp;&nbsp; <b>Email:</b> ${esc(business?.email||'—')}</div>
  ${business?.gstin?`<div><b>GSTIN:</b> ${esc(business.gstin)}</div>`:''}
 </div>
 <div style="text-align:right;width:40%;">
  <h1 class="inv-title">${isQuotation ? 'Quotation' : 'Invoice'}</h1>
  <div style="font-size:11px;margin-top:6px;line-height:1.6;">
   <div><b>${isQuotation?'QUOTATION #:':'INVOICE #:'}</b> ${esc(doc.number||'TB-0001')}</div>
   <div><b>DATE:</b> ${esc(doc.date)}</div>
  </div>
 </div>
</div>

<div style="display:flex;justify-content:space-between;margin-bottom:12px;">
 <div class="addr-box" style="width:48%;">
  <div style="font-weight:900;font-size:12px;margin-bottom:2px;">Bill to:</div>
  <div><b>Name:</b> ${esc(doc.customer?.name||'Jai Siva')}</div>
  <div><b>Address:</b> ${esc(doc.customer?.address||doc.customer?.siteLocation||'—')}</div>
  <div><b>City/State:</b> ${esc(doc.customer?.city||'—')}, ${esc(doc.customer?.state||'Andhra Pradesh')}</div>
  <div><b>Phone:</b> ${esc(doc.customer?.phone||'—')} &nbsp;&nbsp; <b>Email:</b> ${esc(doc.customer?.email||'—')}</div>
 </div>
 <div class="addr-box" style="width:48%;">
  <div style="font-weight:900;font-size:12px;margin-bottom:2px;">Ship To:</div>
  <div><b>Site / Project:</b> ${esc(doc.project?.name||doc.customer?.siteLocation||'Site Work')}</div>
  <div><b>Address:</b> ${esc(doc.customer?.siteLocation||doc.customer?.address||'—')}</div>
  <div><b>City/State:</b> ${esc(doc.customer?.city||'—')}, ${esc(doc.customer?.state||'Andhra Pradesh')}</div>
  <div><b>Contact:</b> ${esc(doc.customer?.name||'Customer')} (${esc(doc.customer?.phone||'—')})</div>
 </div>
</div>

<div style="font-size:10.5px;margin-bottom:10px;">
 <b>Comments or Special Instructions:</b> ${esc(doc.terms||'All measurements subject to final site verification.')}
</div>

<table style="width:100%;border-collapse:collapse;border:1px solid #000;margin-bottom:12px;font-size:10px;">
 <tr class="blue-strip">
  <th>SALESPERSON</th>
  <th>P.O. NUMBER</th>
  <th>SHIP DATE</th>
  <th>SHIP VIA</th>
  <th>F.O.B. POINT</th>
  <th>TERMS</th>
 </tr>
 <tr>
  <td style="border:1px solid #000;padding:5px;text-align:center;">${esc(doc.salesperson||business?.owner||'Direct')}</td>
  <td style="border:1px solid #000;padding:5px;text-align:center;">${esc(doc.poNumber||'—')}</td>
  <td style="border:1px solid #000;padding:5px;text-align:center;">${esc(doc.shipDate||doc.date)}</td>
  <td style="border:1px solid #000;padding:5px;text-align:center;">${esc(doc.shipVia||'Local / By Hand')}</td>
  <td style="border:1px solid #000;padding:5px;text-align:center;">${esc(doc.fobPoint||'Site')}</td>
  <td style="border:1px solid #000;padding:5px;text-align:center;">${esc(doc.termsShort||'As agreed')}</td>
 </tr>
</table>

<table style="width:100%;border-collapse:collapse;border:1.2px solid #000;">
 <thead>
  <tr class="blue-table">
   <th style="width:90px;text-align:center;">QUANTITY</th>
   <th style="text-align:left;">DESCRIPTION</th>
   <th style="width:95px;text-align:right;">UNIT PRICE</th>
   <th style="width:105px;text-align:right;">AMOUNT</th>
  </tr>
 </thead>
 <tbody>
  ${tableRows}
  <tr>
   <td colspan="2" style="border:1px solid #000;border-bottom:none;"></td>
   <td style="border:1px solid #000;padding:6px 8px;font-weight:700;font-size:10.5px;">SUBTOTAL</td>
   <td style="border:1px solid #000;padding:6px 8px;text-align:right;font-weight:700;">₹ ${Number(doc.subtotal||doc.total||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
  </tr>
  ${hasTax ? `
  <tr>
   <td colspan="2" style="border:1px solid #000;border-bottom:none;border-top:none;"></td>
   <td style="border:1px solid #000;padding:5px 8px;font-size:10.5px;">TAX RATE</td>
   <td style="border:1px solid #000;padding:5px 8px;text-align:right;">${doc.taxPercent}%</td>
  </tr>
  <tr>
   <td colspan="2" style="border:1px solid #000;border-bottom:none;border-top:none;"></td>
   <td style="border:1px solid #000;padding:5px 8px;font-size:10.5px;">SALES TAX</td>
   <td style="border:1px solid #000;padding:5px 8px;text-align:right;">₹ ${Number(doc.tax).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
  </tr>` : ''}
  ${doc.discount ? `
  <tr>
   <td colspan="2" style="border:1px solid #000;border-bottom:none;border-top:none;"></td>
   <td style="border:1px solid #000;padding:5px 8px;font-size:10.5px;">DISCOUNT</td>
   <td style="border:1px solid #000;padding:5px 8px;text-align:right;">− ₹ ${Number(doc.discount).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
  </tr>` : ''}
  <tr>
   <td colspan="2" style="border:1px solid #000;border-top:none;"></td>
   <td style="border:1.5px solid #000;padding:7px 8px;font-weight:900;font-size:12px;background:#F8FAFC;">TOTAL</td>
   <td style="border:1.5px solid #000;padding:7px 8px;text-align:right;font-weight:900;font-size:13px;background:#F8FAFC;">₹ ${Number(doc.total||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
  </tr>
 </tbody>
</table>

<div style="font-size:10.5px;color:#171817;margin-top:20px;line-height:1.5;">
 <div>Make all payments payable to <b>${esc(business?.name||'Mahesh Constructions')}</b>${business?.upiId ? ' (UPI: ' + esc(business.upiId) + ')' : ''}</div>
 <div>If you have any questions concerning this document, contact <b>${esc(business?.owner||business?.name)}</b> at <b>${esc(business?.phone||'—')}</b> or by email at <b>${esc(business?.email||'—')}</b></div>
</div>

<div style="text-align:center;color:#0066B2;font-size:13px;font-weight:900;letter-spacing:0.5px;margin-top:16px;">
 THANK YOU FOR YOUR BUSINESS!
</div>
${annexureHtml}
</body></html>`;
 }

 // 5. Layout: Compact Spreadsheet (Reference 5: sales-invoice-template)
 if (theme.id === 'corporate_sales') {
  const tableRows = (doc.items||[]).map((l, i) => {
   const entry=catalogue.find(x=>x.id===l.catalogueId);
   const name=entry&&l.name===entry.name&&doc.language!=='en'?entry[doc.language]||l.name:l.name;
   return `<tr>
    <td style="padding:6px 8px;border:0.8px solid #CBD5E1;width:80px;text-align:center;font-size:10.5px;color:#475569;">[${esc(l.hsn||l.code||String(i+1).padStart(4,'0'))}]</td>
    <td style="padding:6px 8px;border:0.8px solid #CBD5E1;">
     <div style="font-weight:600;font-size:11.5px;color:#0F172A;">${esc(name)}</div>
     ${formatItemSubtitle(l)?`<div style="font-size:9.5px;color:#475569;margin-top:2px;">${esc(formatItemSubtitle(l))}</div>`:''}
     ${l.note?`<div style="font-size:9.5px;color:#64748B;">${esc(l.note)}</div>`:''}
    </td>
    <td style="padding:6px 8px;border:0.8px solid #CBD5E1;width:60px;text-align:center;font-weight:700;">${Number(l.measuredQty||l.qty||0).toFixed(0)}</td>
    <td style="padding:6px 8px;border:0.8px solid #CBD5E1;width:80px;text-align:right;">${Number(l.rate||0).toFixed(2)}</td>
    <td style="padding:6px 8px;border:0.8px solid #CBD5E1;width:95px;text-align:right;font-weight:700;color:#0F172A;">${Number(l.amount||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
   </tr>`;
  }).join('');

  return `<!doctype html><html lang="${esc(doc.language)}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(doc.number)}</title><style>${basePrintCss}
.indigo-bar{background:#3B5998;color:#FFFFFF;font-weight:700;font-size:10.5px;padding:4px 8px;letter-spacing:0.5px}
.subtle-box{border:0.8px solid #CBD5E1;padding:6px 8px;font-size:10px;line-height:1.45}
table.sheet-grid{width:100%;border-collapse:collapse;border:0.8px solid #CBD5E1;font-size:10.5px}
table.sheet-grid th{background:#3B5998;color:#FFFFFF;padding:6px 8px;font-weight:700;font-size:10.5px;border:0.8px solid #CBD5E1;letter-spacing:0.4px}
</style></head><body>
<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px;">
 <div style="font-size:10.5px;color:#475569;line-height:1.45;width:55%;">
  <div style="font-size:14px;font-weight:800;color:#0F172A;margin-bottom:2px;">[${esc(business?.name||'Mahesh Constructions')}]</div>
  <div>${esc(business?.address||'')}${business?.city?', '+esc(business.city):''}${business?.district?', '+esc(business.district):''}</div>
  <div>Phone: ${esc(business?.phone||'—')} &nbsp; Fax: ${esc(business?.fax||'—')}</div>
  <div>Website / Email: ${esc(business?.email||'—')}</div>
 </div>
 <div style="text-align:right;width:40%;">
  <div style="font-size:26px;font-weight:800;color:#6B8EA9;letter-spacing:1px;margin-bottom:6px;">${isQuotation ? 'QUOTATION' : 'INVOICE'}</div>
  <table style="border-collapse:collapse;border:0.8px solid #CBD5E1;float:right;font-size:9.5px;width:150px;">
   <tr>
    <td style="padding:3px 6px;border:0.8px solid #CBD5E1;font-weight:700;background:#F8FAFC;text-align:center;">DATE</td>
    <td style="padding:3px 6px;border:0.8px solid #CBD5E1;text-align:center;">${esc(doc.date)}</td>
   </tr>
   <tr>
    <td style="padding:3px 6px;border:0.8px solid #CBD5E1;font-weight:700;background:#F8FAFC;text-align:center;">${isQuotation?'QUOTE #':'INVOICE #'}</td>
    <td style="padding:3px 6px;border:0.8px solid #CBD5E1;text-align:center;">${esc(doc.number||'TB-0001')}</td>
   </tr>
   <tr>
    <td style="padding:3px 6px;border:0.8px solid #CBD5E1;font-weight:700;background:#F8FAFC;text-align:center;">CUSTOMER ID</td>
    <td style="padding:3px 6px;border:0.8px solid #CBD5E1;text-align:center;">[${esc(doc.customer?.id ? doc.customer.id.slice(-5) : '101')}]</td>
   </tr>
  </table>
 </div>
</div>

<div style="display:flex;justify-content:space-between;margin-bottom:12px;clear:both;">
 <div style="width:48%;">
  <div class="indigo-bar">BILL TO:</div>
  <div class="subtle-box">
   <b>[${esc(doc.customer?.name||'Customer')}]</b><br>
   ${esc(doc.customer?.address||doc.customer?.siteLocation||'—')}<br>
   Phone: ${esc(doc.customer?.phone||'—')}
  </div>
 </div>
 <div style="width:48%;">
  <div class="indigo-bar">SHIP TO:</div>
  <div class="subtle-box">
   <b>[${esc(doc.project?.name||doc.customer?.name||'Customer')}]</b><br>
   ${esc(doc.customer?.siteLocation||doc.customer?.address||'—')}<br>
   Phone: ${esc(doc.customer?.phone||'—')}
  </div>
 </div>
</div>

<table style="width:100%;border-collapse:collapse;border:0.8px solid #CBD5E1;margin-bottom:12px;font-size:9.5px;">
 <thead>
  <tr style="background:#3B5998;color:#FFF;">
   <th style="padding:4px 6px;border:0.8px solid #CBD5E1;">SALESPERSON</th>
   <th style="padding:4px 6px;border:0.8px solid #CBD5E1;">P.O. #</th>
   <th style="padding:4px 6px;border:0.8px solid #CBD5E1;">SHIP DATE</th>
   <th style="padding:4px 6px;border:0.8px solid #CBD5E1;">SHIP VIA</th>
   <th style="padding:4px 6px;border:0.8px solid #CBD5E1;">F.O.B.</th>
   <th style="padding:4px 6px;border:0.8px solid #CBD5E1;">TERMS</th>
  </tr>
 </thead>
 <tbody>
  <tr>
   <td style="padding:4px;border:0.8px solid #CBD5E1;text-align:center;">${esc(doc.salesperson||business?.owner||'Direct')}</td>
   <td style="padding:4px;border:0.8px solid #CBD5E1;text-align:center;">${esc(doc.poNumber||'—')}</td>
   <td style="padding:4px;border:0.8px solid #CBD5E1;text-align:center;">${esc(doc.shipDate||doc.date)}</td>
   <td style="padding:4px;border:0.8px solid #CBD5E1;text-align:center;">${esc(doc.shipVia||'Local delivery')}</td>
   <td style="padding:4px;border:0.8px solid #CBD5E1;text-align:center;">${esc(doc.fobPoint||'Site')}</td>
   <td style="padding:4px;border:0.8px solid #CBD5E1;text-align:center;">${esc(doc.termsShort||'As agreed')}</td>
  </tr>
 </tbody>
</table>

<table class="sheet-grid">
 <thead>
  <tr>
   <th style="width:80px;text-align:center;">ITEM #</th>
   <th style="text-align:left;">DESCRIPTION</th>
   <th style="width:60px;text-align:center;">QTY</th>
   <th style="width:80px;text-align:right;">UNIT PRICE</th>
   <th style="width:95px;text-align:right;">TOTAL</th>
  </tr>
 </thead>
 <tbody>
  ${tableRows}
 </tbody>
</table>

<div style="display:flex;justify-content:space-between;margin-top:12px;align-items:flex-start;">
 <div style="width:52%;">
  <div style="background:#CBD5E1;color:#1E293B;font-weight:700;font-size:10.5px;padding:4px 8px;">Other Comments or Special Instructions</div>
  <div style="border:0.8px solid #CBD5E1;border-top:none;padding:8px 10px;font-size:10px;line-height:1.5;">
   <div>1. ${esc(doc.terms||'Total payment due as per agreed milestone terms.')}</div>
   <div>2. Please include document number on payment receipt.</div>
  </div>
 </div>
 <div style="width:42%;">
  <table style="width:100%;border-collapse:collapse;font-size:10px;border:0.8px solid #CBD5E1;">
   <tr>
    <td style="padding:4px 8px;border:0.8px solid #CBD5E1;font-weight:700;color:#475569;">SUBTOTAL</td>
    <td style="padding:4px 8px;border:0.8px solid #CBD5E1;text-align:right;">${Number(doc.subtotal||doc.total||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
   </tr>
   ${hasTax ? `
   <tr>
    <td style="padding:4px 8px;border:0.8px solid #CBD5E1;color:#475569;">TAX RATE</td>
    <td style="padding:4px 8px;border:0.8px solid #CBD5E1;text-align:right;">${doc.taxPercent}%</td>
   </tr>
   <tr>
    <td style="padding:4px 8px;border:0.8px solid #CBD5E1;color:#475569;">TAX</td>
    <td style="padding:4px 8px;border:0.8px solid #CBD5E1;text-align:right;">${Number(doc.tax).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
   </tr>` : ''}
   ${doc.discount ? `
   <tr>
    <td style="padding:4px 8px;border:0.8px solid #CBD5E1;color:#475569;">DISCOUNT</td>
    <td style="padding:4px 8px;border:0.8px solid #CBD5E1;text-align:right;">− ${Number(doc.discount).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
   </tr>` : ''}
   <tr style="background:#3B5998;color:#FFFFFF;font-weight:900;">
    <td style="padding:6px 8px;border:0.8px solid #3B5998;font-size:11px;">TOTAL</td>
    <td style="padding:6px 8px;border:0.8px solid #3B5998;text-align:right;font-size:11.5px;">₹ ${Number(doc.total||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
   </tr>
  </table>
 </div>
</div>

<div style="font-size:10px;text-align:center;margin-top:24px;color:#334155;line-height:1.45;">
 <div>Make all payments payable to <b>[${esc(business?.name||'Mahesh Constructions')}]</b></div>
 <div>If you have any questions about this document, please contact <b>[${esc(business?.owner||business?.name)}, ${esc(business?.phone||'—')}]</b></div>
 <div style="font-style:italic;font-weight:700;color:#1E293B;font-size:11.5px;margin-top:6px;">Thank You For Your Business!</div>
</div>
${annexureHtml}
</body></html>`;
 }

 // 2. Layout: Contractor Detail (Reference 05)
 if (theme.id === 'contractor_detail') {
  const materialsItems = [];
  const labourItems = [];

  (doc.items||[]).forEach((l, i) => {
   const basis = String(l.basis||'');
   if (basis.includes('Material') || basis.includes('Supply')) {
    materialsItems.push(l);
   } else {
    labourItems.push(l);
   }
  });

  // If all ended up in one or empty, keep them intuitive
  if (!materialsItems.length && labourItems.length > 1) {
   materialsItems.push(labourItems.shift());
  } else if (!materialsItems.length && labourItems.length === 1) {
   // Split line 50/50 for preview representation if single item
   const orig = labourItems[0];
   const half = (orig.amount||0)/2;
   materialsItems.push({...orig, name: orig.name+' (Materials)', rate: (orig.rate||0)/2, amount: half});
   labourItems[0] = {...orig, name: orig.name+' (Labour laying)', rate: (orig.rate||0)/2, amount: half};
  }

  const matSubtotal = materialsItems.reduce((s, x) => s + Number(x.amount||0), 0);
  const labSubtotal = labourItems.reduce((s, x) => s + Number(x.amount||0), 0);

  const renderSectionRows = (items) => items.map((l, idx) => `<tr>
   <td style="text-align:center;padding:7px;border-bottom:1px solid #E2E8F0;width:32px;">${idx+1}</td>
   <td style="padding:7px;border-bottom:1px solid #E2E8F0;font-weight:600;"><div>${esc(l.name)}</div>${formatItemSubtitle(l)?`<div style="font-size:9.5px;color:#475569;margin-top:2px;font-weight:normal;">${esc(formatItemSubtitle(l))}</div>`:''}</td>
   <td style="padding:7px;border-bottom:1px solid #E2E8F0;color:#64748B;">${esc(l.note||l.section||'')}</td>
   <td style="text-align:right;padding:7px;border-bottom:1px solid #E2E8F0;">${Number(l.measuredQty||l.qty||0).toFixed(0)} ${esc(l.unit||'sq.ft')}</td>
   <td style="text-align:right;padding:7px;border-bottom:1px solid #E2E8F0;">${Number(l.rate||0).toFixed(2)}</td>
   <td style="text-align:right;padding:7px;border-bottom:1px solid #E2E8F0;font-weight:700;">${Number(l.amount||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
  </tr>`).join('');

  return `<!doctype html><html lang="${esc(doc.language)}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(doc.number)}</title><style>${sizeConfig.rule}
*{box-sizing:border-box}
body{font:12px/1.4 'Segoe UI',Inter,Arial,'Noto Sans Telugu','Noto Sans Devanagari',sans-serif;color:#171817;margin:0;background:white;padding:${pageSizeId==='thermal'?'10px':'20px'};-webkit-font-smoothing:antialiased}
thead{display:table-header-group}
.top-accent{height:6px;background:#FFD500;border-radius:3px 3px 0 0;margin-bottom:16px}
.header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px}
.section-banner{background:#FFF3B0;padding:6px 10px;font-size:12px;font-weight:900;color:#171817;letter-spacing:0.5px;margin-top:14px;border:1px solid #FDE047;border-bottom:none}
table.sec-table{width:100%;border-collapse:collapse;border:1px solid #E2E8F0;font-size:11.5px}
table.sec-table th{background:#F8FAFC;border-bottom:1px solid #CBD5E1;padding:6px 7px;font-size:10.5px;font-weight:700;color:#334155}
.subtotal-bar{background:#F8FAFC;padding:7px 10px;display:flex;justify-content:space-between;font-size:12px;font-weight:700;border:1px solid #E2E8F0;border-top:none}
.grand-bar{background:#FEF3C7;border:1px solid #FACC15;padding:10px 14px;display:flex;justify-content:space-between;align-items:center;margin-top:16px;border-radius:4px}
@media print{.no-print{display:none}}
</style></head><body>
<div class="top-accent"></div>

<div class="header">
 <div>
  <div style="font-size:20px;font-weight:900;color:#171817;border-bottom:2px solid #171817;display:inline-block;padding-bottom:1px;">${esc(business?.name||'Mahesh Constructions')}</div>
  <div style="font-size:12px;color:#667085;margin-top:4px;margin-bottom:12px;">Contractor Detail</div>
  <div style="font-size:11px;font-weight:800;color:#171817;">Bill To:</div>
  <div style="font-size:13px;font-weight:800;color:#171817;">${esc(doc.customer?.name||'Jai Siva')}</div>
  <div style="font-size:12px;color:#475569;">${esc(doc.customer?.siteLocation||doc.customer?.address||'Kailasapuram')}</div>
  <div style="font-size:11px;font-weight:800;color:#171817;margin-top:8px;">Scope of Work:</div>
  <div style="font-size:12px;color:#475569;">${esc(doc.title||'Supply and installation as listed.')}</div>
 </div>
 <div style="text-align:right;">
  <div style="font-size:20px;font-weight:900;color:#171817;border-bottom:3px solid #FFD500;display:inline-block;padding-bottom:2px;letter-spacing:0.5px;">${localizedHeader}</div>
  <div style="font-size:11.5px;color:#475569;margin-top:8px;"><b>Quote No:</b> ${esc(doc.number||'QT-0001')}</div>
  <div style="font-size:11.5px;color:#475569;"><b>Date:</b> ${esc(doc.date)}</div>
  <div style="font-size:11.5px;color:#475569;"><b>Valid Till:</b> ${esc(doc.dueDate||'25 Oct 2026')}</div>
 </div>
</div>

<div class="section-banner">MATERIALS</div>
<table class="sec-table">
 <thead>
  <tr>
   <th style="width:32px;">#</th>
   <th>Item</th>
   <th>Description</th>
   <th style="width:85px;text-align:right;">Qty</th>
   <th style="width:75px;text-align:right;">Rate (₹)</th>
   <th style="width:95px;text-align:right;">Amount (₹)</th>
  </tr>
 </thead>
 <tbody>
  ${renderSectionRows(materialsItems)}
 </tbody>
</table>
<div class="subtotal-bar">
 <span>Materials Subtotal</span>
 <span>₹${matSubtotal.toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</span>
</div>

<div class="section-banner" style="margin-top:14px;">LABOUR</div>
<table class="sec-table">
 <thead>
  <tr>
   <th style="width:32px;">#</th>
   <th>Item</th>
   <th>Description</th>
   <th style="width:85px;text-align:right;">Qty</th>
   <th style="width:75px;text-align:right;">Rate (₹)</th>
   <th style="width:95px;text-align:right;">Amount (₹)</th>
  </tr>
 </thead>
 <tbody>
  ${renderSectionRows(labourItems)}
 </tbody>
</table>
<div class="subtotal-bar">
 <span>Labour Subtotal</span>
 <span>₹${labSubtotal.toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</span>
</div>

<div class="grand-bar">
 <span style="font-size:15px;font-weight:900;color:#171817;">Grand Total</span>
 <span style="font-size:18px;font-weight:900;color:#171817;">₹${Number(doc.total||(matSubtotal+labSubtotal)).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}</span>
</div>

<div style="margin-top:14px;font-size:11px;color:#475569;">
 <b>Note:</b><br>${esc(doc.terms||'Material specifications attached separately.')}
</div>

<div style="display:flex;justify-content:space-between;margin-top:40px;padding-top:10px;">
 <div style="width:40%;text-align:center;border-top:1px solid #171817;padding-top:6px;font-size:11px;color:#475569;">Contractor Signature</div>
 <div style="width:40%;text-align:center;border-top:1px solid #171817;padding-top:6px;font-size:11px;color:#475569;">Customer Acknowledgment</div>
</div>
${annexureHtml}
</body></html>`;
  }

  // 3. Layout: Project Summary (Reference 06)
  if (theme.id === 'project_summary') {
   const isQuotation = doc.kind === 'quotation';
   const docTitle = isQuotation ? 'CONSTRUCTION QUOTATION' : 'TAX INVOICE';
   const items = doc.items || [];
   const totalAmount = Number(doc.total || 0);

   const tableRows = items.map(it => {
     const basisText = it.basis || (it.qty && it.rate ? `${Number(it.measuredQty||it.qty)} ${esc(it.unit||'sq.ft')} × ₹${Number(it.rate)}` : 'Fixed scope');
     return `<tr>
      <td style="padding:10px 12px;border-bottom:1px solid #E2E8F0;font-weight:600;font-size:12.5px;color:#0F172A;"><div>${esc(it.name)}</div>${formatItemSubtitle(it)?`<div style="font-size:10.5px;color:#475569;margin-top:3px;font-weight:normal;">${esc(formatItemSubtitle(it))}</div>`:''}</td>
      <td style="padding:10px 12px;border-bottom:1px solid #E2E8F0;color:#334155;font-size:12px;text-align:center;">${esc(basisText)}</td>
      <td style="padding:10px 12px;border-bottom:1px solid #E2E8F0;font-weight:700;font-size:12.5px;text-align:right;color:#0F172A;">₹${Number(it.amount||0).toLocaleString('en-IN')}</td>
     </tr>`;
   }).join('');

   return `<!doctype html><html lang="${esc(doc.language)}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(doc.number)}</title><style>${sizeConfig.rule}
*{box-sizing:border-box}
body{font:13px 'Segoe UI',Inter,-apple-system,BlinkMacSystemFont,Roboto,sans-serif;color:#171817;margin:0;background:white;padding:28px;-webkit-font-smoothing:antialiased}
table{width:100%;border-collapse:collapse;margin:16px 0;}
thead{display:table-header-group;background:#F1F5F9;}
th{text-align:left;padding:9px 12px;font-size:11px;font-weight:800;color:#334155;letter-spacing:0.5px;border-top:1px solid #CBD5E1;border-bottom:1px solid #CBD5E1;}
td{padding:9px 12px;vertical-align:middle;}
tr{break-inside:avoid;}
.grand-row td{background:#F1F5F9;font-weight:900;font-size:14px;color:#0F172A;border-top:1px solid #CBD5E1;border-bottom:1px solid #CBD5E1;}
</style></head><body>
<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:16px;">
 <div>
  <h1 style="font-size:26px;font-weight:900;margin:0 0 6px;color:#0F172A;letter-spacing:-0.5px;text-transform:uppercase;line-height:1.1;">${esc(docTitle)}</h1>
  <div style="font-size:12px;color:#64748B;">From:</div>
  <div style="font-size:15px;font-weight:900;color:#0F172A;">${esc(business.name||'Mahesh Constructions')}</div>
 </div>
 <div style="text-align:right;font-size:12px;line-height:1.6;">
  <div style="font-size:15px;font-weight:900;color:#0F172A;margin-bottom:4px;">${esc(doc.number||'QT-0001')}</div>
  <div><span style="color:#64748B;">Date:</span> <b>${esc(doc.date||'18 Oct 2026')}</b></div>
  <div><span style="color:#64748B;">Valid Until:</span> <b>${esc(doc.dueDate||'25 Oct 2026')}</b></div>
  <div><span style="color:#64748B;">Project Type:</span> <b>${esc(doc.title||'Residential finishing work')}</b></div>
  <div><span style="color:#64748B;">Site Location:</span> <b>${esc(doc.siteLocation||doc.customer?.siteLocation||'Kailasapuram')}</b></div>
 </div>
</div>

<div style="border-top:1px solid #CBD5E1;padding-top:14px;margin-bottom:18px;display:flex;justify-content:space-between;align-items:flex-start;">
 <div style="width:48%;">
  <div style="font-size:12px;color:#64748B;">To:</div>
  <div style="font-size:15px;font-weight:900;color:#0F172A;">${esc(doc.customer?.name||'Jai Siva')}</div>
 </div>
 <div style="width:48%;text-align:right;">
  <div style="font-size:12px;font-weight:800;color:#0F172A;">Project Summary</div>
  <div style="font-size:12px;color:#475569;">${esc(doc.title||'Residential finishing work')} at ${esc(doc.siteLocation||doc.customer?.siteLocation||'Kailasapuram')}.</div>
 </div>
</div>

<table>
 <thead>
  <tr>
   <th style="width:45%;">WORK</th>
   <th style="width:30%;text-align:center;">BASIS</th>
   <th style="width:25%;text-align:right;">AMOUNT</th>
  </tr>
 </thead>
 <tbody>
  ${tableRows}
  <tr class="grand-row">
   <td colspan="2" style="padding:10px 12px;font-weight:900;font-size:13px;letter-spacing:0.5px;">GRAND TOTAL</td>
   <td style="padding:10px 12px;text-align:right;font-size:15px;font-weight:900;">₹${totalAmount.toLocaleString('en-IN')}</td>
  </tr>
 </tbody>
</table>

<div style="margin-top:20px;">
 <div style="font-weight:800;font-size:12.5px;color:#0F172A;margin-bottom:3px;">Scope of Work</div>
 <div style="font-size:12px;color:#475569;border-bottom:1px solid #E2E8F0;padding-bottom:10px;margin-bottom:14px;">
  ${esc(doc.terms||'Work limited to the items listed above.')}
 </div>

 <div style="font-weight:800;font-size:12.5px;color:#0F172A;margin-bottom:3px;">Materials</div>
 <div style="font-size:12px;color:#475569;border-bottom:1px solid #E2E8F0;padding-bottom:10px;margin-bottom:32px;">
  See separate material specification agreement.
 </div>
</div>

<div style="display:flex;justify-content:space-between;margin-top:40px;">
 <div style="width:42%;text-align:center;">
  <div style="border-top:1px solid #0F172A;margin-bottom:6px;"></div>
  <div style="font-weight:700;font-size:12px;color:#0F172A;">For ${esc(business.name||'Mahesh Constructions')}</div>
  <div style="font-size:10.5px;color:#64748B;">(Authorized Signatory)</div>
 </div>
 <div style="width:42%;text-align:center;">
  <div style="border-top:1px solid #0F172A;margin-bottom:6px;"></div>
  <div style="font-weight:700;font-size:12px;color:#0F172A;">For ${esc(doc.customer?.name||'Jai Siva')}</div>
  <div style="font-size:10.5px;color:#64748B;">(Customer Signature)</div>
 </div>
</div>

${annexureHtml}

</body></html>`;
  }

  // 4. Fallback / Universal Modern Template (TileBill signature)
 const logoHtml=business?.logo
  ? `<img src="${esc(business.logo)}" alt="${esc(business.name)}" style="max-height:58px;max-width:180px;object-fit:contain;border-radius:6px" />`
  : generateBrandMonogramSvg(business?.name||'TileBill Pro',theme.color,theme.accent);

 const signHtml=doc.signature||business?.signature
  ? `<div style="display:inline-block;text-align:right"><img src="${esc(doc.signature||business.signature)}" alt="Signature" style="max-height:48px;max-width:140px;object-fit:contain;margin-bottom:3px"/><div style="border-top:1.5px solid #1E293B;padding-top:4px;font-size:11px;font-weight:600;color:#0F172A">${esc(business?.owner||business?.name)}</div><div style="font-size:10px;color:#64748B">${t.signature} · Verified</div></div>`
  : `<div style="display:inline-block;min-width:140px;text-align:right"><div style="height:36px"></div><div style="border-top:1.5px solid #1E293B;padding-top:4px;font-size:11px;font-weight:600;color:#0F172A">${esc(business?.owner||business?.name)}</div><div style="font-size:10px;color:#64748B">${t.signature}</div></div>`;

 let section='';
 const lines=(doc.items||[]).map((l,i)=>{
  let head='';
  if(l.section&&l.section!==section){
   section=l.section;
   head=`<tr class="section"><td colspan="6">${esc(section)}</td></tr>`;
  }
  const entry=catalogue.find(x=>x.id===l.catalogueId),name=entry&&l.name===entry.name&&doc.language!=='en'?entry[doc.language]||l.name:l.name;
  const dims = [l.length,l.width,l.height].filter(Boolean).join(' × ');
  const dimStr = dims ? dims + (l.dimensionUnit ? ' ' + l.dimensionUnit : '') + (l.qty ? ' × ' + l.qty : '') : '';
  const mQty = l.measuredQty !== undefined ? l.measuredQty : (l.qty || 0);
  return head+`<tr><td>${i+1}</td><td><b>${esc(name)}</b>${formatItemSubtitle(l)?`<div style="font-size:10px;color:#475569;margin-top:2px;">${esc(formatItemSubtitle(l))}</div>`:''}<small>${esc(l.note||'')}${dimStr?'<br>'+esc(dimStr):''}</small></td><td>${mQty} ${esc(l.unit||'sq.ft')}</td><td>${money(l.rate)}</td><td>${esc(l.basis||'')}</td><td>${money(l.amount)}</td></tr>`;
 }).join('');

 const bankDetailsHtml = business?.showBankDetails !== false && (business?.bankName || business?.bankAccount || business?.bankIfsc)
  ? `<div style="border:1px dashed #94A3B8;padding:8px 12px;border-radius:6px;font-size:11px;color:#0F172A;background:#F8FAFC;flex:1;">
      <b>Bank Transfer:</b> ${business.bankName ? esc(business.bankName) + ' · ' : ''}<b>A/C:</b> ${esc(business.bankAccount || '—')}<br>
      <span style="font-size:10px;color:#64748B;"><b>IFSC:</b> ${esc(business.bankIfsc || '—')} ${business.bankHolder ? '· <b>Holder:</b> ' + esc(business.bankHolder) : ''}</span>
    </div>`
  : '';
 const upiHtml=business?.upiId?`<div class="upi-box" style="flex:1;"><b>UPI Pay:</b> ${esc(business.upiId)}<span style="display:block;font-size:10px;color:#64748B">Instant payment via any UPI App (GPay/PhonePe/Paytm)</span></div>`:'';

 return `<!doctype html><html lang="${esc(doc.language)}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(doc.number)}</title><style>${sizeConfig.rule}
*{box-sizing:border-box}
body{font:12.5px 'Segoe UI',Inter,Arial,'Noto Sans Telugu','Noto Sans Devanagari',sans-serif;color:#0F172A;margin:0;background:white;padding:${pageSizeId==='thermal'?'10px':'24px'};-webkit-font-smoothing:antialiased}
.top{display:flex;justify-content:space-between;align-items:flex-start;gap:20px;border-bottom:3px solid ${theme.color};padding-bottom:18px}
.brand{display:flex;align-items:center;gap:14px}
.brand-info h1{font-size:${pageSizeId==='thermal'?'18px':'22px'};margin:0 0 4px;color:${theme.color};letter-spacing:-0.3px}
.brand-info small{display:block;color:#475569;line-height:1.45;font-size:11.5px}
.doc-badge{text-align:right}
.doc-badge h2{font-size:18px;margin:0 0 4px;color:${theme.color};letter-spacing:0.5px}
.doc-badge b{font-size:14px;color:#0F172A}
.doc-badge small{display:block;color:#64748B;line-height:1.5;font-size:11px}
.meta{display:flex;justify-content:space-between;padding:14px 0;gap:20px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;margin:14px 0;padding:12px 14px}
.meta>div{flex:1}
.meta small{display:block;color:#64748B;font-size:10.5px;text-transform:uppercase;font-weight:600;letter-spacing:0.4px;margin-bottom:3px}
.meta b{font-size:13px;color:#0F172A}
.meta span{display:block;color:#475569;font-size:11.5px;line-height:1.4;margin-top:2px}
h3{font-size:13px;margin:16px 0 8px;color:${theme.color};text-transform:uppercase;letter-spacing:0.4px}
table{border-collapse:collapse;width:100%;font-size:11px}
thead{display:table-header-group;background:${theme.color};color:white}
td,th{text-align:left;padding:8px 7px;border-bottom:1px solid #E2E8F0;overflow-wrap:anywhere}
th{font-weight:600;letter-spacing:0.3px;font-size:10.5px}
tr{break-inside:avoid}
tbody tr:nth-child(even){background:#FBFCFE}
td:last-child,th:last-child{text-align:right;white-space:nowrap}
.section td{text-align:left!important;white-space:normal!important;background:#EDF2F7;font-weight:bold;color:${theme.color};padding:6px 7px}
.totals{margin:18px 0 18px auto;max-width:320px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;padding:12px 14px}
.totals p{display:flex;justify-content:space-between;gap:16px;margin:6px 0;font-size:11.5px}
.grand{font-size:15px;font-weight:bold;border-top:2px solid ${theme.color};padding-top:10px;margin-top:8px!important;color:${theme.color}}
.note{white-space:pre-wrap;line-height:1.6;overflow-wrap:anywhere;font-size:11.5px;color:#334155;background:#FAFBFD;padding:10px;border-radius:6px;border-left:3px solid ${theme.accent}}
.sign-row{display:flex;justify-content:space-between;align-items:flex-end;margin-top:24px;gap:20px}
.upi-box{border:1px dashed #94A3B8;padding:8px 12px;border-radius:6px;font-size:11px;color:#0F172A;background:#F8FAFC}
.foot{border-top:1px solid #E2E8F0;margin-top:24px;padding-top:12px;display:flex;justify-content:space-between;color:#64748B;font-size:10.5px}
a{color:${theme.color}}
@media print{.no-print{display:none}}
</style></head><body>
<div class="top">
 <div class="brand">
  ${logoHtml}
  <div class="brand-info">
   <h1>${esc(business?.name||'TileBill Pro')}</h1>
   <small>${esc(business?.owner||'')}${business?.phone?'<br>'+esc(business.phone):''}${business?.address?'<br>'+esc(business.address):''}${(business?.city||business?.district)?'<br>'+esc(business.city||business.district):''}${business?.gstin?'<br><b>GSTIN:</b> '+esc(business.gstin):''}</small>
  </div>
 </div>
 <div class="doc-badge">
  <h2>${(t && t[doc.kind]) || (doc.kind === 'quotation' ? 'Quotation' : 'Tax Invoice')}</h2>
  <b>${esc(doc.number)}</b>
  <small>${t.date}: ${esc(doc.date)}<br>${t.valid}: ${esc(doc.dueDate||'—')}</small>
 </div>
</div>
<div class="meta">
 <div><small>${t.customer}</small><b>${esc(doc.customer?.name||'Customer')}</b><span>${esc(doc.customer?.phone||'')}${doc.customer?.address?'<br>'+esc(doc.customer.address):''}</span></div>
 <div><small>${t.project}</small><b>${esc(doc.project?.name||doc.title)}</b><span>${esc(doc.project?.address||'')}</span></div>
</div>
<h3>${esc(doc.title)}</h3>
<table><thead><tr><th>#</th><th>${t.description}</th><th>${t.quantity}</th><th>${t.rate}</th><th>Scope</th><th>${t.amount}</th></tr></thead><tbody>${lines}</tbody></table>
<div class="totals">
 <p><span>${t.subtotal}</span><b>${money(doc.subtotal)}</b></p>
 <p><span>${t.discount}</span><b>− ${money(doc.discount)}</b></p>
 <p><span>${(t && t.tax) || 'Tax'} (${doc.taxPercent || 0}%)</span><b>${money(doc.tax)}</b></p>
 <p class="grand"><span>${t.total}</span><span>${money(doc.total)}</span></p>
 ${doc.retention?`<p><span>${t.retention}</span><b>${money(doc.retention)}</b></p>`:''}
 ${doc.kind==='invoice'?`<p><span>${t.paid}</span><b>${money(paid)}</b></p><p><span>${t.balance}</span><b>${money(Math.max(0,doc.total-paid))}</b></p><p><span>${t.dueNow}</span><b>${money(Math.max(0,doc.total-doc.retention-paid))}</b></p>`:''}
</div>
${[['terms',doc.terms||business?.terms],['exclusions',doc.exclusions],['milestones',doc.milestones]].filter(x=>x[1]).map(([k,v])=>`<h3>${t[k]||k}</h3><div class="note">${esc(v)}</div>`).join('')}
${(doc.notes||business?.notes)?`<h3>${t.notes||'Notes'}</h3><div class="note">${esc(doc.notes||business.notes)}</div>`:''}
<div class="sign-row">
 <div style="display:flex;flex-direction:column;gap:8px;flex:1;max-width:380px;">
  ${upiHtml}
  ${bankDetailsHtml}
 </div>
 ${signHtml}
</div>
<div class="foot"><span>${t.thanks}</span><span>${esc(business?.name||'TileBill Pro')} · ${esc(doc.number)}</span></div>
${annexureHtml}
</body></html>`;
}

function renderAgreementContent(agreement, business, linkedQuotation) {
  const lang = agreement?.language || linkedQuotation?.language || 'en';
  const t = {
    en: {
      title: 'MATERIAL SPECIFICATION AGREEMENT',
      projectDetails: '1. Project Details',
      customerName: 'Customer Name',
      projectSite: 'Project Site',
      agreementNo: 'Agreement No.',
      date: 'Date',
      materialSpecs: '2. Material Specifications',
      colMaterial: 'Material',
      colBrandGrade: 'Brand-Grade',
      colSpec: 'Specification',
      colSuppliedBy: 'Supplied by',
      contractor: 'Contractor',
      customer: 'Customer',
      toBeConfirmed: 'To be confirmed',
      asAgreed: 'As agreed',
      toBeSpecified: 'To be specified',
      footnote: '*Illustrative entries; confirm project specifications.',
      scopeNotes: '3. Scope & Notes',
      defaultScope: 'Material substitutions require prior customer approval.',
      signatures: '4. Signatures',
      forContractor: 'For ' + (business?.name || 'Contractor'),
      forCustomer: 'For ' + (agreement?.customer?.name || linkedQuotation?.customer?.name || 'Customer'),
      contractorRole: '(Contractor)',
      customerRole: '(Customer)',
      signature: 'Signature',
      dateLabel: 'Date'
    },
    te: {
      title: 'మెటీరియల్ స్పెసిఫికేషన్ అగ్రిమెంట్',
      projectDetails: '1. ప్రాజెక్ట్ వివరాలు',
      customerName: 'కస్టమర్ పేరు',
      projectSite: 'సైట్ ప్రదేశం',
      agreementNo: 'అగ్రిమెంట్ నం.',
      date: 'తేదీ',
      materialSpecs: '2. మెటీరియల్ వివరాలు',
      colMaterial: 'మెటీరియల్',
      colBrandGrade: 'బ్రాండ్ - గ్రేడ్',
      colSpec: 'స్పెసిఫికేషన్',
      colSuppliedBy: 'సరఫరా',
      contractor: 'కాంట్రాక్టర్',
      customer: 'కస్టమర్',
      toBeConfirmed: 'ఖరారు చేయాలి',
      asAgreed: 'ఒప్పుకున్న ప్రకారం',
      toBeSpecified: 'నిర్దేశించాలి',
      footnote: '*పరిశీలన ఎంట్రీలు; ప్రాజెక్ట్ స్పెసిఫికేషన్‌లను నిర్ధారించండి.',
      scopeNotes: '3. పని పరిధి & నిబంధనలు',
      defaultScope: 'మెటీరియల్ మార్పులకు ముందస్తు కస్టమర్ అనుమతి అవసరం.',
      signatures: '4. సంతకాలు',
      forContractor: (business?.name || 'కాంట్రాక్టర్') + ' కొరకు',
      forCustomer: (agreement?.customer?.name || linkedQuotation?.customer?.name || 'కస్టమర్') + ' కొరకు',
      contractorRole: '(కాంట్రాక్టర్)',
      customerRole: '(కస్టమర్)',
      signature: 'సంతకం',
      dateLabel: 'తేదీ'
    },
    hi: {
      title: 'सामग्री विनिर्देश समझौता',
      projectDetails: '1. परियोजना विवरण',
      customerName: 'ग्राहक का नाम',
      projectSite: 'साइट का स्थान',
      agreementNo: 'समझौता संख्या',
      date: 'तारीख',
      materialSpecs: '2. सामग्री विनिर्देश',
      colMaterial: 'सामग्री',
      colBrandGrade: 'ब्रांड - ग्रेड',
      colSpec: 'विनिर्देश',
      colSuppliedBy: 'आपूर्ति कर्ता',
      contractor: 'ठेकेदार',
      customer: 'ग्राहक',
      toBeConfirmed: 'पुष्टि की जानी है',
      asAgreed: 'सहमति अनुसार',
      toBeSpecified: 'निर्दिष्ट किया जाना है',
      footnote: '*परियोजना विनिर्देशों की पुष्टि करें।',
      scopeNotes: '3. कार्यक्षेत्र और शर्तें',
      defaultScope: 'सामग्री प्रतिस्थापन के लिए ग्राहक की पूर्व स्वीकृति आवश्यक है।',
      signatures: '4. हस्ताक्षर',
      forContractor: (business?.name || 'ठेकेदार') + ' की ओर से',
      forCustomer: (agreement?.customer?.name || linkedQuotation?.customer?.name || 'ग्राहक') + ' की ओर से',
      contractorRole: '(ठेकेदार)',
      customerRole: '(ग्राहक)',
      signature: 'हस्ताक्षर',
      dateLabel: 'तारीख'
    }
  }[lang] || {
    title: 'MATERIAL SPECIFICATION AGREEMENT',
    projectDetails: '1. Project Details',
    customerName: 'Customer Name',
    projectSite: 'Project Site',
    agreementNo: 'Agreement No.',
    date: 'Date',
    materialSpecs: '2. Material Specifications',
    colMaterial: 'Material',
    colBrandGrade: 'Brand-Grade',
    colSpec: 'Specification',
    colSuppliedBy: 'Supplied by',
    contractor: 'Contractor',
    customer: 'Customer',
    toBeConfirmed: 'To be confirmed',
    asAgreed: 'As agreed',
    toBeSpecified: 'To be specified',
    footnote: '*Illustrative entries; confirm project specifications.',
    scopeNotes: '3. Scope & Notes',
    defaultScope: 'Material substitutions require prior customer approval.',
    signatures: '4. Signatures',
    forContractor: 'For ' + (business?.name || 'Contractor'),
    forCustomer: 'For ' + (agreement?.customer?.name || linkedQuotation?.customer?.name || 'Customer'),
    contractorRole: '(Contractor)',
    customerRole: '(Customer)',
    signature: 'Signature',
    dateLabel: 'Date'
  };

  const custName = agreement?.customer?.name || linkedQuotation?.customer?.name || 'Jai Siva';
  const siteLocation = agreement?.projectSite || agreement?.project?.address || linkedQuotation?.project?.address || linkedQuotation?.project?.name || 'Kailasapuram';
  const agreeNo = agreement?.number || 'AG-0001';
  const agreeDate = agreement?.date || linkedQuotation?.date || '18 Oct 2026';
  const materials = (agreement?.materials && agreement.materials.length > 0) ? agreement.materials : [
    { name: 'Steel rods', brand: '', grade: '', sizes: ['8 mm', '12 mm'], whereUsed: '', suppliedBy: 'contractor' },
    { name: 'Cement', brand: '', grade: '', sizes: [], whereUsed: 'As agreed', suppliedBy: 'contractor' },
    { name: 'Pipes', brand: '', grade: '', sizes: [], whereUsed: 'To be specified', suppliedBy: 'customer' }
  ];

  const rowsHtml = materials.map((m) => {
    const brandGrade = [m.brand, m.grade].filter(Boolean).join(' - ') || t.toBeConfirmed;
    let spec = '';
    if (m.sizes && m.sizes.length > 0) {
      spec = m.sizes.join(', ') + (m.whereUsed ? ` (${m.whereUsed})` : '');
    } else if (m.whereUsed) {
      spec = m.whereUsed;
    } else {
      spec = t.asAgreed;
    }
    const supplied = m.suppliedBy === 'customer' ? t.customer : t.contractor;
    return `<tr>
      <td style="padding:7px 10px;border:1px solid #CBD5E1;font-weight:600;color:#0F172A;">${esc(m.name)}</td>
      <td style="padding:7px 10px;border:1px solid #CBD5E1;color:#334155;text-align:center;">${esc(brandGrade)}</td>
      <td style="padding:7px 10px;border:1px solid #CBD5E1;color:#334155;text-align:center;">${esc(spec)}</td>
      <td style="padding:7px 10px;border:1px solid #CBD5E1;color:#334155;text-align:center;">${esc(supplied)}</td>
    </tr>`;
  }).join('');

  const scopeNotes = agreement?.terms || agreement?.notes || business?.terms || t.defaultScope;

  return `
  <div style="font-family:'Segoe UI',Inter,Arial,'Noto Sans Telugu','Noto Sans Devanagari',sans-serif;color:#0F172A;">
    <!-- Top Header -->
    <div style="display:flex;justify-content:space-between;align-items:flex-start;padding-bottom:14px;border-bottom:3px solid #FFD500;">
      <div style="display:flex;align-items:center;gap:12px;">
        ${business?.logo ? `<img src="${esc(business.logo)}" alt="${esc(business.name)}" style="max-height:50px;max-width:140px;object-fit:contain;"/>` : generateBrandMonogramSvg(business?.name || 'Mahesh Constructions', '#0F172A', '#FFD500')}
        <div>
          <div style="font-size:18px;font-weight:800;color:#0F172A;letter-spacing:-0.3px;">${esc(business?.name || 'Mahesh Constructions')}</div>
          <div style="font-size:11px;color:#475569;margin-top:2px;">${esc(business?.address || 'Kailasapuram, Hyderabad - 500072')}</div>
          <div style="font-size:11px;color:#64748B;margin-top:1px;">Ph: ${esc(business?.phone || '97000 12345')} | ${esc(business?.owner || '')}${business?.gstin ? ' | <b>GSTIN:</b> ' + esc(business.gstin) : ''}</div>
        </div>
      </div>
      <div style="text-align:right;font-size:11px;color:#334155;line-height:1.5;">
        <div><b>Agreement No:</b> ${esc(agreeNo)}</div>
        <div><b>Date:</b> ${esc(agreeDate)}</div>
        <div><b>Customer:</b> ${esc(custName)}</div>
        <div><b>Site:</b> ${esc(siteLocation)}</div>
      </div>
    </div>

    <!-- Title -->
    <div style="text-align:center;margin:18px 0 14px 0;">
      <h2 style="font-size:15px;font-weight:900;letter-spacing:0.8px;color:#0F172A;margin:0;text-transform:uppercase;">
        ${esc(t.title)}
      </h2>
    </div>

    <!-- 1. Project Details -->
    <div style="margin-bottom:16px;">
      <div style="font-weight:800;font-size:12px;color:#0F172A;margin-bottom:5px;">${esc(t.projectDetails)}</div>
      <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:6px;padding:8px 12px;font-size:11.5px;line-height:1.6;display:grid;grid-template-columns:1fr 1fr;gap:4px 16px;">
        <div><span style="color:#64748B;display:inline-block;width:110px;">${esc(t.customerName)}</span> : <b>${esc(custName)}</b></div>
        <div><span style="color:#64748B;display:inline-block;width:110px;">${esc(t.projectSite)}</span> : <b>${esc(siteLocation)}</b></div>
        <div><span style="color:#64748B;display:inline-block;width:110px;">${esc(t.agreementNo)}</span> : <b>${esc(agreeNo)}</b></div>
        <div><span style="color:#64748B;display:inline-block;width:110px;">${esc(t.date)}</span> : <b>${esc(agreeDate)}</b></div>
      </div>
    </div>

    <!-- 2. Material Specifications -->
    <div style="margin-bottom:16px;">
      <div style="font-weight:800;font-size:12px;color:#0F172A;margin-bottom:5px;">${esc(t.materialSpecs)}</div>
      <table style="width:100%;border-collapse:collapse;font-size:11.5px;border:1px solid #CBD5E1;">
        <thead>
          <tr style="background:#FEF08A;color:#171817;font-weight:700;">
            <th style="padding:7px 10px;border:1px solid #CBD5E1;text-align:left;">${esc(t.colMaterial)}</th>
            <th style="padding:7px 10px;border:1px solid #CBD5E1;text-align:center;">${esc(t.colBrandGrade)}</th>
            <th style="padding:7px 10px;border:1px solid #CBD5E1;text-align:center;">${esc(t.colSpec)}</th>
            <th style="padding:7px 10px;border:1px solid #CBD5E1;text-align:center;">${esc(t.colSuppliedBy)}</th>
          </tr>
        </thead>
        <tbody>
          ${rowsHtml}
        </tbody>
      </table>
      <div style="font-size:10px;color:#64748B;margin-top:5px;font-style:italic;">
        ${esc(t.footnote)}
      </div>
    </div>

    <!-- 3. Scope & Notes -->
    <div style="margin-bottom:20px;">
      <div style="font-weight:800;font-size:12px;color:#0F172A;margin-bottom:5px;">${esc(t.scopeNotes)}</div>
      <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:6px;padding:8px 12px;font-size:11.5px;color:#334155;line-height:1.5;">
        • ${esc(scopeNotes)}
      </div>
    </div>

    <!-- 4. Signatures -->
    <div>
      <div style="font-weight:800;font-size:12px;color:#0F172A;margin-bottom:6px;">${esc(t.signatures)}</div>
      <div style="display:flex;justify-content:space-between;gap:16px;">
        <div style="flex:1;border:1px solid #E2E8F0;border-radius:6px;padding:10px 12px;background:#FFFFFF;">
          <div style="font-weight:700;font-size:11.5px;color:#0F172A;">${esc(t.forContractor)}</div>
          <div style="font-size:10px;color:#64748B;margin-bottom:4px;">${esc(t.contractorRole)}</div>
          <div style="min-height:36px;display:flex;align-items:center;">
            ${(business?.signature || agreement?.signature) ? `<img src="${esc(business?.signature || agreement?.signature)}" style="max-height:36px;max-width:120px;object-fit:contain;margin-bottom:2px;" />` : `<div style="height:36px;"></div>`}
          </div>
          <div style="display:flex;justify-content:space-between;align-items:flex-end;border-top:1px solid #CBD5E1;padding-top:4px;">
            <div style="font-size:10px;color:#64748B;">${esc(t.signature)}</div>
            <div style="font-size:10px;color:#64748B;">${esc(t.dateLabel)}</div>
          </div>
        </div>

        <div style="flex:1;border:1px solid #E2E8F0;border-radius:6px;padding:10px 12px;background:#FFFFFF;">
          <div style="font-weight:700;font-size:11.5px;color:#0F172A;">${esc(t.forCustomer)}</div>
          <div style="font-size:10px;color:#64748B;margin-bottom:24px;">${esc(t.customerRole)}</div>
          <div style="display:flex;justify-content:space-between;align-items:flex-end;border-top:1px solid #CBD5E1;padding-top:4px;">
            <div style="font-size:10px;color:#64748B;">${esc(t.signature)}</div>
            <div style="font-size:10px;color:#64748B;">${esc(t.dateLabel)}</div>
          </div>
        </div>
      </div>
    </div>
  </div>`;
}

function agreementHtml(agreement, business, linkedQuotation, options = {}) {
  const pageSizeId = options.pageSize || agreement?.pageSize || business?.pageSize || 'a4';
  const sizeConfig = pageSizes.find(x => x.id === pageSizeId) || pageSizes[0];
  const lang = agreement?.language || linkedQuotation?.language || 'en';
  return `<!doctype html><html lang="${esc(lang)}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(agreement?.number || 'AG-0001')}</title><style>${sizeConfig.rule}
*{box-sizing:border-box}
body{font:12.5px 'Segoe UI',Inter,Arial,'Noto Sans Telugu','Noto Sans Devanagari',sans-serif;color:#0F172A;margin:0;background:white;padding:${pageSizeId === 'thermal' ? '10px' : '24px'};-webkit-font-smoothing:antialiased}
@media print{.no-print{display:none}}
</style></head><body>
${renderAgreementContent(agreement, business, linkedQuotation)}
</body></html>`;
}

function renderMaterialListContent(list, business, options = {}) {
  const lang = options.language || list?.language || 'en';
  const showPrices = Boolean(options.showPrices ?? list?.showPrices ?? false);
  const dictMap = {
    en: {
      title: 'MATERIALS TO PURCHASE',
      subtitle: 'Client Purchase Specification List',
      customerName: 'Customer Name',
      projectSite: 'Site / Location',
      listNo: 'List No',
      date: 'Date',
      workAreas: 'Work Areas Included',
      colItem: 'Material & Specification',
      colCategory: 'Category',
      colQty: 'Required Qty',
      colEstRate: 'Est. Rate',
      colEstTotal: 'Est. Amount',
      estBudgetTotal: 'Estimated Materials Budget',
      brandNotes: 'Brand / Shop Instructions',
      footnote: 'Note: Prepared for client purchase. Please verify all specifications and quantities with contractor before purchase.',
      forContractor: 'Prepared by Contractor',
      forCustomer: 'Client Acknowledgment',
      signature: 'Signature',
      dateLabel: 'Date'
    },
    te: {
      title: 'కొనుగోలు చేయవలసిన సామాగ్రి',
      subtitle: 'కస్టమర్ కొనుగోలు మెటీరియల్ లిస్ట్',
      customerName: 'కస్టమర్ పేరు',
      projectSite: 'సైట్ / ప్రాంతం',
      listNo: 'లిస్ట్ సంఖ్య',
      date: 'తేదీ',
      workAreas: 'చేర్చబడిన పని గదులు / ప్రాంతాలు',
      colItem: 'సామాగ్రి & స్పెసిఫికేషన్',
      colCategory: 'విభాగం',
      colQty: 'కావలసిన పరిమాణం',
      colEstRate: 'అంచనా ధర',
      colEstTotal: 'అంచనా మొత్తం',
      estBudgetTotal: 'అంచనా మెటీరియల్ బడ్జెట్',
      brandNotes: 'బ్రాండ్ / షాప్ సూచనలు',
      footnote: 'గమనిక: కస్టమర్ కొనుగోలు కోసం తయారు చేయబడింది. సామాగ్రి కొనుగోలు చేసే ముందు స్పెసిఫికేషన్లను సరిచూసుకోండి.',
      forContractor: 'కాంట్రాక్టర్ సంతకం',
      forCustomer: 'కస్టమర్ అంగీకారం',
      signature: 'సంతకం',
      dateLabel: 'తేదీ'
    },
    hi: {
      title: 'खरीदी जाने वाली सामग्री सूची',
      subtitle: 'ग्राहक खरीद सामग्री सूची',
      customerName: 'ग्राहक का नाम',
      projectSite: 'साइट / स्थान',
      listNo: 'सूची संख्या',
      date: 'तारीख',
      workAreas: 'शामिल कार्य क्षेत्र व कमरे',
      colItem: 'सामग्री व विनिर्देश',
      colCategory: 'श्रेणी',
      colQty: 'आवश्यक मात्रा',
      colEstRate: 'अनुमानित दर',
      colEstTotal: 'अनुमानित राशि',
      estBudgetTotal: 'अनुमानित सामग्री बजट',
      brandNotes: 'ब्रांड / दुकान निर्देश',
      footnote: 'नोट: ग्राहक द्वारा खरीद हेतु। खरीदने से पहले कृपया सभी विनिर्देशों की पुष्टि कर लें।',
      forContractor: 'ठेकेदार हस्ताक्षर',
      forCustomer: 'ग्राहक स्वीकृति',
      signature: 'हस्ताक्षर',
      dateLabel: 'तारीख'
    }
  };
  const t = dictMap[lang] || dictMap.en;
  const custName = list?.customer?.name || list?.customerName || 'Customer';
  const siteLocation = list?.siteLocation || list?.customer?.siteLocation || list?.customer?.address || 'Site';
  const listNo = list?.number || 'TB-MAT-0001';
  const listDate = list?.date || new Date().toISOString().slice(0, 10);
  const items = Array.isArray(list?.items) ? list.items : [];
  const workAreas = list?.workAreasSummary || (Array.isArray(list?.rooms) ? list.rooms.map(r => r.name).join(', ') : 'All Work Areas');

  let totalEstAmount = 0;
  const rowsHtml = items.map((it, idx) => {
    const qty = Number(it.qty || 1);
    const rate = Number(it.rate || it.defaultRate || 0);
    const lineTotal = qty * rate;
    totalEstAmount += lineTotal;
    const name = it.name || 'Item';
    const specs = [it.brand, it.specs || it.specification].filter(Boolean).join(' • ');

    return `<tr>
      <td style="padding:8px 10px;border:1px solid #CBD5E1;color:#64748B;text-align:center;font-size:11px;">${idx + 1}</td>
      <td style="padding:8px 10px;border:1px solid #CBD5E1;color:#0F172A;">
        <div style="font-weight:700;font-size:12.5px;">${esc(name)}</div>
        ${specs ? `<div style="font-size:11px;color:#475569;margin-top:2px;">${esc(specs)}</div>` : ''}
      </td>
      <td style="padding:8px 10px;border:1px solid #CBD5E1;color:#475569;text-align:center;font-size:11px;">${esc(it.category || 'General')}</td>
      <td style="padding:8px 10px;border:1px solid #CBD5E1;color:#0F172A;text-align:center;font-weight:800;font-size:12px;">${qty} <span style="font-size:10.5px;font-weight:600;color:#64748B;">${esc(it.unit || 'pcs')}</span></td>
      ${showPrices ? `
        <td style="padding:8px 10px;border:1px solid #CBD5E1;color:#475569;text-align:right;font-size:11.5px;">${money(rate)}</td>
        <td style="padding:8px 10px;border:1px solid #CBD5E1;color:#0F172A;text-align:right;font-weight:700;font-size:12px;">${money(lineTotal)}</td>
      ` : ''}
    </tr>`;
  }).join('');

  return `
  <div style="font-family:'Segoe UI',Inter,Arial,'Noto Sans Telugu','Noto Sans Devanagari',sans-serif;color:#0F172A;">
    <!-- Top Header -->
    <div style="display:flex;justify-content:space-between;align-items:flex-start;padding-bottom:14px;border-bottom:3px solid #FFD500;">
      <div style="display:flex;align-items:center;gap:12px;">
        ${business?.logo ? `<img src="${esc(business.logo)}" alt="${esc(business.name)}" style="max-height:50px;max-width:140px;object-fit:contain;"/>` : generateBrandMonogramSvg(business?.name || 'TileBill Pro', '#0F172A', '#FFD500')}
        <div>
          <div style="font-size:18px;font-weight:800;color:#0F172A;letter-spacing:-0.3px;">${esc(business?.name || 'TileBill Pro Contractor')}</div>
          <div style="font-size:11px;color:#475569;margin-top:2px;">${esc(business?.address || business?.city || 'Site Office')}</div>
          <div style="font-size:11px;color:#64748B;margin-top:1px;">Ph: ${esc(business?.phone || '')} ${business?.owner ? '| ' + esc(business.owner) : ''}</div>
        </div>
      </div>
      <div style="text-align:right;font-size:11px;color:#334155;line-height:1.5;">
        <div><b>${esc(t.listNo)}:</b> ${esc(listNo)}</div>
        <div><b>${esc(t.date)}:</b> ${esc(listDate)}</div>
        <div><b>${esc(t.customerName)}:</b> ${esc(custName)}</div>
        <div><b>${esc(t.projectSite)}:</b> ${esc(siteLocation)}</div>
      </div>
    </div>

    <!-- Title Banner -->
    <div style="text-align:center;margin:16px 0 12px 0;">
      <h2 style="font-size:16px;font-weight:900;letter-spacing:0.6px;color:#0F172A;margin:0;text-transform:uppercase;">
        🛒 ${esc(t.title)}
      </h2>
      <div style="font-size:11px;color:#64748B;margin-top:2px;">${esc(t.subtitle)}</div>
    </div>

    <!-- Work Areas Chip Box -->
    <div style="background:#FEF9E7;border:1px solid #FEF08A;border-radius:8px;padding:8px 12px;margin-bottom:14px;">
      <div style="font-size:11px;font-weight:700;color:#854D0E;text-transform:uppercase;letter-spacing:0.5px;">📍 ${esc(t.workAreas)}:</div>
      <div style="font-size:12px;font-weight:700;color:#111827;margin-top:2px;">${esc(workAreas)}</div>
    </div>

    <!-- Materials Table -->
    <div style="margin-bottom:16px;">
      <table style="width:100%;border-collapse:collapse;font-size:11.5px;border:1px solid #CBD5E1;">
        <thead>
          <tr style="background:#FEF08A;color:#171817;font-weight:800;">
            <th style="padding:7px 10px;border:1px solid #CBD5E1;width:32px;">#</th>
            <th style="padding:7px 10px;border:1px solid #CBD5E1;text-align:left;">${esc(t.colItem)}</th>
            <th style="padding:7px 10px;border:1px solid #CBD5E1;text-align:center;width:90px;">${esc(t.colCategory)}</th>
            <th style="padding:7px 10px;border:1px solid #CBD5E1;text-align:center;width:110px;">${esc(t.colQty)}</th>
            ${showPrices ? `
              <th style="padding:7px 10px;border:1px solid #CBD5E1;text-align:right;width:85px;">${esc(t.colEstRate)}</th>
              <th style="padding:7px 10px;border:1px solid #CBD5E1;text-align:right;width:95px;">${esc(t.colEstTotal)}</th>
            ` : ''}
          </tr>
        </thead>
        <tbody>
          ${rowsHtml}
        </tbody>
        ${showPrices ? `
        <tfoot>
          <tr style="background:#F8FAFC;font-weight:800;">
            <td colspan="5" style="padding:8px 10px;border:1px solid #CBD5E1;text-align:right;color:#0F172A;">${esc(t.estBudgetTotal)}:</td>
            <td style="padding:8px 10px;border:1px solid #CBD5E1;text-align:right;color:#0F172A;font-size:13px;">${money(totalEstAmount)}</td>
          </tr>
        </tfoot>
        ` : ''}
      </table>
    </div>

    <!-- Brand / Shop Instructions -->
    ${(list?.instructions || list?.brandNotes) ? `
    <div style="margin-bottom:16px;">
      <div style="font-weight:800;font-size:11.5px;color:#0F172A;margin-bottom:4px;">🏪 ${esc(t.brandNotes)}:</div>
      <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:6px;padding:8px 12px;font-size:11.5px;color:#334155;line-height:1.5;">
        ${esc(list?.instructions || list?.brandNotes)}
      </div>
    </div>
    ` : ''}

    <!-- Footnote -->
    <div style="font-size:10.5px;color:#64748B;font-style:italic;margin-bottom:16px;">
      ${esc(t.footnote)}
    </div>

    <!-- Signatures -->
    <div>
      <div style="display:flex;justify-content:space-between;gap:16px;">
        <div style="flex:1;border:1px solid #E2E8F0;border-radius:6px;padding:10px 12px;background:#FFFFFF;">
          <div style="font-weight:700;font-size:11.5px;color:#0F172A;">${esc(t.forContractor)}</div>
          <div style="height:32px;"></div>
          <div style="display:flex;justify-content:space-between;align-items:flex-end;border-top:1px solid #CBD5E1;padding-top:4px;">
            <div style="font-size:10px;color:#64748B;">${esc(t.signature)}</div>
            <div style="font-size:10px;color:#64748B;">${esc(t.dateLabel)}</div>
          </div>
        </div>

        <div style="flex:1;border:1px solid #E2E8F0;border-radius:6px;padding:10px 12px;background:#FFFFFF;">
          <div style="font-weight:700;font-size:11.5px;color:#0F172A;">${esc(t.forCustomer)}</div>
          <div style="height:32px;"></div>
          <div style="display:flex;justify-content:space-between;align-items:flex-end;border-top:1px solid #CBD5E1;padding-top:4px;">
            <div style="font-size:10px;color:#64748B;">${esc(t.signature)}</div>
            <div style="font-size:10px;color:#64748B;">${esc(t.dateLabel)}</div>
          </div>
        </div>
      </div>
    </div>
  </div>`;
}

function materialListHtml(list, business, options = {}) {
  const pageSizeId = options.pageSize || business?.pageSize || 'a4';
  const sizeConfig = pageSizes.find(x => x.id === pageSizeId) || pageSizes[0];
  const lang = options.language || list?.language || 'en';
  return `<!doctype html><html lang="${esc(lang)}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(list?.number || 'TB-MAT-0001')}</title><style>${sizeConfig.rule}
*{box-sizing:border-box}
body{font:12.5px 'Segoe UI',Inter,Arial,'Noto Sans Telugu','Noto Sans Devanagari',sans-serif;color:#0F172A;margin:0;background:white;padding:${pageSizeId === 'thermal' ? '10px' : '24px'};-webkit-font-smoothing:antialiased}
@media print{.no-print{display:none}}
</style></head><body>
${renderMaterialListContent(list, business, options)}
</body></html>`;
}

function renderLabourBillContent(bill, business, options = {}) {
  const lang = options.language || bill?.language || 'en';
  const dictMap = {
    en: {
      title: 'LABOUR CHARGES BILL',
      subtitle: 'Work & Labour Account Summary',
      customerName: 'Customer Name',
      projectSite: 'Site / Location',
      billNo: 'Bill No',
      date: 'Date',
      colItem: 'Work Description',
      colBasis: 'Billing Basis',
      colQty: 'Qty / Rooms',
      colRate: 'Labour Rate',
      colAmount: 'Amount',
      totalLabour: 'Total Labour Charges',
      forContractor: 'Authorised Signature',
      forCustomer: 'Client Signature',
      signature: 'Signature',
      dateLabel: 'Date'
    },
    te: {
      title: 'లేబర్ ఛార్జీల బిల్లు',
      subtitle: 'కూలీ & పని వివరాల రశీదు',
      customerName: 'కస్టమర్ పేరు',
      projectSite: 'సైట్ / ప్రాంతం',
      billNo: 'బిల్లు సంఖ్య',
      date: 'తేదీ',
      colItem: 'పని వివరాలు',
      colBasis: 'బిల్లింగ్ విధానం',
      colQty: 'పరిమాణం / గదులు',
      colRate: 'కూలీ ధర',
      colAmount: 'మొత్తం',
      totalLabour: 'మొత్తం లేబర్ ఛార్జీలు',
      forContractor: 'అధీకృత సంతకం',
      forCustomer: 'కస్టమర్ సంతకం',
      signature: 'సంతకం',
      dateLabel: 'తేదీ'
    },
    hi: {
      title: 'मजदूरी शुल्क बिल',
      subtitle: 'कार्य व श्रम विवरण बिल',
      customerName: 'ग्राहक का नाम',
      projectSite: 'साइट / स्थान',
      billNo: 'बिल संख्या',
      date: 'तारीख',
      colItem: 'काम का विवरण',
      colBasis: 'बिलिंग आधार',
      colQty: 'मात्रा / कमरे',
      colRate: 'मजदूरी दर',
      colAmount: 'राशि',
      totalLabour: 'कुल मजदूरी शुल्क',
      forContractor: 'अधिकृत हस्ताक्षर',
      forCustomer: 'ग्राहक हस्ताक्षर',
      signature: 'हस्ताक्षर',
      dateLabel: 'तारीख'
    }
  };
  const t = dictMap[lang] || dictMap.en;
  const custName = bill?.customer?.name || bill?.customerName || 'Customer';
  const siteLocation = bill?.siteLocation || bill?.customer?.siteLocation || 'Site';
  const billNo = bill?.number || 'TB-LAB-0001';
  const billDate = bill?.date || new Date().toISOString().slice(0, 10);
  const items = Array.isArray(bill?.items) && bill.items.length > 0 
    ? bill.items 
    : (Array.isArray(bill?.rooms) ? bill.rooms.flatMap(r => (r.items || []).map(it => ({
        name: `${r.name} — ${it.name || it.workTypeName || 'Work'}`,
        basis: it.unit === 'point' ? 'Per point' : it.unit === 'm' ? 'Per meter' : 'Work item',
        qty: Number(it.qty || it.netQty || it.length || 1),
        unit: it.unit || 'pt',
        rate: Number(it.rate || (it.unit === 'point' ? (bill.pointRate || 650) : (bill.routeRate || 120))),
        amount: Number(it.amount || ((it.qty || it.netQty || it.length || 1) * (it.rate || (it.unit === 'point' ? (bill.pointRate || 650) : (bill.routeRate || 120)))))
      }))) : []);
  const totalAmount = items.reduce((sum, it) => sum + Number(it.amount || (it.qty * it.rate) || 0), 0);

  const rowsHtml = items.map((it, idx) => {
    const qty = Number(it.qty || 1);
    const rate = Number(it.rate || 0);
    const amount = Number(it.amount || (qty * rate));
    return `<tr>
      <td style="padding:8px 10px;border:1px solid #CBD5E1;color:#64748B;text-align:center;font-size:11px;">${idx + 1}</td>
      <td style="padding:8px 10px;border:1px solid #CBD5E1;color:#0F172A;font-weight:700;">${esc(it.name || 'Labour work')}</td>
      <td style="padding:8px 10px;border:1px solid #CBD5E1;color:#475569;text-align:center;font-size:11px;">${esc(it.basis || 'Per point')}</td>
      <td style="padding:8px 10px;border:1px solid #CBD5E1;color:#0F172A;text-align:center;font-weight:700;">${qty} <span style="font-size:10px;font-weight:600;color:#64748B;">${esc(it.unit || '')}</span></td>
      <td style="padding:8px 10px;border:1px solid #CBD5E1;color:#475569;text-align:right;">${money(rate)}</td>
      <td style="padding:8px 10px;border:1px solid #CBD5E1;color:#0F172A;text-align:right;font-weight:800;">${money(amount)}</td>
    </tr>`;
  }).join('');

  return `
  <div style="font-family:'Segoe UI',Inter,Arial,'Noto Sans Telugu','Noto Sans Devanagari',sans-serif;color:#0F172A;">
    <!-- Top Header -->
    <div style="display:flex;justify-content:space-between;align-items:flex-start;padding-bottom:14px;border-bottom:3px solid #FFD500;">
      <div style="display:flex;align-items:center;gap:12px;">
        ${business?.logo ? `<img src="${esc(business.logo)}" alt="${esc(business.name)}" style="max-height:50px;max-width:140px;object-fit:contain;"/>` : generateBrandMonogramSvg(business?.name || 'TileBill Pro', '#0F172A', '#FFD500')}
        <div>
          <div style="font-size:18px;font-weight:800;color:#0F172A;letter-spacing:-0.3px;">${esc(business?.name || 'TileBill Pro Contractor')}</div>
          <div style="font-size:11px;color:#475569;margin-top:2px;">${esc(business?.address || business?.city || 'Site Office')}</div>
          <div style="font-size:11px;color:#64748B;margin-top:1px;">Ph: ${esc(business?.phone || '')} ${business?.owner ? '| ' + esc(business.owner) : ''}</div>
        </div>
      </div>
      <div style="text-align:right;font-size:11px;color:#334155;line-height:1.5;">
        <div><b>${esc(t.billNo)}:</b> ${esc(billNo)}</div>
        <div><b>${esc(t.date)}:</b> ${esc(billDate)}</div>
        <div><b>${esc(t.customerName)}:</b> ${esc(custName)}</div>
        <div><b>${esc(t.projectSite)}:</b> ${esc(siteLocation)}</div>
      </div>
    </div>

    <!-- Title Banner -->
    <div style="text-align:center;margin:16px 0 14px 0;">
      <h2 style="font-size:16px;font-weight:900;letter-spacing:0.6px;color:#0F172A;margin:0;text-transform:uppercase;">
        👷 ${esc(t.title)}
      </h2>
      <div style="font-size:11px;color:#64748B;margin-top:2px;">${esc(t.subtitle)}</div>
    </div>

    <!-- Labour Items Table -->
    <div style="margin-bottom:16px;">
      <table style="width:100%;border-collapse:collapse;font-size:11.5px;border:1px solid #CBD5E1;">
        <thead>
          <tr style="background:#FEF08A;color:#171817;font-weight:800;">
            <th style="padding:7px 10px;border:1px solid #CBD5E1;width:32px;">#</th>
            <th style="padding:7px 10px;border:1px solid #CBD5E1;text-align:left;">${esc(t.colItem)}</th>
            <th style="padding:7px 10px;border:1px solid #CBD5E1;text-align:center;width:110px;">${esc(t.colBasis)}</th>
            <th style="padding:7px 10px;border:1px solid #CBD5E1;text-align:center;width:100px;">${esc(t.colQty)}</th>
            <th style="padding:7px 10px;border:1px solid #CBD5E1;text-align:right;width:85px;">${esc(t.colRate)}</th>
            <th style="padding:7px 10px;border:1px solid #CBD5E1;text-align:right;width:95px;">${esc(t.colAmount)}</th>
          </tr>
        </thead>
        <tbody>
          ${rowsHtml}
        </tbody>
        <tfoot>
          <tr style="background:#F8FAFC;font-weight:800;">
            <td colspan="5" style="padding:9px 10px;border:1px solid #CBD5E1;text-align:right;color:#0F172A;font-size:12.5px;">${esc(t.totalLabour)}:</td>
            <td style="padding:9px 10px;border:1px solid #CBD5E1;text-align:right;color:#0F172A;font-size:14px;font-weight:900;">${money(totalAmount)}</td>
          </tr>
        </tfoot>
      </table>
    </div>

    <!-- Signatures -->
    <div style="margin-top:24px;">
      <div style="display:flex;justify-content:space-between;gap:16px;">
        <div style="flex:1;border:1px solid #E2E8F0;border-radius:6px;padding:10px 12px;background:#FFFFFF;">
          <div style="font-weight:700;font-size:11.5px;color:#0F172A;">${esc(t.forContractor)}</div>
          <div style="height:32px;"></div>
          <div style="display:flex;justify-content:space-between;align-items:flex-end;border-top:1px solid #CBD5E1;padding-top:4px;">
            <div style="font-size:10px;color:#64748B;">${esc(t.signature)}</div>
            <div style="font-size:10px;color:#64748B;">${esc(t.dateLabel)}</div>
          </div>
        </div>

        <div style="flex:1;border:1px solid #E2E8F0;border-radius:6px;padding:10px 12px;background:#FFFFFF;">
          <div style="font-weight:700;font-size:11.5px;color:#0F172A;">${esc(t.forCustomer)}</div>
          <div style="height:32px;"></div>
          <div style="display:flex;justify-content:space-between;align-items:flex-end;border-top:1px solid #CBD5E1;padding-top:4px;">
            <div style="font-size:10px;color:#64748B;">${esc(t.signature)}</div>
            <div style="font-size:10px;color:#64748B;">${esc(t.dateLabel)}</div>
          </div>
        </div>
      </div>
    </div>
  </div>`;
}

function labourBillHtml(bill, business, options = {}) {
  const pageSizeId = options.pageSize || business?.pageSize || 'a4';
  const sizeConfig = pageSizes.find(x => x.id === pageSizeId) || pageSizes[0];
  const lang = options.language || bill?.language || 'en';
  return `<!doctype html><html lang="${esc(lang)}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(bill?.number || 'TB-LAB-0001')}</title><style>${sizeConfig.rule}
*{box-sizing:border-box}
body{font:12.5px 'Segoe UI',Inter,Arial,'Noto Sans Telugu','Noto Sans Devanagari',sans-serif;color:#0F172A;margin:0;background:white;padding:${pageSizeId === 'thermal' ? '10px' : '24px'};-webkit-font-smoothing:antialiased}
@media print{.no-print{display:none}}
</style></head><body>
${renderLabourBillContent(bill, business, options)}
</body></html>`;
}

module.exports={services,catalogue,districts,units,calcLine,totals,emptyWorkspace,dict,documentHtml,money,round,nonneg,esc,documentTemplates,pageSizes,generateBrandMonogramSvg,numberToIndianWords,resolveTemplate,renderAgreementContent,agreementHtml,defaultTradeMaterials,renderMaterialListContent,materialListHtml,renderLabourBillContent,labourBillHtml,computeUnitSummary,computeTaxDetails,formatItemSubtitle};

