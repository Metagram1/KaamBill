import React,{useState} from 'react';
import {View,Pressable,ScrollView} from 'react-native';
import {T,I,Button,Field,Select,Sheet,Badge,Card,Fade,TradeBanner,s,C} from './ui';
import {profiles} from './service.cjs';
import {services,units,calcLine,totals,money,documentTemplates,pageSizes} from './domain.cjs';
import CustomerModal from './CustomerModal';
import DocumentSetupModal from './DocumentSetupModal';
export { DocumentSetupModal };
export const localDate=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2);
const isIsoDate=v=>/^\d{4}-\d{2}-\d{2}$/.test(String(v||''))&&Number.isFinite(Date.parse(v))&&new Date(v).toISOString().slice(0,10)===v;

export function Pair({children}){
 return <View style={{flexDirection:'row',gap:10,alignItems:'flex-start'}}>{React.Children.map(children,x=>x?<View style={{flex:1,minWidth:0}}>{x}</View>:null)}</View>;
}

export function EntityForm({type,initial={},w,service,onClose,onSave,busy}){
 const balance=Math.max(0,(initial.total||0)-(initial.paid||0));
 const defaults={
  customer:{name:'',phone:'',address:'',notes:''},
  project:{name:'',customerId:w.customers[0]?.id,service,address:'',budget:'',progress:'0',status:'In progress',dueDate:''},
  worker:{name:'',phone:'',role:'Skilled worker',dailyRate:'',service,projectId:''},
  payment:{docId:initial.id,date:localDate(),amount:String(balance),method:'UPI',note:''},
  attendance:{workerId:initial.id,date:localDate(),status:'present',projectId:initial.projectId||''},
  payout:{workerId:initial.id,date:localDate(),amount:String((initial.dailyRate||0)*(w.attendance.find(a=>a.workerId===initial.id&&a.date===localDate())?.status==='half'?.5:w.attendance.find(a=>a.workerId===initial.id&&a.date===localDate())?.status==='present'?1:0)),method:'Cash',note:''},
  feedback:{customerId:w.customers[0]?.id,rating:5,message:''},
  rate:{name:'',service,unit:'sq.ft',mode:'area',rate:'',basis:'Labour only'}
 };
 const [f,setF]=useState({...defaults[type],...(['customer','project','worker','rate'].includes(type)?initial:{})});
 const [tried,setTried]=useState(false);
 const put=(k,v)=>setF(x=>({...x,[k]:v}));

 const errors={};
 if(['customer','project','worker','rate'].includes(type)&&!String(f.name||'').trim())errors.name=(type==='project'?'Project name':'Name')+' is required';
 if(type==='project'){
  if(!f.customerId)errors.customerId='Select a customer';
  if(f.budget!==''&&(Number.isNaN(Number(f.budget))||Number(f.budget)<0))errors.budget='Enter a valid amount';
  if(f.progress!==''&&(Number.isNaN(Number(f.progress))||Number(f.progress)<0||Number(f.progress)>100))errors.progress='Enter 0–100%';
  if(f.dueDate&&!isIsoDate(f.dueDate))errors.dueDate='Use YYYY-MM-DD';
 }
 if(type==='worker'&&(f.dailyRate===''||Number.isNaN(Number(f.dailyRate))||Number(f.dailyRate)<0))errors.dailyRate='Enter a valid daily wage';
 if(['payment','payout','attendance'].includes(type)&&!isIsoDate(f.date))errors.date='Use YYYY-MM-DD';
 if(type==='payment'){
  const amt=Number(f.amount);
  if(!Number.isFinite(amt)||amt<=0)errors.amount='Enter a positive amount';
  else if(balance>0&&amt>balance+0.005)errors.amount='Exceeds balance ('+money(balance)+')';
 }
 if(type==='payout'){
  const amt=Number(f.amount);
  if(!Number.isFinite(amt)||amt<=0)errors.amount='Enter a positive payout';
 }
 if(type==='rate'&&(f.rate===''||Number.isNaN(Number(f.rate))||Number(f.rate)<0))errors.rate='Enter a valid rate';

 const field=(key,label,props={})=><Field key={key} label={label} value={f[key]} onChange={v=>put(key,v)} error={tried?errors[key]:undefined} {...props}/>;
 const select=(key,label,options)=><Select key={key} label={label} value={f[key]} onChange={v=>put(key,v)} options={options} error={tried?errors[key]:undefined}/>;
 const submit=()=>{
  if(busy)return;
  setTried(true);
  if(Object.keys(errors).length)return;
  onSave(type,f);
 };

 return <Sheet
  title={{customer:'Customer details',project:'Project details',worker:'Team member',payment:'Record payment',attendance:'Mark attendance',payout:'Labour payout',feedback:'Customer feedback',rate:'Rate catalogue item'}[type]}
  subtitle={['attendance','payout'].includes(type)?initial.name:type==='payment'?(initial.number?initial.number+' · Balance '+money(balance):'Record customer payment'):undefined}
  onClose={onClose}
  footer={<Button disabled={busy} onPress={submit} icon="checkmark">{busy?'Saving…':'Save details'}</Button>}
 >
  {['customer','project','worker','rate'].includes(type)&&field('name',type==='project'?'Project name':'Name')}
  {['customer','worker'].includes(type)&&field('phone','Phone number',{numeric:true})}
  {type==='customer'&&<>{field('address','Address',{multiline:true})}{field('notes','Notes (optional)',{multiline:true})}</>}
  {type==='project'&&<>
   {select('customerId','Customer',w.customers.map(c=>({value:c.id,label:c.name})))}
   {field('address','Site address',{multiline:true})}
   <Pair>{field('budget','Budget (₹)',{numeric:true})}{field('progress','Completed (%)',{numeric:true})}</Pair>
   <Pair>{select('status','Status',['In progress','Planning','On hold','Completed'])}{field('dueDate','Target date',{placeholder:'YYYY-MM-DD'})}</Pair>
  </>}
  {type==='worker'&&<>
   <Pair>{field('role','Trade / role')}{field('dailyRate','Daily wage (₹)',{numeric:true})}</Pair>
   {select('projectId','Assigned project',[{value:'',label:'Unassigned'},...w.projects.map(p=>({value:p.id,label:p.name}))])}
  </>}
  {['payment','payout','attendance'].includes(type)&&field('date','Date (YYYY-MM-DD)')}
  {['payment','payout'].includes(type)&&<>
   <Pair>{field('amount','Amount (₹)',{numeric:true})}{select('method','Payment method',['Cash','UPI','Bank transfer','Cheque'])}</Pair>
   {field('note','Reference / note (optional)')}
   {type==='payout'&&<T style={s.muted}>Suggested amount uses today’s attendance. One payout per worker per date.</T>}
  </>}
  {type==='attendance'&&<>
   <Pair>{select('status','Attendance',['present','half','absent','leave'])}{select('projectId','Work site',[{value:'',label:'Unassigned'},...w.projects.map(p=>({value:p.id,label:p.name}))])}</Pair>
  </>}
  {type==='feedback'&&<>
   <Pair>{select('customerId','Customer',w.customers.map(c=>({value:c.id,label:c.name})))}{select('rating','Rating',[1,2,3,4,5].map(n=>({value:n,label:'★'.repeat(n)+' · '+n+'/5'})))}</Pair>
   {field('message','Customer comments',{multiline:true})}
   <T style={s.muted}>Labelled “Recorded by contractor”. Share a bill link for direct customer feedback.</T>
  </>}
  {type==='rate'&&<>
   <Pair>{select('mode','Measurement',['qty','area','length','volume'])}{select('unit','Billing unit',units)}</Pair>
   <Pair>{field('rate','Agreed rate (₹)',{numeric:true})}{select('basis','Price includes',['Labour only','Material only','Labour + material','Supply + delivery'])}</Pair>
   <T style={s.muted}>Set your market rate and confirm scope with your customer.</T>
  </>}
 </Sheet>;
}

const standardTerms={
 en:'Work will be carried out as per the agreed specification. Final billing is based on jointly verified site measurements. Any additional work requires customer approval.',
 te:'అంగీకరించిన వివరాల ప్రకారం పని పూర్తి చేస్తాము. ఇరువురు ధృవీకరించిన సైట్ కొలతల ఆధారంగా తుది బిల్లు తయారు చేస్తాము. అదనపు పనులకు కస్టమర్ అనుమతి అవసరం.',
 hi:'काम सहमत विवरण के अनुसार होगा। अंतिम बिल दोनों पक्षों द्वारा सत्यापित साइट माप पर आधारित होगा। अतिरिक्त काम के लिए ग्राहक की अनुमति आवश्यक है।'
};

function SectionHeader({title,subtitle,action}){
 return <View style={[s.row,{justifyContent:'space-between',marginTop:10,marginBottom:8,flexWrap:'nowrap'}]}>
  <View style={{flex:1,minWidth:0}}>
   <T style={s.h2}>{title}</T>
   {!!subtitle&&<T style={{fontSize:12,color:C.muted,marginTop:1}}>{subtitle}</T>}
  </View>
  {action}
 </View>;
}

function Summary({total}){
 return <Card style={{backgroundColor:'#F8FAFF',borderColor:'#DCE5F7',marginTop:12,padding:12}}>
  {[['Subtotal',total.subtotal],['Discount',-(total.discount||0)],['Tax ('+(total.taxPercent||0)+'%)',total.tax]].map(([label,amount])=>(
   <View key={label} style={[s.row,{justifyContent:'space-between',marginBottom:6}]}>
    <T style={s.muted}>{label}</T>
    <T style={{fontSize:14,fontWeight:'500'}}>{money(amount||0)}</T>
   </View>
  ))}
  <View style={[s.row,{justifyContent:'space-between',paddingTop:8,marginTop:2,borderTopWidth:1,borderColor:C.line}]}>
   <T style={{fontWeight:'600',color:C.ink,fontSize:15}}>Grand total</T>
   <T style={{fontWeight:'600',color:C.blue,fontSize:18}}>{money(total.total||0)}</T>
  </View>
  {!!total.retention&&<T style={[s.muted,{marginTop:6,fontSize:12}]}>Retention: {money(total.retention)} · Due now: {money(total.dueNow)}</T>}
 </Card>;
}

const cleanBasis=b=>['Labour only','Material only','Labour + material','Supply + delivery'].includes(b)?b:'Labour only';

export function DocumentForm(props) {
  return <DocumentSetupModal {...props} />;
}

function LineForm({initial,rates=[],onClose,onSave}){
 const [f,setF]=useState({...initial,basis:cleanBasis(initial.basis)});
 const [details,setDetails]=useState(!!initial.note||!!initial.section);
 const [tried,setTried]=useState(false);
 const p=(k,v)=>setF(x=>({...x,[k]:v}));
 const measure=f.mode!=='qty';

 let calculated,calcError;
 try{calculated=calcLine(f)}catch(e){calcError=e.message}

 const nameErr=!String(f.name||'').trim()?'Enter item or service name':undefined;
 const qtyErr=Number.isNaN(Number(f.qty))||Number(f.qty)<=0?'Enter quantity > 0':undefined;
 const rateErr=f.rate===''||Number.isNaN(Number(f.rate))||Number(f.rate)<0?'Enter valid rate':undefined;
 const lenErr=measure&&(Number.isNaN(Number(f.length))||Number(f.length)<=0)?'Enter length > 0':undefined;
 const widErr=measure&&['area','volume'].includes(f.mode)&&(Number.isNaN(Number(f.width))||Number(f.width)<=0)?'Enter width > 0':undefined;
 const hgtErr=measure&&f.mode==='volume'&&(Number.isNaN(Number(f.height))||Number(f.height)<=0)?'Enter height > 0':undefined;

 const toggleMeasure=()=>{
  if(measure){
   setF(x=>({...x,mode:'qty',qty:String(calculated?.measuredQty||x.qty||'1'),deduction:'0'}));
  }else{
   const mode=f.measurementMode==='qty'?'area':f.measurementMode||'area';
   setF(x=>({...x,mode,qty:x.qty||'1',length:x.length||'10',width:x.width||'10',height:x.height||(mode==='volume'?'1':''),unit:{area:'sq.ft',length:'r.ft',volume:'cu.ft'}[mode]}));
  }
 };

 const submit=()=>{
  setTried(true);
  if(nameErr||!calculated)return;
  onSave(calculated);
 };

 return <Card style={{borderColor:C.blue,borderWidth:1.5,padding:13,marginBottom:12,backgroundColor:'white'}}>
  <View style={[s.row,{justifyContent:'space-between',marginBottom:10,flexWrap:'nowrap'}]}>
   <View style={{flex:1}}>
    <T style={s.h2}>{initial.name?'Edit item':'Add item'}</T>
    <T style={{fontSize:12,color:C.muted}}>Enter quantity × rate, or open calculator</T>
   </View>
   <Button quiet compact icon="close" onPress={onClose}>Cancel</Button>
  </View>

  {!initial.name&&rates.length>0&&<ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginBottom:10}}>
   <View style={{flexDirection:'row',gap:6}}>
    {rates.slice(0,6).map(r=>(
     <Pressable key={r.id} accessibilityRole="button" onPress={()=>setF(x=>({...x,catalogueId:r.id,name:r.name,unit:r.unit,rate:String(r.rate),measurementMode:r.mode}))} style={{paddingHorizontal:10,paddingVertical:6,borderRadius:16,backgroundColor:f.name===r.name?'#EEF3FF':'#F3F6FB',borderWidth:1,borderColor:f.name===r.name?C.blue:C.line}}>
      <T style={{fontSize:12,fontWeight:'500',color:f.name===r.name?C.blue:C.ink}}>{r.name} · ₹{r.rate}/{r.unit}</T>
     </Pressable>
    ))}
   </View>
  </ScrollView>}

  <Field label="Item / service name" placeholder="e.g. Floor tile laying" value={f.name} onChange={v=>p('name',v)} error={tried?nameErr:undefined}/>

  <Pair>
   <Field numeric label={measure?'Count / sets':'Quantity'} value={f.qty} onChange={v=>p('qty',v)} error={tried?qtyErr:undefined}/>
   <Select label="Unit" value={f.unit} onChange={v=>p('unit',v)} options={measure?{area:['sq.ft','sq.m'],length:['r.ft','m'],volume:['cu.ft','cu.m']}[f.mode]:units}/>
  </Pair>

  <Pair>
   <Field numeric label={'Rate per '+f.unit+' (₹)'} value={f.rate} onChange={v=>p('rate',v)} error={tried?rateErr:undefined}/>
   <Select label="Price includes" value={f.basis} onChange={v=>p('basis',v)} options={['Labour only','Material only','Labour + material','Supply + delivery']}/>
  </Pair>

  <View style={{flexDirection:'row',gap:8,marginBottom:10}}>
   <Button secondary compact icon="calculator-outline" style={{flex:1}} onPress={toggleMeasure}>
    {measure?'Use direct quantity':'Measurement calculator'}
   </Button>
   <Button secondary compact icon={details?'chevron-up':'add'} onPress={()=>setDetails(!details)}>
    {details?'Hide room/notes':'Room & notes'}
   </Button>
  </View>

  {measure&&<View style={{backgroundColor:'#F8FAFC',borderWidth:1,borderColor:'#CBD5E1',borderRadius:10,padding:11,marginBottom:12}}>
   <View style={{backgroundColor:'#EEF2F6',borderRadius:6,paddingHorizontal:9,paddingVertical:5,marginBottom:8,flexDirection:'row',alignItems:'center',gap:6}}>
    <I name="calculator-outline" size={14} color={C.blue}/>
    <T style={{fontSize:11.5,fontWeight:'600',color:'#334155'}}>
     {f.mode==='area'?'Formula: Length × Width − Deduction = Net Area':f.mode==='volume'?'Formula: Length × Width × Height = Volume (÷100 = Brass)':'Formula: Length − Deduction = Running Length'}
    </T>
   </View>
   <Pair>
    <Select
     label="Method"
     value={f.mode}
     onChange={v=>{p('mode',v);p('unit',{area:'sq.ft',length:'r.ft',volume:'cu.ft'}[v])}}
     options={[{value:'area',label:'Area (L × W)'},{value:'length',label:'Length (L)'},{value:'volume',label:'Volume (L × W × H)'}]}
    />
    <Select label="Dimension unit" value={f.dimensionUnit} onChange={v=>p('dimensionUnit',v)} options={[{value:'ft',label:'Feet (ft)'},{value:'in',label:'Inches (in)'},{value:'m',label:'Metres (m)'}]}/>
   </Pair>
   <Pair>
    <Field numeric label={'Length ('+f.dimensionUnit+')'} value={f.length} onChange={v=>p('length',v)} error={tried?lenErr:undefined}/>
    {['area','volume'].includes(f.mode)?<Field numeric label={'Width ('+f.dimensionUnit+')'} value={f.width} onChange={v=>p('width',v)} error={tried?widErr:undefined}/>:<Field numeric label={'Deduction ('+f.unit+')'} value={f.deduction} onChange={v=>p('deduction',v)}/>}
   </Pair>
   {['area','volume'].includes(f.mode)&&<Pair>
    {f.mode==='volume'&&<Field numeric label={'Height ('+f.dimensionUnit+')'} value={f.height} onChange={v=>p('height',v)} error={tried?hgtErr:undefined}/>}
    <Field numeric label={'Deduction ('+f.unit+')'} value={f.deduction} onChange={v=>p('deduction',v)}/>
   </Pair>}
   {f.mode==='volume'&&calculated&&<View style={{backgroundColor:'#FEF3C7',paddingHorizontal:8,paddingVertical:4,borderRadius:6,marginTop:4,alignSelf:'flex-start'}}>
    <T style={{fontSize:11,fontWeight:'600',color:'#92400E'}}>≈ {(calculated.measuredQty/100).toFixed(2)} Brass (100 cu.ft = 1 Brass)</T>
   </View>}
  </View>}

  {details&&<View style={{marginBottom:8}}>
   <Field label="Room / floor / section" placeholder="e.g. Ground floor hall" value={f.section} onChange={v=>p('section',v)}/>
   <Field label="Brand / specification / notes" multiline value={f.note} onChange={v=>p('note',v)}/>
  </View>}

  <View style={{backgroundColor:'#EFF6FF',borderRadius:8,paddingHorizontal:12,paddingVertical:9,marginBottom:12,flexDirection:'row',alignItems:'center',justifyContent:'space-between',borderWidth:1,borderColor:'#DBEAFE'}}>
   <View style={{flex:1,minWidth:0}}>
    <T style={{fontSize:11.5,color:C.muted}}>Calculated net item amount</T>
    <T numberOfLines={1} style={{fontSize:13,fontWeight:'600',color:calculated?C.ink:C.red,marginTop:1}}>
     {calculated?`${calculated.measuredQty} ${f.unit}${f.mode==='volume'?' ('+(calculated.measuredQty/100).toFixed(2)+' Brass)':''} × ${money(f.rate)}`:(calcError||'Enter valid quantity & rate')}
    </T>
   </View>
   <T style={{fontSize:17,fontWeight:'700',color:C.blue}}>{calculated?money(calculated.amount):'—'}</T>
  </View>

  <View style={{flexDirection:'row',gap:8}}>
   <Button secondary onPress={onClose} style={{flex:1}}>Cancel</Button>
   <Button icon="checkmark" onPress={submit} style={{flex:2}}>Save item</Button>
  </View>
 </Card>;
}

