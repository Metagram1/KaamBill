// TileBill PRO - Unified Service Measurement Engine
// Provides service-specific schemas, field validation, safe decimal calculations, room management & bill adapters

export const MEASURE_SERVICES = {
  tiles: {
    id: 'tiles',
    areaTerm: { en: 'Room', te: 'గది', hi: 'कमरा' },
    workTypes: [
      {
        id: 'floor',
        name: { en: 'Floor', te: 'నేల', hi: 'फ़्लोर' },
        fullName: { en: 'Floor Tiles', te: 'నేల టైల్స్', hi: 'फ़्लोर टाइल्स' },
        iconType: 'floor',
        mode: 'area',
        defaultUnit: 'sq.ft',
        dimensionUnit: 'ft',
        defaultRate: 45,
        fields: ['length', 'width', 'deduction', 'rate']
      },
      {
        id: 'wall',
        name: { en: 'Wall', te: 'గోడ', hi: 'दीवार' },
        fullName: { en: 'Wall Tiles', te: 'వాల్ టైల్స్', hi: 'दीवार टाइल्स' },
        iconType: 'wall',
        mode: 'area',
        defaultUnit: 'sq.ft',
        dimensionUnit: 'ft',
        defaultRate: 55,
        fields: ['length', 'height', 'deduction', 'rate']
      },
      {
        id: 'skirting',
        name: { en: 'Skirting', te: 'స్కిర్టింగ్', hi: 'स्कर्टिंग' },
        fullName: { en: 'Skirting Tiles', te: 'స్కిర్టింగ్', hi: 'स्कर्टिंग' },
        iconType: 'skirting',
        mode: 'length',
        defaultUnit: 'r.ft',
        dimensionUnit: 'ft',
        defaultRate: 35,
        fields: ['length', 'deduction', 'rate']
      }
    ]
  },

  construction: {
    id: 'construction',
    areaTerm: { en: 'Area / Stage', te: 'ప్రాంతం / దశ', hi: 'क्षेत्र / चरण' },
    workTypes: [
      {
        id: 'brickwork',
        name: { en: 'Brickwork', te: 'ఇటుక పని', hi: 'ईंट का काम' },
        fullName: { en: 'Brick Masonry', te: 'ఇటుక గోడ పని', hi: 'ईंट की दीवार' },
        iconType: 'wall',
        mode: 'volume',
        defaultUnit: 'cu.ft',
        dimensionUnit: 'ft',
        defaultRate: 35,
        fields: ['length', 'height', 'depth', 'deduction', 'rate']
      },
      {
        id: 'plastering',
        name: { en: 'Plastering', te: 'ప్లాస్టరింగ్', hi: 'प्लास्टर' },
        fullName: { en: 'Wall Plastering', te: 'ప్లాస్టరింగ్ పని', hi: 'दीवार प्लास्टर' },
        iconType: 'wall',
        mode: 'area',
        defaultUnit: 'sq.ft',
        dimensionUnit: 'ft',
        defaultRate: 28,
        fields: ['length', 'height', 'deduction', 'rate']
      },
      {
        id: 'concrete',
        name: { en: 'Concrete', te: 'కాంక్రీట్', hi: 'कंक्रीट' },
        fullName: { en: 'RCC Concrete Work', te: 'కాంక్రీట్ వేత', hi: 'आरसीसी कंक्रीट' },
        iconType: 'floor',
        mode: 'volume',
        defaultUnit: 'cu.m',
        dimensionUnit: 'm',
        defaultRate: 6500,
        fields: ['length', 'width', 'depth', 'rate']
      },
      {
        id: 'shuttering',
        name: { en: 'Centring', te: 'సెంట్రింగ్', hi: 'शटरिंग' },
        fullName: { en: 'Slab Shuttering', te: 'స్లాబ్ సెంట్రింగ్', hi: 'स्लैब शटरिंग' },
        iconType: 'floor',
        mode: 'area',
        defaultUnit: 'sq.ft',
        dimensionUnit: 'ft',
        defaultRate: 45,
        fields: ['length', 'width', 'rate']
      }
    ]
  },

  plumbing: {
    id: 'plumbing',
    areaTerm: { en: 'Room / Line', te: 'గది / లైన్', hi: 'कमरा / लाइन' },
    workTypes: [
      {
        id: 'pipe',
        name: { en: 'Pipe Route', te: 'పైప్ లైన్', hi: 'पाइप लाइन' },
        fullName: { en: 'Water Pipe Run', te: 'నీటి పైప్ లైన్', hi: 'पानी का पाइप' },
        iconType: 'pipe',
        mode: 'length',
        defaultUnit: 'm',
        dimensionUnit: 'm',
        defaultRate: 100,
        fields: ['length', 'rate']
      },
      {
        id: 'fittings',
        name: { en: 'Fittings', te: 'ఫిట్టింగ్స్', hi: 'फिटिंग्स' },
        fullName: { en: 'Pipe Fittings & Valves', te: 'వాల్వ్స్ & ఫిట్టింగ్స్', hi: 'वाल्व व फिटिंग्स' },
        iconType: 'points',
        mode: 'qty',
        defaultUnit: 'no',
        defaultRate: 150,
        fields: ['qty', 'rate']
      },
      {
        id: 'sanitary',
        name: { en: 'Sanitary Points', te: 'శానిటరీ పాయింట్స్', hi: 'सैनिटरी पॉइंट' },
        fullName: { en: 'Sanitary Points', te: 'శానిటరీ పాయింట్స్', hi: 'सैनिटरी पॉइंट' },
        iconType: 'points',
        mode: 'qty',
        defaultUnit: 'point',
        defaultRate: 850,
        fields: ['qty', 'rate']
      },
      {
        id: 'fixtures',
        name: { en: 'Fixtures', te: 'నల్లా & బేసిన్', hi: 'नल व बेसिन' },
        fullName: { en: 'WC & Basin Installation', te: 'డబ్ల్యూసీ & వాష్ బేసిన్', hi: 'बेसिन व शौचालय' },
        iconType: 'points',
        mode: 'qty',
        defaultUnit: 'no',
        defaultRate: 800,
        fields: ['qty', 'rate']
      }
    ]
  },

  electrical: {
    id: 'electrical',
    areaTerm: { en: 'Room / Circuit', te: 'గది / సర్క్యూట్', hi: 'कमरा / सर्किट' },
    workTypes: [
      {
        id: 'wiring',
        name: { en: 'Wiring Points', te: 'వైరింగ్ పాయింట్లు', hi: 'वायरिंग पॉइंट्स' },
        fullName: { en: 'Electrical Points', te: 'వైరింగ్ పాయింట్లు', hi: 'वायरिंग पॉइंट' },
        iconType: 'points',
        mode: 'qty',
        defaultUnit: 'point',
        defaultRate: 350,
        fields: ['qty', 'rate']
      },
      {
        id: 'cable',
        name: { en: 'Cable Run', te: 'కేబుల్ లైన్', hi: 'केबल लाइन' },
        fullName: { en: 'Main Cable Laying', te: 'మెయిన్ కేబుల్ లైన్', hi: 'मेन केबल' },
        iconType: 'pipe',
        mode: 'length',
        defaultUnit: 'm',
        dimensionUnit: 'm',
        defaultRate: 40,
        fields: ['length', 'rate']
      },
      {
        id: 'fixtures',
        name: { en: 'Lights & Fans', te: 'లైట్లు & ఫ్యాన్లు', hi: 'लाइट व पंखे' },
        fullName: { en: 'Fixture Installation', te: 'లైట్లు & ఫ్యాన్ల అమరిక', hi: 'लाइट पंखे लगाना' },
        iconType: 'points',
        mode: 'qty',
        defaultUnit: 'no',
        defaultRate: 180,
        fields: ['qty', 'rate']
      },
      {
        id: 'panel',
        name: { en: 'Distribution Board', te: 'డిస్ట్రిబ్యూషన్ బోర్డ్', hi: 'डिस्ट्रिब्यूशन बोर्ड' },
        fullName: { en: 'MCB / Panel Board', te: 'మెయిన్ బోర్డ్ / ఎంసీబీ', hi: 'एमसीबी पैनल' },
        iconType: 'wall',
        mode: 'qty',
        defaultUnit: 'no',
        defaultRate: 2500,
        fields: ['qty', 'rate']
      }
    ]
  },

  cement: {
    id: 'cement',
    areaTerm: { en: 'Delivery / Batch', te: 'డెలివరీ / బ్యాచ్', hi: 'डिलीवरी / बैच' },
    workTypes: [
      {
        id: 'bags',
        name: { en: 'Cement Bags', te: 'సిమెంట్ బస్తాలు', hi: 'सीमेंट बैग' },
        fullName: { en: '50kg Cement Bags', te: '50 కేజీల సిమెంట్ బస్తాలు', hi: '50 किलो सीमेंट बैग' },
        iconType: 'points',
        mode: 'qty',
        defaultUnit: 'bag',
        defaultRate: 350,
        fields: ['qty', 'rate']
      },
      {
        id: 'sand',
        name: { en: 'Sand Supply', te: 'ఇసుక సరఫరా', hi: 'रेत आपूर्ति' },
        fullName: { en: 'River Sand / M-Sand', te: 'ఇసుక సరఫరా (cu.ft)', hi: 'रेत आपूर्ति' },
        iconType: 'floor',
        mode: 'qty',
        defaultUnit: 'cu.ft',
        defaultRate: 55,
        fields: ['qty', 'rate']
      },
      {
        id: 'aggregate',
        name: { en: 'Aggregates', te: 'కంకర సరఫరా', hi: 'गिट्टी आपूर्ति' },
        fullName: { en: 'Crushed Stone / Aggregate', te: 'కంకర (టన్నుల్లో)', hi: 'गिट्टी' },
        iconType: 'points',
        mode: 'qty',
        defaultUnit: 'tonne',
        defaultRate: 1200,
        fields: ['qty', 'rate']
      },
      {
        id: 'steel_tmt',
        name: { en: 'TMT Steel', te: 'టీఎంటీ స్టీల్', hi: 'टीएमटी स्टील' },
        fullName: { en: 'TMT Steel Rebars', te: 'టీఎంటీ స్టీల్ (కేజీల్లో)', hi: 'टीएमटी सरिया' },
        iconType: 'pipe',
        mode: 'qty',
        defaultUnit: 'kg',
        defaultRate: 65,
        fields: ['qty', 'rate']
      }
    ]
  },

  painting: {
    id: 'painting',
    areaTerm: { en: 'Room / Section', te: 'గది / విభాగం', hi: 'कमरा / सेक्शन' },
    workTypes: [
      {
        id: 'wall_paint',
        name: { en: 'Wall Paint', te: 'గోడల పెయింటింగ్', hi: 'दीवार पेंटिंग' },
        fullName: { en: 'Interior Wall Painting', te: 'లోపలి గోడల పెయింట్', hi: 'दीवार पेंटिंग' },
        iconType: 'wall',
        mode: 'area',
        defaultUnit: 'sq.ft',
        dimensionUnit: 'ft',
        defaultRate: 18,
        fields: ['length', 'height', 'deduction', 'rate']
      },
      {
        id: 'ceiling_paint',
        name: { en: 'Ceiling', te: 'సీలింగ్ పెయింట్', hi: 'छत पेंट' },
        fullName: { en: 'Ceiling Painting', te: 'సీలింగ్ పెయింటింగ్', hi: 'छत पेंटिंग' },
        iconType: 'floor',
        mode: 'area',
        defaultUnit: 'sq.ft',
        dimensionUnit: 'ft',
        defaultRate: 16,
        fields: ['length', 'width', 'rate']
      },
      {
        id: 'putty',
        name: { en: 'Putty Coat', te: 'వాల్ పుట్టీ', hi: 'पुट्टी कोट' },
        fullName: { en: 'Wall Putty (2 Coats)', te: 'వాల్ పుట్టీ కోట్', hi: 'वॉल पुट्टी' },
        iconType: 'wall',
        mode: 'area',
        defaultUnit: 'sq.ft',
        dimensionUnit: 'ft',
        defaultRate: 14,
        fields: ['length', 'height', 'deduction', 'rate']
      }
    ]
  },

  carpentry: {
    id: 'carpentry',
    areaTerm: { en: 'Room / Unit', te: 'గది / యూనిట్', hi: 'कमरा / यूनिट' },
    workTypes: [
      {
        id: 'cabinet',
        name: { en: 'Cabinet / Cupboard', te: 'క్యాబినెట్ / బీరువా', hi: 'कैबिनेट / अलमारी' },
        fullName: { en: 'Modular Cabinet Face', te: 'క్యాబినెట్ తయారీ', hi: 'मॉड्यूलर कैबिनेट' },
        iconType: 'wall',
        mode: 'area',
        defaultUnit: 'sq.ft',
        dimensionUnit: 'ft',
        defaultRate: 1600,
        fields: ['width', 'height', 'rate']
      },
      {
        id: 'door',
        name: { en: 'Doors', te: 'తలుపుల అమరిక', hi: 'दरवाजा लगाना' },
        fullName: { en: 'Door & Frame Install', te: 'తలుపు & ఫ్రేమ్ పని', hi: 'दरवाजा व फ्रेम' },
        iconType: 'wall',
        mode: 'qty',
        defaultUnit: 'no',
        defaultRate: 1800,
        fields: ['qty', 'rate']
      },
      {
        id: 'trim',
        name: { en: 'Wood Trim', te: 'చెక్క ట్రిమ్', hi: 'लकड़ी ट्रिम' },
        fullName: { en: 'Moulding & Edge Trim', te: 'మోల్డింగ్ & ట్రిమ్', hi: 'मोल्डिंग ट्रिम' },
        iconType: 'skirting',
        mode: 'length',
        defaultUnit: 'r.ft',
        dimensionUnit: 'ft',
        defaultRate: 120,
        fields: ['length', 'rate']
      }
    ]
  },

  steel: {
    id: 'steel',
    areaTerm: { en: 'Structure / Item', te: 'స్ట్రక్చర్ / ఐటమ్', hi: 'संरचना / आइटम' },
    workTypes: [
      {
        id: 'weight_steel',
        name: { en: 'By Weight (kg)', te: 'బరువు ఆధారిత (కేజీ)', hi: 'वजन अनुसार (किग्रा)' },
        fullName: { en: 'MS Fabrication (Weight)', te: 'ఎంఎస్ స్టీల్ పని (కేజీల్లో)', hi: 'एमएस फैब्रिकेशन (किग्रा)' },
        iconType: 'points',
        mode: 'qty',
        defaultUnit: 'kg',
        defaultRate: 110,
        fields: ['qty', 'rate']
      },
      {
        id: 'grill_gate',
        name: { en: 'Grill / Gate', te: 'గ్రిల్ & గేటు', hi: 'ग्रिल व गेट' },
        fullName: { en: 'Window Grill / Main Gate', te: 'కిటికీ గ్రిల్ / గేట్', hi: 'खिड़की ग्रिल व गेट' },
        iconType: 'wall',
        mode: 'area',
        defaultUnit: 'sq.ft',
        dimensionUnit: 'ft',
        defaultRate: 450,
        fields: ['length', 'height', 'rate']
      },
      {
        id: 'welding_labour',
        name: { en: 'Welding Charge', te: 'వెల్డింగ్ కూలీ', hi: 'वेल्डिंग मजदूरी' },
        fullName: { en: 'Structural Welding Work', te: 'వెల్డింగ్ & లేబర్ చార్జ్', hi: 'वेल्डिंग लेबर' },
        iconType: 'points',
        mode: 'fixed',
        defaultUnit: 'job',
        defaultRate: 3000,
        fields: ['rate']
      }
    ]
  },

  roofing: {
    id: 'roofing',
    areaTerm: { en: 'Roof Section', te: 'రూఫ్ సెక్షన్', hi: 'छत अनुभाग' },
    workTypes: [
      {
        id: 'slope_roof',
        name: { en: 'Slope Roof Sheets', te: 'రూఫ్ షీట్లు', hi: 'रूफिंग शीट' },
        fullName: { en: 'Sloped Roof Surface', te: 'రూఫ్ షీట్ల విస్తీర్ణం', hi: 'छत की शीट' },
        iconType: 'floor',
        mode: 'area',
        defaultUnit: 'sq.ft',
        dimensionUnit: 'ft',
        defaultRate: 110,
        fields: ['length', 'width', 'rate']
      },
      {
        id: 'gutter',
        name: { en: 'Rain Gutter', te: 'వర్షపు నీటి గట్టర్', hi: 'वर्षा जल गटर' },
        fullName: { en: 'Rainwater Gutter Run', te: 'నీటి గట్టర్ & రిడ్జ్', hi: 'पानी का गटर' },
        iconType: 'skirting',
        mode: 'length',
        defaultUnit: 'r.ft',
        dimensionUnit: 'ft',
        defaultRate: 220,
        fields: ['length', 'rate']
      },
      {
        id: 'labour',
        name: { en: 'Fitting Labour', te: 'అమరిక కూలీ', hi: 'फिटिंग मजदूरी' },
        fullName: { en: 'Sheet Installation Labour', te: 'షీట్లు అమర్చే కూలీ', hi: 'शीट लगाने की मजदूरी' },
        iconType: 'floor',
        mode: 'area',
        defaultUnit: 'sq.ft',
        dimensionUnit: 'ft',
        defaultRate: 25,
        fields: ['length', 'width', 'rate']
      }
    ]
  },

  waterproofing: {
    id: 'waterproofing',
    areaTerm: { en: 'Area / Surface', te: 'ప్రాంతం / ఉపరితలం', hi: 'क्षेत्र / सतह' },
    workTypes: [
      {
        id: 'terrace',
        name: { en: 'Terrace Surface', te: 'టెర్రస్ వాటర్‌ప్రూఫింగ్', hi: 'छत वॉटरप्रूफिंग' },
        fullName: { en: 'Terrace Waterproofing', te: 'పైకప్పు వాటర్‌ప్రూఫింగ్', hi: 'छत वॉटरप्रूफिंग' },
        iconType: 'floor',
        mode: 'area',
        defaultUnit: 'sq.ft',
        dimensionUnit: 'ft',
        defaultRate: 65,
        fields: ['length', 'width', 'deduction', 'rate']
      },
      {
        id: 'bathroom',
        name: { en: 'Bathroom Treatment', te: 'బాత్‌రూమ్ వాటర్‌ప్రూఫింగ్', hi: 'बाथरूम वॉटरप्रूफिंग' },
        fullName: { en: 'Bathroom Floor & Wall', te: 'బాత్‌రూమ్ కోటింగ్', hi: 'बाथरूम कोटिंग' },
        iconType: 'wall',
        mode: 'area',
        defaultUnit: 'sq.ft',
        dimensionUnit: 'ft',
        defaultRate: 80,
        fields: ['length', 'width', 'deduction', 'rate']
      },
      {
        id: 'crack',
        name: { en: 'Crack Treatment', te: 'పగుళ్ల మరమ్మత్తు', hi: 'दरार मरम्मत' },
        fullName: { en: 'Crack Sealing & Joint Tape', te: 'పగుళ్ల సీలింగ్ పని', hi: 'क्रैक सीलिंग' },
        iconType: 'skirting',
        mode: 'length',
        defaultUnit: 'r.ft',
        dimensionUnit: 'ft',
        defaultRate: 100,
        fields: ['length', 'rate']
      }
    ]
  },

  earthwork: {
    id: 'earthwork',
    areaTerm: { en: 'Pit / Trench / Area', te: 'గొయ్యి / ట్రెంచ్ / ఏరియా', hi: 'गड्ढा / खाई / क्षेत्र' },
    workTypes: [
      {
        id: 'excavation',
        name: { en: 'Excavation Pit', te: 'తవ్వకం (పిట్)', hi: 'खुदाई (गड्ढा)' },
        fullName: { en: 'Pit / Trench Excavation', te: 'పునాది తవ్వకం పని', hi: 'नींव खुदाई' },
        iconType: 'floor',
        mode: 'volume',
        defaultUnit: 'cu.m',
        dimensionUnit: 'm',
        defaultRate: 500,
        fields: ['length', 'width', 'depth', 'rate']
      },
      {
        id: 'filling',
        name: { en: 'Soil Filling', te: 'మట్టి నింపడం', hi: 'मिट्टी भरना' },
        fullName: { en: 'Earth Filling & Compaction', te: 'మట్టి నింపడం & లెవెలింగ్', hi: 'मिट्टी भरना' },
        iconType: 'floor',
        mode: 'volume',
        defaultUnit: 'cu.m',
        dimensionUnit: 'm',
        defaultRate: 450,
        fields: ['length', 'width', 'depth', 'rate']
      },
      {
        id: 'loads',
        name: { en: 'Truck Loads', te: 'ట్రాక్టర్ / లారీ ట్రిప్పులు', hi: 'ट्रक / ट्रैक्टर ट्रिप' },
        fullName: { en: 'Vehicle Load Quantity', te: 'ట్రిప్పుల సంఖ్య', hi: 'ट्रिप संख्या' },
        iconType: 'points',
        mode: 'qty',
        defaultUnit: 'no',
        defaultRate: 1200,
        fields: ['qty', 'rate']
      }
    ]
  },

  other: {
    id: 'other',
    areaTerm: { en: 'Area / Item', te: 'ప్రాంతం / ఐటమ్', hi: 'क्षेत्र / आइटम' },
    workTypes: [
      {
        id: 'area',
        name: { en: 'Area (L × W)', te: 'విస్తీర్ణం', hi: 'क्षेत्रफल' },
        fullName: { en: 'Area Based Work', te: 'విస్తీర్ణం పని', hi: 'क्षेत्रफल आधारित' },
        iconType: 'floor',
        mode: 'area',
        defaultUnit: 'sq.ft',
        dimensionUnit: 'ft',
        defaultRate: 50,
        fields: ['length', 'width', 'deduction', 'rate']
      },
      {
        id: 'length',
        name: { en: 'Running Length', te: 'పొడవు (రన్నింగ్)', hi: 'रनिंग लंबाई' },
        fullName: { en: 'Length Based Work', te: 'పొడవు పని', hi: 'लंबाई आधारित' },
        iconType: 'skirting',
        mode: 'length',
        defaultUnit: 'r.ft',
        dimensionUnit: 'ft',
        defaultRate: 40,
        fields: ['length', 'rate']
      },
      {
        id: 'volume',
        name: { en: 'Volume (L × W × D)', te: 'పరిమాణం (వాల్యూమ్)', hi: 'आयतन' },
        fullName: { en: 'Volume Based Work', te: 'పరిమాణం పని', hi: 'आयतन आधारित' },
        iconType: 'floor',
        mode: 'volume',
        defaultUnit: 'cu.ft',
        dimensionUnit: 'ft',
        defaultRate: 60,
        fields: ['length', 'width', 'depth', 'rate']
      },
      {
        id: 'qty',
        name: { en: 'Count / Pieces', te: 'సంఖ్య ఆధారిత', hi: 'संख्या आधारित' },
        fullName: { en: 'Quantity Based Work', te: 'సంఖ్య పని', hi: 'संख्या काम' },
        iconType: 'points',
        mode: 'qty',
        defaultUnit: 'no',
        defaultRate: 100,
        fields: ['qty', 'rate']
      }
    ]
  }
};

// Safe decimal rounding helper
export const round2 = n => Math.round((Number(n || 0) + Number.EPSILON) * 100) / 100;

// Metric conversion factors
const DIM_FACTORS = {
  ft: 0.3048,
  in: 0.0254,
  m: 1
};

export function calculateMeasurementItem(item) {
  const mode = item.mode || 'area';
  const dimUnit = item.dimensionUnit || 'ft';
  const unit = item.unit || (mode === 'area' ? 'sq.ft' : mode === 'length' ? 'r.ft' : mode === 'volume' ? 'cu.ft' : 'no');
  const count = Math.max(1, Math.floor(Number(item.count || 1)));
  const rate = Math.max(0, Number(item.rate || 0));
  const factor = DIM_FACTORS[dimUnit] || 0.3048;

  let grossQty = 0;

  if (mode === 'fixed') {
    grossQty = 1;
  } else if (mode === 'qty') {
    grossQty = Math.max(0, Number(item.qty || count));
  } else if (mode === 'length') {
    const rawLen = Math.max(0, Number(item.length || 0));
    const metres = rawLen * factor;
    grossQty = unit === 'r.ft' ? metres / 0.3048 : metres;
  } else if (mode === 'area') {
    const rawLen = Math.max(0, Number(item.length || 0));
    const rawWid = Math.max(0, Number(item.width || item.height || 0));
    const sqM = (rawLen * factor) * (rawWid * factor);
    grossQty = unit === 'sq.ft' ? sqM / 0.09290304 : sqM;
  } else if (mode === 'volume') {
    const rawLen = Math.max(0, Number(item.length || 0));
    const rawWid = Math.max(0, Number(item.width || 0));
    const rawHgt = Math.max(0, Number(item.height || item.depth || 0));
    const cuM = (rawLen * factor) * (rawWid * factor) * (rawHgt * factor);
    grossQty = unit === 'cu.ft' ? cuM / 0.028316846592 : cuM;
  }

  grossQty = round2(grossQty * count);

  const rawDeduct = Math.max(0, Number(item.deduction || 0));
  const deduction = Math.min(grossQty, rawDeduct);
  const netQty = round2(Math.max(0, grossQty - deduction));
  const amount = round2(netQty * rate);

  return {
    ...item,
    count,
    rate,
    grossQty,
    deduction: rawDeduct,
    netQty,
    amount,
    error: rawDeduct > grossQty ? 'Deduction exceeds gross quantity' : null
  };
}

export function getDefaultRoomsForService(serviceId, appLang = 'te') {
  const svc = MEASURE_SERVICES[serviceId] || MEASURE_SERVICES.tiles;
  const workTypes = svc.workTypes;
  const defaultWorkType = workTypes[0];

  if (serviceId === 'tiles') {
    return [
      {
        id: 'room-hall',
        name: appLang === 'te' ? 'హాల్' : appLang === 'hi' ? 'हॉल' : 'Hall',
        workType: 'floor',
        items: [
          {
            id: 'item-h1',
            workTypeId: 'floor',
            workTypeName: appLang === 'te' ? 'నేల టైల్స్' : appLang === 'hi' ? 'फ़्लोर टाइल्स' : 'Floor Tiles',
            mode: 'area',
            length: 12,
            width: 10,
            height: 0,
            depth: 0,
            count: 1,
            deduction: 0,
            rate: 45,
            unit: 'sq.ft',
            dimensionUnit: 'ft',
            customFields: [],
            grossQty: 120,
            netQty: 120,
            amount: 5400,
            saved: true
          }
        ]
      },
      {
        id: 'room-bed',
        name: appLang === 'te' ? 'బెడ్‌రూమ్' : appLang === 'hi' ? 'बेडरूम' : 'Bedroom',
        workType: 'floor',
        items: [
          {
            id: 'item-b1',
            workTypeId: 'floor',
            workTypeName: appLang === 'te' ? 'నేల టైల్స్' : appLang === 'hi' ? 'फ़्लोर टाइल्स' : 'Floor Tiles',
            mode: 'area',
            length: 10,
            width: 10,
            height: 0,
            depth: 0,
            count: 1,
            deduction: 0,
            rate: 45,
            unit: 'sq.ft',
            dimensionUnit: 'ft',
            customFields: [],
            grossQty: 100,
            netQty: 100,
            amount: 4500,
            saved: true
          }
        ]
      }
    ];
  }

  if (serviceId === 'electrical') {
    return [
      {
        id: 'room-bed',
        name: appLang === 'te' ? 'బెడ్‌రూమ్' : appLang === 'hi' ? 'बेडरूम' : 'Bedroom',
        workType: 'wiring',
        isMainSupply: false,
        points: { light: 4, fan: 1, socket: 3 },
        cableRoute: { length: 24, unit: 'm', route: 'DB to Bedroom switchboard', notes: '' },
        customItems: [],
        items: [
          calculateMeasurementItem({
            id: 'item-el-b1',
            workTypeId: 'wiring',
            workTypeName: appLang === 'te' ? 'బెడ్‌రూమ్ — లైట్ & పవర్ పాయింట్లు' : appLang === 'hi' ? 'बेडरूम — लाइट व पावर पॉइंट्स' : 'Bedroom — Light & Power Points',
            mode: 'qty',
            qty: 8,
            unit: 'point',
            rate: 650,
            saved: true
          }),
          calculateMeasurementItem({
            id: 'item-el-b2',
            workTypeId: 'cable',
            workTypeName: appLang === 'te' ? 'బెడ్‌రూమ్ — కేబుల్ రూట్' : appLang === 'hi' ? 'बेडरूम — केबल रूट' : 'Bedroom — Cable Route',
            mode: 'length',
            length: 24,
            unit: 'm',
            dimensionUnit: 'm',
            rate: 60,
            saved: true
          })
        ]
      },
      {
        id: 'room-kitchen',
        name: appLang === 'te' ? 'కిచెన్' : appLang === 'hi' ? 'रसोई' : 'Kitchen',
        workType: 'wiring',
        isMainSupply: false,
        points: { light: 2, fan: 0, socket: 4 },
        cableRoute: { length: 18, unit: 'm', route: 'DB to Kitchen power board', notes: '' },
        customItems: [],
        items: [
          calculateMeasurementItem({
            id: 'item-el-k1',
            workTypeId: 'wiring',
            workTypeName: appLang === 'te' ? 'కిచెన్ — పవర్ సాకెట్ పాయింట్లు' : appLang === 'hi' ? 'रसोई — पावर सॉकेट पॉइंट्स' : 'Kitchen — Power Socket Points',
            mode: 'qty',
            qty: 6,
            unit: 'point',
            rate: 650,
            saved: true
          }),
          calculateMeasurementItem({
            id: 'item-el-k2',
            workTypeId: 'cable',
            workTypeName: appLang === 'te' ? 'కిచెన్ — కేబుల్ రూట్' : appLang === 'hi' ? 'रसोई — केबल रूट' : 'Kitchen — Cable Route',
            mode: 'length',
            length: 18,
            unit: 'm',
            dimensionUnit: 'm',
            rate: 60,
            saved: true
          })
        ]
      },
      {
        id: 'room-main-supply',
        name: appLang === 'te' ? 'మెయిన్ సప్లై' : appLang === 'hi' ? 'मुख्य आपूर्ति' : 'Main supply',
        workType: 'cable',
        isMainSupply: true,
        points: { light: 0, fan: 0, socket: 0 },
        cableRoute: { length: 15, unit: 'm', route: 'Meter to DB main line', notes: 'Armoured 4-core cable' },
        customItems: [
          { id: 'ci-db', name: 'Distribution Board / MCB installation', qty: 1, unit: 'no', rate: 2500 }
        ],
        items: [
          calculateMeasurementItem({
            id: 'item-el-m1',
            workTypeId: 'cable',
            workTypeName: appLang === 'te' ? 'మెయిన్ సప్లై — కేబుల్ రూట్' : appLang === 'hi' ? 'मुख्य आपूर्ति — केबल रूट' : 'Main supply — Cable Route',
            mode: 'length',
            length: 15,
            unit: 'm',
            dimensionUnit: 'm',
            rate: 75,
            saved: true
          }),
          calculateMeasurementItem({
            id: 'item-el-m2',
            workTypeId: 'panel',
            workTypeName: appLang === 'te' ? 'మెయిన్ సప్లై — డిస్ట్రిబ్యూషన్ బోర్డ్' : appLang === 'hi' ? 'मुख्य आपूर्ति — डिस्ट्रिब्यूशन बोर्ड' : 'Main supply — Distribution Board',
            mode: 'qty',
            qty: 1,
            unit: 'no',
            rate: 2500,
            saved: true
          })
        ]
      }
    ];
  }

  // Generic fallback for other services
  const defaultName = svc.areaTerm[appLang] || svc.areaTerm.en;
  const initialItem = calculateMeasurementItem({
    id: 'item-1',
    workTypeId: defaultWorkType.id,
    workTypeName: defaultWorkType.name[appLang] || defaultWorkType.name.en,
    mode: defaultWorkType.mode,
    length: defaultWorkType.mode === 'volume' ? 5 : defaultWorkType.mode === 'qty' ? 0 : 10,
    width: defaultWorkType.mode === 'volume' ? 2 : defaultWorkType.mode === 'qty' ? 0 : 10,
    height: defaultWorkType.mode === 'volume' ? 1 : 0,
    depth: defaultWorkType.mode === 'volume' ? 1 : 0,
    qty: defaultWorkType.mode === 'qty' ? 5 : 1,
    count: 1,
    deduction: 0,
    rate: defaultWorkType.defaultRate,
    unit: defaultWorkType.defaultUnit,
    dimensionUnit: defaultWorkType.dimensionUnit || 'ft',
    customFields: [],
    saved: true
  });

  return [
    {
      id: 'area-1',
      name: defaultName + ' 1',
      workType: defaultWorkType.id,
      items: [initialItem]
    }
  ];
}

// Convert measurement items to structured Bill Lines for Invoice / Quotation
export function formatMeasurementBillLines(rooms, serviceId) {
  const lines = [];

  for (const r of rooms || []) {
    for (const item of r.items || []) {
      const calc = calculateMeasurementItem(item);
      if (calc.netQty <= 0 && calc.amount <= 0) continue;

      let dimSummary = '';
      if (calc.mode === 'area') {
        dimSummary = `${calc.length} × ${calc.width || calc.height} ${calc.dimensionUnit}`;
      } else if (calc.mode === 'length') {
        dimSummary = `${calc.length} ${calc.dimensionUnit} run`;
      } else if (calc.mode === 'volume') {
        dimSummary = `${calc.length} × ${calc.width} × ${calc.depth || calc.height} ${calc.dimensionUnit}`;
      } else if (calc.mode === 'qty') {
        dimSummary = `${calc.qty || calc.count} items`;
      }

      const customNote = (calc.customFields || [])
        .map(cf => `${cf.name}: ${cf.value}${cf.unit ? ' ' + cf.unit : ''}`)
        .join(', ');

      lines.push({
        id: 'meas-' + (item.id || Math.random().toString(36).slice(2, 9)),
        name: `${r.name} - ${calc.workTypeName || 'Work'}`,
        section: r.name,
        mode: calc.mode,
        length: calc.length,
        width: calc.width,
        height: calc.height || calc.depth,
        dimensionUnit: calc.dimensionUnit,
        deduction: calc.deduction,
        qty: calc.count,
        measuredQty: calc.netQty,
        unit: calc.unit,
        rate: calc.rate,
        amount: calc.amount,
        basis: 'Measurements verified',
        note: [dimSummary, customNote].filter(Boolean).join(' · ')
      });
    }
  }

  return lines;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    MEASURE_SERVICES,
    round2,
    calculateMeasurementItem,
    getDefaultRoomsForService,
    formatMeasurementBillLines
  };
}
