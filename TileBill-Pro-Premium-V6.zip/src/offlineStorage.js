import AsyncStorage from '@react-native-async-storage/async-storage';
import { calcLine, totals, round, nonneg, units } from './domain.cjs';
import { IS_OFFLINE_TEST_MODE } from './config';

export const STORAGE_KEY_USER = 'TB_CACHED_USER';
export const STORAGE_KEY_WORKSPACE = 'TB_CACHED_WORKSPACE';
export const STORAGE_KEY_SERVICE = 'TB_CACHED_SERVICE';
export const STORAGE_KEY_USER_ID = 'TB_CACHED_USER_ID';
export const STORAGE_KEY_SYNC_QUEUE = 'TB_OFFLINE_SYNC_QUEUE';

export async function hydrateOfflineState(expectedUserId = null) {
  try {
    const [userStr, wStr, serviceStr, cachedUserId] = await Promise.all([
      AsyncStorage.getItem(STORAGE_KEY_USER),
      AsyncStorage.getItem(STORAGE_KEY_WORKSPACE),
      AsyncStorage.getItem(STORAGE_KEY_SERVICE),
      AsyncStorage.getItem(STORAGE_KEY_USER_ID)
    ]);
    const user = userStr ? JSON.parse(userStr) : null;
    const workspace = wStr ? JSON.parse(wStr) : null;
    const service = serviceStr || null;

    // Account-specific data isolation: If expectedUserId is provided and doesn't match cached user, reject!
    if (expectedUserId && cachedUserId && expectedUserId !== cachedUserId) {
      console.warn('[OfflineStorage] Cached user ID mismatch! Clearing cached data to prevent data leakage.');
      await clearOfflineState();
      return { user: null, workspace: null, service: null };
    }

    return { user, workspace, service };
  } catch (err) {
    console.warn('Failed to hydrate offline state:', err);
    return { user: null, workspace: null, service: null };
  }
}

export async function persistOfflineUser(user) {
  if (!user) return;
  try {
    await Promise.all([
      AsyncStorage.setItem(STORAGE_KEY_USER, JSON.stringify(user)),
      user.id ? AsyncStorage.setItem(STORAGE_KEY_USER_ID, String(user.id)) : Promise.resolve()
    ]);
  } catch {}
}

export async function persistOfflineWorkspace(workspace) {
  if (!workspace) return;
  try {
    await AsyncStorage.setItem(STORAGE_KEY_WORKSPACE, JSON.stringify(workspace));
  } catch {}
}

export async function persistOfflineService(service) {
  try {
    if (service) await AsyncStorage.setItem(STORAGE_KEY_SERVICE, service);
    else await AsyncStorage.removeItem(STORAGE_KEY_SERVICE);
  } catch {}
}

export async function clearOfflineState() {
  try {
    await Promise.all([
      AsyncStorage.removeItem(STORAGE_KEY_USER),
      AsyncStorage.removeItem(STORAGE_KEY_WORKSPACE),
      AsyncStorage.removeItem(STORAGE_KEY_SERVICE),
      AsyncStorage.removeItem(STORAGE_KEY_USER_ID),
      AsyncStorage.removeItem(STORAGE_KEY_SYNC_QUEUE)
    ]);
  } catch {}
}

/**
 * Sync Queue Management for Reliable Offline Sync
 */
export async function getPendingSyncQueue() {
  try {
    const qStr = await AsyncStorage.getItem(STORAGE_KEY_SYNC_QUEUE);
    return qStr ? JSON.parse(qStr) : [];
  } catch {
    return [];
  }
}

export async function queueOfflineAction({ action, payload, service }) {
  try {
    const queue = await getPendingSyncQueue();
    const syncItem = {
      syncId: 'sync_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
      action,
      payload: JSON.parse(JSON.stringify(payload)),
      service,
      createdAt: Date.now(),
      attempts: 0
    };
    queue.push(syncItem);
    await AsyncStorage.setItem(STORAGE_KEY_SYNC_QUEUE, JSON.stringify(queue));
    return syncItem;
  } catch (err) {
    console.warn('[OfflineStorage] Failed to queue offline action:', err);
    return null;
  }
}

export async function removePendingSyncItem(syncId) {
  try {
    const queue = await getPendingSyncQueue();
    const updated = queue.filter(item => item.syncId !== syncId);
    await AsyncStorage.setItem(STORAGE_KEY_SYNC_QUEUE, JSON.stringify(updated));
  } catch {}
}

export async function clearPendingSyncQueue() {
  try {
    await AsyncStorage.removeItem(STORAGE_KEY_SYNC_QUEUE);
  } catch {}
}

export async function getPendingSyncCount() {
  const q = await getPendingSyncQueue();
  return q.length;
}

/**
 * Applies actions locally when device is disconnected from the server.
 * Guarantees zero data loss and uninterrupted invoice/agreement creation.
 */
export function handleOfflineAction(workspace, action, payload, service = 'tiles') {
  if (!workspace) return null;
  const w = JSON.parse(JSON.stringify(workspace)); // Deep clone
  const scope = service || w.business?.service || 'tiles';
  const prefix = (w.business?.prefix || 'TB').trim().toUpperCase() || 'TB';
  const nowIso = new Date().toISOString();
  const dateStr = nowIso.split('T')[0];

  switch (action) {
    case 'business': {
      w.business = { ...w.business, ...payload, service: scope };
      w.onboarded = true;
      break;
    }

    case 'customer': {
      const cId = payload.id || ('cust_offline_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6));
      payload.id = cId;
      const c = {
        id: cId,
        service: scope,
        name: (payload.name || 'Customer').trim(),
        phone: String(payload.phone || '').trim(),
        address: String(payload.address || '').trim(),
        siteLocation: String(payload.siteLocation || '').trim(),
        notes: String(payload.notes || '').trim()
      };
      if (!Array.isArray(w.customers)) w.customers = [];
      if (w.customers.some(x => x.id === cId)) {
        w.customers = w.customers.map(x => x.id === cId ? c : x);
      } else {
        w.customers = [c, ...w.customers];
      }
      break;
    }

    case 'document': {
      if (!Array.isArray(w.documents)) w.documents = [];
      if (payload.id && w.documents.some(x => x.id === payload.id)) {
        const d = w.documents.find(x => x.id === payload.id);
        if (payload.template) d.template = payload.template;
        if (payload.pageSize) d.pageSize = payload.pageSize;
        if (payload.language) d.language = payload.language;
        if (Array.isArray(payload.items) && payload.items.length > 0) {
          const items = payload.items.map(l => {
            const u = l.unit === 'rft' ? 'r.ft' : (l.unit === 'sqft' ? 'sq.ft' : (units.includes(l.unit) ? l.unit : 'sq.ft'));
            return calcLine({ ...l, unit: u });
          });
          d.items = items;
          Object.assign(d, totals(items, payload.discount || 0, payload.taxPercent || 0, payload.retentionPercent || 0));
        }
        if (payload.title) d.title = payload.title;
        if (payload.date) d.date = payload.date;
        if (payload.dueDate !== undefined) d.dueDate = payload.dueDate;
        if (payload.siteLocation !== undefined) d.siteLocation = payload.siteLocation;
        if (payload.terms !== undefined) d.terms = payload.terms;
        if (payload.exclusions !== undefined) d.exclusions = payload.exclusions;
        if (payload.milestones !== undefined) d.milestones = payload.milestones;
        if (payload.customer) d.customer = payload.customer;
        if (payload.projectId !== undefined) d.projectId = payload.projectId;
        if (payload.attachAgreement !== undefined) d.attachAgreement = Boolean(payload.attachAgreement);
        if (payload.agreement !== undefined) d.agreement = payload.agreement;
        break;
      }

      const nextNo = w.nextNo || 1;
      const docNo = `${prefix}-${String(nextNo).padStart(4, '0')}`;
      const c = (w.customers || []).find(x => x.id === payload.customerId) || payload.customer || { name: 'Customer' };
      const items = Array.isArray(payload.items) ? payload.items.map(l => {
        const u = l.unit === 'rft' ? 'r.ft' : (l.unit === 'sqft' ? 'sq.ft' : (units.includes(l.unit) ? l.unit : 'sq.ft'));
        return calcLine({ ...l, unit: u });
      }) : [];
      const calcResults = totals(items, payload.discount || 0, payload.taxPercent || 0, payload.retentionPercent || 0);

      const dId = payload.id || ('doc_offline_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6));
      payload.id = dId;
      payload.number = docNo;

      const d = {
        id: dId,
        number: docNo,
        kind: payload.kind === 'quotation' ? 'quotation' : 'invoice',
        service: payload.service || scope,
        language: ['en', 'te', 'hi'].includes(payload.language) ? payload.language : 'en',
        date: payload.date || dateStr,
        dueDate: payload.dueDate || '',
        customer: JSON.parse(JSON.stringify(c)),
        projectId: payload.projectId || null,
        siteLocation: payload.siteLocation || c.siteLocation || '',
        title: payload.title || (payload.kind === 'quotation' ? 'Quotation' : 'Tax Invoice'),
        template: payload.template || w.business?.template || 'classic_ledger',
        pageSize: payload.pageSize || w.business?.pageSize || 'a4',
        attachAgreement: Boolean(payload.attachAgreement),
        agreement: payload.agreement || null,
        agreementId: payload.agreementId || null,
        items,
        ...calcResults,
        paid: 0,
        terms: payload.terms || '',
        exclusions: payload.exclusions || '',
        milestones: payload.milestones || '',
        createdAt: nowIso
      };

      w.nextNo = nextNo + 1;
      w.documents = [d, ...w.documents];
      break;
    }

    case 'document_update': {
      if (Array.isArray(w.documents)) {
        const d = w.documents.find(x => x.id === payload.id);
        if (d) {
          if (payload.template) d.template = payload.template;
          if (payload.pageSize) d.pageSize = payload.pageSize;
          if (payload.language) d.language = payload.language;
        }
      }
      break;
    }

    case 'agreement': {
      if (!Array.isArray(w.agreements)) w.agreements = [];
      const c = payload.customerId ? (w.customers || []).find(x => x.id === payload.customerId) : payload.customer;
      const count = (w.agreements || []).length + 1;
      const agreeNo = payload.number || `${prefix}-AG-${String(count).padStart(4, '0')}`;
      const aId = payload.id || ('agr_offline_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6));
      payload.id = aId;
      payload.number = agreeNo;

      const a = {
        id: aId,
        number: agreeNo,
        service: payload.service || scope,
        language: ['en', 'te', 'hi'].includes(payload.language) ? payload.language : 'te',
        date: payload.date || dateStr,
        customerId: c?.id || payload.customerId || null,
        customer: c ? JSON.parse(JSON.stringify(c)) : null,
        projectId: payload.projectId || null,
        projectSite: payload.projectSite || payload.siteLocation || c?.siteLocation || '',
        title: payload.title || 'మెటీరియల్స్ ఒప్పందం',
        materials: Array.isArray(payload.materials) ? payload.materials : [],
        terms: payload.terms || '',
        notes: payload.notes || '',
        linkedQuotationId: payload.linkedQuotationId || null,
        status: payload.status || 'draft',
        createdAt: payload.createdAt || nowIso
      };
      if (payload.id && w.agreements.some(x => x.id === payload.id)) {
        w.agreements = w.agreements.map(x => x.id === payload.id ? a : x);
      } else {
        w.agreements = [a, ...w.agreements];
      }
      break;
    }

    case 'material_catalog': {
      if (!Array.isArray(w.materialsCatalog)) w.materialsCatalog = [];
      const item = {
        id: payload.id || ('mat_' + Date.now()),
        service: scope,
        name: payload.name || 'Material',
        teName: payload.teName || '',
        hiName: payload.hiName || '',
        category: payload.category || 'Other',
        specs: payload.specs || '',
        brand: payload.brand || '',
        unit: payload.unit || 'pcs',
        defaultRate: Number(payload.defaultRate || payload.rate || 0),
        imageUri: payload.imageUri || '',
        isFavorite: Boolean(payload.isFavorite),
        updatedAt: nowIso
      };
      if (payload.id && w.materialsCatalog.some(x => x.id === payload.id)) {
        w.materialsCatalog = w.materialsCatalog.map(x => x.id === payload.id ? item : x);
      } else {
        w.materialsCatalog = [item, ...w.materialsCatalog];
      }
      break;
    }

    case 'material_catalog_delete': {
      if (Array.isArray(w.materialsCatalog)) {
        w.materialsCatalog = w.materialsCatalog.filter(x => x.id !== payload.id);
      }
      break;
    }

    case 'worker': {
      if (!Array.isArray(w.workers)) w.workers = [];
      const wrk = {
        id: payload.id || ('wrk_' + Date.now()),
        service: scope,
        name: payload.name || 'Worker',
        phone: payload.phone || '',
        role: payload.role || 'Mason',
        dailyRate: Number(payload.dailyRate || 0),
        notes: payload.notes || '',
        createdAt: nowIso
      };
      if (payload.id && w.workers.some(x => x.id === payload.id)) {
        w.workers = w.workers.map(x => x.id === payload.id ? wrk : x);
      } else {
        w.workers = [wrk, ...w.workers];
      }
      break;
    }

    case 'payout': {
      if (!Array.isArray(w.payouts)) w.payouts = [];
      const p = {
        id: payload.id || ('pay_' + Date.now()),
        workerId: payload.workerId,
        service: scope,
        date: payload.date || dateStr,
        amount: Number(payload.amount || 0),
        purpose: payload.purpose === 'wage' ? 'wage' : 'advance',
        method: payload.method || 'Cash',
        split: payload.split || null,
        ref: payload.ref || '',
        note: payload.note || '',
        void: Boolean(payload.void),
        at: nowIso
      };
      if (payload.id && w.payouts.some(x => x.id === payload.id)) {
        w.payouts = w.payouts.map(x => x.id === payload.id ? p : x);
      } else {
        w.payouts = [p, ...w.payouts];
      }
      break;
    }

    case 'payout_void': {
      if (Array.isArray(w.payouts)) {
        const p = w.payouts.find(x => x.id === payload.id);
        if (p) p.void = !p.void;
      }
      break;
    }

    case 'project': {
      if (!Array.isArray(w.projects)) w.projects = [];
      const pId = payload.id || ('proj_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6));
      const p = {
        ...payload,
        id: pId,
        service: payload.service || scope,
        name: (payload.name || 'Site / Project').trim(),
        budget: Number(payload.budget || 0),
        progress: Number(payload.progress || 0),
        dueDate: payload.dueDate || '',
        customerId: payload.customerId || null,
        address: payload.address || ''
      };
      if (payload.id && w.projects.some(x => x.id === payload.id)) {
        w.projects = w.projects.map(x => x.id === payload.id ? p : x);
      } else {
        w.projects = [p, ...w.projects];
      }
      break;
    }

    case 'material_list': {
      if (!Array.isArray(w.materialLists)) w.materialLists = [];
      const c = payload.customerId ? (w.customers || []).find(x => x.id === payload.customerId) : payload.customer;
      const mId = payload.id || ('matlist_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6));
      const matList = {
        id: mId,
        number: payload.number || (`${prefix}-MAT-${String((w.materialLists || []).length + 1).padStart(4, '0')}`),
        service: scope,
        language: ['en', 'te', 'hi'].includes(payload.language) ? payload.language : 'en',
        date: payload.date || dateStr,
        customerId: c?.id || payload.customerId || null,
        customer: c ? JSON.parse(JSON.stringify(c)) : null,
        customerName: c?.name || payload.customerName || '',
        projectId: payload.projectId || null,
        siteLocation: payload.siteLocation || c?.siteLocation || c?.address || '',
        workAreasSummary: payload.workAreasSummary || '',
        rooms: Array.isArray(payload.rooms) ? payload.rooms : [],
        items: Array.isArray(payload.items) ? payload.items : [],
        showPrices: Boolean(payload.showPrices),
        instructions: payload.instructions || '',
        createdAt: payload.createdAt || nowIso
      };
      if (payload.id && w.materialLists.some(x => x.id === payload.id)) {
        w.materialLists = w.materialLists.map(x => x.id === payload.id ? matList : x);
      } else {
        w.materialLists = [matList, ...w.materialLists];
      }
      break;
    }

    case 'material_list_delete': {
      if (Array.isArray(w.materialLists)) {
        w.materialLists = w.materialLists.filter(x => x.id !== payload.id);
      }
      break;
    }

    case 'convert': {
      if (!Array.isArray(w.documents)) w.documents = [];
      const q = w.documents.find(d => d.id === payload.id && d.kind === 'quotation');
      if (q) {
        const nextNo = w.nextNo || 1;
        const docNo = `${prefix}-${String(nextNo).padStart(4, '0')}`;
        w.nextNo = nextNo + 1;
        const inv = {
          ...JSON.parse(JSON.stringify(q)),
          id: 'doc_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
          kind: 'invoice',
          number: docNo,
          date: dateStr,
          paid: 0,
          sourceQuoteId: q.id,
          createdAt: nowIso
        };
        w.documents = [inv, ...w.documents];
      }
      break;
    }

    case 'payment': {
      if (!Array.isArray(w.payments)) w.payments = [];
      if (!Array.isArray(w.documents)) w.documents = [];
      const d = w.documents.find(doc => doc.id === payload.docId && doc.kind === 'invoice');
      const amount = Number(payload.amount || 0);
      const payId = payload.id || ('paym_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6));
      const payRec = {
        id: payId,
        docId: payload.docId,
        amount,
        method: payload.method || 'Cash',
        date: payload.date || dateStr,
        note: payload.note || '',
        createdAt: nowIso
      };
      w.payments = [payRec, ...w.payments];
      if (d) {
        d.paid = round((d.paid || 0) + amount);
      }
      break;
    }

    case 'attendance': {
      if (!Array.isArray(w.attendance)) w.attendance = [];
      if (!Array.isArray(w.workers)) w.workers = [];
      const worker = w.workers.find(x => x.id === payload.workerId);
      if (payload.status === 'clear' || payload.status === 'none') {
        w.attendance = w.attendance.filter(x => !(x.workerId === payload.workerId && x.date === payload.date));
        break;
      }
      const old = w.attendance.find(x => x.workerId === payload.workerId && x.date === payload.date);
      const dailyRate = payload.dailyRate !== undefined ? Number(payload.dailyRate) : (old?.dailyRate ?? worker?.dailyRate ?? 0);
      const earned = round(dailyRate * (payload.status === 'present' ? 1 : payload.status === 'half' ? 0.5 : 0));
      const attRec = {
        id: old?.id || ('att_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6)),
        service: scope,
        workerId: payload.workerId,
        date: payload.date,
        status: payload.status,
        projectId: payload.projectId || worker?.projectId || '',
        dailyRate,
        earned
      };
      w.attendance = old ? w.attendance.map(x => x.id === old.id ? attRec : x) : [attRec, ...w.attendance];
      break;
    }

    case 'rate': {
      if (!Array.isArray(w.rates)) w.rates = [];
      const rId = payload.id || ('rate_' + Date.now());
      const r = {
        ...payload,
        id: rId,
        service: payload.service || scope,
        name: payload.name || 'Item',
        rate: Number(payload.rate || 0),
        unit: payload.unit || 'sq.ft',
        mode: payload.mode || 'area',
        sample: false
      };
      if (payload.id && w.rates.some(x => x.id === payload.id)) {
        w.rates = w.rates.map(x => x.id === payload.id ? r : x);
      } else {
        w.rates = [...w.rates, r];
      }
      break;
    }

    case 'feedback': {
      if (!Array.isArray(w.feedback)) w.feedback = [];
      const cust = (w.customers || []).find(c => c.id === payload.customerId);
      const fb = {
        id: 'fb_' + Date.now(),
        service: scope,
        customerId: payload.customerId,
        customer: cust?.name || payload.customer || 'Customer',
        rating: Number(payload.rating || 5),
        message: String(payload.message || ''),
        source: 'Recorded by contractor',
        at: nowIso
      };
      w.feedback = [fb, ...w.feedback];
      break;
    }
  }

  // Queue for cloud sync ONLY if not in offline test mode
  if (!IS_OFFLINE_TEST_MODE) {
    try {
      queueOfflineAction({ action, payload, service: scope });
    } catch (qErr) {
      console.warn('[OfflineStorage] Error queueing action for sync:', qErr);
    }
  }

  return w;
}

/**
 * Creates a versioned local JSON backup of the workspace and tester profile.
 */
export function createLocalBackupPayload(workspace, user) {
  return {
    app: 'TileBill PRO',
    schema: workspace?.schema || 6,
    version: '6.0.4',
    type: 'offline_local_backup',
    exportedAt: new Date().toISOString(),
    user: user ? {
      name: user.name || 'Contractor',
      phone: user.phone || '',
      email: user.email || ''
    } : null,
    workspace: JSON.parse(JSON.stringify(workspace || {}))
  };
}

/**
 * Validates and sanitizes a local backup payload before restoring.
 */
export function validateLocalBackupPayload(raw) {
  try {
    const data = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (!data || typeof data !== 'object') {
      return { ok: false, error: 'Invalid backup file format' };
    }
    if (!data.workspace || typeof data.workspace !== 'object') {
      return { ok: false, error: 'Backup does not contain workspace data' };
    }
    const w = data.workspace;
    if (!w.business || typeof w.business !== 'object' || !w.business.name) {
      return { ok: false, error: 'Backup is missing business profile information' };
    }
    return { ok: true, data };
  } catch (err) {
    return { ok: false, error: err.message || 'Failed to parse backup JSON' };
  }
}

