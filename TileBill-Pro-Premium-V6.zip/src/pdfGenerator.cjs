/**
 * TileBill PRO - Server-side PDF Generator (src/pdfGenerator.cjs)
 * Produces genuine, standards-compliant A4 PDF documents.
 * Priority 1: Headless Chrome / Chromium / Edge for pixel-perfect HTML rendering with full Telugu/Hindi fonts.
 * Priority 2: Pure Node.js vector PDF generator fallback (zero external dependencies).
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFileSync } = require('child_process');
const { documentHtml, agreementHtml } = require('./domain.cjs');

// Find available Chrome or Edge browser executable
function findBrowserBinary() {
  if (process.env.CHROME_BIN && fs.existsSync(process.env.CHROME_BIN)) {
    return process.env.CHROME_BIN;
  }

  const candidates = [
    // Windows Chrome & Edge
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    path.join(os.homedir(), 'AppData\\Local\\Google\\Chrome\\Application\\chrome.exe'),
    path.join(os.homedir(), 'AppData\\Local\\Microsoft\\Edge\\Application\\msedge.exe'),
    // Linux / Mac
    '/usr/bin/google-chrome',
    '/usr/bin/google-chrome-stable',
    '/usr/bin/chromium',
    '/usr/bin/chromium-browser',
    '/snap/bin/chromium',
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge'
  ];

  for (const p of candidates) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

/**
 * Generate PDF using headless browser
 */
function generatePdfWithBrowser(html, browserPath) {
  const tmpDir = path.join(__dirname, '../scratch');
  if (!fs.existsSync(tmpDir)) {
    fs.mkdirSync(tmpDir, { recursive: true });
  }

  const nonce = Date.now() + '_' + Math.random().toString(36).slice(2, 8);
  const htmlPath = path.join(tmpDir, `doc_${nonce}.html`);
  const pdfPath = path.join(tmpDir, `doc_${nonce}.pdf`);

  try {
    fs.writeFileSync(htmlPath, html, 'utf8');

    // Execute headless browser to print to PDF
    // Flags ensure clean A4 output without headers/footers
    const args = [
      '--headless',
      '--disable-gpu',
      '--no-first-run',
      '--no-default-browser-check',
      '--no-pdf-header-footer',
      `--print-to-pdf=${pdfPath}`,
      htmlPath
    ];

    execFileSync(browserPath, args, {
      timeout: 25000,
      stdio: ['ignore', 'pipe', 'pipe']
    });

    if (fs.existsSync(pdfPath)) {
      const pdfBuf = fs.readFileSync(pdfPath);
      if (pdfBuf && pdfBuf.length > 500 && pdfBuf.slice(0, 5).toString('utf8') === '%PDF-') {
        return pdfBuf;
      }
    }
    throw new Error('Browser did not produce a valid PDF file');
  } finally {
    try { if (fs.existsSync(htmlPath)) fs.unlinkSync(htmlPath); } catch {}
    try { if (fs.existsSync(pdfPath)) fs.unlinkSync(pdfPath); } catch {}
  }
}

/**
 * Pure Node.js PDF Generator Fallback
 * Used if headless browser is unavailable in a minimalist hosting environment.
 * Generates valid PDF 1.4 syntax with A4 page dimensions (595.28 x 841.89 pt).
 */
function generatePdfPureNode(doc, business) {
  const isAgreement = Boolean(doc.isAgreement || doc.kind === 'agreement');
  const isQuotation = doc.kind === 'quotation';
  const docType = isAgreement ? 'MATERIAL SPECIFICATION AGREEMENT' : (isQuotation ? 'QUOTATION' : 'TAX INVOICE');

  const bizName = (business?.name || 'TileBill Pro').toUpperCase();
  const bizPhone = business?.phone || '';
  const bizCity = business?.city || '';
  const custName = doc.customer?.name || (isAgreement ? doc.customerName : 'Customer') || 'Customer';
  const site = doc.siteLocation || doc.projectSite || doc.customer?.siteLocation || '';
  const docNo = doc.number || (isAgreement ? 'AG-0001' : (isQuotation ? 'QT-0001' : 'INV-0001'));
  const docDate = doc.date || new Date().toISOString().slice(0, 10);

  // PDF stream elements
  const objects = [];
  const addObject = (content) => {
    objects.push(content);
    return objects.length; // 1-based obj num
  };

  // Obj 1: Catalog
  addObject('<< /Type /Catalog /Pages 2 0 R >>');
  // Obj 2: Pages
  addObject('<< /Type /Pages /Kids [3 0 R] /Count 1 >>');

  // Build stream content
  let stream = '';
  const sanitize = (str) => String(str || '').replace(/[\\()]/g, '\\$&').replace(/[^\x20-\x7E]/g, ' ');

  // Header Box
  stream += 'q\n';
  stream += '0.95 0.85 0.1 rg\n'; // Amber top bar
  stream += '40 790 515 20 re f\n';
  stream += '0.1 0.1 0.1 rg\n';
  stream += 'BT /F1 16 Tf 50 760 Td (' + sanitize(bizName) + ') Tj ET\n';
  stream += 'BT /F2 9 Tf 50 745 Td (' + sanitize([bizPhone, bizCity].filter(Boolean).join(' | ')) + ') Tj ET\n';

  // Title Box
  stream += '0.12 0.16 0.22 rg\n';
  stream += 'BT /F1 14 Tf 360 760 Td (' + sanitize(docType) + ') Tj ET\n';
  stream += 'BT /F2 9 Tf 360 745 Td (Doc No: ' + sanitize(docNo) + '   Date: ' + sanitize(docDate) + ') Tj ET\n';

  // Divider line
  stream += '0.8 0.8 0.8 RG 1 w\n';
  stream += '40 730 m 555 730 l S\n';

  // Customer & Site Block
  stream += '0.96 0.97 0.98 rg 40 675 515 45 re f\n';
  stream += '0.8 0.8 0.8 RG 40 675 515 45 re s\n';
  stream += '0.1 0.1 0.1 rg\n';
  stream += 'BT /F1 10 Tf 50 705 Td (CUSTOMER / CLIENT:) Tj ET\n';
  stream += 'BT /F2 10 Tf 50 690 Td (' + sanitize(custName) + ') Tj ET\n';
  stream += 'BT /F1 10 Tf 320 705 Td (SITE / PROJECT LOCATION:) Tj ET\n';
  stream += 'BT /F2 9 Tf 320 690 Td (' + sanitize(site || 'Local Site') + ') Tj ET\n';

  // Items Table Header
  let y = 650;
  stream += '0.92 0.94 0.96 rg 40 ' + (y - 5) + ' 515 18 re f\n';
  stream += '0.2 0.2 0.2 rg\n';
  if (isAgreement) {
    stream += 'BT /F1 9 Tf 45 ' + y + ' Td (S.No) Tj 80 ' + y + ' Td (Material / Item) Tj 220 ' + y + ' Td (Brand / Grade) Tj 340 ' + y + ' Td (Sizes / Specs) Tj 450 ' + y + ' Td (Supplied By) Tj ET\n';
  } else {
    stream += 'BT /F1 9 Tf 45 ' + y + ' Td (S.No) Tj 80 ' + y + ' Td (Item Description) Tj 280 ' + y + ' Td (Qty) Tj 330 ' + y + ' Td (Unit) Tj 380 ' + y + ' Td (Rate) Tj 470 ' + y + ' Td (Amount) Tj ET\n';
  }

  // Items List
  const items = isAgreement ? (doc.materials || []) : (doc.items || []);
  let idx = 1;
  y -= 20;

  for (const it of items.slice(0, 25)) {
    stream += '0.9 0.9 0.9 RG 0.5 w 40 ' + (y - 3) + ' m 555 ' + (y - 3) + ' l S\n';
    stream += '0.1 0.1 0.1 rg\n';
    if (isAgreement) {
      stream += 'BT /F2 8.5 Tf 45 ' + y + ' Td (' + idx + ') Tj 80 ' + y + ' Td (' + sanitize((it.name || '').slice(0, 24)) + ') Tj 220 ' + y + ' Td (' + sanitize(([it.brand, it.grade].filter(Boolean).join(' ') || '-').slice(0, 18)) + ') Tj 340 ' + y + ' Td (' + sanitize((Array.isArray(it.sizes) ? it.sizes.join(', ') : it.specs || '-').slice(0, 20)) + ') Tj 450 ' + y + ' Td (' + sanitize(it.suppliedBy === 'customer' ? 'Customer' : 'Contractor') + ') Tj ET\n';
    } else {
      const amtStr = 'Rs. ' + Number(it.amount || 0).toFixed(2);
      stream += 'BT /F2 8.5 Tf 45 ' + y + ' Td (' + idx + ') Tj 80 ' + y + ' Td (' + sanitize((it.name || '').slice(0, 32)) + ') Tj 280 ' + y + ' Td (' + sanitize(it.qty || 1) + ') Tj 330 ' + y + ' Td (' + sanitize(it.unit || 'sqft') + ') Tj 380 ' + y + ' Td (' + sanitize(it.rate || 0) + ') Tj 470 ' + y + ' Td (' + sanitize(amtStr) + ') Tj ET\n';
    }
    y -= 18;
    idx++;
  }

  // Totals Section (Strictly omitted for Materials Agreement!)
  if (!isAgreement) {
    y -= 10;
    stream += '0.95 0.95 0.95 rg 320 ' + (y - 45) + ' 235 55 re f\n';
    stream += '0.8 0.8 0.8 RG 320 ' + (y - 45) + ' 235 55 re s\n';
    stream += '0.1 0.1 0.1 rg\n';
    stream += 'BT /F2 9 Tf 330 ' + (y - 2) + ' Td (Subtotal:) Tj 460 ' + (y - 2) + ' Td (Rs. ' + Number(doc.subtotal || doc.total || 0).toFixed(2) + ') Tj ET\n';
    if (doc.taxPercent > 0) {
      stream += 'BT /F2 9 Tf 330 ' + (y - 16) + ' Td (GST (' + doc.taxPercent + '%):) Tj 460 ' + (y - 16) + ' Td (Rs. ' + Number(doc.taxAmount || 0).toFixed(2) + ') Tj ET\n';
    }
    stream += 'BT /F1 11 Tf 330 ' + (y - 34) + ' Td (GRAND TOTAL:) Tj 450 ' + (y - 34) + ' Td (Rs. ' + Number(doc.grandTotal || doc.total || 0).toFixed(2) + ') Tj ET\n';
  }

  // Footer & Signatures
  y = Math.min(y - 60, 120);
  stream += '0.8 0.8 0.8 RG 1 w 40 ' + y + ' m 555 ' + y + ' l S\n';
  stream += '0.4 0.4 0.4 rg\n';
  stream += 'BT /F2 8 Tf 40 ' + (y - 15) + ' Td (Generated securely via TileBill PRO - Contractor Billing & Project Management) Tj ET\n';
  stream += 'BT /F1 9 Tf 400 ' + (y - 15) + ' Td (Authorized Signatory) Tj ET\n';
  stream += 'Q\n';

  // Obj 3: Page Definition
  addObject('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Contents 4 0 R /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> >>');
  // Obj 4: Content Stream
  const streamLen = Buffer.byteLength(stream, 'utf8');
  addObject('<< /Length ' + streamLen + ' >>\nstream\n' + stream + '\nendstream');
  // Obj 5: Font F1 (Helvetica Bold)
  addObject('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>');
  // Obj 6: Font F2 (Helvetica Regular)
  addObject('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>');

  // Build xref table
  let pdf = '%PDF-1.4\n%\xE2\xE3\xCF\xD3\n';
  const offsets = [0];

  for (let i = 0; i < objects.length; i++) {
    offsets.push(Buffer.byteLength(pdf, 'utf8'));
    pdf += (i + 1) + ' 0 obj\n' + objects[i] + '\nendobj\n';
  }

  const xrefOffset = Buffer.byteLength(pdf, 'utf8');
  pdf += 'xref\n';
  pdf += '0 ' + (objects.length + 1) + '\n';
  pdf += '0000000000 65535 f \n';
  for (let i = 1; i <= objects.length; i++) {
    pdf += String(offsets[i]).padStart(10, '0') + ' 00000 n \n';
  }
  pdf += 'trailer\n';
  pdf += '<< /Size ' + (objects.length + 1) + ' /Root 1 0 R >>\n';
  pdf += 'startxref\n';
  pdf += xrefOffset + '\n';
  pdf += '%%EOF\n';

  return Buffer.from(pdf, 'utf8');
}

/**
 * Primary export: generatePdf
 * @param {Object} options - { doc, business, html }
 * @returns {Buffer} PDF binary buffer
 */
function generatePdf({ doc = {}, business = {}, html = '' }) {
  const isAgreement = Boolean(doc.isAgreement || doc.kind === 'agreement');
  const renderedHtml = html || (isAgreement ? agreementHtml(doc, business) : documentHtml(doc, business));

  const browserBin = findBrowserBinary();
  if (browserBin) {
    try {
      return generatePdfWithBrowser(renderedHtml, browserBin);
    } catch (err) {
      console.warn('Headless browser PDF failed, falling back to pure Node generator:', err.message);
    }
  }

  // Graceful pure Node generator
  return generatePdfPureNode(doc, business);
}

module.exports = {
  findBrowserBinary,
  generatePdf,
  generatePdfWithBrowser,
  generatePdfPureNode
};
