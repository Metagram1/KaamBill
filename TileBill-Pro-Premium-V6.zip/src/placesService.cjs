/**
 * TileBill PRO - Places & Location Service (src/placesService.cjs)
 * Supports Google Places API when GOOGLE_PLACES_API_KEY is configured in .env.
 * When not configured, provides a rich regional database of Andhra Pradesh & Telangana
 * contractor localities, municipalities, and mandals with accurate coordinates.
 */

// Regional database of AP & Telangana contractor localities
const REGIONAL_PLACES = [
  // Visakhapatnam
  { id: 'ap_vskp_muralinagar', name: 'మురళీనగర్ (Muralinagar)', locality: 'Muralinagar', city: 'Visakhapatnam', state: 'Andhra Pradesh', pincode: '530007', lat: 17.7432, lng: 83.2755 },
  { id: 'ap_vskp_gajuwaka', name: 'గాజువాక (Gajuwaka)', locality: 'Gajuwaka', city: 'Visakhapatnam', state: 'Andhra Pradesh', pincode: '530026', lat: 17.6906, lng: 83.2096 },
  { id: 'ap_vskp_madhurawada', name: 'మధురవాడ (Madhurawada)', locality: 'Madhurawada', city: 'Visakhapatnam', state: 'Andhra Pradesh', pincode: '530048', lat: 17.8188, lng: 83.3562 },
  { id: 'ap_vskp_pendurthi', name: 'పెందుర్తి (Pendurthi)', locality: 'Pendurthi', city: 'Visakhapatnam', state: 'Andhra Pradesh', pincode: '531173', lat: 17.8322, lng: 83.2006 },
  { id: 'ap_vskp_mvp', name: 'MVP కాలనీ (MVP Colony)', locality: 'MVP Colony', city: 'Visakhapatnam', state: 'Andhra Pradesh', pincode: '530017', lat: 17.7423, lng: 83.3343 },
  { id: 'ap_vskp_dwarakanagar', name: 'ద్వారకా నగర్ (Dwaraka Nagar)', locality: 'Dwaraka Nagar', city: 'Visakhapatnam', state: 'Andhra Pradesh', pincode: '530016', lat: 17.7287, lng: 83.3075 },
  { id: 'ap_vskp_nad', name: 'NAD జంక్షన్ (NAD Junction)', locality: 'NAD Junction', city: 'Visakhapatnam', state: 'Andhra Pradesh', pincode: '530009', lat: 17.7483, lng: 83.2372 },
  { id: 'ap_vskp_kurmannapalem', name: 'కూర్మన్నపాలెం (Kurmannapalem)', locality: 'Kurmannapalem', city: 'Visakhapatnam', state: 'Andhra Pradesh', pincode: '530046', lat: 17.6744, lng: 83.1554 },

  // Vijayawada
  { id: 'ap_vja_benzcircle', name: 'బెంజ్ సర్కిల్ (Benz Circle)', locality: 'Benz Circle', city: 'Vijayawada', state: 'Andhra Pradesh', pincode: '520010', lat: 16.4984, lng: 80.6548 },
  { id: 'ap_vja_patamata', name: 'పటమట (Patamata)', locality: 'Patamata', city: 'Vijayawada', state: 'Andhra Pradesh', pincode: '520010', lat: 16.4932, lng: 80.6653 },
  { id: 'ap_vja_gandhinagar', name: 'గాంధీనగర్ (Gandhi Nagar)', locality: 'Gandhi Nagar', city: 'Vijayawada', state: 'Andhra Pradesh', pincode: '520003', lat: 16.5173, lng: 80.6276 },
  { id: 'ap_vja_poranki', name: 'పోరంకి (Poranki)', locality: 'Poranki', city: 'Vijayawada', state: 'Andhra Pradesh', pincode: '521137', lat: 16.4812, lng: 80.7024 },
  { id: 'ap_vja_gunadala', name: 'గుణదల (Gunadala)', locality: 'Gunadala', city: 'Vijayawada', state: 'Andhra Pradesh', pincode: '520004', lat: 16.5218, lng: 80.6621 },

  // Guntur
  { id: 'ap_gtr_arundelpet', name: 'అరండల్‌పేట్ (Arundelpet)', locality: 'Arundelpet', city: 'Guntur', state: 'Andhra Pradesh', pincode: '522002', lat: 16.3052, lng: 80.4431 },
  { id: 'ap_gtr_lakshmipuram', name: 'లక్ష్మీపురం (Lakshmipuram)', locality: 'Lakshmipuram', city: 'Guntur', state: 'Andhra Pradesh', pincode: '522007', lat: 16.2974, lng: 80.4285 },
  { id: 'ap_gtr_brodipet', name: 'బ్రోడీపేట (Brodipet)', locality: 'Brodipet', city: 'Guntur', state: 'Andhra Pradesh', pincode: '522002', lat: 16.3112, lng: 80.4354 },

  // Tirupati
  { id: 'ap_tpt_leelamahal', name: 'లీలామహల్ సర్కిల్ (Leela Mahal Circle)', locality: 'Leela Mahal Circle', city: 'Tirupati', state: 'Andhra Pradesh', pincode: '517501', lat: 13.6335, lng: 79.4217 },
  { id: 'ap_tpt_korlagunta', name: 'కోర్లగుంట (Korlagunta)', locality: 'Korlagunta', city: 'Tirupati', state: 'Andhra Pradesh', pincode: '517501', lat: 13.6268, lng: 79.4312 },
  { id: 'ap_tpt_mrpalli', name: 'ఎం.ఆర్. పల్లి (MR Palli)', locality: 'MR Palli', city: 'Tirupati', state: 'Andhra Pradesh', pincode: '517502', lat: 13.6192, lng: 79.4087 },

  // Rajahmundry
  { id: 'ap_rjy_danavaipeta', name: 'దానవాయిపేట (Danavaipeta)', locality: 'Danavaipeta', city: 'Rajahmundry', state: 'Andhra Pradesh', pincode: '533103', lat: 17.0051, lng: 81.7825 },
  { id: 'ap_rjy_morampudi', name: 'మోరంపూడి (Morampudi)', locality: 'Morampudi', city: 'Rajahmundry', state: 'Andhra Pradesh', pincode: '533107', lat: 16.9923, lng: 81.8105 },

  // Kakinada
  { id: 'ap_kkd_bhanugudi', name: 'భానుగుడి (Bhanugudi)', locality: 'Bhanugudi', city: 'Kakinada', state: 'Andhra Pradesh', pincode: '533003', lat: 16.9602, lng: 82.2384 },
  { id: 'ap_kkd_sriram', name: 'శ్రీరామ్‌నగర్ (Sriram Nagar)', locality: 'Sriram Nagar', city: 'Kakinada', state: 'Andhra Pradesh', pincode: '533003', lat: 16.9715, lng: 82.2471 },

  // Other AP Districts
  { id: 'ap_knl_main', name: 'కర్నూలు మెయిన్ (Kurnool Town)', locality: 'City Center', city: 'Kurnool', state: 'Andhra Pradesh', pincode: '518001', lat: 15.8281, lng: 78.0373 },
  { id: 'ap_nlr_main', name: 'నెల్లూరు టౌన్ (Nellore Town)', locality: 'Pogathota', city: 'Nellore', state: 'Andhra Pradesh', pincode: '524001', lat: 14.4426, lng: 79.9865 },
  { id: 'ap_atp_main', name: 'అనంతపురం టౌన్ (Anantapur Town)', locality: 'Clock Tower', city: 'Anantapur', state: 'Andhra Pradesh', pincode: '515001', lat: 14.6819, lng: 77.6006 },
  { id: 'ap_kdp_main', name: 'కడప సిటీ (Kadapa City)', locality: 'City Center', city: 'Kadapa', state: 'Andhra Pradesh', pincode: '516001', lat: 14.4673, lng: 78.8242 },
  { id: 'ap_ong_main', name: 'ఒంగోలు టౌన్ (Ongole Town)', locality: 'Lawyerpet', city: 'Ongole', state: 'Andhra Pradesh', pincode: '523001', lat: 15.5057, lng: 80.0499 },
  { id: 'ap_elr_main', name: 'ఏలూరు (Eluru)', locality: 'Powerpet', city: 'Eluru', state: 'Andhra Pradesh', pincode: '534002', lat: 16.7107, lng: 81.0952 },
  { id: 'ap_vzm_main', name: 'విజయనగరం (Vizianagaram)', locality: 'Cantonment', city: 'Vizianagaram', state: 'Andhra Pradesh', pincode: '535003', lat: 18.1124, lng: 83.3989 },
  { id: 'ap_sklm_main', name: 'శ్రీకాకుళం (Srikakulam)', locality: 'Seven Road Junction', city: 'Srikakulam', state: 'Andhra Pradesh', pincode: '532001', lat: 18.2969, lng: 83.8967 },

  // Telangana - Hyderabad
  { id: 'tg_hyd_kphb', name: 'కూకట్‌పల్లి / కేపీహెచ్‌బీ (Kukatpally)', locality: 'KPHB Colony', city: 'Hyderabad', state: 'Telangana', pincode: '500072', lat: 17.4947, lng: 78.3996 },
  { id: 'tg_hyd_madhapur', name: 'మాదాపూర్ (Madhapur)', locality: 'Madhapur', city: 'Hyderabad', state: 'Telangana', pincode: '500081', lat: 17.4483, lng: 78.3915 },
  { id: 'tg_hyd_gachibowli', name: 'గచ్చిబౌలి (Gachibowli)', locality: 'Gachibowli', city: 'Hyderabad', state: 'Telangana', pincode: '500032', lat: 17.4401, lng: 78.3489 },
  { id: 'tg_hyd_dilsukhnagar', name: 'దిల్‍సుఖ్‍నగర్ (Dilsukhnagar)', locality: 'Dilsukhnagar', city: 'Hyderabad', state: 'Telangana', pincode: '500060', lat: 17.3688, lng: 78.5247 },
  { id: 'tg_hyd_ameerpet', name: 'అమీర్‌పేట్ (Ameerpet)', locality: 'Ameerpet', city: 'Hyderabad', state: 'Telangana', pincode: '500016', lat: 17.4375, lng: 78.4482 },
  { id: 'tg_hyd_lbnagar', name: 'ఎల్బీనగర్ (LB Nagar)', locality: 'LB Nagar', city: 'Hyderabad', state: 'Telangana', pincode: '500074', lat: 17.3457, lng: 78.5522 },
  { id: 'tg_hyd_secunderabad', name: 'సికింద్రాబాద్ (Secunderabad Clock Tower)', locality: 'Clock Tower', city: 'Hyderabad', state: 'Telangana', pincode: '500003', lat: 17.4411, lng: 78.4984 },
  { id: 'tg_hyd_banjarahills', name: 'బంజారా హిల్స్ (Banjara Hills)', locality: 'Banjara Hills', city: 'Hyderabad', state: 'Telangana', pincode: '500034', lat: 17.4156, lng: 78.4357 },
  { id: 'tg_hyd_miyapur', name: 'మియాపూర్ (Miyapur)', locality: 'Miyapur', city: 'Hyderabad', state: 'Telangana', pincode: '500049', lat: 17.4968, lng: 78.3614 },

  // Telangana - Districts
  { id: 'tg_wgl_hanmakonda', name: 'హన్మకొండ, వరంగల్ (Hanamkonda)', locality: 'Hanamkonda', city: 'Warangal', state: 'Telangana', pincode: '506001', lat: 17.9949, lng: 79.5661 },
  { id: 'tg_knr_city', name: 'కరీంనగర్ సిటీ (Karimnagar City)', locality: 'Collectorate Road', city: 'Karimnagar', state: 'Telangana', pincode: '505001', lat: 18.4386, lng: 79.1288 },
  { id: 'tg_kmm_wyra', name: 'ఖమ్మం వైరా రోడ్ (Khammam Wyra Road)', locality: 'Wyra Road', city: 'Khammam', state: 'Telangana', pincode: '507001', lat: 17.2473, lng: 80.1514 },
  { id: 'tg_nzb_main', name: 'నిజామాబాద్ టౌన్ (Nizamabad Town)', locality: 'Khaleelwadi', city: 'Nizamabad', state: 'Telangana', pincode: '503001', lat: 18.6725, lng: 78.0941 },
  { id: 'tg_nlg_clock', name: 'నల్గొండ క్లాక్ టవర్ (Nalgonda Clock Tower)', locality: 'Clock Tower', city: 'Nalgonda', state: 'Telangana', pincode: '508001', lat: 17.0577, lng: 79.2684 },
  { id: 'tg_mbnr_town', name: 'మహబూబ్ నగర్ టౌన్ (Mahbubnagar Town)', locality: 'Town Center', city: 'Mahbubnagar', state: 'Telangana', pincode: '509001', lat: 16.7488, lng: 77.9856 },
  { id: 'tg_rgm_main', name: 'రామగుండం / గోదావరిఖని (Ramagundam)', locality: 'Godavarikhani', city: 'Ramagundam', state: 'Telangana', pincode: '505209', lat: 18.7551, lng: 79.5139 }
];

function getGoogleApiKey() {
  return process.env.GOOGLE_PLACES_API_KEY || process.env.GOOGLE_MAPS_API_KEY || null;
}

/**
 * Autocomplete place search
 */
async function searchPlaces(query = '') {
  const cleanQ = String(query || '').trim();
  const apiKey = getGoogleApiKey();

  if (apiKey && cleanQ.length >= 2) {
    try {
      const url = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${encodeURIComponent(cleanQ)}&components=country:in&key=${apiKey}`;
      const res = await fetch(url);
      const data = await res.json();
      if (data.status === 'OK' && Array.isArray(data.predictions)) {
        return {
          ok: true,
          configured: true,
          provider: 'google',
          predictions: data.predictions.map(p => ({
            placeId: p.place_id,
            displayName: p.structured_formatting?.main_text || p.description,
            secondaryText: p.structured_formatting?.secondary_text || '',
            formattedAddress: p.description,
            terms: (p.terms || []).map(t => t.value)
          }))
        };
      }
    } catch (e) {
      console.warn('Google Places Autocomplete failed, falling back to regional DB:', e.message);
    }
  }

  // Regional Database Search
  const lowerQ = cleanQ.toLowerCase();
  const matches = REGIONAL_PLACES.filter(p => {
    if (!lowerQ) return true;
    return (
      p.name.toLowerCase().includes(lowerQ) ||
      p.locality.toLowerCase().includes(lowerQ) ||
      p.city.toLowerCase().includes(lowerQ) ||
      p.state.toLowerCase().includes(lowerQ) ||
      p.pincode.includes(lowerQ)
    );
  }).slice(0, 15);

  const formattedMatches = matches.map(p => ({
    placeId: p.id,
    displayName: p.name,
    secondaryText: `${p.city}, ${p.state} ${p.pincode}`,
    formattedAddress: `${p.locality}, ${p.city}, ${p.state} ${p.pincode}`,
    locality: p.locality,
    city: p.city,
    state: p.state,
    pincode: p.pincode,
    lat: p.lat,
    lng: p.lng
  }));

  return {
    ok: true,
    configured: Boolean(apiKey),
    provider: 'regional_database',
    message: apiKey ? undefined : 'Google Places API key is not configured in .env (GOOGLE_PLACES_API_KEY). Using verified regional contractor localities database.',
    predictions: formattedMatches,
    suggestions: formattedMatches
  };
}

/**
 * Resolve full place details by ID
 */
async function resolvePlaceDetails(placeId) {
  const apiKey = getGoogleApiKey();

  if (apiKey && !placeId.startsWith('ap_') && !placeId.startsWith('tg_')) {
    try {
      const url = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${encodeURIComponent(placeId)}&fields=place_id,name,formatted_address,geometry,address_components&key=${apiKey}`;
      const res = await fetch(url);
      const data = await res.json();
      if (data.status === 'OK' && data.result) {
        const r = data.result;
        const comps = r.address_components || [];
        const findComp = (type) => comps.find(c => (c.types || []).includes(type))?.long_name || '';
        return {
          ok: true,
          placeId: r.place_id,
          displayName: r.name,
          formattedAddress: r.formatted_address,
          locality: findComp('sublocality_level_1') || findComp('sublocality') || findComp('locality'),
          city: findComp('locality') || findComp('administrative_area_level_2'),
          state: findComp('administrative_area_level_1'),
          pincode: findComp('postal_code'),
          country: findComp('country'),
          lat: r.geometry?.location?.lat,
          lng: r.geometry?.location?.lng,
          provider: 'google'
        };
      }
    } catch (e) {
      console.warn('Google Places Details failed, falling back to regional DB:', e.message);
    }
  }

  // Lookup in regional DB
  const found = REGIONAL_PLACES.find(p => p.id === placeId);
  if (found) {
    return {
      ok: true,
      placeId: found.id,
      displayName: found.name,
      formattedAddress: `${found.locality}, ${found.city}, ${found.state} ${found.pincode}`,
      locality: found.locality,
      city: found.city,
      state: found.state,
      pincode: found.pincode,
      country: 'India',
      lat: found.lat,
      lng: found.lng,
      provider: 'regional_database'
    };
  }

  // Generic fallback if placeId is a custom string
  return {
    ok: true,
    placeId: placeId || 'custom_place',
    displayName: placeId,
    formattedAddress: placeId,
    locality: '',
    city: '',
    state: '',
    country: 'India',
    provider: 'custom'
  };
}

/**
 * Reverse geocode coordinates to approximate location for confirmation
 */
async function reverseGeocode(lat, lng) {
  const apiKey = getGoogleApiKey();

  if (apiKey) {
    try {
      const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${apiKey}`;
      const res = await fetch(url);
      const data = await res.json();
      if (data.status === 'OK' && Array.isArray(data.results) && data.results[0]) {
        const r = data.results[0];
        return {
          ok: true,
          displayName: r.formatted_address,
          formattedAddress: r.formatted_address,
          lat,
          lng,
          isApproximate: true,
          provider: 'google'
        };
      }
    } catch {}
  }

  // Find nearest regional place
  let nearest = REGIONAL_PLACES[0];
  let minDist = Infinity;
  for (const p of REGIONAL_PLACES) {
    const d = Math.hypot(p.lat - lat, p.lng - lng);
    if (d < minDist) {
      minDist = d;
      nearest = p;
    }
  }

  return {
    ok: true,
    placeId: nearest.id,
    displayName: nearest.name,
    formattedAddress: `${nearest.locality}, ${nearest.city}, ${nearest.state} ${nearest.pincode}`,
    locality: nearest.locality,
    city: nearest.city,
    state: nearest.state,
    pincode: nearest.pincode,
    lat,
    lng,
    isApproximate: true,
    provider: 'gps_approximate'
  };
}

module.exports = {
  REGIONAL_PLACES,
  getGoogleApiKey,
  searchPlaces,
  resolvePlaceDetails,
  reverseGeocode
};
