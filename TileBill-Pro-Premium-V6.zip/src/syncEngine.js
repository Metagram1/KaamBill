import {
  getPendingSyncQueue,
  removePendingSyncItem,
  getPendingSyncCount
} from './offlineStorage';

let isSyncing = false;
let syncListeners = [];

export function subscribeSyncStatus(listener) {
  syncListeners.push(listener);
  return () => {
    syncListeners = syncListeners.filter(l => l !== listener);
  };
}

function notifySyncStatus(status) {
  for (const listener of syncListeners) {
    try { listener(status); } catch {}
  }
}

/**
 * Synchronizes pending offline actions with the authoritative backend server.
 * Handles:
 * - Sequential execution in FIFO order
 * - Version conflict recovery (409 refresh + retry)
 * - Document collision mapping (preserves client IDs and respects server-assigned numbers)
 * - Automatic retry without duplicate creation
 */
export async function syncPendingActions({
  api,
  adopt,
  notify,
  getVersion,
  setVersion,
  appLang = 'te'
}) {
  if (isSyncing) return { inProgress: true };

  const queue = await getPendingSyncQueue();
  if (!queue || queue.length === 0) {
    notifySyncStatus({ status: 'synced', pendingCount: 0 });
    return { success: true, count: 0 };
  }

  isSyncing = true;
  notifySyncStatus({ status: 'syncing', pendingCount: queue.length });

  let syncedCount = 0;
  let hasNetworkError = false;

  try {
    for (const item of queue) {
      let currentVersion = typeof getVersion === 'function' ? getVersion() : 0;
      let attempt = 0;
      let success = false;

      while (attempt < 2 && !success) {
        attempt++;
        try {
          const res = await api('/action', {
            action: item.action,
            payload: item.payload,
            version: currentVersion,
            service: item.service
          });

          if (res && res.workspace) {
            if (typeof adopt === 'function') {
              adopt(res);
            }
            if (res.version !== undefined && typeof setVersion === 'function') {
              setVersion(res.version);
            }
            await removePendingSyncItem(item.syncId);
            syncedCount++;
            success = true;
          }
        } catch (err) {
          // Check for 409 Conflict (version mismatch from concurrent/stale state)
          if (err.status === 409) {
            console.log('[SyncEngine] Version conflict detected (409). Fetching latest server state...');
            try {
              const fresh = await api('/me');
              if (fresh) {
                if (typeof adopt === 'function') adopt(fresh);
                if (fresh.version !== undefined) {
                  currentVersion = fresh.version;
                  if (typeof setVersion === 'function') setVersion(fresh.version);
                }
              }
            } catch (refreshErr) {
              // Could not refresh version, stop this attempt
              break;
            }
          } else if (
            err.name === 'AbortError' ||
            (err.message && (
              err.message.includes('Cannot reach') ||
              err.message.includes('Network request failed') ||
              err.message.includes('Failed to fetch')
            ))
          ) {
            // Still offline — pause synchronization
            hasNetworkError = true;
            break;
          } else {
            // Other server error: record attempt, don't crash
            console.warn('[SyncEngine] Action sync failed:', item.action, err.message);
            // If bad request or already exists, remove from queue to avoid poisoning
            if (err.status === 400 || err.status === 404 || err.status === 422) {
              await removePendingSyncItem(item.syncId);
            }
            break;
          }
        }
      }

      if (hasNetworkError) {
        break;
      }
    }

    const remaining = await getPendingSyncCount();
    if (syncedCount > 0 && typeof notify === 'function') {
      const msg = appLang === 'te'
        ? `${syncedCount} ఆఫ్‌లైన్ మార్పులు సర్వర్‌తో సింక్ చేయబడ్డాయి`
        : (appLang === 'hi'
            ? `${syncedCount} ऑफ़लाइन परिवर्तन सिंक किए गए`
            : `${syncedCount} offline item(s) synchronized with server`);
      notify(msg);
    }

    const finalStatus = remaining > 0 ? (hasNetworkError ? 'offline' : 'pending') : 'synced';
    notifySyncStatus({ status: finalStatus, pendingCount: remaining });

    return {
      success: !hasNetworkError,
      count: syncedCount,
      remaining
    };
  } finally {
    isSyncing = false;
  }
}
