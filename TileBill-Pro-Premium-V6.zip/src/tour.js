import React, { useState, useEffect, useRef } from 'react';
import { View, ScrollView, Pressable, Animated, Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { T, I, Button, Card, Badge, C, s, BrandAvatar } from './ui';

export const TOUR_STORAGE_KEY = '@tb_guided_tour_seen_v6';

export const tourLanguages = [
  { id: 'te', label: 'తెలుగు', name: 'Telugu', badge: 'వాయిస్ గైడ్', speechLang: 'te-IN' },
  { id: 'en', label: 'English', name: 'English', badge: 'Audio Guide', speechLang: 'en-IN' },
  { id: 'hi', label: 'हिन्दी', name: 'Hindi', badge: 'ऑडियो गाइड', speechLang: 'hi-IN' }
];

export function speakTourText(text, lang = 'te', onStart, onEnd) {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    if (onStart) onStart();
    setTimeout(() => { if (onEnd) onEnd(); }, 3500);
    return null;
  }
  try {
    window.speechSynthesis.cancel();
    // Normalize text for cleaner pronunciation
    const clean = text
      .replace(/₹/g, lang === 'te' ? ' రూపాయలు ' : lang === 'hi' ? ' रुपये ' : ' rupees ')
      .replace(/sq\.ft/gi, lang === 'te' ? ' చదరపు అడుగులు ' : lang === 'hi' ? ' स्क्वायर फीट ' : ' square feet ')
      .replace(/cu\.ft/gi, lang === 'te' ? ' ఘనపు అడుగులు ' : lang === 'hi' ? ' क्यूबिक फीट ' : ' cubic feet ')
      .replace(/TB-\d+/g, m => m.replace('-', ' '));

    const utterance = new SpeechSynthesisUtterance(clean);
    utterance.lang = lang === 'te' ? 'te-IN' : lang === 'hi' ? 'hi-IN' : 'en-IN';
    utterance.rate = 0.92;
    utterance.pitch = 1.0;

    // Pick a voice matching locale if available
    const voices = window.speechSynthesis.getVoices?.() || [];
    const targetVoice = voices.find(v => v.lang && v.lang.startsWith(utterance.lang)) ||
      voices.find(v => v.lang && v.lang.startsWith(lang));
    if (targetVoice) utterance.voice = targetVoice;

    utterance.onstart = () => { if (onStart) onStart(); };
    utterance.onend = () => { if (onEnd) onEnd(); };
    utterance.onerror = () => { if (onEnd) onEnd(); };

    window.speechSynthesis.speak(utterance);
    return utterance;
  } catch (err) {
    if (onEnd) onEnd();
    return null;
  }
}

export function stopTourSpeech() {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    try { window.speechSynthesis.cancel(); } catch {}
  }
}

export const tourSteps = [
  {
    step: 0,
    icon: 'language-outline',
    eyebrow: {
      te: 'భాష ఎంపిక · PREFERRED LANGUAGE',
      en: 'WELCOME · PREFERRED LANGUAGE',
      hi: 'भाषा चयन · PREFERRED LANGUAGE'
    },
    title: {
      te: 'మీకు అనుకూలమైన భాషను ఎంచుకోండి',
      en: 'Choose your preferred language',
      hi: 'अपनी पसंदीदा भाषा चुनें'
    },
    subtitle: {
      te: 'యాప్ లో ప్రతి దశను స్పష్టమైన వాయిస్‌ఓవర్ తో సులభంగా నేర్చుకోండి.',
      en: 'Listen to clear voiceover instructions explaining every feature.',
      hi: 'स्पष्ट वॉइस-ओवर के साथ ऐप के हर फीचर को आसानी से समझें।'
    },
    speech: {
      te: 'TileBill Pro కి స్వాగతం! మీకు నచ్చిన భాషను ఎంచుకోండి. తెలుగు, ఇంగ్లీష్ లేదా హిందీలో యాప్ ఉపయోగించే పూర్తి విధానాన్ని వివరంగా చూద్దాం. క్రింద ఉన్న తర్వాత బటన్ నొక్కండి.',
      en: 'Welcome to TileBill Pro! Please select your preferred language. Let us show you step by step how to create professional bills and share them. Tap Next to continue.',
      hi: 'TileBill Pro में आपका स्वागत है! कृपया अपनी पसंदीदा भाषा चुनें। आइए देखें कि पेशेवर बिल कैसे बनाएं और ग्राहकों को कैसे भेजें। आगे बढ़ने के लिए अगला बटन दबाएं।'
    }
  },
  {
    step: 1,
    icon: 'shield-checkmark-outline',
    eyebrow: {
      te: 'దశ 1/5 · బిజినెస్ ప్రొఫైల్ & లోగో',
      en: 'STEP 1/5 · BUSINESS IDENTITY',
      hi: 'चरण 1/5 · व्यापार प्रोफाइल और लोगो'
    },
    title: {
      te: 'కంపెనీ పేరు, లగ్జరీ క్రెస్ట్ & UPI ID',
      en: 'Business name, luxury crest & UPI ID',
      hi: 'कंपनी का नाम, लक्जरी क्रेस्ट और UPI ID'
    },
    subtitle: {
      te: 'లోగో లేకపోయినా మీ కంపెనీ పేరుతో అందమైన రాయల్ మోనోగ్రామ్ క్రెస్ట్ ఆటోమేటిక్‌గా తయారవుతుంది.',
      en: 'If you have no logo, TileBill automatically creates a gold monogram crest from your business name.',
      hi: 'यदि लोगो नहीं है, तो आपके नाम से एक शानदार गोल्ड मोनोग्राम क्रेस्ट अपने आप तैयार हो जाता है।'
    },
    speech: {
      te: 'మొదటి దశ: మీ వ్యాపార వివరాలు మరియు బ్రాండ్ లోగో. సెట్టింగ్స్‌లో మీ కంపెనీ పేరు, ఫోన్ నంబర్ నమోదు చేయండి. లోగో లేకపోతే మీ వ్యాపార పేరుతోనే అందమైన గోల్డ్ మోనోగ్రామ్ క్రెస్ట్‌ను యాప్ ఆటోమేటిక్‌గా తయారు చేస్తుంది. అలాగే మీ UPI ID సెట్ చేసుకుంటే బిల్లుపై స్కాన్ అండ్ పే కోడ్ ప్రింట్ అవుతుంది.',
      en: 'Step 1: Set up your business name, phone number, and logo. If you do not have a logo, TileBill automatically creates a luxury gold monogram crest from your company initials. Adding your UPI ID prints an instant payment code on every invoice.',
      hi: 'पहला चरण: अपने व्यापार का नाम, फोन और लोगो सेट करें। यदि आपके पास लोगो नहीं है, तो TileBill अपने आप एक लक्जरी गोल्ड मोनोग्राम क्रेस्ट तैयार करता है। साथ ही अपनी UPI ID सेट करें ताकि ग्राहक तुरंत स्कैन करके भुगतान कर सकें।'
    }
  },
  {
    step: 2,
    icon: 'calculator-outline',
    eyebrow: {
      te: 'దశ 2/5 · మల్టీ-డాష్‌బోర్డ్ & కొలతల ల్యాబ్',
      en: 'STEP 2/5 · MULTI-DASHBOARD & MEASUREMENTS',
      hi: 'चरण 2/5 · मल्टी-डैशबोर्ड और माप लैब'
    },
    title: {
      te: 'ఫైనాన్స్ హబ్ & లైవ్ కొలతల కాలిక్యులేటర్',
      en: 'Finance hub & trade measurement lab',
      hi: 'फाइनेंस हब और लाइव माप कैलकुलेटर'
    },
    subtitle: {
      te: 'పొడవు, వెడల్పు ఎంటర్ చేయగానే చదరపు అడుగులు, బ్రాస్ మరియు మొత్తం ధర క్షణాల్లో లెక్కించబడుతుంది.',
      en: 'Enter length and width to instantly calculate square feet, brass, and total billing amount.',
      hi: 'लंबाई और चौड़ाई दर्ज करते ही स्क्वायर फीट, ब्रास और कुल राशि तुरंत तैयार हो जाती है।'
    },
    speech: {
      te: 'రెండవ దశ: మల్టీ-డాష్‌బోర్డ్. హోమ్ స్క్రీన్‌లో మూడు భాగాలు ఉంటాయి. ఫైనాన్స్ హబ్‌లో వచ్చిన నగదు, రావాల్సిన బాకీలు కనిపిస్తాయి. మెజర్‌మెంట్ ల్యాబ్‌లో టైల్స్, నిర్మాణం లేదా పెయింటింగ్ పనుల పొడవు, వెడల్పు నమోదు చేయగానే స్క్వేర్ ఫీట్ మరియు బ్రాస్ లెక్కలు క్షణాల్లో సిద్ధమవుతాయి. అక్కడి నుంచే నేరుగా బిల్లు చేయవచ్చు.',
      en: 'Step 2: Explore the Multi-Dashboard. The Finance Hub shows money collected and pending dues. The Measurement Lab calculates Square Feet, Running Feet, and Brass instantly from length and width, letting you create a bill with one tap.',
      hi: 'दूसरा चरण: मल्टी-डैशबोर्ड को समझें। फाइनेंस हब में आया हुआ पैसा और बाकी बकाया दिखता है। मेजरमेंट लैब में लंबाई और चौड़ाई डालते ही स्क्वायर फीट और ब्रास का हिसाब तुरंत तैयार होता है, जिससे आप एक क्लिक में बिल बना सकते हैं।'
    }
  },
  {
    step: 3,
    icon: 'document-text-outline',
    eyebrow: {
      te: 'దశ 3/5 · ఇన్వాయిస్ & కొటేషన్ సృష్టి',
      en: 'STEP 3/5 · CREATING BILLS & ESTIMATES',
      hi: 'चरण 3/5 · बिल और कोटेशन निर्माण'
    },
    title: {
      te: 'కస్టమర్ ఎంపిక & ఐటెమ్స్ జోడించడం',
      en: 'Select customer & add items with quantity × rate',
      hi: 'ग्राहक चुनें और मात्रा × दर के साथ आइटम जोड़ें'
    },
    subtitle: {
      te: 'ఐటెమ్ పేరు, కొలత లేదా సంఖ్య, రేటు నమోదు చేయండి. డిస్కౌంట్, ట్యాక్స్ ఆటోమేటిక్‌గా లెక్కించబడతాయి.',
      en: 'Add items with quantity and rate, specify labour or material basis. Discounts & taxes calculate automatically.',
      hi: 'आइटम का नाम, मात्रा और दर दर्ज करें। लेबर या मटेरियल आधार चुनें। कुल राशि तुरंत तैयार हो जाएगी।'
    },
    speech: {
      te: 'మూడవ దశ: కొత్త బిల్లు లేదా కొటేషన్. ప్లస్ న్యూ బిల్ పై నొక్కి కస్టమర్‌ను ఎంచుకోండి. ఆపై ఐటెమ్ పేరు, కొలత లేదా సంఖ్య, మరియు రేటు ఇవ్వండి. మెటీరియల్ తోనా లేదా లేబర్ మాత్రమేనా అనేది ఎంచుకోవచ్చు. డిస్కౌంట్ మరియు ట్యాక్స్ ఆటోమేటిక్‌గా లెక్కించబడతాయి.',
      en: 'Step 3: Tap New Bill to begin. Select or add a customer, enter items with quantity and rate, and choose labour or material scope. Discounts and taxes are calculated automatically.',
      hi: 'तीसरा चरण: नया बिल या कोटेशन बनाएं। न्यू बिल पर टैप करें, ग्राहक चुनें, आइटम की मात्रा और दर दर्ज करें। लेबर या मटेरियल आधार चुनें। कुल राशि तुरंत तैयार हो जाएगी।'
    }
  },
  {
    step: 4,
    icon: 'color-palette-outline',
    eyebrow: {
      te: 'దశ 4/5 · డిజైన్ టెంప్లేట్‌లు & ప్రింట్ సైజులు',
      en: 'STEP 4/5 · 6 LUXURY DESIGNS & PAGE SIZES',
      hi: 'चरण 4/5 · 6 लक्जरी डिजाइन और पेपर साइज'
    },
    title: {
      te: '6 రాయల్ ఇన్వాయిస్ థీమ్స్ & A4, A5, థర్మల్ సైజులు',
      en: '6 executive templates & A4, A5, thermal sizes',
      hi: '6 एग्जीक्यूटिव डिजाइन और A4, A5, थर्मल साइज'
    },
    subtitle: {
      te: 'ఎగ్జిక్యూటివ్ నేవీ, లగ్జరీ ఎమరాల్డ్, మోడ్రన్ స్లేట్ వంటి థీమ్స్ మరియు మీ ప్రింటర్‌కు తగిన పేపర్ సైజు ఎంచుకోండి.',
      en: 'Choose Executive Corporate, Luxury Emerald, Modern Minimalist themes and fit standard A4 or 80mm thermal slips.',
      hi: 'कॉर्पोरेट नेवी, लक्जरी एमराल्ड जैसे थीम चुनें और अपने प्रिंटर के अनुसार A4, A5 या 80mm थर्मल स्लिप चुनें।'
    },
    speech: {
      te: 'నాల్గవ దశ: ఇన్వాయిస్ డిజైన్ మరియు పేపర్ సైజు. మీ బిల్లు రాయల్ గా కనిపించేలా ఎగ్జిక్యూటివ్, లగ్జరీ ఎమరాల్డ్, మోడ్రన్ వంటి ఆరు రకాల థీమ్స్ ఉన్నాయి. అలాగే మీ ప్రింటర్‌కు తగినట్లుగా A4, చిన్న A5, లేదా థర్మల్ 80 ఎంఎం స్లిప్ సైజును ఎంచుకోవచ్చు.',
      en: 'Step 4: Choose your invoice theme and paper size. Select from 6 executive styles like Corporate Navy, Luxury Emerald, or Modern Minimalist. Choose A4 for full pages, A5 for compact sheets, or 80mm thermal for instant slips.',
      hi: 'चौथा चरण: इनवॉइस डिज़ाइन और पेपर साइज चुनें। 6 एग्जीक्यूटिव डिज़ाइनों में से चुनें जैसे कॉर्पोरेट नेवी या लक्जरी एमराल्ड। फुल पेज के लिए A4, छोटे साइज के लिए A5, या थर्मल 80mm स्लिप आसानी से चुनें।'
    }
  },
  {
    step: 5,
    icon: 'logo-whatsapp',
    eyebrow: {
      te: 'దశ 5/5 · పీడీఎఫ్ ప్రింట్ & వాట్సాప్ షేరింగ్',
      en: 'STEP 5/5 · PDF PRINT & WHATSAPP SHARING',
      hi: 'चरण 5/5 · पीडीएफ प्रिंट और व्हाट्सएप शेयरिंग'
    },
    title: {
      te: 'అధికారిక డిజిటల్ సంతకం, UPI పే & వాట్సాప్ మెసేజ్',
      en: 'Verified digital signature, UPI & 1-tap WhatsApp',
      hi: 'सत्यापित डिजिटल हस्ताक्षर, UPI और व्हाट्सएप शेयर'
    },
    subtitle: {
      te: 'PDF / Print పై క్లిక్ చేయండి. లేదా Share Bill ద్వారా నేరుగా కస్టమర్ వాట్సాప్‌కు పూర్తి వివరాల లింక్ పంపండి.',
      en: 'Tap PDF / Print for verified documents, or Share Bill to send an instant summary directly to customer WhatsApp.',
      hi: 'सत्यापित बिल के लिए PDF / Print दबाएं, या Share Bill द्वारा सीधे ग्राहक के व्हाट्सएप पर लिंक भेजें।'
    },
    speech: {
      te: 'ఐదవ దశ: పీడీఎఫ్ ప్రింట్ మరియు వాట్సాప్ షేరింగ్. పీడీఎఫ్ ప్రింట్ పై క్లిక్ చేస్తే మీ డిజిటల్ సంతకం మరియు యూపీఐ క్యూఆర్ తో పూర్తి బిల్లు వస్తుంది. అలాగే షేర్ బిల్ బటన్ నొక్కితే నేరుగా కస్టమర్ వాట్సాప్‌కు పూర్తి వివరాలతో కూడిన మెసేజ్ క్షణాల్లో వెళ్లిపోతుంది. ఇప్పుడే మీ మొదటి బిల్లు తయారు చేసుకోండి!',
      en: 'Final Step: Tap PDF / Print to generate an official document with your verified signature and UPI QR code. Then tap Share Bill to send the formatted invoice and view link directly to your customer WhatsApp in one tap! Start billing now.',
      hi: 'अंतिम चरण: PDF / Print पर टैप करके सत्यापित हस्ताक्षर और UPI कोड के साथ बिल प्रिंट करें। फिर Share Bill दबाकर सीधे ग्राहक के व्हाट्सएप पर पूरा बिल और लिंक तुरंत भेजें! अब बिल बनाना शुरू करें।'
    }
  }
];

export function GuidedAudioTour({ visible, onClose, onStartBilling, defaultLang = 'te' }) {
  const [lang, setLang] = useState(defaultLang);
  const [stepIndex, setStepIndex] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [muted, setMuted] = useState(false);

  // Pulse wave animation for audio feedback
  const waveAnim = useRef(new Animated.Value(0.4)).current;

  useEffect(() => {
    if (isSpeaking && !muted) {
      const loop = Animated.loop(
        Animated.sequence([
          Animated.timing(waveAnim, { toValue: 1, duration: 400, useNativeDriver: true }),
          Animated.timing(waveAnim, { toValue: 0.35, duration: 400, useNativeDriver: true })
        ])
      );
      loop.start();
      return () => loop.stop();
    } else {
      waveAnim.setValue(0.4);
    }
  }, [isSpeaking, muted]);

  // Handle step speaking
  useEffect(() => {
    if (!visible) {
      stopTourSpeech();
      setIsSpeaking(false);
      return;
    }
    const current = tourSteps[stepIndex];
    if (!muted && current?.speech?.[lang]) {
      speakTourText(
        current.speech[lang],
        lang,
        () => setIsSpeaking(true),
        () => setIsSpeaking(false)
      );
    } else {
      setIsSpeaking(false);
    }
    return () => {
      stopTourSpeech();
      setIsSpeaking(false);
    };
  }, [visible, stepIndex, lang, muted]);

  if (!visible) return null;

  const currentStep = tourSteps[stepIndex];
  const isLast = stepIndex === tourSteps.length - 1;

  const handleNext = () => {
    if (isLast) {
      handleComplete();
    } else {
      setStepIndex(stepIndex + 1);
    }
  };

  const handleBack = () => {
    if (stepIndex > 0) setStepIndex(stepIndex - 1);
  };

  const handleComplete = async () => {
    stopTourSpeech();
    try { await AsyncStorage.setItem(TOUR_STORAGE_KEY, 'seen'); } catch {}
    onClose();
    if (onStartBilling) onStartBilling();
  };

  const handleSkip = async () => {
    stopTourSpeech();
    try { await AsyncStorage.setItem(TOUR_STORAGE_KEY, 'seen'); } catch {}
    onClose();
  };

  const replayVoice = () => {
    if (currentStep?.speech?.[lang]) {
      speakTourText(
        currentStep.speech[lang],
        lang,
        () => setIsSpeaking(true),
        () => setIsSpeaking(false)
      );
    }
  };

  return (
    <View style={{
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(15, 23, 42, 0.72)',
      justifyContent: 'center',
      alignItems: 'center',
      padding: 14,
      zIndex: 9999
    }}>
      <View style={{
        backgroundColor: 'white',
        borderRadius: 18,
        maxWidth: 500,
        width: '100%',
        maxHeight: '92%',
        borderWidth: 1,
        borderColor: '#E2E8F0',
        elevation: 24,
        shadowColor: '#0F172A',
        shadowOffset: { width: 0, height: 12 },
        shadowOpacity: 0.22,
        shadowRadius: 20,
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column'
      }}>
        {/* Header Bar */}
        <View style={{
          backgroundColor: '#0F172A',
          paddingHorizontal: 16,
          paddingVertical: 12,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
          borderBottomWidth: 1,
          borderColor: '#1E293B'
        }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <View style={{
              width: 32,
              height: 32,
              borderRadius: 8,
              backgroundColor: '#2563EB',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <I name="headset-outline" size={17} color="white" />
            </View>
            <View>
              <T style={{ color: 'white', fontWeight: '700', fontSize: 13.5 }}>
                TileBill Pro · Audio Tour
              </T>
              <T style={{ color: '#94A3B8', fontSize: 11 }}>
                {tourLanguages.find(l => l.id === lang)?.badge || 'Guide'}
              </T>
            </View>
          </View>

          {/* Language Switcher Pills */}
          <View style={{ flexDirection: 'row', gap: 4, alignItems: 'center' }}>
            {tourLanguages.map(l => (
              <Pressable
                key={l.id}
                onPress={() => setLang(l.id)}
                style={{
                  paddingHorizontal: 9,
                  paddingVertical: 4,
                  borderRadius: 6,
                  backgroundColor: lang === l.id ? '#2563EB' : '#1E293B',
                  borderWidth: 1,
                  borderColor: lang === l.id ? '#60A5FA' : '#334155'
                }}
              >
                <T style={{
                  color: 'white',
                  fontSize: 11.5,
                  fontWeight: lang === l.id ? '700' : '400'
                }}>
                  {l.label}
                </T>
              </Pressable>
            ))}

            <Pressable
              onPress={handleSkip}
              accessibilityLabel="Close tour"
              style={{
                width: 32,
                height: 32,
                borderRadius: 16,
                backgroundColor: '#1E293B',
                alignItems: 'center',
                justifyContent: 'center',
                marginLeft: 4
              }}
            >
              <I name="close" size={18} color="#CBD5E1" />
            </Pressable>
          </View>
        </View>

        {/* Live Audio Status Strip */}
        <View style={{
          backgroundColor: isSpeaking ? '#EFF6FF' : '#F8FAFC',
          borderBottomWidth: 1,
          borderColor: isSpeaking ? '#BFDBFE' : '#E2E8F0',
          paddingHorizontal: 16,
          paddingVertical: 7,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between'
        }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 7, flex: 1, minWidth: 0 }}>
            {isSpeaking && !muted ? (
              <Animated.View style={{ flexDirection: 'row', gap: 2, alignItems: 'center', opacity: waveAnim }}>
                <View style={{ width: 3, height: 12, backgroundColor: '#2563EB', borderRadius: 2 }} />
                <View style={{ width: 3, height: 16, backgroundColor: '#2563EB', borderRadius: 2 }} />
                <View style={{ width: 3, height: 8, backgroundColor: '#2563EB', borderRadius: 2 }} />
              </Animated.View>
            ) : (
              <I name="volume-medium-outline" size={16} color="#64748B" />
            )}
            <T numberOfLines={1} style={{
              fontSize: 12,
              fontWeight: '600',
              color: isSpeaking ? '#1E40AF' : '#64748B'
            }}>
              {isSpeaking && !muted
                ? (lang === 'te' ? 'వాయిస్‌ఓవర్ చదువుతోంది...' : lang === 'hi' ? 'ऑडियो वॉइस-ओवर चल रहा है...' : 'Playing voiceover...')
                : (lang === 'te' ? 'వాయిస్ గైడ్ సిద్ధంగా ఉంది' : lang === 'hi' ? 'वॉइस गाइड तैयार है' : 'Audio guide ready')}
            </T>
          </View>

          <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center' }}>
            <Pressable
              onPress={replayVoice}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                gap: 4,
                paddingHorizontal: 8,
                paddingVertical: 4,
                borderRadius: 6,
                backgroundColor: 'white',
                borderWidth: 1,
                borderColor: '#CBD5E1'
              }}
            >
              <I name="refresh" size={13} color="#2563EB" />
              <T style={{ fontSize: 11, fontWeight: '600', color: '#2563EB' }}>
                {lang === 'te' ? 'మళ్లీ వినండి' : lang === 'hi' ? 'पुनः सुनें' : 'Replay'}
              </T>
            </Pressable>

            <Pressable
              onPress={() => {
                if (!muted) stopTourSpeech();
                setMuted(!muted);
              }}
              style={{
                width: 28,
                height: 28,
                borderRadius: 6,
                backgroundColor: 'white',
                borderWidth: 1,
                borderColor: '#CBD5E1',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              <I name={muted ? 'volume-mute-outline' : 'volume-high-outline'} size={14} color={muted ? '#EF4444' : '#64748B'} />
            </Pressable>
          </View>
        </View>

        {/* Content Body */}
        <ScrollView contentContainerStyle={{ padding: 18 }} style={{ flexGrow: 1 }}>
          {/* Eyebrow & Step Indicator */}
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
            <Badge tone="blue">{currentStep.eyebrow[lang] || currentStep.eyebrow.te}</Badge>
            <View style={{ flexDirection: 'row', gap: 4 }}>
              {tourSteps.map((s, idx) => (
                <View
                  key={s.step}
                  style={{
                    width: idx === stepIndex ? 16 : 6,
                    height: 6,
                    borderRadius: 3,
                    backgroundColor: idx === stepIndex ? '#2563EB' : '#CBD5E1'
                  }}
                />
              ))}
            </View>
          </View>

          {/* Step Title & Subtitle */}
          <T style={{ fontSize: 18, fontWeight: '700', color: '#0F172A', marginTop: 4, lineHeight: 24 }}>
            {currentStep.title[lang] || currentStep.title.te}
          </T>
          <T style={{ fontSize: 13, color: '#64748B', marginTop: 4, lineHeight: 18 }}>
            {currentStep.subtitle[lang] || currentStep.subtitle.te}
          </T>

          {/* Step Visual Interactive Showcase */}
          <View style={{
            backgroundColor: '#F8FAFC',
            borderRadius: 12,
            borderWidth: 1,
            borderColor: '#E2E8F0',
            padding: 12,
            marginVertical: 14
          }}>
            {stepIndex === 0 && (
              <View style={{ gap: 8 }}>
                <T style={{ fontSize: 11.5, fontWeight: '600', color: '#64748B', letterSpacing: 0.5 }}>
                  {lang === 'te' ? 'మీ భాషను ఎంచుకోండి' : lang === 'hi' ? 'अपनी भाषा चुनें' : 'SELECT LANGUAGE'}
                </T>
                {tourLanguages.map(l => (
                  <Pressable
                    key={l.id}
                    onPress={() => setLang(l.id)}
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: 10,
                      borderRadius: 10,
                      backgroundColor: lang === l.id ? '#EFF6FF' : 'white',
                      borderWidth: 1,
                      borderColor: lang === l.id ? '#3B82F6' : '#E2E8F0'
                    }}
                  >
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 9 }}>
                      <View style={{
                        width: 32,
                        height: 32,
                        borderRadius: 16,
                        backgroundColor: lang === l.id ? '#2563EB' : '#F1F5F9',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}>
                        <T style={{ fontSize: 13, fontWeight: '700', color: lang === l.id ? 'white' : '#475569' }}>
                          {l.id.toUpperCase()}
                        </T>
                      </View>
                      <View>
                        <T style={{ fontSize: 14, fontWeight: '700', color: '#0F172A' }}>{l.label}</T>
                        <T style={{ fontSize: 11.5, color: '#64748B' }}>{l.name} · {l.badge}</T>
                      </View>
                    </View>
                    {lang === l.id ? (
                      <I name="checkmark-circle" size={20} color="#2563EB" />
                    ) : (
                      <I name="chevron-forward" size={17} color="#94A3B8" />
                    )}
                  </Pressable>
                ))}
              </View>
            )}

            {stepIndex === 1 && (
              <View style={{ gap: 8 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                  <BrandAvatar name="Sri Lakshmi Contractors" size={44} />
                  <View style={{ flex: 1 }}>
                    <T style={{ fontWeight: '700', fontSize: 14.5 }}>Sri Lakshmi Contractors</T>
                    <T style={{ fontSize: 11.5, color: '#D97706', fontWeight: '600' }}>
                      {lang === 'te' ? 'ఆటో-జనరేటెడ్ గోల్డ్ క్రెస్ట్ మోనోగ్రామ్' : lang === 'hi' ? 'ऑटो-गोल्ड मोनोग्राम क्रेस्ट' : 'Auto-generated Gold Monogram Crest'}
                    </T>
                    <T style={{ fontSize: 11.5, color: '#64748B' }}>UPI: contractor@oksbi</T>
                  </View>
                </View>
                <View style={{
                  backgroundColor: 'white',
                  borderRadius: 8,
                  padding: 8,
                  borderWidth: 1,
                  borderColor: '#E2E8F0',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}>
                  <T style={{ fontSize: 11.5, color: '#475569' }}>
                    {lang === 'te' ? 'డిజిటల్ సంతకం & సీల్' : lang === 'hi' ? 'डिजिटल हस्ताक्षर और मुहर' : 'Digital Signature & Stamp'}
                  </T>
                  <Badge tone="green">
                    {lang === 'te' ? 'ధృవీకరించబడింది' : lang === 'hi' ? 'सत्यापित' : 'Verified'}
                  </Badge>
                </View>
              </View>
            )}

            {stepIndex === 2 && (
              <View style={{ gap: 8 }}>
                <View style={{ flexDirection: 'row', gap: 6 }}>
                  {['Billing & Finance', 'Measurement Lab', 'Sites & Labour'].map((t, idx) => (
                    <View
                      key={t}
                      style={{
                        flex: 1,
                        paddingVertical: 5,
                        borderRadius: 6,
                        backgroundColor: idx === 1 ? '#2563EB' : 'white',
                        borderWidth: 1,
                        borderColor: idx === 1 ? '#2563EB' : '#E2E8F0',
                        alignItems: 'center'
                      }}
                    >
                      <T style={{
                        fontSize: 10.5,
                        fontWeight: '700',
                        color: idx === 1 ? 'white' : '#64748B'
                      }}>
                        {t}
                      </T>
                    </View>
                  ))}
                </View>
                <View style={{
                  backgroundColor: 'white',
                  borderRadius: 8,
                  padding: 10,
                  borderWidth: 1,
                  borderColor: '#E2E8F0'
                }}>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 }}>
                    <T style={{ fontSize: 12, color: '#64748B' }}>Length 10 ft × Width 12 ft</T>
                    <T style={{ fontSize: 12, fontWeight: '700', color: '#0F172A' }}>120 sq.ft</T>
                  </View>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                    <T style={{ fontSize: 12, color: '#64748B' }}>Rate ₹45.00 / sq.ft</T>
                    <T style={{ fontSize: 14, fontWeight: '700', color: '#2563EB' }}>₹5,400.00</T>
                  </View>
                </View>
              </View>
            )}

            {stepIndex === 3 && (
              <View style={{ gap: 8 }}>
                <View style={{
                  backgroundColor: 'white',
                  borderRadius: 8,
                  padding: 10,
                  borderWidth: 1,
                  borderColor: '#E2E8F0'
                }}>
                  <T style={{ fontSize: 11, color: '#64748B', fontWeight: '600' }}>CUSTOMER</T>
                  <T style={{ fontSize: 13.5, fontWeight: '700', color: '#0F172A' }}>Ravi Kumar · Kakinada</T>
                  <View style={{ height: 1, backgroundColor: '#E2E8F0', marginVertical: 6 }} />
                  <T style={{ fontSize: 11, color: '#64748B', fontWeight: '600' }}>ITEMS</T>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 2 }}>
                    <T style={{ fontSize: 12.5, color: '#0F172A' }}>1. Floor tile laying (1200 sq.ft × ₹45)</T>
                    <T style={{ fontSize: 13, fontWeight: '700', color: '#0F172A' }}>₹54,000</T>
                  </View>
                </View>
              </View>
            )}

            {stepIndex === 4 && (
              <View style={{ gap: 8 }}>
                <T style={{ fontSize: 11, color: '#64748B', fontWeight: '600' }}>6 SELECTABLE TEMPLATES</T>
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
                  {[
                    ['Executive Navy', '#1e3a8a'],
                    ['Luxury Emerald', '#065f46'],
                    ['Fintech Indigo', '#4338ca'],
                    ['Modern Slate', '#334155'],
                    ['Industrial Graphite', '#18181b'],
                    ['Compact Slip', '#0f172a']
                  ].map(([name, color]) => (
                    <View
                      key={name}
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        gap: 5,
                        backgroundColor: 'white',
                        paddingHorizontal: 8,
                        paddingVertical: 4,
                        borderRadius: 6,
                        borderWidth: 1,
                        borderColor: '#E2E8F0'
                      }}
                    >
                      <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: color }} />
                      <T style={{ fontSize: 10.5, fontWeight: '600', color: '#334155' }}>{name}</T>
                    </View>
                  ))}
                </View>
                <View style={{ flexDirection: 'row', gap: 6, marginTop: 4 }}>
                  {['A4 Full page', 'A5 Compact', 'Thermal 80mm'].map(p => (
                    <Badge key={p} tone="gray">{p}</Badge>
                  ))}
                </View>
              </View>
            )}

            {stepIndex === 5 && (
              <View style={{ gap: 8 }}>
                <View style={{
                  backgroundColor: '#25D366',
                  borderRadius: 10,
                  padding: 10,
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: 8
                }}>
                  <I name="logo-whatsapp" size={22} color="white" />
                  <View style={{ flex: 1 }}>
                    <T style={{ color: 'white', fontWeight: '700', fontSize: 13 }}>
                      {lang === 'te' ? 'కస్టమర్ వాట్సాప్‌కు క్షణాల్లో పంపండి' : lang === 'hi' ? 'सीधे व्हाट्सएप पर भेजें' : 'Share instantly to Customer WhatsApp'}
                    </T>
                    <T style={{ color: 'rgba(255,255,255,0.9)', fontSize: 11 }}>
                      {lang === 'te' ? 'పూర్తి బిల్లు వివరాలు & ఆన్‌లైన్ పేమెంట్ లింక్' : lang === 'hi' ? 'बिल विवरण और ऑनलाइन भुगतान लिंक' : 'Detailed summary, totals & PDF link'}
                    </T>
                  </View>
                </View>
              </View>
            )}
          </View>

          {/* Transcript Quote Box */}
          <View style={{
            backgroundColor: '#F1F5F9',
            borderRadius: 10,
            padding: 11,
            borderLeftWidth: 3,
            borderLeftColor: '#2563EB'
          }}>
            <T style={{ fontSize: 12.5, lineHeight: 18, color: '#334155' }}>
              "{currentStep.speech[lang] || currentStep.speech.te}"
            </T>
          </View>
        </ScrollView>

        {/* Bottom Actions Row */}
        <View style={{
          padding: 14,
          backgroundColor: 'white',
          borderTopWidth: 1,
          borderColor: '#E2E8F0',
          flexDirection: 'row',
          alignItems: 'center',
          gap: 10
        }}>
          {stepIndex > 0 ? (
            <Button
              secondary
              compact
              onPress={handleBack}
              style={{ minHeight: 46, paddingHorizontal: 14 }}
            >
              {lang === 'te' ? '← వెనుకకు' : lang === 'hi' ? '← पीछे' : '← Back'}
            </Button>
          ) : (
            <Button
              quiet
              compact
              onPress={handleSkip}
              style={{ minHeight: 46, paddingHorizontal: 12 }}
            >
              {lang === 'te' ? 'దాటవేయి' : lang === 'hi' ? 'छोड़ें' : 'Skip'}
            </Button>
          )}

          <Button
            icon={isLast ? 'rocket-outline' : 'arrow-forward'}
            onPress={handleNext}
            style={{
              flex: 1,
              minHeight: 46,
              backgroundColor: isLast ? '#059669' : '#2563EB'
            }}
          >
            {isLast
              ? (lang === 'te' ? '🚀 ఇప్పుడే బిల్లు తయారు చేయండి' : lang === 'hi' ? '🚀 अभी बिल बनाएं' : '🚀 Start Billing Now')
              : (lang === 'te' ? 'తర్వాత దశ →' : lang === 'hi' ? 'अगला चरण →' : 'Next Step →')}
          </Button>
        </View>
      </View>
    </View>
  );
}
