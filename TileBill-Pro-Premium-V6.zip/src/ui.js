import React,{useState,createContext,useContext,useId,useEffect,useRef} from 'react';
import {View,Text,TextInput,Pressable,ScrollView,Modal,StyleSheet,Platform,useWindowDimensions,Animated,AccessibilityInfo,KeyboardAvoidingView,Image} from 'react-native';
import {Ionicons} from '@expo/vector-icons';
import {matchOption} from './voice.cjs';
import {profiles} from './service.cjs';
import {services} from './domain.cjs';

export const C={
 ink:'#0F172A',
 muted:'#64748B',
 line:'#E2E8F0',
 bg:'#F8FAFC',
 blue:'#2563EB',
 gold:'#D97706',
 green:'#059669',
 red:'#DC2626',
 yellow:'#D97706',
 coral:'#EA580C',
 purple:'#7C3AED'
};

export const VoiceContext=createContext({start:()=>{},listening:false,field:null,fail:()=>{}});
export const I=({name,size=18,color=C.ink})=><Ionicons name={name} size={size} color={color}/>;

export const T=({children,style,...rest})=>{
 const flat=StyleSheet.flatten([s.text,style]);
 const content=Array.isArray(children)?children.filter(x=>typeof x==='string').join(''):typeof children==='string'?children:'';
 const telugu=/[\u0C00-\u0C7F]/.test(content);
 const weight=Number(flat.fontWeight)||400;
 const fontFamily=(telugu?'TBTelugu':'TBInter')+(weight>=700?'Bold':weight>=600?'Semi':'');
 const fontSize=flat.fontSize||13.5;
 const minLh=telugu?Math.ceil(fontSize*1.56):Math.ceil(fontSize*1.38);
 const lineHeight=flat.lineHeight?Math.max(flat.lineHeight,minLh):minLh;
 return <Text {...rest} style={[flat,{fontFamily,fontWeight:Platform.OS==='web'?String(weight):'normal',fontSize,lineHeight,...(telugu&&Platform.OS==='android'?{includeFontPadding:true,paddingVertical:1}:{})}]}>{children}</Text>;
};

export function Fade({children,change}){
 const a=useRef(new Animated.Value(1)).current;
 useEffect(()=>{
  let cancelled=false;
  AccessibilityInfo.isReduceMotionEnabled().then(reduce=>{
   if(cancelled||reduce)return;
   a.setValue(0);
   Animated.timing(a,{toValue:1,duration:180,useNativeDriver:true}).start();
  });
  return()=>{cancelled=true};
 },[change]);
 return <Animated.View style={{opacity:a}}>{children}</Animated.View>;
}

export function Button({children,onPress,icon,secondary,quiet,danger,compact,disabled,style,testID,accessibilityLabel}){
 const color=danger?C.red:secondary||quiet?C.ink:'white';
 const hasLabel=children!==undefined&&children!==null&&children!=='';
 const label=accessibilityLabel||(typeof children==='string'?children:icon==='close'?'Close':icon==='create-outline'?'Edit':icon==='trash-outline'?'Remove':undefined);
 return <Pressable testID={testID} accessibilityRole="button" accessibilityLabel={label} hitSlop={4} disabled={disabled} onPress={onPress} style={({pressed})=>[s.button,secondary&&s.secondary,quiet&&s.quiet,danger&&{backgroundColor:'#FEF2F2',borderColor:'#FCA5A5',borderWidth:1},compact&&{paddingHorizontal:9,paddingVertical:6,minHeight:40},(pressed||disabled)&&{opacity:.65},pressed&&{transform:[{scale:.985}]},style]}>
  {icon&&<I name={icon} size={compact?16:18} color={color}/>}
  {hasLabel&&<T style={[s.buttonText,secondary||quiet?{fontWeight:'500'}:null,{color}]}>{children}</T>}
 </Pressable>;
}

export function BrandAvatar({name='TileBill Pro',logo,size=42,rounded=true}){
 if(logo){
  return <Image source={{uri:logo}} style={{width:size,height:size,borderRadius:rounded?size/2:8,backgroundColor:'white',borderWidth:1,borderColor:'#E2E8F0'}} resizeMode="contain"/>;
 }
 const words=String(name||'TB').trim().split(/\s+/).filter(Boolean);
 const initials=(words.length>=2?words[0][0]+words[1][0]:words[0]?.slice(0,2)||'TB').toUpperCase();
 return <View style={{width:size,height:size,borderRadius:rounded?size/2:8,backgroundColor:'#0F172A',alignItems:'center',justifyContent:'center',borderWidth:1.5,borderColor:'#D97706',shadowColor:'#0F172A',shadowOffset:{width:0,height:2},shadowOpacity:.12,shadowRadius:4,elevation:3}}>
  <T style={{color:'#FFFFFF',fontSize:Math.round(size*0.38),fontWeight:'700',letterSpacing:0.8}}>{initials}</T>
 </View>;
}

export function MetricCard({title,subtitle,amount,tone='blue',icon,style}){
 const colors={
  blue:['#EFF6FF','#2563EB'],
  green:['#ECFDF5','#059669'],
  amber:['#FFFBEB','#D97706'],
  slate:['#F8FAFC','#0F172A']
 }[tone]||['#F8FAFC','#0F172A'];
 return <View style={[{backgroundColor:'white',borderRadius:10,borderWidth:1,borderColor:'#E2E8F0',padding:11,shadowColor:'#0F172A',shadowOffset:{width:0,height:1},shadowOpacity:.03,shadowRadius:3,elevation:1},style]}>
  <View style={{flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginBottom:4}}>
   <T style={{fontSize:10.5,fontWeight:'600',color:'#64748B',textTransform:'uppercase',letterSpacing:.4}}>{title}</T>
   {icon&&<View style={{width:22,height:22,borderRadius:6,backgroundColor:colors[0],alignItems:'center',justifyContent:'center'}}><I name={icon} size={13} color={colors[1]}/></View>}
  </View>
  <T adjustsFontSizeToFit numberOfLines={1} style={{fontSize:16,fontWeight:'700',color:'#0F172A',letterSpacing:-.3}}>{amount}</T>
  {!!subtitle&&<T numberOfLines={1} style={{fontSize:11,color:colors[1],marginTop:2,fontWeight:'500'}}>{subtitle}</T>}
 </View>;
}

// Clean VoiceScope with no floating mic clutter
const FocusContext=createContext({select:()=>{},release:()=>{},selected:null,nested:false});
export function VoiceScope({children,style}){
 return <FocusContext.Provider value={{select:()=>{},release:()=>{},selected:null,nested:true}}>
  <View style={[{position:'relative'},style]}>{children}</View>
 </FocusContext.Provider>;
}

export function Field({label,value,onChange,multiline,numeric,secret,placeholder,error,hint,style}){
 const isTelugu=/[\u0C00-\u0C7F]/.test(String(value||''));
 return <View style={[s.field,style]}>
  {!!label&&<T style={s.label}>{label}</T>}
  <View style={[s.inputWrap,multiline&&{alignItems:'flex-start'},!!error&&{borderColor:C.red,backgroundColor:'#FFFBFB'}]}>
   <TextInput accessibilityLabel={label||placeholder} placeholder={placeholder||label} placeholderTextColor="#94A3B8" value={String(value??'')} onChangeText={onChange} secureTextEntry={secret} keyboardType={numeric?'decimal-pad':'default'} autoCapitalize={secret?'none':'sentences'} multiline={multiline} style={[s.input,{fontFamily:isTelugu?'TBTelugu':'TBInter',lineHeight:isTelugu?23:19},multiline&&{minHeight:66,textAlignVertical:'top'}]}/>
  </View>
  {!!error&&<View style={{flexDirection:'row',alignItems:'center',gap:4,marginTop:3}}><I name="alert-circle-outline" size={14} color={C.red}/><T style={{fontSize:11.5,color:C.red,flex:1}}>{error}</T></View>}
  {!error&&!!hint&&<T style={{fontSize:11.5,color:C.muted,marginTop:3}}>{hint}</T>}
 </View>;
}

export function TradeBanner({service='tiles',compact,style}){
 const p=profiles[service]||profiles.tiles;
 const sItem=services.find(s=>s.id===service)||services[0];
 return <View style={[{backgroundColor:'#F8FAFC',borderWidth:1,borderColor:'#E2E8F0',borderRadius:10,paddingHorizontal:12,paddingVertical:compact?7:9,marginBottom:11,flexDirection:'row',alignItems:'center',gap:9},style]}>
  <View style={{width:32,height:32,borderRadius:8,backgroundColor:(p.color||'#2563EB')+'18',alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:(p.color||'#2563EB')+'30'}}>
   <I name={sItem?.icon||'grid-outline'} size={17} color={p.color||'#2563EB'}/>
  </View>
  <View style={{flex:1,minWidth:0}}>
   <View style={{flexDirection:'row',alignItems:'center',gap:6}}>
    <T numberOfLines={1} style={{fontSize:13,fontWeight:'700',color:C.ink}}>{p.title}</T>
    <T numberOfLines={1} style={{fontSize:11.5,fontWeight:'600',color:p.color||C.blue}}>· {p.te}</T>
   </View>
   <T numberOfLines={1} style={{fontSize:11,color:C.muted,marginTop:1}}>{p.teHint||p.hint}</T>
  </View>
  <Badge tone="blue">{p.units.split('·')[0].trim()}</Badge>
 </View>;
}

export function Select({label,value,options,onChange,style,error}){
 const [open,setOpen]=useState(false);
 const [search,setSearch]=useState('');
 const opts=options.map(x=>typeof x==='string'?{value:x,label:x}:x);
 const select=o=>{onChange(o.value);setOpen(false);setSearch('');};
 const activeItem=opts.find(x=>x.value===value);
 const activeLabel=activeItem?.label||'Choose / ఎంచుకోండి';
 const filteredOpts=search?opts.filter(x=>x.label.toLowerCase().includes(search.toLowerCase())):opts;

 return <View style={[s.field,style]}>
  {!!label&&<T style={s.label}>{label}</T>}
  <Pressable
   accessibilityRole="button"
   accessibilityLabel={label||'Select option'}
   onPress={()=>setOpen(true)}
   style={[
    s.inputWrap,
    {paddingHorizontal:11,paddingVertical:8,minHeight:42,flexDirection:'row',alignItems:'center',justifyContent:'space-between',gap:8,backgroundColor:'white'},
    open&&{borderColor:C.blue},
    !!error&&{borderColor:C.red}
   ]}
  >
   <T numberOfLines={1} style={{flex:1,fontSize:14,color:activeItem?C.ink:C.muted}}>
    {activeLabel}
   </T>
   <I name="chevron-down" size={17} color={C.muted}/>
  </Pressable>

  {/* Floating Premium Modal Popover - ZERO layout shifting! */}
  {open&&<Modal transparent visible={open} animationType="fade" onRequestClose={()=>setOpen(false)}>
   <Pressable
    onPress={()=>setOpen(false)}
    style={{flex:1,backgroundColor:'rgba(15,23,42,0.48)',justifyContent:'center',alignItems:'center',padding:16,zIndex:99999}}
   >
    <Pressable
     onPress={e=>e.stopPropagation?.()}
     style={{
      backgroundColor:'white',
      borderRadius:16,
      maxWidth:440,
      width:'100%',
      maxHeight:'80%',
      borderWidth:1,
      borderColor:'#CBD5E1',
      shadowColor:'#0F172A',
      shadowOffset:{width:0,height:10},
      shadowOpacity:0.25,
      shadowRadius:20,
      elevation:25,
      overflow:'hidden'
     }}
    >
     {/* Modal Header */}
     <View style={{paddingHorizontal:16,paddingVertical:12,borderBottomWidth:1,borderColor:C.line,flexDirection:'row',alignItems:'center',justifyContent:'space-between',backgroundColor:'#F8FAFC'}}>
      <View style={{flexDirection:'row',alignItems:'center',gap:7}}>
       <T style={{fontSize:14,fontWeight:'700',color:C.ink}}>{label||'Select option'}</T>
       <Badge tone="blue">{opts.length}</Badge>
      </View>
      <Pressable onPress={()=>setOpen(false)} style={{width:30,height:30,borderRadius:15,alignItems:'center',justifyContent:'center',backgroundColor:'#E2E8F0'}}>
       <I name="close" size={16} color={C.ink}/>
      </Pressable>
     </View>

     {/* Filter input if options > 6 */}
     {opts.length>6&&<View style={{paddingHorizontal:12,paddingVertical:8,borderBottomWidth:1,borderColor:'#F1F5F9'}}>
      <TextInput
       placeholder="Search options / వెతకండి..."
       placeholderTextColor="#94A3B8"
       value={search}
       onChangeText={setSearch}
       autoFocus
       style={{fontSize:13,paddingHorizontal:10,paddingVertical:7,backgroundColor:'#F1F5F9',borderRadius:8,color:C.ink}}
      />
     </View>}

     {/* Scrollable Options List */}
     <ScrollView keyboardShouldPersistTaps="handled" style={{maxHeight:320}}>
      {filteredOpts.map((x,i)=>(
       <Pressable
        key={i}
        accessibilityRole="button"
        onPress={()=>select(x)}
        style={({pressed})=>[{
         paddingHorizontal:16,
         paddingVertical:12,
         minHeight:46,
         flexDirection:'row',
         alignItems:'center',
         justifyContent:'space-between',
         backgroundColor:value===x.value?'#EFF6FF':pressed?'#F8FAFC':'white',
         borderBottomWidth:i<filteredOpts.length-1?1:0,
         borderColor:'#F1F5F9'
        }]}
       >
        <T style={{fontSize:13.5,fontWeight:value===x.value?'700':'400',color:value===x.value?C.blue:C.ink,flex:1}}>
         {x.label}
        </T>
        {value===x.value&&(
         <View style={{width:22,height:22,borderRadius:11,backgroundColor:C.blue,alignItems:'center',justifyContent:'center'}}>
          <I name="checkmark" size={14} color="white"/>
         </View>
        )}
       </Pressable>
      ))}
      {!filteredOpts.length&&<View style={{padding:20,alignItems:'center'}}><T style={{color:C.muted,fontSize:13}}>No matching options found</T></View>}
     </ScrollView>
    </Pressable>
   </Pressable>
  </Modal>}

  {!!error&&<View style={{flexDirection:'row',alignItems:'center',gap:4,marginTop:3}}><I name="alert-circle-outline" size={14} color={C.red}/><T style={{fontSize:11.5,color:C.red,flex:1}}>{error}</T></View>}
 </View>;
}

export function Badge({children,tone='green'}){
 const colors={green:['#ECFDF5',C.green],yellow:['#FFFBEB','#B45309'],blue:['#EFF6FF',C.blue],gray:['#F1F5F9',C.muted],red:['#FEF2F2',C.red],gold:['#FEF3C7','#B45309'],amber:['#FEF3C7','#D97706'],emerald:['#ECFDF5','#059669']}[tone]||['#F1F5F9',C.muted];
 return <View style={{backgroundColor:colors[0],borderRadius:6,paddingVertical:3,paddingHorizontal:7,alignSelf:'flex-start'}}><T style={{fontSize:11,fontWeight:'600',color:colors[1],letterSpacing:.2}}>{children}</T></View>;
}

export function Card({children,style}){return <View style={[s.card,style]}>{children}</View>}
export function Pair({children}){return <View style={{flexDirection:'row',gap:10,alignItems:'flex-start'}}>{React.Children.map(children,x=>x?<View style={{flex:1,minWidth:0}}>{x}</View>:null)}</View>;}
export function Heading({eyebrow,title,subtitle,action}){return <View style={[s.row,{marginBottom:12,alignItems:'flex-start',justifyContent:'space-between'}]}><View style={{flex:1,minWidth:180}}>{eyebrow&&<T style={s.eyebrow}>{eyebrow}</T>}<T style={s.title}>{title}</T>{subtitle&&<T style={{color:C.muted,fontSize:12.5,marginTop:3,lineHeight:17}}>{subtitle}</T>}</View>{action}</View>}
export function Empty({icon='file-tray-outline',title,body,action}){return <View style={{paddingVertical:22,paddingHorizontal:12,alignItems:'center',gap:8}}><View style={s.iconBox}><I name={icon} size={20} color={C.blue}/></View><T style={s.h3}>{title}</T><T style={{color:C.muted,fontSize:12.5,textAlign:'center',maxWidth:300,lineHeight:18}}>{body}</T>{action}</View>}

export function Sheet({title,subtitle,onClose,children,footer,wide}){
 const {width}=useWindowDimensions();
 const mobile=width<700;
 const scrollRef=useRef(null);
 useEffect(()=>{
  scrollRef.current?.scrollTo({y:0,animated:false});
 },[title]);
 return <Modal visible transparent animationType="fade" onRequestClose={onClose}>
  <KeyboardAvoidingView behavior={Platform.OS==='ios'?'padding':'height'} style={[s.overlay,mobile&&{justifyContent:'flex-end',paddingTop:0}]}>
   <View style={[s.sheet,{width:mobile?'100%':wide?660:540,maxWidth:mobile?'100%':'96%',maxHeight:mobile?'98%':'92%',borderBottomLeftRadius:mobile?0:14,borderBottomRightRadius:mobile?0:14}]}>
    <View style={[s.row,{paddingHorizontal:15,paddingVertical:11,borderBottomWidth:1,borderColor:C.line,flexWrap:'nowrap'}]}>
     <View style={{flex:1,minWidth:0}}>
      <T numberOfLines={1} style={s.title}>{title}</T>
      {!!subtitle&&<T numberOfLines={1} style={{fontSize:11.5,color:C.muted,marginTop:2}}>{subtitle}</T>}
     </View>
     <Button quiet compact icon="close" onPress={onClose}>Close</Button>
    </View>
    <ScrollView ref={scrollRef} keyboardShouldPersistTaps="handled" contentContainerStyle={{paddingHorizontal:15,paddingTop:12,paddingBottom:footer?76:30}}>{children}</ScrollView>
    {footer&&<View style={{paddingHorizontal:15,paddingVertical:10,borderTopWidth:1,borderColor:C.line,backgroundColor:'white'}}>{footer}</View>}
   </View>
  </KeyboardAvoidingView>
 </Modal>;
}

export const s=StyleSheet.create({
 text:{fontFamily:Platform.OS==='web'?'"Segoe UI", Inter, -apple-system, sans-serif':undefined,fontSize:13.5,color:C.ink},
 title:{fontSize:20,fontWeight:'700',letterSpacing:-.3,lineHeight:26,color:C.ink},
 h2:{fontSize:16,fontWeight:'600',letterSpacing:-.2,lineHeight:22,color:C.ink},
 h3:{fontSize:14.5,fontWeight:'600',lineHeight:20,color:C.ink},
 eyebrow:{fontSize:10.5,fontWeight:'700',letterSpacing:.7,color:C.muted,marginBottom:3,textTransform:'uppercase'},
 label:{fontSize:11.5,fontWeight:'600',color:'#475569',marginBottom:4,lineHeight:16},
 row:{flexDirection:'row',alignItems:'center',gap:8,flexWrap:'wrap'},
 field:{marginBottom:11,width:'100%',minWidth:0},
 card:{borderRadius:12,borderWidth:1,borderColor:C.line,backgroundColor:'white',padding:13,shadowColor:'#0F172A',shadowOffset:{width:0,height:1},shadowOpacity:.03,shadowRadius:4,elevation:1},
 button:{minHeight:42,minWidth:42,paddingHorizontal:13,paddingVertical:8,backgroundColor:C.blue,borderRadius:8,flexDirection:'row',justifyContent:'center',alignItems:'center',gap:6,...(Platform.OS==='web'?{outlineStyle:'none'}:{})},
 buttonText:{fontSize:13.5,fontWeight:'600',lineHeight:19},
 secondary:{backgroundColor:'white',borderWidth:1,borderColor:'#CBD5E1'},
 quiet:{backgroundColor:'transparent',paddingHorizontal:6},
 inputWrap:{borderWidth:1,borderColor:'#CBD5E1',borderRadius:8,backgroundColor:'white',flexDirection:'row',alignItems:'center',minHeight:42},
 input:{flex:1,minWidth:0,paddingHorizontal:11,paddingVertical:8,fontSize:14,color:C.ink,...(Platform.OS==='web'?{outlineStyle:'none'}:{})},
 iconBox:{width:36,height:36,borderRadius:9,backgroundColor:'#EFF6FF',alignItems:'center',justifyContent:'center'},
 overlay:{flex:1,backgroundColor:'rgba(15,23,42,.45)',justifyContent:Platform.OS==='web'?'center':'flex-end',alignItems:'center',paddingTop:8},
 sheet:{backgroundColor:'white',borderRadius:16,maxHeight:'96%',overflow:'hidden'},
 divider:{height:1,backgroundColor:C.line,marginVertical:12},
 tableHead:{paddingVertical:8,borderBottomWidth:1,borderColor:C.line,flexDirection:'row',gap:8},
 tableRow:{flexWrap:'wrap',paddingVertical:9,borderBottomWidth:1,borderColor:'#F1F5F9',flexDirection:'row',gap:8,alignItems:'center'},
 muted:{color:C.muted,fontSize:12.5,lineHeight:17},
 link:{color:C.blue,fontWeight:'600'},
 sectionGap:{marginTop:14}
});

